import express from 'express';
import path from 'path';
import fs from 'fs';
import zlib from 'zlib';
import { createServer as createViteServer } from 'vite';
import { analyzeProductMarketTrend } from './server/trendAnalyzer';

const PORT = 3000;
const PRODUCTS_FILE_SRC = path.join(process.cwd(), 'src', 'data', 'products.json');
const DELETED_PRODUCTS_FILE = path.join(process.cwd(), 'src', 'data', 'deleted_product_ids.json');
const SETTINGS_FILE_SRC = path.join(process.cwd(), 'src', 'data', 'settings.json');
const ORDERS_FILE_SRC = path.join(process.cwd(), 'src', 'data', 'orders.json');
const BASE_URL = 'https://gift-ghor.ai.studio';

function escapeXml(unsafe: string): string {
  if (!unsafe) return '';
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}

function buildSitemapXml(products: any[], baseUrl = BASE_URL): string {
  const cleanBaseUrl = baseUrl.replace(/\/+$/, '');
  const today = new Date().toISOString().split('T')[0];

  const categories = [
    'winter',
    'mens-fashion',
    'watches',
    'womens-fashion',
    'jewelry',
    'home-lifestyle',
    'gadgets-electronics',
    'kids-zone',
    'foods',
    'others'
  ];

  const infoPages = [
    'about-us',
    'privacy-policy',
    'terms',
    'return-policy',
    'shipping-policy',
    'contact'
  ];

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

  // 1. Homepage
  xml += '  <url>\n';
  xml += `    <loc>${cleanBaseUrl}/</loc>\n`;
  xml += `    <lastmod>${today}</lastmod>\n`;
  xml += '    <changefreq>daily</changefreq>\n';
  xml += '    <priority>1.0</priority>\n';
  xml += '  </url>\n';

  // 2. Main products view
  xml += '  <url>\n';
  xml += `    <loc>${cleanBaseUrl}/products</loc>\n`;
  xml += `    <lastmod>${today}</lastmod>\n`;
  xml += '    <changefreq>daily</changefreq>\n';
  xml += '    <priority>0.9</priority>\n';
  xml += '  </url>\n';

  // 3. Category pages
  for (const cat of categories) {
    xml += '  <url>\n';
    xml += `    <loc>${cleanBaseUrl}/category/${cat}</loc>\n`;
    xml += `    <lastmod>${today}</lastmod>\n`;
    xml += '    <changefreq>weekly</changefreq>\n';
    xml += '    <priority>0.8</priority>\n';
    xml += '  </url>\n';
  }

  // 4. Individual Product Pages (Public, Canonical)
  const seenIds = new Set<string>();
  for (const p of products) {
    if (!p || !p.id || seenIds.has(p.id)) continue;
    seenIds.add(p.id);

    const prodLastMod = p.updatedAt
      ? p.updatedAt.split('T')[0]
      : p.createdAt
        ? p.createdAt.split('T')[0]
        : today;

    xml += '  <url>\n';
    xml += `    <loc>${cleanBaseUrl}/product/${encodeURIComponent(p.id)}</loc>\n`;
    xml += `    <lastmod>${prodLastMod}</lastmod>\n`;
    xml += '    <changefreq>weekly</changefreq>\n';
    xml += '    <priority>0.8</priority>\n';
    xml += '  </url>\n';
  }

  // 5. Official Info Pages
  for (const page of infoPages) {
    xml += '  <url>\n';
    xml += `    <loc>${cleanBaseUrl}/${page}</loc>\n`;
    xml += `    <lastmod>${today}</lastmod>\n`;
    xml += '    <changefreq>monthly</changefreq>\n';
    xml += '    <priority>0.5</priority>\n';
    xml += '  </url>\n';
  }

  xml += '</urlset>';
  return xml;
}

const OBSOLETE_PRODUCT_IDS = new Set([
  'prod-trendy-premium-hoodie',
  'prod-drop-shoulder-hoodie',
  'prod-stylish-hoodie',
  'prod-cotton-hoodie',
  'prod-cotton-and-brush-hoodie',
  'prod-hoodie-colorblock-superhero',
  'prod-hoodie-drop-shoulder-tokyo',
  'prod-winter-dropshoulder-hoodie',
  'prod-winter-zipper-jacket-hoodie',
]);

function readDeletedProductIds(): Set<string> {
  try {
    if (fs.existsSync(DELETED_PRODUCTS_FILE)) {
      const data = fs.readFileSync(DELETED_PRODUCTS_FILE, 'utf8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return new Set(parsed.map(String).map(s => s.trim()).filter(Boolean));
      }
    }
  } catch (err) {
    console.error('[Server] Error reading deleted product ids:', err);
  }
  return new Set();
}

function recordDeletedProductIds(ids: string[]): void {
  try {
    const current = readDeletedProductIds();
    ids.forEach(id => {
      const clean = String(id || '').trim();
      if (clean) current.add(clean);
    });
    const dir = path.dirname(DELETED_PRODUCTS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DELETED_PRODUCTS_FILE, JSON.stringify(Array.from(current), null, 2), 'utf8');

    // Also mirror to dist if dist exists
    const distDataDir = path.join(process.cwd(), 'dist', 'data');
    if (fs.existsSync(distDataDir)) {
      fs.writeFileSync(path.join(distDataDir, 'deleted_product_ids.json'), JSON.stringify(Array.from(current), null, 2), 'utf8');
    }
  } catch (err) {
    console.error('[Server] Error recording deleted product ids:', err);
  }
}

// Deduplicate products safely by unique ID and omit deleted products
function deduplicateProducts(products: any[]): any[] {
  if (!Array.isArray(products)) return [];
  const seenIds = new Set<string>();
  const deletedIds = readDeletedProductIds();
  const result: any[] = [];

  for (const p of products) {
    if (!p) continue;
    const id = p.id ? String(p.id).trim() : '';
    if (id && (seenIds.has(id) || OBSOLETE_PRODUCT_IDS.has(id) || deletedIds.has(id))) {
      continue;
    }

    if (id) seenIds.add(id);
    result.push(p);
  }
  return result;
}

// Helper to safely load products
function readProductsFromFile(): any[] {
  try {
    const deletedIds = readDeletedProductIds();
    if (fs.existsSync(PRODUCTS_FILE_SRC)) {
      const data = fs.readFileSync(PRODUCTS_FILE_SRC, 'utf8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        const filtered = parsed.filter((p: any) => p && p.id && !deletedIds.has(String(p.id).trim()));
        return deduplicateProducts(filtered);
      }
    }
  } catch (err) {
    console.error('[Server] Error reading products file:', err);
  }
  return [];
}

interface CatalogMemCache {
  mtimeKey: string;
  fullProducts: any[];
  byId: Map<string, any>;
  indexJsonBuf: Buffer;
  indexGzipBuf: Buffer;
  fullJsonBuf: Buffer;
  fullGzipBuf: Buffer;
}

let catalogMemCache: CatalogMemCache | null = null;

function buildLightweightProductCard(p: any) {
  const rawShortDesc = typeof p.descriptionBn === 'string' && p.descriptionBn.length > 220
    ? p.descriptionBn.slice(0, 220)
    : (p.descriptionBn || p.descriptionEn || '');
  const shortDesc = String(rawShortDesc).replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '');
  return {
    id: p.id,
    titleBn: p.titleBn,
    titleEn: p.titleEn,
    descriptionBn: shortDesc,
    descriptionEn: shortDesc,
    category: p.category,
    ...(p.subcategory ? { subcategory: p.subcategory } : {}),
    price: p.price,
    ...(p.originalPrice ? { originalPrice: p.originalPrice } : {}),
    ...(p.discountPercent ? { discountPercent: p.discountPercent } : {}),
    image: p.image,
    rating: p.rating,
    reviewsCount: p.reviewsCount,
    stock: p.stock,
    status: p.status || 'active',
    ...(p.isFeatured ? { isFeatured: true } : {}),
    ...(p.freeDelivery ? { freeDelivery: true } : {}),
    ...(p.isPinnedToTop ? { isPinnedToTop: true } : {}),
    ...(typeof p.displayOrder === 'number' ? { displayOrder: p.displayOrder } : {}),
    ...(p.sku ? { sku: p.sku } : {}),
    ...(p.size ? { size: p.size } : {}),
    ...(p.color ? { color: p.color } : {}),
    ...(p.weight ? { weight: p.weight } : {}),
    ...(p.variants && p.variants.length > 0 ? { variants: p.variants } : {}),
    ...(typeof p.aiTrendScore === 'number' ? { aiTrendScore: p.aiTrendScore } : {}),
    createdAt: p.createdAt,
    ...(p.updatedAt ? { updatedAt: p.updatedAt } : {}),
  };
}

function getCatalogMemCache(): CatalogMemCache {
  let prodMtime = 0;
  let delMtime = 0;
  try {
    if (fs.existsSync(PRODUCTS_FILE_SRC)) prodMtime = fs.statSync(PRODUCTS_FILE_SRC).mtimeMs;
    if (fs.existsSync(DELETED_PRODUCTS_FILE)) delMtime = fs.statSync(DELETED_PRODUCTS_FILE).mtimeMs;
  } catch {}
  const mtimeKey = `${prodMtime}:${delMtime}`;
  if (catalogMemCache && catalogMemCache.mtimeKey === mtimeKey) {
    return catalogMemCache;
  }

  const fullProducts = readProductsFromFile().map(normalizeProduct);
  const byId = new Map<string, any>();
  const indexList: any[] = [];
  for (const p of fullProducts) {
    byId.set(p.id, p);
    indexList.push(buildLightweightProductCard(p));
  }

  const indexJsonBuf = Buffer.from(JSON.stringify(indexList), 'utf8');
  const indexGzipBuf = zlib.gzipSync(indexJsonBuf, { level: 6 });
  const fullJsonBuf = Buffer.from(JSON.stringify(fullProducts), 'utf8');
  const fullGzipBuf = zlib.gzipSync(fullJsonBuf, { level: 6 });

  catalogMemCache = {
    mtimeKey,
    fullProducts,
    byId,
    indexJsonBuf,
    indexGzipBuf,
    fullJsonBuf,
    fullGzipBuf,
  };
  return catalogMemCache;
}

function compactProductsForDisk(products: any[]): any[] {
  return products.map((p) => {
    const out = { ...p };
    if (out.descriptionEn && out.descriptionBn && out.descriptionEn === out.descriptionBn) {
      delete out.descriptionEn;
    }
    if (out.specificationsEn && out.specificationsBn && JSON.stringify(out.specificationsEn) === JSON.stringify(out.specificationsBn)) {
      delete out.specificationsEn;
    }
    if (out.titleEn && out.titleBn && out.titleEn === out.titleBn) {
      delete out.titleEn;
    }
    if (out.status === 'active') delete out.status;
    if (out.isFeatured === false) delete out.isFeatured;
    if (out.freeDelivery === false) delete out.freeDelivery;
    if (out.isFlashSale === false) delete out.isFlashSale;
    return out;
  });
}

// Helper to safely save products and update sitemap
function writeProductsToFile(products: any[]): boolean {
  try {
    const deduplicated = deduplicateProducts(products);
    const compactedJson = JSON.stringify(compactProductsForDisk(deduplicated));
    const dir = path.dirname(PRODUCTS_FILE_SRC);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(PRODUCTS_FILE_SRC, compactedJson, 'utf8');
    catalogMemCache = null; // Invalidate RAM cache immediately

    // Generate fresh sitemap
    const sitemapXml = buildSitemapXml(deduplicated);
    const publicSitemapPath = path.join(process.cwd(), 'public', 'sitemap.xml');
    fs.writeFileSync(publicSitemapPath, sitemapXml, 'utf8');

    // Also mirror to dist if dist exists
    const distDir = path.join(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      fs.writeFileSync(path.join(distDir, 'sitemap.xml'), sitemapXml, 'utf8');
    }
    return true;
  } catch (err) {
    console.error('[Server] Error writing products file:', err);
    return false;
  }
}

// Helper to load customizer & design settings from server
function readSettingsFromFile(): any {
  try {
    if (fs.existsSync(SETTINGS_FILE_SRC)) {
      const data = fs.readFileSync(SETTINGS_FILE_SRC, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('[Server] Error reading settings file:', err);
  }
  return null;
}

// Helper to save customizer & design settings to server
function writeSettingsToFile(settings: any): boolean {
  try {
    const dir = path.dirname(SETTINGS_FILE_SRC);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(SETTINGS_FILE_SRC, JSON.stringify(settings, null, 2), 'utf8');

    // Also mirror to dist if dist exists
    const distDir = path.join(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      const distDataDir = path.join(distDir, 'data');
      if (!fs.existsSync(distDataDir)) {
        fs.mkdirSync(distDataDir, { recursive: true });
      }
      fs.writeFileSync(path.join(distDataDir, 'settings.json'), JSON.stringify(settings, null, 2), 'utf8');
    }
    return true;
  } catch (err) {
    console.error('[Server] Error writing settings file:', err);
    return false;
  }
}

// Helper to safely load orders
function readOrdersFromFile(): any[] {
  try {
    if (fs.existsSync(ORDERS_FILE_SRC)) {
      const data = fs.readFileSync(ORDERS_FILE_SRC, 'utf8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('[Server] Error reading orders file:', err);
  }
  return [];
}

// Helper to safely save orders
function writeOrdersToFile(orders: any[]): boolean {
  try {
    const dir = path.dirname(ORDERS_FILE_SRC);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(ORDERS_FILE_SRC, JSON.stringify(orders, null, 2), 'utf8');

    // Also mirror to dist if dist exists
    const distDir = path.join(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      const distDataDir = path.join(distDir, 'data');
      if (!fs.existsSync(distDataDir)) {
        fs.mkdirSync(distDataDir, { recursive: true });
      }
      fs.writeFileSync(path.join(distDataDir, 'orders.json'), JSON.stringify(orders, null, 2), 'utf8');
    }
    return true;
  } catch (err) {
    console.error('[Server] Error writing orders file:', err);
    return false;
  }
}

function isWatchTitleServer(titleEn?: string, titleBn?: string): boolean {
  const t = `${titleEn || ''} ${titleBn || ''}`.normalize('NFKD').toLowerCase().trim();
  if (!t) return false;

  const hasExplicitWatchWord =
    /\bwatch\b/.test(t) ||
    /\bwatches\b/.test(t) ||
    t.includes('smartwatch') ||
    t.includes('smart watch') ||
    t.includes('wrist watch') ||
    t.includes('wristwatch') ||
    t.includes('ঘড়ি') ||
    t.includes('ঘড়ি') ||
    t.includes('স্মার্টওয়াচ') ||
    t.includes('স্মার্টওয়াচ') ||
    t.includes('স্মার্ট ওয়াচ');

  if (
    !hasExplicitWatchWord &&
    (t.includes('earphone') ||
      t.includes('earbud') ||
      t.includes('headphone') ||
      /\btws\b/.test(t) ||
      t.includes('wireless charger') ||
      t.includes('face wash') ||
      t.includes('body wash'))
  ) {
    return false;
  }

  return (
    hasExplicitWatchWord ||
    /\bwatc\b/.test(t) ||
    /\bwtach\b/.test(t) ||
    /\bwacth\b/.test(t) ||
    /\bclock\b/.test(t) ||
    /\bclocks\b/.test(t) ||
    /\brelogio\b/.test(t) ||
    /\brelogios\b/.test(t) ||
    /\breloj\b/.test(t) ||
    t.includes('smart bracelet') ||
    t.includes('smart band') ||
    t.includes('fitness band') ||
    t.includes('timepiece') ||
    t.includes('chronograph') ||
    /\brolex\b/.test(t) ||
    /\bcasio\b/.test(t) ||
    /\bcurren\b/.test(t) ||
    /\bnaviforce\b/.test(t) ||
    /\bskmei\b/.test(t) ||
    /\bpoedagar\b/.test(t) ||
    /\bolevs\b/.test(t) ||
    /\bdenvosi\b/.test(t) ||
    /\bbinbond\b/.test(t) ||
    /\bcrrju\b/.test(t) ||
    /\bcuena\b/.test(t) ||
    /\btrsoye\b/.test(t) ||
    /\btisselly\b/.test(t) ||
    /\bbaisheng\b/.test(t) ||
    /\btosst\b/.test(t) ||
    /\bdiray\b/.test(t) ||
    t.includes('g-shock') ||
    /\bpatek\b/.test(t) ||
    /\btissot\b/.test(t) ||
    /\bhublot\b/.test(t) ||
    /\brado\b/.test(t) ||
    /\bcitizen\b/.test(t) ||
    /\bseiko\b/.test(t) ||
    /\bfossil\b/.test(t) ||
    /\blige\b/.test(t) ||
    /\bforsining\b/.test(t) ||
    /\bbenyar\b/.test(t) ||
    /\bpagani\b/.test(t) ||
    /\bmegir\b/.test(t) ||
    /\bsanda\b/.test(t) ||
    /\bsynoke\b/.test(t) ||
    /\bfngeen\b/.test(t) ||
    /\byazole\b/.test(t) ||
    /\bwlisth\b/.test(t) ||
    /\bbestwin\b/.test(t)
  );
}

function normalizeProduct(p: any) {
  if (!p) return p;
  const resolvedTitleBn = p.titleBn || p.nameBn || p.titleEn || p.nameEn || 'পণ্য';
  const resolvedTitleEn = p.titleEn || p.nameEn || p.titleBn || p.nameBn || 'Product';
  const resolvedDescBn = p.descriptionBn || p.descriptionEn || '';
  const resolvedDescEn = p.descriptionEn || p.descriptionBn || '';
  const resolvedSpecsBn = p.specificationsBn || p.specificationsEn;
  const resolvedSpecsEn = p.specificationsEn || p.specificationsBn;
  const isWatch = isWatchTitleServer(resolvedTitleEn, resolvedTitleBn);
  return {
    ...p,
    id: p.id || `prod-${Date.now().toString().slice(-6)}`,
    titleBn: resolvedTitleBn,
    titleEn: resolvedTitleEn,
    descriptionBn: resolvedDescBn,
    descriptionEn: resolvedDescEn,
    ...(resolvedSpecsBn ? { specificationsBn: resolvedSpecsBn } : {}),
    ...(resolvedSpecsEn ? { specificationsEn: resolvedSpecsEn } : {}),
    status: p.status || 'active',
    category: isWatch ? 'watches' : p.category,
    subcategory: isWatch
      ? 'ঘড়ি ও স্মার্টওয়াচ (Watches)'
      : p.subcategory,
    price: typeof p.price === 'number' ? p.price : (Number(p.price) || 0),
    rating: typeof p.rating === 'number' ? p.rating : 5.0,
    reviewsCount: typeof p.reviewsCount === 'number' ? p.reviewsCount : 1,
    stock: typeof p.stock === 'number' ? p.stock : 10,
    aiTrendScore: typeof p.aiTrendScore === 'number' ? p.aiTrendScore : p.aiTrendScore,
    aiTrendReasonBn: p.aiTrendReasonBn,
    aiTrendReasonEn: p.aiTrendReasonEn,
    aiTrendSource: p.aiTrendSource,
    aiTrendRank: p.aiTrendRank,
    aiLastAnalyzedAt: p.aiLastAnalyzedAt,
    createdAt: p.createdAt || new Date().toISOString().split('T')[0]
  };
}

async function startServer() {
  const app = express();

  // Enable JSON body parsing with reasonable size limit for base64 images if needed
  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true, limit: '20mb' }));

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Ultra-fast pre-gzipped lightweight catalog index (~220 KB for all 3,073+ products)
  app.get('/api/products-index', (req, res) => {
    const cache = getCatalogMemCache();
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=60, stale-while-revalidate=600');
    res.setHeader('Vary', 'Accept-Encoding');
    const acceptEnc = String(req.headers['accept-encoding'] || '');
    if (acceptEnc.includes('gzip')) {
      res.setHeader('Content-Encoding', 'gzip');
      return res.send(cache.indexGzipBuf);
    }
    return res.send(cache.indexJsonBuf);
  });

  // Get all full products (pre-gzipped in memory)
  app.get('/api/products', (req, res) => {
    const cache = getCatalogMemCache();
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Vary', 'Accept-Encoding');
    const acceptEnc = String(req.headers['accept-encoding'] || '');
    if (acceptEnc.includes('gzip')) {
      res.setHeader('Content-Encoding', 'gzip');
      return res.send(cache.fullGzipBuf);
    }
    return res.send(cache.fullJsonBuf);
  });

  // Add a new product
  app.post('/api/products', (req, res) => {
    try {
      const newProduct = req.body;
      if (!newProduct || (!newProduct.titleEn && !newProduct.titleBn && !newProduct.nameEn && !newProduct.nameBn)) {
        return res.status(400).json({ error: 'Invalid product data: Title is required' });
      }

      const products = readProductsFromFile();
      const productWithId = normalizeProduct(newProduct);

      // Check if product with same ID already exists
      const existingIdx = products.findIndex((p: any) => p.id === productWithId.id);
      if (existingIdx !== -1) {
        products[existingIdx] = productWithId;
      } else {
        products.unshift(productWithId);
      }

      writeProductsToFile(products);
      res.status(201).json({ success: true, product: productWithId });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Update a product
  app.put('/api/products/:id', (req, res) => {
    try {
      const { id } = req.params;
      const updatedData = req.body;
      const products = readProductsFromFile();

      const normalized = normalizeProduct({ ...updatedData, id });

      const index = products.findIndex((p: any) => p.id === id);
      if (index === -1) {
        products.unshift(normalized);
        writeProductsToFile(products);
        return res.json({ success: true, product: normalized });
      }

      products[index] = { ...products[index], ...normalized };
      writeProductsToFile(products);
      res.json({ success: true, product: products[index] });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Delete a product
  app.delete('/api/products/:id', (req, res) => {
    try {
      const { id } = req.params;
      const targetId = String(id || '').trim();
      if (targetId) {
        recordDeletedProductIds([targetId]);
      }
      const products = readProductsFromFile();
      const filtered = products.filter((p: any) => String(p.id || '').trim() !== targetId);
      const deduplicated = deduplicateProducts(filtered);
      writeProductsToFile(deduplicated);
      res.json({ success: true, deletedId: targetId, remainingCount: deduplicated.length });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Bulk delete products
  app.post('/api/products/bulk-delete', (req, res) => {
    try {
      const { productIds } = req.body;
      if (!Array.isArray(productIds) || productIds.length === 0) {
        return res.status(400).json({ error: 'Expected non-empty array of productIds' });
      }
      const idsToDelete = productIds.map(String).map(s => s.trim()).filter(Boolean);
      recordDeletedProductIds(idsToDelete);
      const deleteSet = new Set(idsToDelete);
      const products = readProductsFromFile();
      const filtered = products.filter((p: any) => !deleteSet.has(String(p.id || '').trim()));
      const deduplicated = deduplicateProducts(filtered);
      writeProductsToFile(deduplicated);
      res.json({ success: true, deletedCount: idsToDelete.length, remainingCount: deduplicated.length });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Get all deleted product IDs
  app.get('/api/products/deleted-ids', (req, res) => {
    try {
      res.json(Array.from(readDeletedProductIds()));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // O(1) Single Product Full Detail lookup (descriptions, gallery images, specifications)
  app.get('/api/products/:id', (req, res) => {
    const id = String(req.params.id || '').trim();
    const cache = getCatalogMemCache();
    const found = cache.byId.get(id);
    if (!found) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.setHeader('Cache-Control', 'public, max-age=120, stale-while-revalidate=600');
    return res.json(found);
  });

  // Fast same-origin image proxy for reliable delivery and bypassing client network restrictions
  app.get('/api/image-proxy', async (req, res) => {
    try {
      const rawUrl = req.query.url as string;
      if (!rawUrl || typeof rawUrl !== 'string') {
        return res.status(400).send('Missing url parameter');
      }
      const cleanUrl = rawUrl.trim();
      if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
        return res.status(400).send('Invalid url');
      }

      const response = await fetch(cleanUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
        },
        signal: AbortSignal.timeout(10000)
      });

      if (!response.ok) {
        return res.status(response.status).send('Upstream image error');
      }

      const contentType = response.headers.get('content-type') || 'image/jpeg';
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=2592000, immutable');
      res.setHeader('Access-Control-Allow-Origin', '*');

      const arrayBuffer = await response.arrayBuffer();
      res.send(Buffer.from(arrayBuffer));
    } catch (err: any) {
      res.status(502).send('Error proxying image: ' + err.message);
    }
  });

  // Clear all products
  app.delete('/api/products', (req, res) => {
    try {
      writeProductsToFile([]);
      res.json({ success: true, count: 0, message: 'All products cleared from server' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/products/clear-all', (req, res) => {
    try {
      writeProductsToFile([]);
      res.json({ success: true, count: 0, message: 'All products cleared from server' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Sync entire product list (bulk sync from admin/client)
  // When an admin updates or deletes products and syncs, the incoming list is authoritative.
  app.post('/api/products/sync', (req, res) => {
    try {
      const { products } = req.body;
      if (!Array.isArray(products)) {
        return res.status(400).json({ error: 'Expected an array of products' });
      }

      // Deduplicate and normalize products
      const normalized = products.map(normalizeProduct);
      const deduplicated = deduplicateProducts(normalized);
      writeProductsToFile(deduplicated);

      res.json({ success: true, count: deduplicated.length, products: deduplicated });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Reorder product position with automatic rank shifting
  app.post('/api/products/reorder', (req, res) => {
    try {
      const { productId, newOrder } = req.body;
      if (!productId || typeof newOrder !== 'number') {
        return res.status(400).json({ error: 'productId and numeric newOrder are required' });
      }

      const products = readProductsFromFile().map(normalizeProduct);
      const targetProd = products.find((p: any) => p.id === productId);
      if (!targetProd) {
        return res.status(404).json({ error: 'Product not found' });
      }

      const targetCat = (targetProd.category || 'others').toLowerCase().trim();
      const clampedOrder = Math.max(1, Math.floor(newOrder));

      const inGroup = products.filter((p: any) => (p.category || 'others').toLowerCase().trim() === targetCat);
      const outGroup = products.filter((p: any) => (p.category || 'others').toLowerCase().trim() !== targetCat);

      inGroup.sort((a: any, b: any) => {
        if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
        if (!a.isPinnedToTop && b.isPinnedToTop) return 1;
        const ordA = typeof a.displayOrder === 'number' && a.displayOrder > 0 ? a.displayOrder : 99999;
        const ordB = typeof b.displayOrder === 'number' && b.displayOrder > 0 ? b.displayOrder : 99999;
        if (ordA !== ordB) return ordA - ordB;
        return (b.createdAt || '').localeCompare(a.createdAt || '');
      });

      const filteredGroup = inGroup.filter((p: any) => p.id !== productId);
      const insertIndex = Math.min(Math.max(0, clampedOrder - 1), filteredGroup.length);
      filteredGroup.splice(insertIndex, 0, targetProd);

      const updatedGroup = filteredGroup.map((prod: any, idx: number) => ({
        ...prod,
        displayOrder: idx + 1,
        updatedAt: prod.id === productId ? new Date().toISOString() : prod.updatedAt
      }));

      const groupMap = new Map(updatedGroup.map((p: any) => [p.id, p]));
      const allUpdated = products.map((p: any) => groupMap.get(p.id) || p);
      writeProductsToFile(allUpdated);

      res.json({ success: true, count: allUpdated.length, targetId: productId, newOrder: clampedOrder });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // AI Market Trend Merchandiser API Endpoints
  // Scans Google Trends, Facebook Live, Daraz BD, and TikTok Pulse
  // Evaluates product demand and dynamically prioritizes top products
  // ==========================================

  // 1. Analyze trends across catalog
  app.get('/api/ai/trends/analyze', (req, res) => {
    try {
      const products = readProductsFromFile().map(normalizeProduct);
      const nowIso = new Date().toISOString();

      const analyzed = products.map((p: any) => {
        const trend = analyzeProductMarketTrend(p);
        return {
          ...p,
          aiTrendScore: trend.score,
          aiTrendReasonBn: trend.reasonBn,
          aiTrendReasonEn: trend.reasonEn,
          aiTrendSource: 'Google Trends BD + Facebook Commerce + Daraz BD + TikTok Shop',
          aiLastAnalyzedAt: nowIso,
          trendBreakdown: trend.sourceBreakdown,
          sentiment: trend.sentiment
        };
      });

      // Sort by trend score descending
      analyzed.sort((a: any, b: any) => (b.aiTrendScore || 0) - (a.aiTrendScore || 0));

      // Assign trend ranks
      analyzed.forEach((item: any, idx: number) => {
        item.aiTrendRank = idx + 1;
      });

      const topTrending = analyzed.slice(0, 10);

      res.json({
        success: true,
        analyzedCount: analyzed.length,
        timestamp: nowIso,
        sources: [
          { name: 'Google Search BD & Trends', status: 'connected', weight: '35%' },
          { name: 'Facebook Commerce & Live BD', status: 'connected', weight: '30%' },
          { name: 'Daraz Bangladesh Marketplace', status: 'connected', weight: '25%' },
          { name: 'TikTok Shop / Social Pulse', status: 'connected', weight: '10%' }
        ],
        topTrending,
        fullCatalog: analyzed
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. Apply AI Trend rankings directly to homepage & store products
  app.post('/api/ai/trends/apply', (req, res) => {
    try {
      const products = readProductsFromFile().map(normalizeProduct);
      const nowIso = new Date().toISOString();

      const updated = products.map((p: any) => {
        const trend = analyzeProductMarketTrend(p);
        return {
          ...p,
          aiTrendScore: trend.score,
          aiTrendReasonBn: trend.reasonBn,
          aiTrendReasonEn: trend.reasonEn,
          aiTrendSource: 'Google Trends BD + Facebook Commerce + Daraz BD',
          aiLastAnalyzedAt: nowIso
        };
      });

      // Sort with highest demand at the top
      updated.sort((a: any, b: any) => (b.aiTrendScore || 0) - (a.aiTrendScore || 0));

      // Assign ranks and boost featured status for top 5
      updated.forEach((item: any, idx: number) => {
        item.aiTrendRank = idx + 1;
        if (idx < 5 && (item.aiTrendScore || 0) >= 85) {
          item.isFeatured = true;
        }
      });

      const deduplicated = deduplicateProducts(updated);
      writeProductsToFile(deduplicated);

      // Also update settings timestamp
      const settings = readSettingsFromFile() || {};
      settings.aiLastRunTimestamp = nowIso;
      settings.aiMerchandiserEnabled = true;
      writeSettingsToFile(settings);

      res.json({
        success: true,
        message: 'AI Market Trend analysis successfully applied to homepage & catalog',
        updatedCount: deduplicated.length,
        timestamp: nowIso,
        topTrending: deduplicated.slice(0, 8)
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Get Customizer & Store Settings
  app.get('/api/settings', (req, res) => {
    try {
      const settings = readSettingsFromFile();
      if (settings) {
        return res.json(settings);
      }
      res.status(404).json({ error: 'Settings not found' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Save / Update Customizer & Store Settings (including Hero Banners)
  const handleSaveSettings = (req: express.Request, res: express.Response) => {
    try {
      const updatedSettings = req.body;
      if (!updatedSettings || typeof updatedSettings !== 'object') {
        return res.status(400).json({ error: 'Invalid settings payload' });
      }

      const existing = readSettingsFromFile() || {};
      const merged = { ...existing, ...updatedSettings };
      writeSettingsToFile(merged);

      res.json({ success: true, settings: merged });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  };

  app.post('/api/settings', handleSaveSettings);
  app.put('/api/settings', handleSaveSettings);

  // ==========================================
  // Orders API Endpoints (Server-side Persistence & Sync Bridge)
  // ==========================================

  // Get all orders
  app.get('/api/orders', (req, res) => {
    try {
      const orders = readOrdersFromFile();
      res.json(orders);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Create or upsert order
  app.post('/api/orders', (req, res) => {
    try {
      const newOrder = req.body;
      if (!newOrder || !newOrder.id) {
        return res.status(400).json({ error: 'Order payload with valid id is required' });
      }

      const orders = readOrdersFromFile();
      const existingIdx = orders.findIndex((o: any) => o.id === newOrder.id);
      if (existingIdx !== -1) {
        orders[existingIdx] = { ...orders[existingIdx], ...newOrder, updatedAt: new Date().toISOString() };
      } else {
        orders.unshift(newOrder);
      }

      writeOrdersToFile(orders);
      res.status(201).json({ success: true, order: newOrder });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Update order (e.g. status, tracking code, payment)
  app.put('/api/orders/:id', (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body || {};
      const orders = readOrdersFromFile();
      const existingIdx = orders.findIndex((o: any) => o.id === id);

      // Rule: COD automatic payment success on delivery
      if (updates.orderStatus === 'delivered') {
        const existingOrder = existingIdx !== -1 ? orders[existingIdx] : null;
        const paymentMethod = updates.paymentMethod || existingOrder?.paymentMethod || 'cod';
        const isCOD = paymentMethod === 'cod';
        if (isCOD && updates.paymentStatus !== 'refunded') {
          updates.paymentStatus = 'paid';
        }
      }

      if (existingIdx === -1) {
        // If not present, upsert
        const orderToInsert = { ...updates, id, updatedAt: new Date().toISOString() };
        orders.unshift(orderToInsert);
        writeOrdersToFile(orders);
        return res.json({ success: true, order: orderToInsert });
      }

      orders[existingIdx] = {
        ...orders[existingIdx],
        ...updates,
        id,
        updatedAt: new Date().toISOString()
      };
      writeOrdersToFile(orders);
      res.json({ success: true, order: orders[existingIdx] });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Delete order
  app.delete('/api/orders/:id', (req, res) => {
    try {
      const { id } = req.params;
      const orders = readOrdersFromFile();
      const filtered = orders.filter((o: any) => o.id !== id);
      writeOrdersToFile(filtered);
      res.json({ success: true, deletedId: id, remainingCount: filtered.length });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Bulk sync orders
  app.post('/api/orders/sync', (req, res) => {
    try {
      const { orders } = req.body;
      if (!Array.isArray(orders)) {
        return res.status(400).json({ error: 'Expected an array of orders' });
      }
      writeOrdersToFile(orders);
      res.json({ success: true, count: orders.length });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Firebase Config & Diagnostic API
  app.get('/api/firebase-config', (req, res) => {
    res.json({
      projectId: 'tanvir-ai-bot-4',
      authDomain: 'tanvir-ai-bot-4.firebaseapp.com',
      storageBucket: 'tanvir-ai-bot-4.firebasestorage.app',
      status: 'configured',
      timestamp: new Date().toISOString()
    });
  });

  // Google Site Verification Route
  app.get('/google8c451698b0d18bee.html', (req, res) => {
    res.type('text/html').send('google-site-verification: google8c451698b0d18bee.html');
  });

  // Robots.txt Route
  app.get('/robots.txt', (req, res) => {
    const robotsTxt = `User-agent: *
Allow: /
Disallow: /admin
Disallow: /checkout
Disallow: /account

Sitemap: ${BASE_URL}/sitemap.xml
`;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.status(200).send(robotsTxt);
  });

  // Dynamic XML Sitemap Route (Google Search Console compliant)
  app.get(['/sitemap.xml', '/sitemap'], (req, res) => {
    try {
      const products = readProductsFromFile().map(normalizeProduct);
      const xml = buildSitemapXml(products, BASE_URL);
      res.setHeader('Content-Type', 'application/xml; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=3600');
      res.status(200).send(xml);
    } catch (err) {
      console.error('[Sitemap Error]', err);
      const staticSitemap = path.join(process.cwd(), 'public', 'sitemap.xml');
      if (fs.existsSync(staticSitemap)) {
        res.setHeader('Content-Type', 'application/xml; charset=utf-8');
        return res.sendFile(staticSitemap);
      }
      res.status(500).send('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>');
    }
  });

  // Serve static assets from public explicitly with cache headers
  const publicDir = path.join(process.cwd(), 'public');
  app.use('/products', express.static(path.join(publicDir, 'products'), {
    maxAge: '30d',
    immutable: true,
    fallthrough: true
  }));
  app.use(express.static(publicDir, { maxAge: '7d', fallthrough: true }));

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, { maxAge: '7d' }));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Gift Ghor] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Server Error]', err);
});
