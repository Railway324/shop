import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Star, 
  Truck, 
  ShieldCheck, 
  RotateCcw, 
  Plus, 
  Minus,
  CheckCircle,
  Package,
  MessageSquare,
  Sparkles,
  ShoppingBag,
  ArrowRight,
  Share2,
  Check,
  CheckCircle2,
  Calendar,
  Edit3,
  Zap,
  Lock,
  Clock
} from 'lucide-react';
import { Product, Language, ProductReview, UserProfile, Order, ProductVariant } from '../types';
import { translations, formatPrice } from '../utils/translations';
import { getOptimizedImageUrl } from '../utils/imageOptimizer';
import { getProductSizes, getProductColors } from '../utils/variantUtils';

interface ProductDetailPageProps {
  product: Product;
  language: Language;
  onBack: () => void;
  onBuyNow: (product: Product, quantity: number, variant?: { size?: string; color?: string; variant?: ProductVariant }) => void;
  onAddToCart?: (product: Product, quantity: number, variant?: { size?: string; color?: string; variant?: ProductVariant }) => void;
  isInCart?: boolean;
  reviews?: ProductReview[];
  currentUser?: UserProfile | null;
  orders?: Order[];
  onOpenWriteReview?: (product: Product, orderId?: string, existing?: ProductReview | null) => void;
  relatedProducts?: Product[];
  onSelectProduct?: (product: Product) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  language,
  onBack,
  onBuyNow,
  onAddToCart,
  reviews = [],
  currentUser = null,
  orders = [],
  onOpenWriteReview,
  relatedProducts = [],
  onSelectProduct,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(product.image || '');
  const [copiedLink, setCopiedLink] = useState(false);
  const [previewPhotoModal, setPreviewPhotoModal] = useState<string | null>(null);

  // Variant selections: Strictly use ONLY real sizes & colors belonging to this product
  const availableSizes = React.useMemo(() => getProductSizes(product), [product]);
  const availableColors = React.useMemo(() => getProductColors(product), [product]);

  const [selectedSize, setSelectedSize] = useState<string>(
    availableSizes.length === 1 ? availableSizes[0] : ''
  );
  const [selectedColor, setSelectedColor] = useState<string>(
    availableColors.length === 1 ? availableColors[0] : ''
  );
  const [variantError, setVariantError] = useState<string>('');

  // Reset and sync on product change
  useEffect(() => {
    setSelectedImage(product.image || '');
    setQuantity(1);
    setSelectedSize(availableSizes.length === 1 ? availableSizes[0] : '');
    setSelectedColor(availableColors.length === 1 ? availableColors[0] : '');
    setVariantError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [product.id, availableSizes, availableColors]);

  const t = translations[language];

  // Filter reviews for this product
  const productReviews = reviews.filter(
    r => (r.productId === product.id || (!r.productId && (r.productTitle === product.titleBn || r.productTitle === product.titleEn))) && 
         (r.status === 'approved' || (currentUser && r.userEmail === currentUser.email))
  );

  const totalReviewsCount = productReviews.length;
  const baseProductRating = typeof product.rating === 'number' ? product.rating : 5.0;
  const averageRating = totalReviewsCount > 0
    ? (productReviews.reduce((sum, r) => sum + r.rating, 0) / totalReviewsCount).toFixed(1)
    : baseProductRating.toFixed(1);

  const ratingCounts = {
    5: productReviews.filter(r => r.rating === 5).length,
    4: productReviews.filter(r => r.rating === 4).length,
    3: productReviews.filter(r => r.rating === 3).length,
    2: productReviews.filter(r => r.rating === 2).length,
    1: productReviews.filter(r => r.rating === 1).length,
  };

  // Orders check: Only customer who bought this product can review AFTER delivery
  const userOrdersForProduct = orders.filter(o => 
    (
      (currentUser && o.userId === currentUser.uid) ||
      (currentUser?.email && o.userEmail?.toLowerCase() === currentUser.email.toLowerCase()) ||
      (currentUser?.phone && o.phone?.trim() === currentUser.phone.trim())
    ) &&
    o.items.some(item => 
      item.product.id === product.id || 
      item.product.titleEn === product.titleEn || 
      item.product.titleBn === product.titleBn
    )
  );

  const deliveredOrderForProduct = userOrdersForProduct.find(o => o.orderStatus === 'delivered');
  const activeOrderForProduct = userOrdersForProduct.find(o => o.orderStatus !== 'delivered' && o.orderStatus !== 'cancelled');

  const existingUserReview = currentUser ? productReviews.find(
    r => (r.userEmail && r.userEmail.toLowerCase() === currentUser.email?.toLowerCase()) ||
         (r.userId && r.userId === currentUser.uid)
  ) : null;

  const galleryImages = Array.from(new Set([
    product.image,
    ...(product.additionalImages || [])
  ])).filter(Boolean);

  const handleIncrement = () => {
    if (quantity < (product.stock || 99)) {
      setQuantity(q => q + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(q => q - 1);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.titleEn || product.titleBn,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-[#380208] text-white pb-24 md:pb-16 animate-fadeIn">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-4 sm:py-6 space-y-6 sm:space-y-8">
        
        {/* Navigation Breadcrumbs & Back Button */}
        <div className="flex items-center justify-between gap-3">
          <button
            onClick={onBack}
            className="group px-4 py-2 rounded-2xl bg-[#240106] hover:bg-[#3D030C] text-neutral-200 hover:text-white border border-[#6B0B1D] text-xs sm:text-sm font-bold flex items-center gap-2 transition shadow-xs cursor-pointer active:scale-95"
          >
            <ArrowLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-1 transition-transform" />
            <span>← Back to Products</span>
          </button>

          {/* Breadcrumbs */}
          <div className="hidden sm:flex items-center gap-2 text-xs text-neutral-300 font-medium truncate max-w-md">
            <span className="hover:text-white cursor-pointer" onClick={onBack}>
              Home / Products
            </span>
            <span>/</span>
            <span className="text-amber-300 font-semibold capitalize">
              {product.category}
            </span>
            <span>/</span>
            <span className="text-white font-semibold truncate max-w-[180px]">
              {product.titleEn || product.titleBn}
            </span>
          </div>

          {/* Share Button */}
          <button
            onClick={handleShare}
            className="px-3.5 py-1.5 rounded-xl bg-[#240106] hover:bg-[#3D030C] text-neutral-200 hover:text-white border border-[#6B0B1D] text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
          >
            {copiedLink ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-bold">Link Copied!</span>
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5 text-neutral-400" />
                <span>Share</span>
              </>
            )}
          </button>
        </div>

        {/* Main Product Details Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          
          {/* Left Column: Visuals & Thumbnails (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* Primary Large Image */}
            <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-[#240106] border border-[#6B0B1D] shadow-md group">
              <img
                src={getOptimizedImageUrl(selectedImage, 800, 85)}
                alt={product.titleEn || product.titleBn}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                loading="eager"
                decoding="async"
                fetchPriority="high"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  const target = e.currentTarget as HTMLImageElement;
                  const clean = selectedImage ? selectedImage.replace('public//storage', 'public/storage') : '';
                  if (clean && target.src !== clean && !target.src.includes('image-proxy')) {
                    target.src = clean;
                    return;
                  }
                  if (clean && !target.src.includes('image-proxy')) {
                    target.src = `/api/image-proxy?url=${encodeURIComponent(clean)}`;
                    return;
                  }
                }}
              />

              {/* Discount Badge */}
              {product.discountPercent && product.discountPercent > 0 && (
                <div className="absolute top-4 left-4 bg-amber-400 text-neutral-950 font-black text-xs sm:text-sm px-3 py-1.5 rounded-xl shadow-md flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>-{product.discountPercent}% OFF</span>
                </div>
              )}

              {/* Cash On Delivery Seal */}
              <div className="absolute bottom-4 left-4 bg-[#240106]/95 backdrop-blur-md text-neutral-200 border border-[#6B0B1D] text-[11px] font-bold px-3 py-1.5 rounded-xl shadow-sm flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-amber-400" />
                <span>Cash On Delivery Available</span>
              </div>
            </div>

            {/* Thumbnail Carousel */}
            {galleryImages.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-thin">
                {galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(img)}
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 transition shrink-0 cursor-pointer bg-[#240106] ${
                      selectedImage === img 
                        ? 'border-amber-400 ring-2 ring-amber-400/30' 
                        : 'border-[#520510] opacity-80 hover:opacity-100'
                    }`}
                  >
                    <img 
                      src={getOptimizedImageUrl(img, 160, 75)} 
                      alt={`Thumb ${idx + 1}`} 
                      className="w-full h-full object-cover"
                      loading="lazy"
                      decoding="async"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        const target = e.currentTarget as HTMLImageElement;
                        const clean = img ? img.replace('public//storage', 'public/storage') : '';
                        if (clean && target.src !== clean && !target.src.includes('image-proxy')) {
                          target.src = clean;
                          return;
                        }
                        if (clean && !target.src.includes('image-proxy')) {
                          target.src = `/api/image-proxy?url=${encodeURIComponent(clean)}`;
                        }
                      }}
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Trust Assurances */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#240106] border border-[#520510] shadow-xs">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">100% Authentic</h4>
                  <p className="text-[10px] text-neutral-400">Verified Quality</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#240106] border border-[#520510] shadow-xs">
                <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Easy Replacement</h4>
                  <p className="text-[10px] text-neutral-400">Hassle-free return</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Pricing & Quick Checkout (7 cols) */}
          <div className="lg:col-span-7 space-y-5 bg-[#240106] p-5 sm:p-7 rounded-3xl border border-[#5A0617] shadow-md">
            {/* Category & Badge */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                {product.category}
              </span>
              <div className="flex items-center gap-1 text-amber-400 text-xs font-bold bg-[#3B030B] px-2.5 py-1 rounded-full border border-amber-400/30">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{averageRating}</span>
                <span className="text-neutral-400 font-normal">
                  ({productReviews.length || product.reviewsCount || 0} reviews)
                </span>
              </div>
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl font-black text-white leading-snug">
              {product.titleEn || product.titleBn}
            </h1>

            {/* Pricing Card */}
            <div className="p-4 sm:p-5 rounded-2xl bg-[#1C0104] border border-[#520510] space-y-2">
              <div className="flex items-baseline gap-3">
                <span className="text-3xl sm:text-4xl font-black text-amber-400">
                  {formatPrice(product.price, 'en')}
                </span>
                {product.originalPrice && product.originalPrice > product.price && (
                  <span className="text-base sm:text-lg text-neutral-400 line-through">
                    {formatPrice(product.originalPrice, 'en')}
                  </span>
                )}
                {product.originalPrice && product.originalPrice > product.price && (
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2.5 py-1 rounded-full border border-emerald-500/30">
                    Save {formatPrice(product.originalPrice - product.price, 'en')}
                  </span>
                )}
              </div>

              {product.freeDelivery && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs font-bold shadow-inner">
                  <Truck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{language === 'bn' ? '🎉 এই পণ্যের জন্য ডেলিভারি সম্পূর্ণ ফ্রি!' : '🎉 Free Delivery for this product!'}</span>
                </div>
              )}

              {/* Stock Notice */}
              <div className="flex items-center gap-2 text-xs font-semibold pt-1">
                {(product.stock ?? 1) > 0 ? (
                  <span className="text-emerald-400 flex items-center gap-1.5 font-bold">
                    <CheckCircle className="w-4 h-4" />
                    <span>In Stock — ready for express shipping</span>
                  </span>
                ) : (
                  <span className="text-red-400 flex items-center gap-1.5 font-bold">
                    <Package className="w-4 h-4" />
                    <span>Currently Out of Stock</span>
                  </span>
                )}
              </div>
            </div>

            {/* Color Selection Option (ONLY shown if product actually has color) */}
            {availableColors.length > 0 && (
              <div className="space-y-2.5 pt-3 border-t border-[#520510]">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-neutral-100 flex items-center gap-1.5">
                    <span>🎨 {language === 'bn' ? 'কালার (Color):' : 'Color:'}</span>
                    <span className="text-amber-300 font-extrabold">
                      {selectedColor || (language === 'bn' ? 'সিলেক্ট করুন' : 'Select Color')}
                    </span>
                  </span>
                  {availableColors.length > 1 && (
                    <span className="text-[11px] text-amber-200/80">
                      {language === 'bn' ? 'পছন্দের কালার বেছে নিন' : 'Choose color'}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {availableColors.map((color) => {
                    const isSelected = selectedColor === color;
                    return (
                      <button
                        key={color}
                        type="button"
                        onClick={() => {
                          setSelectedColor(color);
                          setVariantError('');
                        }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
                          isSelected
                            ? 'bg-amber-400 border-amber-400 text-neutral-950 ring-2 ring-amber-400/30 shadow-sm'
                            : 'bg-[#1C0104] border-[#6B0B1D] text-neutral-200 hover:border-amber-400/60 hover:text-white'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 text-neutral-950" />}
                        <span>{color}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Size Selection Option (ONLY shown if product actually has size) */}
            {availableSizes.length > 0 && (
              <div className="space-y-2.5 pt-3 border-t border-[#520510]">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-neutral-100 flex items-center gap-1.5">
                    <span>📏 {language === 'bn' ? 'সাইজ (Size):' : 'Size:'}</span>
                    <span className="text-amber-300 font-extrabold">
                      {selectedSize || (language === 'bn' ? 'সিলেক্ট করুন' : 'Select Size')}
                    </span>
                  </span>
                  {availableSizes.length > 1 && (
                    <span className="text-[11px] text-amber-200/80">
                      {language === 'bn' ? 'পছন্দের সাইজ বেছে নিন' : 'Choose size'}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {availableSizes.map((size) => {
                    const isSelected = selectedSize === size;
                    return (
                      <button
                        key={size}
                        type="button"
                        onClick={() => {
                          setSelectedSize(size);
                          setVariantError('');
                        }}
                        className={`min-w-[46px] px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border ${
                          isSelected
                            ? 'bg-amber-400 border-amber-400 text-neutral-950 ring-2 ring-amber-400/30 shadow-sm'
                            : 'bg-[#1C0104] border-[#6B0B1D] text-neutral-200 hover:border-amber-400/60 hover:text-white'
                        }`}
                      >
                        <span>{size}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-neutral-950" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {variantError && (
              <div className="p-3 rounded-xl bg-amber-400/15 border border-amber-400/50 text-amber-200 text-xs font-bold flex items-center gap-2">
                <span>⚠️</span>
                <span>{variantError}</span>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="flex items-center justify-between pt-3 border-t border-[#520510]">
              <span className="text-xs font-bold text-neutral-200 uppercase">
                {language === 'bn' ? 'পরিমাণ (Quantity):' : 'Quantity:'}
              </span>
              <div className="flex items-center border border-[#6B0B1D] rounded-2xl overflow-hidden bg-[#1C0104] shadow-2xs">
                <button
                  type="button"
                  onClick={handleDecrement}
                  disabled={quantity <= 1}
                  className="w-10 h-10 flex items-center justify-center text-neutral-200 hover:bg-[#380208] disabled:opacity-30 cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-black text-sm text-amber-400 font-mono">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={handleIncrement}
                  disabled={quantity >= (product.stock || 99)}
                  className="w-10 h-10 flex items-center justify-center text-neutral-200 hover:bg-[#380208] disabled:opacity-30 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* DropshippingBD Delivery Areas & Charge Information */}
            <div className="p-3.5 rounded-2xl bg-[#1C0104] border border-[#520510] space-y-2 text-xs">
              <div className="flex items-center justify-between font-bold text-white">
                <span className="flex items-center gap-1.5 text-amber-400">
                  <Truck className="w-4 h-4" />
                  <span>ডেলিভারি চার্জ (Delivery Rate):</span>
                </span>
                <span className="text-[11px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
                  ক্যাশ অন ডেলিভারি (COD)
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-[11px]">
                <div className="p-2.5 rounded-xl bg-[#240106] border border-[#520510]">
                  <div className="font-bold text-neutral-100 flex items-center justify-between">
                    <span className="flex items-center gap-1">🏠 <span>Inside Dhaka (ঢাকার ভিতরে)</span></span>
                    <span className="text-amber-400 font-black text-xs">65.00 ৳</span>
                  </div>
                  <p className="text-[10px] text-neutral-400 mt-0.5">২৪-৪৮ ঘণ্টার মধ্যে হোম ডেলিভারি</p>
                </div>
                <div className="p-2.5 rounded-xl bg-[#240106] border border-[#520510]">
                  <div className="font-bold text-neutral-100 flex items-center justify-between">
                    <span className="flex items-center gap-1">🚚 <span>Outside Dhaka (ঢাকার বাইরে)</span></span>
                    <span className="text-amber-400 font-black text-xs">120.00 ৳</span>
                  </div>
                  <p className="text-[10px] text-neutral-400 mt-0.5">সারা বাংলাদেশ (সকল ৬৩ জেলা ও থানা)</p>
                </div>
              </div>
            </div>

            {/* Action Buttons: Add to Cart & Buy Now */}
            <div className="pt-2 space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {onAddToCart && (
                  <button
                    type="button"
                    onClick={() => {
                      if (availableColors.length > 1 && !selectedColor) {
                        setVariantError(language === 'bn' ? 'অনুগ্রহ করে আপনার পছন্দের কালার সিলেক্ট করুন।' : 'Please select a color.');
                        return;
                      }
                      if (availableSizes.length > 1 && !selectedSize) {
                        setVariantError(language === 'bn' ? 'অনুগ্রহ করে আপনার পছন্দের সাইজ সিলেক্ট করুন।' : 'Please select a size.');
                        return;
                      }
                      setVariantError('');
                      onAddToCart(product, quantity, {
                        size: availableSizes.length > 0 ? selectedSize : undefined,
                        color: availableColors.length > 0 ? selectedColor : undefined,
                      });
                    }}
                    disabled={(product.stock ?? 1) <= 0}
                    className="w-full py-3.5 px-4 rounded-2xl bg-rose-50 hover:bg-rose-100 text-[#800020] border-2 border-[#800020]/30 font-bold text-sm sm:text-base transition flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-40"
                  >
                    <ShoppingBag className="w-5 h-5 text-[#800020]" />
                    <span>{language === 'bn' ? 'কার্টে যোগ করুন' : 'Add to Cart'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    if (availableColors.length > 1 && !selectedColor) {
                      setVariantError(language === 'bn' ? 'অনুগ্রহ করে আপনার পছন্দের কালার সিলেক্ট করুন।' : 'Please select a color.');
                      return;
                    }
                    if (availableSizes.length > 1 && !selectedSize) {
                      setVariantError(language === 'bn' ? 'অনুগ্রহ করে আপনার পছন্দের সাইজ সিলেক্ট করুন।' : 'Please select a size.');
                      return;
                    }
                    setVariantError('');
                    onBuyNow(product, quantity, {
                      size: availableSizes.length > 0 ? selectedSize : undefined,
                      color: availableColors.length > 0 ? selectedColor : undefined,
                    });
                  }}
                  disabled={(product.stock ?? 1) <= 0}
                  className={`w-full py-3.5 px-4 rounded-2xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-sm sm:text-base shadow-lg shadow-amber-400/20 transition flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-40 ${
                    !onAddToCart ? 'sm:col-span-2' : ''
                  }`}
                >
                  <Zap className="w-5 h-5 fill-neutral-950" />
                  <span>{language === 'bn' ? 'অর্ডার করুন (ক্যাশ অন ডেলিভারি)' : 'Order Now (COD)'}</span>
                </button>
              </div>

              <p className="text-center text-[11px] text-neutral-300 font-medium">
                🔒 {language === 'bn' ? 'অগ্রিম কোনো টাকা দিতে হবে না • পণ্য হাতে পেয়ে সম্পূর্ণ দেখে মূল্য পরিশোধ করুন' : '100% Cash on Delivery • Inspect parcel upon delivery'}
              </p>
            </div>
          </div>
        </div>

        {/* DETAILS SECTION: DESCRIPTION FIRST, THEN REVIEWS */}
        <div className="space-y-8 pt-6">
          {/* 1. Product Description & Specifications (FIRST) */}
          <div className="bg-white p-5 sm:p-7 md:p-8 rounded-3xl border border-neutral-200 shadow-xs space-y-4">
            <h3 className="text-lg sm:text-xl font-black text-neutral-900 border-b border-neutral-200 pb-3">
              {language === 'bn' ? 'পণ্যের বিবরণ ও স্পেসিফিকেশন (Product Details)' : 'Product Description & Specifications'}
            </h3>

            <div className="text-xs sm:text-sm text-neutral-700 leading-relaxed space-y-4">
              <div className="whitespace-pre-line">
                {language === 'bn'
                  ? (product.descriptionBn || product.descriptionEn)
                  : (product.descriptionEn || product.descriptionBn)}
              </div>
              
              {(() => {
                const specs = language === 'bn'
                  ? (product.specificationsBn && product.specificationsBn.length > 0 ? product.specificationsBn : product.specificationsEn)
                  : (product.specificationsEn && product.specificationsEn.length > 0 ? product.specificationsEn : product.specificationsBn);
                if (!specs || specs.length === 0) return null;
                return (
                  <div className="mt-4 pt-4 border-t border-neutral-200 space-y-2">
                    <h4 className="font-bold text-xs text-neutral-900 uppercase tracking-wider">
                      {language === 'bn' ? 'মূল বৈশিষ্ট্য ও মাপ (Specifications):' : 'Specifications:'}
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {specs.map((spec, i) => (
                        <div key={i} className="flex items-start gap-2 py-1 text-xs">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0"></span>
                          <span className="text-neutral-700 font-medium">{spec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>

          {/* 2. Customer Reviews & Ratings (SECOND) */}
          <div className="bg-white p-5 sm:p-7 md:p-8 rounded-3xl border border-neutral-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center">
                  <Star className="w-5 h-5 fill-amber-500 text-amber-500" />
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl font-black text-neutral-900">
                    Customer Ratings & Reviews
                  </h3>
                  <p className="text-xs text-neutral-500">Real feedback from verified purchasers</p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xl font-black text-neutral-900">{averageRating}</span>
                <span className="text-xs text-neutral-400"> / 5.0</span>
              </div>
            </div>

            {/* Rating Breakdown & Write Review */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 p-5 bg-neutral-50 rounded-2xl border border-neutral-200">
              <div className="flex flex-col items-center justify-center text-center p-3 border-b md:border-b-0 md:border-r border-neutral-200">
                <span className="text-4xl sm:text-5xl font-black text-neutral-900 leading-none">
                  {averageRating}
                </span>
                <div className="flex items-center gap-1 my-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 h-4 ${
                        star <= Math.round(Number(averageRating))
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-neutral-300'
                      }`}
                    />
                  ))}
                </div>
                <p className="text-xs text-neutral-500 font-semibold">
                  Based on {productReviews.length} customer ratings
                </p>
              </div>

              <div className="space-y-1.5 text-xs">
                {[5, 4, 3, 2, 1].map((stars) => {
                  const count = ratingCounts[stars as keyof typeof ratingCounts] || 0;
                  const percentage = totalReviewsCount > 0 ? (count / totalReviewsCount) * 100 : 0;
                  return (
                    <div key={stars} className="flex items-center gap-2">
                      <span className="w-6 font-bold text-neutral-600 text-[11px] flex items-center justify-end gap-0.5">
                        {stars} <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                      </span>
                      <div className="flex-1 h-2 bg-neutral-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-amber-400 rounded-full transition-all duration-500"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <span className="w-6 text-right text-[10px] text-neutral-400 font-mono">
                        {count}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Review Eligibility Box: Only buyer after delivery can review */}
              <div className="flex flex-col justify-center items-center text-center p-3.5 bg-white rounded-xl border border-neutral-200/80 shadow-2xs space-y-2.5">
                {deliveredOrderForProduct ? (
                  <>
                    <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>{language === 'bn' ? 'ডেলিভারি সম্পন্ন ক্রেতা' : 'Verified Delivered Buyer'}</span>
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-1">
                        {language === 'bn' 
                          ? `অর্ডার #${deliveredOrderForProduct.id} সফলভাবে পেয়েছেন। আপনার মূল্যবান মতামত দিন!` 
                          : `Order #${deliveredOrderForProduct.id} delivered. Share your feedback!`}
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        if (onOpenWriteReview) {
                          onOpenWriteReview(product, deliveredOrderForProduct.id, existingUserReview);
                        }
                      }}
                      className="w-full py-2 px-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{existingUserReview ? (language === 'bn' ? 'রিভিউ এডিট করুন' : 'Edit Your Review') : (language === 'bn' ? '⭐ রিভিউ লিখুন' : '⭐ Write a Review')}</span>
                    </button>
                  </>
                ) : activeOrderForProduct ? (
                  <>
                    <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                        <Truck className="w-3 h-3 text-amber-600" />
                        <span>{language === 'bn' ? 'অর্ডার প্রক্রিয়াধীন' : 'Order In Transit'}</span>
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-1">
                        {language === 'bn' 
                          ? 'পণ্যটি আপনার ঠিকানায় ডেলিভারি সম্পন্ন হওয়ার পরই আপনি রিভিউ দিতে পারবেন।' 
                          : 'You can submit a review once the product is delivered.'}
                      </p>
                    </div>
                    <div className="w-full py-2 px-3 bg-neutral-100 text-neutral-500 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border border-neutral-200 select-none">
                      <Lock className="w-3.5 h-3.5 text-neutral-400" />
                      <span>{language === 'bn' ? 'ডেলিভারির পর রিভিউ আনলক হবে' : 'Review Unlocks After Delivery'}</span>
                    </div>
                  </>
                ) : currentUser ? (
                  <>
                    <div className="w-8 h-8 rounded-full bg-neutral-100 text-neutral-600 flex items-center justify-center">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="inline-flex items-center gap-1 text-[10px] font-bold text-neutral-700 bg-neutral-100 border border-neutral-200 px-2 py-0.5 rounded-full">
                        <Lock className="w-3 h-3 text-neutral-500" />
                        <span>{language === 'bn' ? 'শুধুমাত্র ক্রেতাদের জন্য' : 'Delivered Buyers Only'}</span>
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-1">
                        {language === 'bn' 
                          ? 'যে ক্রেতা এই পণ্যটি ক্রয় করবেন, ডেলিভারি হওয়ার পর তিনিই রিভিউ দিতে পারবেন।' 
                          : 'Only customers who buy and receive delivery can review this product.'}
                      </p>
                    </div>
                    <button
                      onClick={() => onBuyNow(product, 1)}
                      className="w-full py-2 px-3 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'পণ্যটি অর্ডার করুন' : 'Order Now'}</span>
                    </button>
                  </>
                ) : (
                  <>
                    <div className="w-8 h-8 rounded-full bg-neutral-100 text-neutral-600 flex items-center justify-center">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="inline-flex items-center gap-1 text-[10px] font-bold text-neutral-700 bg-neutral-100 border border-neutral-200 px-2 py-0.5 rounded-full">
                        <Lock className="w-3 h-3 text-neutral-500" />
                        <span>{language === 'bn' ? 'ভেরিফাইড ক্রেতার রিভিউ' : 'Verified Reviews'}</span>
                      </div>
                      <p className="text-[10px] text-neutral-500 mt-1">
                        {language === 'bn' 
                          ? 'পণ্যটি কিনে ডেলিভারি পেয়েছেন? রিভিউ দিতে একাউন্টে লগইন করুন।' 
                          : 'Bought & received this item? Log in to submit your review.'}
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        if (onOpenWriteReview) {
                          onOpenWriteReview(product, undefined, null);
                        }
                      }}
                      className="w-full py-2 px-3 bg-neutral-900 hover:bg-black text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>{language === 'bn' ? 'লগইন করে রিভিউ দিন' : 'Sign In to Review'}</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Review List */}
            {productReviews.length === 0 ? (
              <div className="py-8 text-center space-y-2 bg-neutral-50 rounded-2xl border border-dashed border-neutral-300">
                <MessageSquare className="w-7 h-7 text-neutral-300 mx-auto" />
                <p className="text-xs font-bold text-neutral-600">No written reviews yet for this product.</p>
                <p className="text-[11px] text-neutral-400">Be the first to share your experience!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {productReviews.map((review) => (
                  <div 
                    key={review.id}
                    className="p-4 rounded-2xl bg-neutral-50/70 border border-neutral-200 space-y-2.5"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 font-black text-xs flex items-center justify-center uppercase">
                          {(review.customerName || review.userName || 'C').charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-neutral-900">
                              {review.customerName || review.userName || 'Happy Shopper'}
                            </span>
                            <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded-full">
                              <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                              <span>Verified Buyer</span>
                            </span>
                          </div>
                          <span className="text-[10px] text-neutral-400 flex items-center gap-1 mt-0.5">
                            <Calendar className="w-2.5 h-2.5" />
                            <span>{review.date || review.createdAt || 'Recent'}</span>
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star 
                            key={s}
                            className={`w-3 h-3 ${s <= review.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-300'}`}
                          />
                        ))}
                      </div>
                    </div>

                    <p className="text-xs text-neutral-700 leading-relaxed pl-1">
                      {review.comment}
                    </p>

                    {review.reviewImage && (
                      <div className="pt-1">
                        <button
                          type="button"
                          onClick={() => setPreviewPhotoModal(review.reviewImage || null)}
                          className="relative rounded-xl overflow-hidden border border-neutral-200 inline-block cursor-pointer shadow-2xs"
                        >
                          <img 
                            src={review.reviewImage} 
                            alt="Review attachment" 
                            className="w-16 h-16 sm:w-20 sm:h-20 object-contain p-1 bg-white"
                          />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Related Products Section */}
        {relatedProducts.length > 0 && onSelectProduct && (
          <div className="pt-8 space-y-4">
            <h3 className="text-lg sm:text-xl font-black text-neutral-900">
              You May Also Like
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
              {relatedProducts.slice(0, 4).map((rel) => (
                <div
                  key={rel.id}
                  onClick={() => onSelectProduct(rel)}
                  className="bg-white rounded-2xl border border-neutral-200 p-3 hover:shadow-md transition cursor-pointer flex flex-col justify-between group"
                >
                  <div className="aspect-square w-full rounded-xl overflow-hidden bg-neutral-100 flex items-center justify-center">
                    <img
                      src={rel.image?.replace('public//storage', 'public/storage') || ''}
                      alt={rel.titleEn}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        const target = e.currentTarget as HTMLImageElement;
                        const clean = rel.image ? rel.image.replace('public//storage', 'public/storage') : '';
                        if (clean && !target.src.includes('image-proxy')) {
                          target.src = `/api/image-proxy?url=${encodeURIComponent(clean)}`;
                        }
                      }}
                    />
                  </div>
                  <div className="mt-2 space-y-1">
                    <h4 className="text-xs font-bold text-neutral-800 line-clamp-1 group-hover:text-rose-600">
                      {rel.titleEn || rel.titleBn}
                    </h4>
                    <p className="text-sm font-black text-rose-600">
                      {formatPrice(rel.price, 'en')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Photo Lightbox */}
      {previewPhotoModal && (
        <div 
          className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm animate-fadeIn"
          onClick={() => setPreviewPhotoModal(null)}
        >
          <div className="relative max-w-2xl max-h-[85vh] p-2 bg-neutral-900 rounded-3xl overflow-hidden border border-neutral-700">
            <button
              onClick={() => setPreviewPhotoModal(null)}
              className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black transition cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <img 
              src={previewPhotoModal} 
              alt="Preview" 
              className="max-h-[75vh] w-auto mx-auto object-contain rounded-2xl" 
            />
          </div>
        </div>
      )}
    </div>
  );
};
