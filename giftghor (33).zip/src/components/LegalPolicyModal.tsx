import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  FileText, 
  RotateCcw, 
  Truck, 
  Info, 
  Phone, 
  Mail, 
  MapPin, 
  CheckCircle2, 
  Lock,
  Building,
  HelpCircle
} from 'lucide-react';
import { Language } from '../types';

export type PolicyTab = 'privacy' | 'terms' | 'refund' | 'shipping' | 'about' | 'contact';

interface LegalPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  initialTab?: PolicyTab;
}

export const LegalPolicyModal: React.FC<LegalPolicyModalProps> = ({
  isOpen,
  onClose,
  language,
  initialTab = 'privacy'
}) => {
  const [activeTab, setActiveTab] = useState<PolicyTab>(initialTab);

  // Sync initial tab when modal opens
  React.useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const isBn = language === 'bn';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-4xl max-h-[90vh] rounded-2xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-neutral-900">
                {isBn ? 'অফিশিয়াল নীতিমালা ও তথ্যকেন্দ্র' : 'Official Policies & Information'}
              </h2>
              <p className="text-[11px] sm:text-xs text-neutral-500">
                Happy Shopping • Better Product • Happier You
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-200/80 hover:bg-neutral-300 text-neutral-700 flex items-center justify-center transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-4 py-2 bg-neutral-100 border-b border-neutral-200/80 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('privacy')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'privacy' 
                ? 'bg-rose-600 text-white shadow-xs' 
                : 'bg-white text-neutral-600 hover:bg-neutral-200/60'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{isBn ? 'গোপনীয়তা নীতি' : 'Privacy Policy'}</span>
          </button>

          <button
            onClick={() => setActiveTab('terms')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'terms' 
                ? 'bg-rose-600 text-white shadow-xs' 
                : 'bg-white text-neutral-600 hover:bg-neutral-200/60'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isBn ? 'শর্তাবলী' : 'Terms of Service'}</span>
          </button>

          <button
            onClick={() => setActiveTab('refund')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'refund' 
                ? 'bg-rose-600 text-white shadow-xs' 
                : 'bg-white text-neutral-600 hover:bg-neutral-200/60'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isBn ? 'রিটার্ন ও রিফান্ড' : 'Return & Refund'}</span>
          </button>

          <button
            onClick={() => setActiveTab('shipping')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'shipping' 
                ? 'bg-rose-600 text-white shadow-xs' 
                : 'bg-white text-neutral-600 hover:bg-neutral-200/60'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>{isBn ? 'ডেলিভারি পলিসি' : 'Shipping Info'}</span>
          </button>

          <button
            onClick={() => setActiveTab('about')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'about' 
                ? 'bg-rose-600 text-white shadow-xs' 
                : 'bg-white text-neutral-600 hover:bg-neutral-200/60'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span>{isBn ? 'আমাদের সম্পর্কে' : 'About Us'}</span>
          </button>

          <button
            onClick={() => setActiveTab('contact')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'contact' 
                ? 'bg-rose-600 text-white shadow-xs' 
                : 'bg-white text-neutral-600 hover:bg-neutral-200/60'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>{isBn ? 'যোগাযোগ' : 'Contact Us'}</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 text-neutral-700 leading-relaxed space-y-6 text-xs sm:text-sm">
          
          {/* TAB 1: PRIVACY POLICY */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <Lock className="w-5 h-5 text-rose-600" />
                  {isBn ? 'গোপনীয়তা ও ডাটা সুরক্ষা নীতিমালা (Privacy Policy)' : 'Privacy & Data Protection Policy'}
                </h3>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  {isBn ? 'সর্বশেষ হালনাগাদ: সেপ্টেম্বর ২০২৬ | Happy Shopping' : 'Last Updated: September 2026 | Happy Shopping'}
                </p>
              </div>

              <div className="space-y-3">
                <p>
                  {isBn 
                    ? 'Happy Shopping এ গ্রাহকদের তথ্যের গোপনীয়তা ও সুরক্ষা রক্ষা করা আমাদের সর্বোচ্চ অগ্রাধিকার। এই নীতিমালায় ব্যাখ্যা করা হয়েছে আমরা কীভাবে আপনার ব্যক্তিগত তথ্য সংগ্রহ, ব্যবহার এবং সুরক্ষিত রাখি।'
                    : 'At Happy Shopping, protecting your personal privacy and data security is our highest priority. This policy outlines how we collect, use, and protect your information.'}
                </p>

                <div className="bg-rose-50/70 border border-rose-200/70 rounded-xl p-3.5">
                  <h4 className="font-bold text-neutral-900 text-xs sm:text-sm mb-1">
                    {isBn ? '১. আমরা যেসকল তথ্য সংগ্রহ করি:' : '1. Information We Collect:'}
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-neutral-600 text-xs">
                    <li>{isBn ? 'নাম, ডেলিভারি ঠিকানা এবং ফোন নম্বর (অর্ডার প্রসেসিং ও ডেলিভারির জন্য)।' : 'Name, delivery address, and phone number for order processing.'}</li>
                    <li>{isBn ? 'ইমেইল অ্যাড্রেস (অর্ডার কনফার্মেশন এবং কাস্টমার সাপোর্টের জন্য)।' : 'Email address for order confirmations and customer service.'}</li>
                    <li>{isBn ? 'অর্ডার হিস্ট্রি ও পেমেন্ট মেথড (যেমন ক্যাশ অন ডেলিভারি / বিকাশ)। আমরা কোনো পিন বা ওটিপি সংরক্ষণ করি না।' : 'Order history and transaction status (We never store PINs or OTPs).'}</li>
                  </ul>
                </div>

                <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-3.5">
                  <h4 className="font-bold text-neutral-900 text-xs sm:text-sm mb-1">
                    {isBn ? '২. তথ্যের ব্যবহার ও সুরক্ষা:' : '2. Data Usage & Security:'}
                  </h4>
                  <p className="text-xs text-neutral-600">
                    {isBn
                      ? 'আপনার প্রদত্ত তথ্য শুধুমাত্র আপনার পার্সেল ডেলিভারি এবং কাস্টমার সার্ভিসের কাজে ব্যবহৃত হয়। আমরা কোনো তৃতীয় পক্ষের কাছে আপনার ব্যক্তিগত তথ্য বিক্রি বা হস্তান্তর করি না। সকল ডাটা আধুনিক এনক্রিপশনের মাধ্যমে সুরক্ষিত।'
                      : 'Your information is solely used for parcel dispatch, order updates, and customer support. We never sell, lease, or rent customer data to third-party marketing brokers.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TERMS OF SERVICE */}
          {activeTab === 'terms' && (
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-rose-600" />
                  {isBn ? 'ব্যবহারের সাধারণ শর্তাবলী (Terms & Conditions)' : 'Terms & Conditions of Service'}
                </h3>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  {isBn ? 'Happy Shopping প্ল্যাটফর্মে অর্ডারের প্রযোজ্য নিয়মাবলী' : 'Applicable rules for orders on Happy Shopping'}
                </p>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-neutral-600">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-neutral-900">{isBn ? 'অর্ডার নিশ্চিতকরণ:' : 'Order Confirmation:'}</strong>{' '}
                    {isBn 
                      ? 'ওয়েবসাইটে সফলভাবে অর্ডার প্লেস করার পর আমাদের হেল্পডেস্ক থেকে ফোনে কল করে অথবা এসএমএসের মাধ্যমে নিশ্চিত করা হতে পারে।'
                      : 'After placing an order on our platform, our team may verify details via phone or SMS prior to dispatch.'}
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-neutral-900">{isBn ? 'মূল্য ও পণ্যের স্টক:' : 'Pricing & Inventory:'}</strong>{' '}
                    {isBn
                      ? 'ওয়েবসাইটে উল্লেখিত সকল পণ্যের মূল্য টাকায় (BDT) নির্ধারিত। কোনো পণ্যের স্টক অপ্রত্যাশিতভাবে শেষ হয়ে গেলে গ্রাহককে অবিলম্বে অবহিত করে রিফান্ড বা বিকল্পের সুযোগ প্রদান করা হবে।'
                      : 'All prices are in Bangladeshi Taka (BDT). In case of stock depletion, customers will be notified immediately with options for substitution or full refund.'}
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-neutral-900">{isBn ? 'অরিজিনাল পণ্যের প্রতিশ্রুতি:' : 'Authenticity Guarantee:'}</strong>{' '}
                    {isBn
                      ? 'Happy Shopping শতভাগ খাঁটি ও কোয়ালিটি চেক করা পণ্য সরাসরি সরবরাহ করে। প্রতিটি পণ্য ডেলিভারির পূর্বে পরীক্ষা করা হয়।'
                      : 'Happy Shopping guarantees 100% authentic, high-quality merchandise inspected before parcel handover.'}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: RETURN & REFUND */}
          {activeTab === 'refund' && (
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <RotateCcw className="w-5 h-5 text-rose-600" />
                  {isBn ? '৭ দিনের সহজ রিটার্ন ও রিফান্ড নীতি (Return & Refund)' : '7-Day Return & Refund Policy'}
                </h3>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  {isBn ? 'গ্রাহক সন্তুষ্টি নিশ্চিতকরণে ঝামেলাহীন পলিসি' : 'Hassle-free guarantee ensuring customer satisfaction'}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                  <h4 className="font-bold text-emerald-900 text-xs sm:text-sm mb-1.5 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {isBn ? 'রিটার্ন গ্রহণের শর্তাবলী:' : 'Eligible for Return:'}
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-emerald-800 text-xs">
                    <li>{isBn ? 'ভুল পণ্য অথবা ড্যামেজ অবস্থায় পণ্য পৌঁছালে।' : 'Damaged or incorrect item received.'}</li>
                    <li>{isBn ? 'সাইজ বা ফিটিং জনিত অমিল হলে।' : 'Size or fitting mismatch upon arrival.'}</li>
                    <li>{isBn ? 'ডেলিভারির ৭ দিনের মধ্যে অবহিত করতে হবে।' : 'Reported within 7 days of delivery.'}</li>
                  </ul>
                </div>

                <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200">
                  <h4 className="font-bold text-blue-900 text-xs sm:text-sm mb-1.5 flex items-center gap-1.5">
                    <RotateCcw className="w-4 h-4 text-blue-600" />
                    {isBn ? 'রিফান্ড প্রক্রিয়া:' : 'Refund Process:'}
                  </h4>
                  <p className="text-blue-800 text-xs leading-relaxed">
                    {isBn
                      ? 'রিটার্নকৃত পণ্যটি আমাদের হাতে পৌঁছানোর ২৪-৪৮ ঘণ্টার মধ্যে বিকাশ / নগদ অথবা ব্যাংক একাউন্টের মাধ্যমে রিফান্ড সম্পন্ন করা হয়।'
                      : 'Once returned parcel is inspected, refunds are transferred via bKash, Nagad, or bank within 24-48 hours.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: SHIPPING & DELIVERY */}
          {activeTab === 'shipping' && (
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <Truck className="w-5 h-5 text-rose-600" />
                  {isBn ? 'শিপিং ও ডেলিভারি তথ্য (Shipping & Delivery)' : 'Shipping & Nationwide Delivery'}
                </h3>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  {isBn ? 'সারা বাংলাদেশে হোম ডেলিভারি ও ক্যাশ অন ডেলিভারি' : 'Nationwide home delivery with Cash on Delivery'}
                </p>
              </div>

              <div className="space-y-3 text-xs sm:text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                    <p className="font-bold text-neutral-900 mb-0.5">{isBn ? 'ঢাকার ভেতরে ডেলিভারি চার্জ' : 'Inside Dhaka Delivery'}</p>
                    <p className="text-rose-600 font-extrabold text-sm">৳৬০ টাকা (২৪-৪৮ ঘণ্টার মধ্যে)</p>
                  </div>
                  <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200">
                    <p className="font-bold text-neutral-900 mb-0.5">{isBn ? 'ঢাকার বাইরে ডেলিভারি চার্জ' : 'Outside Dhaka Delivery'}</p>
                    <p className="text-rose-600 font-extrabold text-sm">৳১২০ টাকা (২-৩ কার্যদিবস)</p>
                  </div>
                </div>

                <p className="text-neutral-600">
                  {isBn
                    ? 'পার্সেল পাওয়ার পর রাইডারের সামনে দেখে মূল্য পরিশোধ করার সম্পূর্ণ ক্যাশ অন ডেলিভারি (COD) সুবিধা রয়েছে।'
                    : 'Complete Cash on Delivery (COD) facility available nationwide with doorstep parcel verification.'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: ABOUT US */}
          {activeTab === 'about' && (
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <Building className="w-5 h-5 text-rose-600" />
                  {isBn ? 'আমাদের সম্পর্কে (About Happy Shopping)' : 'About Happy Shopping Online Store'}
                </h3>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  Better Product • Happier You
                </p>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-neutral-600 leading-relaxed">
                <div className="flex items-center gap-3 p-3 bg-orange-50/60 rounded-xl border border-orange-100">
                  <img src="/logo.png?v=20260924_2" alt="Happy Shopping" className="w-12 h-12 rounded-full ring-2 ring-orange-300 object-cover" />
                  <div>
                    <h4 className="font-black text-neutral-900 text-sm">Happy Shopping Official Store</h4>
                    <p className="text-[11px] text-orange-700 font-semibold">নিবেদিত খাঁটি পণ্য ও সর্বোচ্চ গ্রাহক সন্তুষ্টি</p>
                  </div>
                </div>

                <p>
                  {isBn
                    ? 'Happy Shopping একটি বিশ্বস্ত বাংলাদেশি ই-কমার্স প্ল্যাটফর্ম। আমরা প্রিমিয়াম পোশাক, ফ্যাশন আইটেম, স্মার্ট গ্যাজেটস, ব্যাগ এবং নিত্যপ্রয়োজনীয় পণ্যের সংগ্রহ সরাসরি গ্রাহকের দোরগোড়ায় পৌঁছে দিই।'
                    : 'Happy Shopping is a licensed and verified premier e-commerce shop in Bangladesh offering high-grade apparel, lifestyle accessories, and quality products directly to valued customers.'}
                </p>
              </div>
            </div>
          )}

          {/* TAB 6: CONTACT US */}
          {activeTab === 'contact' && (
            <div className="space-y-4">
              <div className="border-b border-neutral-200 pb-3">
                <h3 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <Phone className="w-5 h-5 text-rose-600" />
                  {isBn ? 'যোগাযোগ ও সাপোর্ট ডেস্ক (Contact Desk)' : 'Contact Us & Customer Desk'}
                </h3>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  {isBn ? 'যে কোনো প্রয়োজনে আমরা সবসময় আপনার পাশে আছি' : 'We are always ready to assist your queries'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 flex flex-col items-center text-center">
                  <Phone className="w-5 h-5 text-rose-600 mb-1.5" />
                  <span className="font-bold text-neutral-900 text-xs mb-0.5">{isBn ? 'হটলাইন নম্বর' : 'Helpline'}</span>
                  <a href="tel:+8801700000000" className="text-rose-600 font-bold text-xs hover:underline">
                    +880 1700-000000
                  </a>
                </div>

                <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 flex flex-col items-center text-center">
                  <Mail className="w-5 h-5 text-rose-600 mb-1.5" />
                  <span className="font-bold text-neutral-900 text-xs mb-0.5">{isBn ? 'অফিশিয়াল ইমেইল' : 'Official Email'}</span>
                  <a href="mailto:support@happyshopping.com" className="text-rose-600 font-bold text-xs hover:underline break-all">
                    support@happyshopping.com
                  </a>
                </div>

                <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 flex flex-col items-center text-center">
                  <MapPin className="w-5 h-5 text-rose-600 mb-1.5" />
                  <span className="font-bold text-neutral-900 text-xs mb-0.5">{isBn ? 'ঠিকানা' : 'Location'}</span>
                  <span className="text-neutral-600 text-xs">
                    {isBn ? 'ঢাকা, বাংলাদেশ' : 'Dhaka, Bangladesh'}
                  </span>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer actions */}
        <div className="px-5 py-3.5 bg-neutral-50 border-t border-neutral-200/80 flex items-center justify-between">
          <span className="text-[11px] text-neutral-500">
            © {new Date().getFullYear()} Happy Shopping. All Rights Reserved.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-neutral-900 text-white font-bold text-xs hover:bg-neutral-800 transition cursor-pointer"
          >
            {isBn ? 'ঠিক আছে' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
