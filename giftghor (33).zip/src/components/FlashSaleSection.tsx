import React, { useState, useEffect } from 'react';
import { Zap, Clock, ArrowRight } from 'lucide-react';
import { Product, Language, WebsiteCustomizerSettings } from '../types';
import { translations, toBengaliNumber } from '../utils/translations';
import { ProductCard } from './ProductCard';

interface FlashSaleSectionProps {
  products: Product[];
  language: Language;
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product, e: React.MouseEvent) => void;
  cartItemIds: Set<string>;
  onViewAllFlashSale: () => void;
  customizerSettings?: WebsiteCustomizerSettings;
}

export const FlashSaleSection: React.FC<FlashSaleSectionProps> = ({
  products,
  language,
  onSelectProduct,
  onAddToCart,
  cartItemIds,
  onViewAllFlashSale,
  customizerSettings,
}) => {
  const t = translations[language];

  // Check if flash sale is disabled in customizer
  if (customizerSettings && customizerSettings.flashSaleEnabled === false) {
    return null;
  }

  // 12-hour countdown timer calculation or target time
  const [timeLeft, setTimeLeft] = useState({ hours: 7, minutes: 42, seconds: 18 });

  useEffect(() => {
    if (customizerSettings?.flashSaleEndTime) {
      const target = new Date(customizerSettings.flashSaleEndTime).getTime();
      const updateCustomTimer = () => {
        const now = new Date().getTime();
        const diff = Math.max(0, target - now);
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeLeft({ hours, minutes, seconds });
      };
      updateCustomTimer();
      const timer = setInterval(updateCustomTimer, 1000);
      return () => clearInterval(timer);
    } else {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev.seconds > 0) {
            return { ...prev, seconds: prev.seconds - 1 };
          } else if (prev.minutes > 0) {
            return { ...prev, minutes: 59, seconds: 59 };
          } else if (prev.hours > 0) {
            return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
          }
          return { hours: 12, minutes: 0, seconds: 0 };
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [customizerSettings?.flashSaleEndTime]);

  const flashProducts = products.filter(p => p.isFlashSale).slice(0, 4);

  if (flashProducts.length === 0) return null;

  const padZero = (n: number) => n.toString().padStart(2, '0');

  const title = customizerSettings
    ? (language === 'bn' ? customizerSettings.flashSaleTitleBn : customizerSettings.flashSaleTitleEn)
    : t.flashSaleTitle;
  const subtitle = customizerSettings
    ? (language === 'bn' ? customizerSettings.flashSaleSubtitleBn : customizerSettings.flashSaleSubtitleEn)
    : t.flashSaleSubtitle;
  const badgeText = customizerSettings
    ? (language === 'bn' ? customizerSettings.flashSaleBadgeTextBn : customizerSettings.flashSaleBadgeTextEn)
    : 'HOT';

  return (
    <section className="my-5 sm:my-8 bg-gradient-to-r from-rose-50 via-red-50 to-orange-50 border border-rose-200/80 rounded-2xl sm:rounded-3xl p-3.5 sm:p-6 shadow-xs">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 sm:pb-4 border-b border-rose-200/60 mb-4 sm:mb-5">
        <div className="flex items-center gap-2.5 sm:gap-3">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-xs shadow-rose-200 shrink-0">
            <Zap className="w-4 h-4 sm:w-5 sm:h-5 fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <h2 className="text-sm sm:text-lg md:text-xl font-black text-neutral-900 tracking-tight leading-none">
                {title}
              </h2>
              <span className="bg-rose-600 text-white text-[9px] sm:text-[10px] font-black uppercase px-1.5 py-0.5 rounded-md">
                {badgeText}
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-neutral-500 mt-0.5">
              {subtitle}
            </p>
          </div>
        </div>

        {/* Countdown Timer */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1 text-[11px] sm:text-xs font-semibold text-neutral-700">
            <Clock className="w-3.5 h-3.5 text-rose-600" />
            <span className="hidden sm:inline">{t.flashSaleEnds}</span>
          </div>
          <div className="flex items-center gap-1 font-mono font-black text-xs sm:text-sm">
            <span className="bg-neutral-900 text-white px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md sm:rounded-lg shadow-xs">
              {language === 'bn' ? toBengaliNumber(padZero(timeLeft.hours)) : padZero(timeLeft.hours)}
            </span>
            <span className="text-neutral-900 font-bold">:</span>
            <span className="bg-neutral-900 text-white px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md sm:rounded-lg shadow-xs">
              {language === 'bn' ? toBengaliNumber(padZero(timeLeft.minutes)) : padZero(timeLeft.minutes)}
            </span>
            <span className="text-neutral-900 font-bold">:</span>
            <span className="bg-rose-600 text-white px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md sm:rounded-lg shadow-xs">
              {language === 'bn' ? toBengaliNumber(padZero(timeLeft.seconds)) : padZero(timeLeft.seconds)}
            </span>
          </div>
          <button
            onClick={onViewAllFlashSale}
            className="text-xs font-bold text-rose-600 hover:text-rose-800 ml-1 sm:ml-2 flex items-center gap-1 cursor-pointer"
          >
            <span className="hidden sm:inline">{t.viewAll}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Grid of flash sale products */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-2.5 sm:gap-4">
        {flashProducts.map(p => (
          <ProductCard
            key={p.id}
            product={p}
            language={language}
            onSelectProduct={onSelectProduct}
            onAddToCart={onAddToCart}
            isInCart={cartItemIds.has(p.id)}
          />
        ))}
      </div>
    </section>
  );
};

