import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  Phone, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  Loader2,
  Sparkles
} from 'lucide-react';
import { 
  auth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile, 
  sendPasswordResetEmail,
  saveUserProfileToFirestore,
  getUserProfileFromFirestore,
  isUserAdmin
} from '../lib/firebase';
import { Language, UserProfile } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSuccess: (profile: UserProfile, isAdmin?: boolean) => void;
  initialMode?: 'login' | 'register';
  customTitle?: string;
  customSubtitle?: string;
  isOrderGate?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  language,
  onSuccess,
  initialMode = 'login',
  customTitle,
  customSubtitle,
  isOrderGate = false,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Sync mode with initialMode whenever opened and lock background scroll
  React.useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setErrorMessage(null);
      setSuccessMessage(null);
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prevOverflow;
      };
    }
  }, [isOpen, initialMode]);

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  const extractErrorCode = (err: any): string => {
    if (err?.code) return String(err.code);
    const msg = String(err?.message || '');
    const match = msg.match(/auth\/[a-zA-Z0-9-]+/);
    return match ? match[0] : '';
  };

  const getFriendlyError = (errCode: string): string => {
    switch (errCode) {
      case 'auth/email-already-in-use':
        return language === 'bn' 
          ? 'এই ইমেইলটি দিয়ে ইতিমধ্যে অ্যাকাউন্ট খোলা হয়েছে। অনুগ্রহ করে "লগইন" ট্যাবে যান।' 
          : 'An account already exists with this email. Please switch to Sign In.';
      case 'auth/invalid-email':
        return language === 'bn' ? 'সঠিক ইমেইল অ্যাড্রেস লিখুন।' : 'Please enter a valid email address.';
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
        return language === 'bn' 
          ? 'ইমেইল অথবা পাসওয়ার্ড সঠিক নয়। নতুন অ্যাকাউন্ট তৈরি করতে পাশের "নতুন অ্যাকাউন্ট খুলুন" ট্যাবে ক্লিক করুন।' 
          : 'Invalid email or password. If you do not have an account yet, please click "Create Account".';
      case 'auth/user-not-found':
        return language === 'bn' 
          ? 'এই ইমেইল দিয়ে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে "নতুন অ্যাকাউন্ট খুলুন" ট্যাবে গিয়ে সাইন আপ করুন।' 
          : 'No account found with this email. Please register via "Create Account".';
      case 'auth/weak-password':
        return language === 'bn' ? 'পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.';
      case 'auth/network-request-failed':
        return language === 'bn' ? 'ইন্টারনেট সংযোগে সমস্যা হয়েছে। আবার চেষ্টা করুন।' : 'Network connection issue. Please check your internet and try again.';
      default:
        return language === 'bn' ? 'লগইন সম্পন্ন করা যায়নি। অনুগ্রহ করে সঠিক তথ্য দিয়ে আবার চেষ্টা করুন।' : 'Authentication failed. Please check your credentials and try again.';
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    const cleanEmail = email.trim().toLowerCase();

    // Check for specified Admin Credentials
    if (mode === 'login' && cleanEmail === 'winlucky414@gmail.com') {
      if (password === 'zxcvbnmlkjhgfdsa') {
        let profile: UserProfile;
        try {
          const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, password);
          const user = userCredential.user;
          profile = (await getUserProfileFromFirestore(user.uid)) || {
            uid: user.uid,
            displayName: 'Admin Manager',
            email: cleanEmail,
            phone: '01700000000',
            address: 'Store HQ, Dhaka',
            createdAt: new Date().toISOString(),
          };
        } catch {
          // Auto-provision if missing from Firebase Auth
          try {
            const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, password);
            const user = userCredential.user;
            await updateProfile(user, { displayName: 'Admin Manager' });
            profile = {
              uid: user.uid,
              displayName: 'Admin Manager',
              email: cleanEmail,
              phone: '01700000000',
              address: 'Store HQ, Dhaka',
              createdAt: new Date().toISOString(),
            };
            await saveUserProfileToFirestore(user.uid, profile);
          } catch {
            profile = {
              uid: 'admin-winlucky414',
              displayName: 'Admin Manager',
              email: cleanEmail,
              phone: '01700000000',
              address: 'Store HQ, Dhaka',
              createdAt: new Date().toISOString(),
            };
          }
        }

        onSuccess(profile, true);
        onClose();
        setIsLoading(false);
        return;
      }
    }

    try {
      if (mode === 'login') {
        const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
        const user = userCredential.user;

        let profile = await getUserProfileFromFirestore(user.uid);
        if (!profile) {
          profile = {
            uid: user.uid,
            displayName: user.displayName || email.split('@')[0],
            email: user.email || email,
            phone: user.phoneNumber || '',
            createdAt: new Date().toISOString(),
          };
          await saveUserProfileToFirestore(user.uid, profile);
        }

        const isAdminUser = isUserAdmin(profile);
        onSuccess(profile, isAdminUser);
        onClose();
      } else if (mode === 'register') {
        if (!name.trim()) {
          setErrorMessage(language === 'bn' ? 'অনুগ্রহ করে আপনার নাম দিন।' : 'Please enter your full name.');
          setIsLoading(false);
          return;
        }
        if (!phone.trim()) {
          setErrorMessage(language === 'bn' ? 'অনুগ্রহ করে মোবাইল নম্বর দিন।' : 'Please enter your mobile phone number.');
          setIsLoading(false);
          return;
        }

        const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        const user = userCredential.user;

        // Update display name
        await updateProfile(user, { displayName: name.trim() });

        // Save into Firestore (Address is gathered at checkout)
        const newProfile: UserProfile = {
          uid: user.uid,
          displayName: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          address: '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        await saveUserProfileToFirestore(user.uid, newProfile);
        const isAdminUser = isUserAdmin(newProfile);
        onSuccess(newProfile, isAdminUser);
        onClose();
      } else if (mode === 'forgot') {
        await sendPasswordResetEmail(auth, email.trim());
        setSuccessMessage(
          language === 'bn'
            ? 'পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে। ইনবক্স অথবা স্প্যাম ফোল্ডার চেক করুন।'
            : 'Password reset link sent to your email. Please check your inbox or spam.'
        );
      }
    } catch (err: any) {
      console.error(err);
      const code = extractErrorCode(err);
      setErrorMessage(getFriendlyError(code));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-neutral-100 space-y-4 relative max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="flex items-center gap-2.5 pb-1">
          <div className="w-9 h-9 rounded-full overflow-hidden ring-2 ring-orange-400 bg-white shrink-0 flex items-center justify-center">
            <img src="/logo.png?v=20260924_2" alt="Happy Shopping" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <div>
            <span className="text-base font-black text-neutral-900 leading-none"><span className="text-sky-950 font-black">Happy</span> <span className="text-orange-500 font-extrabold">Shopping</span></span>
            <p className="text-[10px] text-orange-600 font-bold">Better Product • Happier You</p>
          </div>
        </div>

        {/* Order Gate Alert Banner */}
        {isOrderGate && (
          <div className="p-3.5 bg-gradient-to-r from-rose-50 to-orange-50 border border-rose-200 rounded-2xl flex items-start gap-3 shadow-xs">
            <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-black text-rose-900">
                {customTitle || (language === 'bn' ? 'অর্ডার করতে আগে সাইন আপ করুন' : 'Sign up to place your order')}
              </h4>
              <p className="text-[11px] text-rose-700 mt-0.5 leading-snug">
                {customSubtitle || (language === 'bn' ? 'Happy Shopping-এ নিরাপদ অর্ডার ও দ্রুত ডেলিভারির জন্য একাউন্ট আবশ্যক।' : 'An account is required for order confirmation and delivery updates.')}
              </p>
            </div>
          </div>
        )}

        {/* Header Tabs */}
        {mode !== 'forgot' ? (
          <div className="flex items-center gap-2 border-b border-neutral-100 pb-3 pr-8">
            <button
              onClick={() => {
                setMode('login');
                setErrorMessage(null);
              }}
              className={`text-base font-black pb-1 border-b-2 transition cursor-pointer ${
                mode === 'login'
                  ? 'border-rose-600 text-rose-600'
                  : 'border-transparent text-neutral-400 hover:text-neutral-700'
              }`}
            >
              {language === 'bn' ? 'লগইন' : 'Sign In'}
            </button>
            <span className="text-neutral-300">|</span>
            <button
              onClick={() => {
                setMode('register');
                setErrorMessage(null);
              }}
              className={`text-base font-black pb-1 border-b-2 transition cursor-pointer ${
                mode === 'register'
                  ? 'border-rose-600 text-rose-600'
                  : 'border-transparent text-neutral-400 hover:text-neutral-700'
              }`}
            >
              {language === 'bn' ? 'নতুন অ্যাকাউন্ট খুলুন' : 'Create Account'}
            </button>
          </div>
        ) : (
          <div className="border-b border-neutral-100 pb-3">
            <h3 className="text-base font-black text-neutral-900">
              {language === 'bn' ? 'পাসওয়ার্ড রিসেট' : 'Reset Password'}
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              {language === 'bn' 
                ? 'আপনার নিবন্ধিত ইমেইল দিলে আমরা পাসওয়ার্ড রিসেট লিংক পাঠিয়ে দেব।' 
                : 'Enter your registered email to receive a password reset link.'}
            </p>
          </div>
        )}

        {/* Error / Success Notifications */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex flex-col gap-1.5">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span className="leading-snug">{errorMessage}</span>
            </div>
            {mode === 'login' && (
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setErrorMessage(null);
                }}
                className="text-left text-[11px] font-bold text-rose-700 hover:text-rose-900 underline ml-6 cursor-pointer"
              >
                {language === 'bn' ? '👉 নতুন একাউন্ট খুলতে এখানে ক্লিক করুন' : '👉 Click here to create a new account'}
              </button>
            )}
          </div>
        )}

        {successMessage && (
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Main Form */}
        <form onSubmit={handleEmailSubmit} className="space-y-3 text-xs text-neutral-900">
          {mode === 'register' && (
            <div>
              <label className="block font-bold text-neutral-800 mb-1">
                {language === 'bn' ? 'আপনার নাম *' : 'Full Name *'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={language === 'bn' ? 'আপনার পূর্ণ নাম লিখুন' : 'Enter your full name'}
                  style={{ color: '#111827', backgroundColor: '#FFFFFF' }}
                  className="w-full pl-9 pr-3 py-2.5 bg-white text-neutral-900 placeholder:text-neutral-400 font-semibold border border-neutral-300 rounded-xl focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-hidden"
                />
                <User className="w-4 h-4 text-neutral-500 absolute left-3 top-3.5" />
              </div>
            </div>
          )}

          <div>
            <label className="block font-bold text-neutral-800 mb-1">
              {language === 'bn' ? 'জিমেইল / ইমেইল *' : 'Gmail / Email *'}
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={language === 'bn' ? 'ইমেইল লিখুন (e.g. name@gmail.com)' : 'Enter email (e.g. name@gmail.com)'}
                style={{ color: '#111827', backgroundColor: '#FFFFFF' }}
                className="w-full pl-9 pr-3 py-2.5 bg-white text-neutral-900 placeholder:text-neutral-400 font-semibold border border-neutral-300 rounded-xl focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-hidden"
              />
              <Mail className="w-4 h-4 text-neutral-500 absolute left-3 top-3.5" />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block font-bold text-neutral-800 mb-1">
                {language === 'bn' ? 'মোবাইল নম্বর *' : 'Mobile Number *'}
              </label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  style={{ color: '#111827', backgroundColor: '#FFFFFF' }}
                  className="w-full pl-9 pr-3 py-2.5 bg-white text-neutral-900 placeholder:text-neutral-400 font-mono font-bold border border-neutral-300 rounded-xl focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-hidden"
                />
                <Phone className="w-4 h-4 text-neutral-500 absolute left-3 top-3.5" />
              </div>
            </div>
          )}

          {mode !== 'forgot' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-bold text-neutral-800">
                  {language === 'bn' ? 'পাসওয়ার্ড *' : 'Password *'}
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot');
                      setErrorMessage(null);
                    }}
                    className="text-[11px] text-rose-600 hover:text-rose-700 font-bold"
                  >
                    {language === 'bn' ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={language === 'bn' ? 'কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড' : 'At least 6 characters'}
                  style={{ color: '#111827', backgroundColor: '#FFFFFF' }}
                  className="w-full pl-9 pr-9 py-2.5 bg-white text-neutral-900 placeholder:text-neutral-400 font-mono font-bold border border-neutral-300 rounded-xl focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 focus:outline-hidden"
                />
                <Lock className="w-4 h-4 text-neutral-500 absolute left-3 top-3.5" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-neutral-500 hover:text-neutral-700 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{language === 'bn' ? 'অপেক্ষা করুন...' : 'Processing...'}</span>
              </>
            ) : mode === 'login' ? (
              <>
                <span>{language === 'bn' ? 'লগইন করুন' : 'Sign In'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : mode === 'register' ? (
              <>
                <span>{language === 'bn' ? 'অ্যাকাউন্ট তৈরি সম্পন্ন করুন' : 'Create Account'}</span>
                <CheckCircle2 className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>{language === 'bn' ? 'রিসেট লিংক পাঠান' : 'Send Reset Link'}</span>
                <Mail className="w-4 h-4" />
              </>
            )}
          </button>

          {mode === 'forgot' && (
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className="w-full text-center text-xs text-rose-600 hover:underline pt-2 font-semibold"
            >
              {language === 'bn' ? 'লগইনে ফিরে যান' : 'Back to Login'}
            </button>
          )}
        </form>
      </div>
    </div>
  );
};
