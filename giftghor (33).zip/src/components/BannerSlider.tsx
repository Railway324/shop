import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight, Sparkles, ShoppingBag } from 'lucide-react';
import { Banner, Language, CategoryId, Product, WebsiteCustomizerSettings } from '../types';
import { getOptimizedImageUrl } from '../utils/imageOptimizer';
import { getStoredDeletedProductIdsSet } from '../utils/storage';

interface BannerSliderProps {
  banners?: Banner[];
  products?: Product[];
  language: Language;
  onSelectCategory: (cat: CategoryId) => void;
  onExplore: () => void;
  onSelectProduct?: (product: Product) => void;
  customizerSettings?: WebsiteCustomizerSettings;
}

export const BannerSlider: React.FC<BannerSliderProps> = React.memo(({
  products = [],
  language,
  onSelectCategory,
  onExplore,
  onSelectProduct,
  customizerSettings,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Dynamically generate banners directly from top 6 valid products or customizer settings in O(1)
  const activeBanners: Banner[] = useMemo(() => {
    const deletedIds = getStoredDeletedProductIdsSet();
    const rawCustom = customizerSettings?.heroBanners;

    if (Array.isArray(rawCustom) && rawCustom.length > 0) {
      const validCustomBanners = rawCustom.filter((b: any) => {
        if (!b) return false;
        const bLink = String(b.linkUrl || '').trim();
        const bId = String(b.id || '').trim();
        if (bLink && deletedIds.has(bLink)) return false;
        if (bId.startsWith('banner-') && deletedIds.has(bId.replace('banner-', ''))) return false;
        const title = `${b.titleBn || ''} ${b.titleEn || ''}`;
        if (title.includes('হ্যাপি শপস') || title.includes('Happy Shops')) return false;
        if (b.imageUrl && typeof b.imageUrl === 'string' && (b.imageUrl.includes('/products/drive/') || (b.imageUrl.includes('logo.png') && products.length > 0))) return false;
        return true;
      });
      if (validCustomBanners.length > 0) {
        return validCustomBanners;
      }
    }

    const topProducts: Product[] = [];
    for (let i = 0; i < products.length && topProducts.length < 6; i++) {
      const p = products[i];
      if (p && p.id && p.status !== 'inactive' && !deletedIds.has(String(p.id).trim())) {
        topProducts.push(p);
      }
    }

    if (topProducts.length > 0) {
      const gradients = [
        'from-rose-700 via-rose-800 to-neutral-950',
        'from-indigo-800 via-purple-900 to-neutral-950',
        'from-emerald-700 via-teal-900 to-neutral-950',
        'from-amber-700 via-rose-900 to-neutral-950',
        'from-blue-700 via-indigo-900 to-neutral-950'
      ];

      return topProducts.map((prod, idx) => {
        const discountText = prod.originalPrice && prod.originalPrice > prod.price
          ? `${Math.round(((prod.originalPrice - prod.price) / prod.originalPrice) * 100)}% বিশেষ ছাড়`
          : 'প্রিমিয়াম কালেকশন';

        return {
          id: `banner-${prod.id}`,
          titleBn: prod.titleBn || prod.titleEn || 'প্রিমিয়াম প্রোডাক্ট',
          titleEn: prod.titleEn || prod.titleBn || 'Premium Product',
          subtitleBn: `মূল্য মাত্র ৳${prod.price} টাকা • ক্যাশ অন ডেলিভারি সুবিধা • ১০০% অরিজিনাল`,
          subtitleEn: `Price: ৳${prod.price} BDT • Cash on Delivery Available • 100% Authentic`,
          badgeBn: discountText,
          badgeEn: prod.originalPrice && prod.originalPrice > prod.price ? 'Special Offer' : 'Exclusive Item',
          buttonTextBn: 'এখনই কিনুন',
          buttonTextEn: 'Order Now',
          bgGradient: gradients[idx % gradients.length],
          imageUrl: prod.image || '/favicon.png',
          linkCategory: prod.category || 'all',
          linkUrl: prod.id
        };
      });
    }

    const bNameBn = customizerSettings?.brandNameBn || 'হ্যাপি শপিং';
    const bNameEn = customizerSettings?.brandNameEn || 'Happy Shopping';
    const storeBadgeBn = customizerSettings?.showOfficialStoreBadge 
      ? ` ${customizerSettings?.officialStoreBadgeBn || 'অফিশিয়াল স্টোর'}` 
      : '';
    const storeBadgeEn = customizerSettings?.showOfficialStoreBadge 
      ? ` ${customizerSettings?.officialStoreBadgeEn || 'Official Store'}` 
      : '';

    return [
      {
        id: 'default-brand',
        titleBn: `${bNameBn}${storeBadgeBn}`,
        titleEn: `${bNameEn}${storeBadgeEn}`,
        subtitleBn: `${customizerSettings?.taglineBn || 'সেরা পণ্য • সুন্দর জীবন'} | প্রিমিয়াম পোশাক, ফ্যাশন ও লাইফস্টাইল কালেকশন`,
        subtitleEn: `${customizerSettings?.taglineEn || 'Better Product • Happier You'} | Authentic Apparel, Gifts & Fashion`,
        badgeBn: '১০০% অরিজিনাল',
        badgeEn: '100% Authentic',
        buttonTextBn: 'কালেকশন দেখুন',
        buttonTextEn: 'Explore Shop',
        bgGradient: 'from-rose-700 via-rose-800 to-neutral-950',
        imageUrl: customizerSettings?.logoUrl || '/favicon.png',
        linkCategory: 'all'
      }
    ];
  }, [customizerSettings, products]);

  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const timer = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [activeBanners.length]);

  // Reset index if out of bounds
  useEffect(() => {
    if (currentIndex >= activeBanners.length) {
      setCurrentIndex(0);
    }
  }, [activeBanners.length, currentIndex]);

  // Preload next banner image for instant transitions
  useEffect(() => {
    if (activeBanners.length > 1) {
      const nextIdx = (currentIndex + 1) % activeBanners.length;
      const nextBanner = activeBanners[nextIdx];
      if (nextBanner?.imageUrl) {
        const img = new Image();
        img.src = getOptimizedImageUrl(nextBanner.imageUrl, 600, 80);
      }
    }
  }, [currentIndex, activeBanners]);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
  };

  const currentBanner = activeBanners[currentIndex] || activeBanners[0];
  if (!currentBanner) return null;

  const handleAction = () => {
    if (currentBanner.linkUrl && onSelectProduct) {
      const targetProd = products.find(p => p.id === currentBanner.linkUrl);
      if (targetProd) {
        onSelectProduct(targetProd);
        return;
      }
    }

    if (currentBanner.linkCategory) {
      onSelectCategory(currentBanner.linkCategory);
    }
    onExplore();
  };

  const heroOptimizedUrl = getOptimizedImageUrl(currentBanner.imageUrl, 600, 80);

  return (
    <div className="relative overflow-hidden rounded-2xl md:rounded-3xl shadow-sm border border-neutral-100 bg-neutral-900 group w-full">
      {/* Background slide */}
      <div 
        className={`relative w-full min-h-[200px] sm:min-h-[260px] md:min-h-[320px] flex items-center bg-gradient-to-r ${currentBanner.bgGradient} transition-all duration-700 ease-out`}
      >
        {/* Pattern overlay */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]"></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-8 md:px-12 py-5 sm:py-7 w-full flex flex-row items-center justify-between gap-3 sm:gap-6">
          {/* Text Content */}
          <div className="flex-1 text-white space-y-2 sm:space-y-3 text-left">
            <div className="inline-flex items-center gap-1 sm:gap-1.5 px-2.5 py-0.5 sm:py-1 rounded-full text-[10px] sm:text-xs font-bold uppercase tracking-wider bg-white/20 backdrop-blur-xs text-white border border-white/30 shadow-xs">
              <Sparkles className="w-3 h-3 text-amber-300 shrink-0" />
              <span>{language === 'bn' ? currentBanner.badgeBn : currentBanner.badgeEn}</span>
            </div>

            <h1 className="text-base sm:text-2xl md:text-3xl lg:text-4xl font-extrabold tracking-tight leading-tight line-clamp-2">
              {language === 'bn' ? currentBanner.titleBn : currentBanner.titleEn}
            </h1>

            <p className="text-xs sm:text-sm md:text-base text-white/90 font-normal max-w-md line-clamp-2 leading-snug">
              {language === 'bn' ? currentBanner.subtitleBn : currentBanner.subtitleEn}
            </p>

            <div className="pt-1 sm:pt-2 flex flex-wrap items-center gap-2 sm:gap-3">
              <button
                id="banner-cta-btn"
                onClick={handleAction}
                className="px-3.5 py-1.5 sm:px-5 sm:py-2.5 rounded-xl bg-white text-rose-700 hover:bg-neutral-100 font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <ShoppingBag className="w-3.5 h-3.5 text-rose-700" />
                <span>{language === 'bn' ? currentBanner.buttonTextBn : currentBanner.buttonTextEn}</span>
                <ArrowRight className="w-3.5 h-3.5 text-rose-700" />
              </button>

              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-black/25 text-white/90 text-xs backdrop-blur-xs">
                <span>৳ ক্যাশ অন ডেলিভারি</span>
              </div>
            </div>
          </div>

          {/* Product Hero Image */}
          <div 
            onClick={handleAction}
            className="w-28 h-28 sm:w-44 sm:h-44 md:w-60 md:h-60 shrink-0 flex items-center justify-center cursor-pointer group-hover:scale-105 transition-transform"
          >
            <div className="relative w-full h-full">
              <img
                src={heroOptimizedUrl}
                alt={currentBanner.titleEn || 'Product Image'}
                className="w-full h-full object-cover rounded-xl sm:rounded-2xl shadow-xl border-2 sm:border-4 border-white/30 bg-neutral-800"
                loading="eager"
                decoding="async"
                fetchPriority="high"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  const clean = currentBanner.imageUrl ? currentBanner.imageUrl.replace('public//storage', 'public/storage') : '';
                  if (clean && target.src !== clean && !target.src.includes('image-proxy')) {
                    target.src = clean;
                    return;
                  }
                  if (clean && !target.src.includes('image-proxy')) {
                    target.src = `/api/image-proxy?url=${encodeURIComponent(clean)}`;
                  }
                }}
              />
            </div>
          </div>
        </div>

        {/* Carousel Arrow Controls */}
        {activeBanners.length > 1 && (
          <>
            <button
              onClick={prevSlide}
              aria-label="Previous Slide"
              className="absolute left-1.5 sm:left-3 top-1/2 -translate-y-1/2 w-7 h-7 sm:w-10 sm:h-10 rounded-full bg-black/30 hover:bg-white/80 text-white hover:text-neutral-900 flex items-center justify-center backdrop-blur-xs transition-all cursor-pointer opacity-80 sm:opacity-0 group-hover:opacity-100"
            >
              <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            <button
              onClick={nextSlide}
              aria-label="Next Slide"
              className="absolute right-1.5 sm:right-3 top-1/2 -translate-y-1/2 w-7 h-7 sm:w-10 sm:h-10 rounded-full bg-black/30 hover:bg-white/80 text-white hover:text-neutral-900 flex items-center justify-center backdrop-blur-xs transition-all cursor-pointer opacity-80 sm:opacity-0 group-hover:opacity-100"
            >
              <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            {/* Dot Indicators */}
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
              {activeBanners.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  aria-label={`Go to slide ${idx + 1}`}
                  className={`h-1.5 rounded-full transition-all cursor-pointer ${
                    currentIndex === idx ? 'w-5 bg-white' : 'w-1.5 bg-white/40 hover:bg-white/60'
                  }`}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
});

