import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  ShieldCheck, 
  Mail, 
  Globe, 
  X,
  Sparkles,
  User,
  LogOut,
  ChevronDown,
  Truck
} from 'lucide-react';
import { Language, CategoryId, Product, UserProfile, WebsiteCustomizerSettings } from '../types';
import { translations, formatPrice, toBengaliNumber } from '../utils/translations';
import { isUserAdmin } from '../lib/firebase';
import { getOptimizedImageUrl } from '../utils/imageOptimizer';

interface HeaderProps {
  language: Language;
  onToggleLanguage: () => void;
  activeView: string;
  onChangeView: (view: any) => void;
  onSelectCategory: (cat: CategoryId) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  products: Product[];
  onSelectProduct: (p: Product) => void;
  userProfile: UserProfile | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenCart?: () => void;
  cartCount?: number;
  onOpenTracking?: (q?: string) => void;
  customizerSettings?: WebsiteCustomizerSettings;
}

export const Header: React.FC<HeaderProps> = React.memo(({
  language,
  onToggleLanguage,
  activeView,
  onChangeView,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  products,
  onSelectProduct,
  userProfile,
  onOpenAuth,
  onLogout,
  onOpenCart,
  cartCount = 0,
  onOpenTracking,
  customizerSettings,
}) => {
  const t = translations[language];
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const tagline = customizerSettings
    ? (language === 'bn' ? customizerSettings.taglineBn : customizerSettings.taglineEn)
    : (language === 'bn' ? 'সেরা পণ্য • সুন্দর জীবন' : 'Better Product • Happier You');
  const rawLogo = customizerSettings?.logoUrl || '/favicon.png';
  const logoUrl = rawLogo.startsWith('/logo.png') ? '/favicon.png' : rawLogo;

  // Fast O(k) early-exit memoized autocomplete (stops as soon as 5 matches are found)
  const matchingProducts = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (q.length < 2) return [];
    const results: Product[] = [];
    for (let i = 0; i < products.length; i++) {
      const p = products[i];
      if (!p || p.status === 'inactive') continue;
      if (
        (p.titleEn && p.titleEn.toLowerCase().includes(q)) ||
        (p.titleBn && p.titleBn.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q))
      ) {
        results.push(p);
        if (results.length >= 5) break;
      }
    }
    return results;
  }, [searchQuery, products]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSearchDropdown(false);
    onChangeView('products');
  };

  return (
    <header className="sticky top-0 z-40 bg-[#45030C] sm:bg-[#45030C]/95 sm:backdrop-blur-md shadow-md border-b border-[#6B0B1D] w-full text-white transform-gpu">
      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2.5 sm:py-3.5 space-y-2.5 sm:space-y-0">
        {/* Row 1 on Mobile / Full Row on Desktop */}
        <div className="flex items-center justify-between gap-2 sm:gap-4 md:gap-6">
          {/* Brand Logo */}
          <button
            id="brand-logo-btn"
            onClick={() => {
              onSelectCategory('all');
              onChangeView('home');
            }}
            className="flex items-center gap-2 sm:gap-3 text-left group shrink-0 cursor-pointer"
          >
            <div className="relative w-9 h-9 sm:w-11 sm:h-11 rounded-full overflow-hidden ring-2 ring-amber-400 bg-white shadow-sm shadow-amber-500/20 group-hover:scale-105 transition-transform flex items-center justify-center shrink-0">
              <img
                src={logoUrl}
                alt="Happy Shopping Logo"
                width={44}
                height={44}
                decoding="async"
                fetchPriority="high"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="text-lg sm:text-xl md:text-2xl font-black tracking-tight text-white flex items-center leading-none">
                {language === 'bn' ? (
                  <>
                    <span>{customizerSettings?.brandNameBn || 'হ্যাপি শপিং'}</span>
                  </>
                ) : (
                  <>
                    <span className="text-white font-black">Happy</span>
                    <span className="text-amber-400 font-extrabold ml-1">
                      {customizerSettings?.brandAccentWordEn || 'Shopping'}
                    </span>
                  </>
                )}
              </span>
              <p className="text-[9px] sm:text-[10px] text-amber-300 font-bold hidden sm:block mt-0.5 tracking-tight">
                {tagline}
              </p>
            </div>
          </button>

          {/* Desktop Search Bar (Visible on sm and larger) */}
          <div className="relative flex-1 max-w-xl hidden sm:block">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <input
                id="search-input-field-desktop"
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  onSearchChange(e.target.value);
                  setShowSearchDropdown(true);
                }}
                onFocus={() => setShowSearchDropdown(true)}
                placeholder={t.searchPlaceholder}
                className="w-full pl-4 pr-24 py-2 sm:py-2.5 text-xs sm:text-sm rounded-full border-2 border-[#800020] focus:outline-hidden focus:ring-2 focus:ring-amber-400/30 focus:border-amber-400 transition bg-[#240106] text-white placeholder-neutral-400"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  className="absolute right-12 sm:right-14 text-neutral-400 hover:text-neutral-200 p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                id="search-submit-btn-desktop"
                type="submit"
                className="absolute right-1 top-1 bottom-1 px-3 sm:px-4 bg-gradient-to-r from-[#9B111E] to-[#600010] hover:from-[#C00030] hover:to-[#800020] text-amber-200 rounded-full flex items-center justify-center text-xs sm:text-sm font-medium transition shadow-xs cursor-pointer border border-amber-500/30"
              >
                <Search className="w-4 h-4" />
              </button>
            </form>

            {/* Live Autocomplete Dropdown */}
            {showSearchDropdown && matchingProducts.length > 0 && (
              <div 
                className="absolute top-full left-0 right-0 mt-2 bg-[#240106] rounded-2xl shadow-2xl border border-[#6B0B1D] z-50 overflow-hidden divide-y divide-[#3B0208]"
                onMouseLeave={() => setShowSearchDropdown(false)}
              >
                <div className="p-2 bg-[#45030C] text-xs font-semibold text-amber-300 flex items-center justify-between border-b border-[#6B0B1D]">
                  <span>{language === 'bn' ? 'সরাসরি পণ্য সমূহ' : 'Matching Products'}</span>
                  <span className="text-[11px] text-neutral-400">{language === 'bn' ? 'ক্লিক করে বিস্তারিত দেখুন' : 'Click to view'}</span>
                </div>
                {matchingProducts.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectProduct(p);
                      setShowSearchDropdown(false);
                    }}
                    className="w-full px-3 py-2 text-left flex items-center gap-3 hover:bg-[#45030C] transition cursor-pointer"
                  >
                    <img
                      src={getOptimizedImageUrl(p.image, 96, 70)}
                      alt={p.titleEn}
                      loading="lazy"
                      decoding="async"
                      className="w-10 h-10 rounded-lg object-cover border border-[#6B0B1D] bg-[#180004]"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-neutral-100 truncate">
                        {language === 'bn' ? p.titleBn : p.titleEn}
                      </p>
                      <p className="text-xs font-bold text-amber-400">
                        {formatPrice(p.price, language)}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Track Order Button */}
            <button
              id="header-track-order-btn"
              onClick={() => onOpenTracking?.()}
              className="flex items-center gap-1.5 bg-[#2A0005] hover:bg-[#5B0616] text-amber-200 hover:text-amber-100 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-full border border-[#800020] text-xs font-bold transition shadow-xs cursor-pointer"
              title={language === 'bn' ? 'অর্ডার ট্র্যাক করুন' : 'Track Order'}
            >
              <Truck className="w-4 h-4 text-amber-400" />
              <span className="hidden md:inline-block">
                {language === 'bn' ? 'অর্ডার ট্র্যাক' : 'Track Order'}
              </span>
            </button>

            {/* Cart Button */}
            <button
              id="header-cart-btn"
              onClick={onOpenCart}
              className="relative flex items-center gap-1.5 bg-gradient-to-r from-[#9B111E] to-[#600010] hover:from-[#C00030] hover:to-[#800020] text-amber-200 border border-amber-500/40 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs font-bold transition shadow-md cursor-pointer"
              title={language === 'bn' ? 'শপিং কার্ট দেখুন' : 'View Shopping Cart'}
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline-block">
                {language === 'bn' ? 'কার্ট' : 'Cart'}
              </span>
              {cartCount > 0 && (
                <span className="bg-amber-400 text-neutral-950 text-[10px] font-black px-1.5 py-0.2 rounded-full shadow-xs">
                  {language === 'bn' ? toBengaliNumber(cartCount) : cartCount}
                </span>
              )}
            </button>

            {/* User Account / Login Button */}
            {userProfile ? (
              <div className="relative">
                <button
                  id="header-user-account-btn"
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-1.5 sm:gap-2 bg-neutral-50 hover:bg-neutral-100 text-neutral-800 p-1.5 sm:px-3 sm:py-1.5 rounded-full border border-neutral-200 transition cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-full bg-[#800020] text-white flex items-center justify-center text-xs font-bold shadow-xs overflow-hidden">
                    {userProfile.photoURL ? (
                      <img src={userProfile.photoURL} alt={userProfile.displayName} className="w-full h-full object-cover" />
                    ) : (
                      userProfile.displayName ? userProfile.displayName.charAt(0).toUpperCase() : 'U'
                    )}
                  </div>
                  <span className="text-xs font-bold max-w-[80px] truncate hidden md:inline-block">
                    {userProfile.displayName || (language === 'bn' ? 'প্রোফাইল' : 'Profile')}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-neutral-400 hidden sm:block" />
                </button>

                {/* Dropdown Menu */}
                {showUserMenu && (
                  <div 
                    className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-neutral-100 py-1.5 z-50 divide-y divide-neutral-100 text-xs animate-fadeIn"
                    onMouseLeave={() => setShowUserMenu(false)}
                  >
                    <div className="px-3 py-2">
                      <p className="font-bold text-neutral-900 truncate">{userProfile.displayName}</p>
                      <p className="text-[11px] text-neutral-500 font-mono truncate">{userProfile.email}</p>
                    </div>
                    <div className="py-1">
                      {isUserAdmin(userProfile) && (
                        <button
                          onClick={() => {
                            onChangeView('admin');
                            setShowUserMenu(false);
                          }}
                          className="w-full px-3 py-2 text-left hover:bg-[#800020]/10 text-[#800020] font-bold flex items-center gap-2 cursor-pointer bg-[#800020]/5"
                        >
                          <ShieldCheck className="w-4 h-4 text-[#800020]" />
                          <span>{language === 'bn' ? 'অ্যাডমিন ড্যাশবোর্ড' : 'Admin Panel'}</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          onChangeView('account');
                          setShowUserMenu(false);
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-[#800020]/10 text-neutral-700 hover:text-[#800020] font-semibold flex items-center gap-2 cursor-pointer"
                      >
                        <User className="w-4 h-4 text-[#800020]" />
                        <span>{language === 'bn' ? 'আমার প্রোফাইল ও অর্ডার' : 'My Account & Orders'}</span>
                      </button>
                    </div>
                    <div className="py-1">
                      <button
                        onClick={() => {
                          onLogout();
                          setShowUserMenu(false);
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-[#800020]/10 text-[#800020] font-semibold flex items-center gap-2 cursor-pointer"
                      >
                        <LogOut className="w-4 h-4 text-[#800020]" />
                        <span>{language === 'bn' ? 'লগআউট' : 'Sign Out'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                id="header-login-btn"
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 bg-[#2A0005] hover:bg-[#5B0616] text-amber-200 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-full border border-[#800020] text-xs font-bold transition shadow-xs cursor-pointer"
              >
                <User className="w-4 h-4 text-amber-400" />
                <span className="hidden sm:inline-block">
                  {language === 'bn' ? 'লগইন / সাইন আপ' : 'Login / Register'}
                </span>
                <span className="sm:hidden text-[11px]">
                  {language === 'bn' ? 'লগইন' : 'Login'}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* Row 2 on Mobile: Dedicated Full-Width Search Input */}
        <div className="sm:hidden relative w-full pt-1">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center w-full">
            <input
              id="search-input-field-mobile"
              type="text"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                setShowSearchDropdown(true);
              }}
              onFocus={() => setShowSearchDropdown(true)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-3.5 pr-20 py-2 text-xs rounded-full border-2 border-[#800020] focus:outline-hidden focus:ring-2 focus:ring-amber-400/30 focus:border-amber-400 transition bg-[#240106] text-white placeholder-neutral-400"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute right-10 text-neutral-400 hover:text-neutral-200 p-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              id="search-submit-btn-mobile"
              type="submit"
              className="absolute right-1 top-1 bottom-1 px-3 bg-gradient-to-r from-[#9B111E] to-[#600010] text-amber-200 rounded-full flex items-center justify-center text-xs font-bold shadow-xs cursor-pointer border border-amber-500/30"
            >
              <Search className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Live Mobile Autocomplete Dropdown */}
          {showSearchDropdown && matchingProducts.length > 0 && (
            <div 
              className="absolute top-full left-0 right-0 mt-1.5 bg-[#240106] rounded-2xl shadow-2xl border border-[#6B0B1D] z-50 overflow-hidden divide-y divide-[#3B0208] max-h-72 overflow-y-auto"
            >
              <div className="p-2 bg-[#45030C] text-[11px] font-semibold text-amber-300 flex items-center justify-between border-b border-[#6B0B1D]">
                <span>{language === 'bn' ? 'সরাসরি পণ্য সমূহ' : 'Matching Products'}</span>
                <button 
                  type="button" 
                  onClick={() => setShowSearchDropdown(false)}
                  className="text-neutral-400 hover:text-neutral-200"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
              {matchingProducts.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    onSelectProduct(p);
                    setShowSearchDropdown(false);
                  }}
                  className="w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-[#45030C] transition cursor-pointer"
                >
                  <img
                    src={getOptimizedImageUrl(p.image, 96, 70)}
                    alt={p.titleEn}
                    loading="lazy"
                    decoding="async"
                    className="w-9 h-9 rounded-lg object-cover border border-[#6B0B1D] bg-[#180004] shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-neutral-100 truncate">
                      {language === 'bn' ? p.titleBn : p.titleEn}
                    </p>
                    <p className="text-xs font-bold text-amber-400">
                      {formatPrice(p.price, language)}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Desktop Quick Nav Category Links */}
        <nav className="hidden md:flex items-center justify-between border-t border-[#6B0B1D]/70 mt-2.5 pt-2 text-xs font-medium text-neutral-200">
          <div className="flex items-center gap-5">
            <button
              id="nav-home-btn"
              onClick={() => {
                onSelectCategory('all');
                onChangeView('home');
              }}
              className={`hover:text-amber-300 transition flex items-center gap-1 cursor-pointer ${
                activeView === 'home' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              <span>{t.homeNav}</span>
            </button>

            <button
              id="nav-all-products-btn"
              onClick={() => {
                onSelectCategory('all');
                onChangeView('products');
              }}
              className={`hover:text-amber-300 transition flex items-center gap-1 cursor-pointer ${
                activeView === 'products' ? 'text-amber-400 font-bold' : ''
              }`}
            >
              <span>{t.allProductsNav}</span>
            </button>

            <button
              onClick={() => {
                onSelectCategory('womens-fashion');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? 'ওমেনস ফ্যাশন' : "Women's Fashion"}
            </button>

            <button
              onClick={() => {
                onSelectCategory('jewelry');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? "জুয়েলারি (Jewelry's)" : "Jewelry's"}
            </button>

            <button
              onClick={() => {
                onSelectCategory('watches');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? 'ঘড়ি কালেকশন' : 'Watches'}
            </button>

            <button
              onClick={() => {
                onSelectCategory('gadgets-electronics');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? 'স্মার্ট গ্যাজেটস' : 'Gadgets & Electronics'}
            </button>

            <button
              onClick={() => {
                onSelectCategory('mens-fashion');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? 'মেনস ফ্যাশন' : "Men's Fashion"}
            </button>

            <button
              onClick={() => {
                onSelectCategory('home-lifestyle');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? 'হোম ও লাইফস্টাইল' : 'Home & Lifestyle'}
            </button>

            <button
              onClick={() => {
                onSelectCategory('kids-zone');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? 'কিডস জোন' : 'Kids Zone'}
            </button>

            <button
              onClick={() => {
                onSelectCategory('foods');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? "ফুডস (Food's)" : "Food's"}
            </button>

            <button
              onClick={() => {
                onSelectCategory('winter');
                onChangeView('products');
              }}
              className="hover:text-amber-300 transition cursor-pointer"
            >
              {language === 'bn' ? 'উইন্টার ও হুডি' : 'Winter & Hoodies'}
            </button>
          </div>

          <div className="flex items-center gap-3 text-rose-600 font-semibold">
            <span className="flex items-center gap-1 text-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              {t.authenticGuaranteed}
            </span>
            <span className="text-neutral-300">|</span>
            <span className="text-neutral-600 text-xs">
              {t.codAvailable}
            </span>
          </div>
        </nav>
      </div>
    </header>
  );
});
