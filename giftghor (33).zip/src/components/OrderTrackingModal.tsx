import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Truck, 
  Package, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Phone, 
  X, 
  AlertCircle, 
  Copy, 
  Check, 
  ExternalLink,
  ChevronRight,
  Sparkles,
  RotateCcw,
  ShieldCheck,
  MessageCircle
} from 'lucide-react';
import { Order, OrderStatus, Language } from '../types';
import { formatPrice, toBengaliNumber, toEnglishNumber } from '../utils/translations';
import { getStoredOrders } from '../utils/storage';
import { getAllOrdersFromFirestore } from '../lib/firebase';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  orders?: Order[];
  initialQuery?: string;
  onSelectProduct?: (product: any) => void;
}

interface TimelineStep {
  status: OrderStatus;
  titleBn: string;
  titleEn: string;
  descBn: string;
  descEn: string;
}

const TRACKING_STEPS: TimelineStep[] = [
  {
    status: 'pending',
    titleBn: 'অর্ডার গৃহীত হয়েছে',
    titleEn: 'Order Placed',
    descBn: 'আপনার অর্ডার সফলভাবে সিস্টেমে রেকর্ড করা হয়েছে।',
    descEn: 'Your order has been recorded in our system.'
  },
  {
    status: 'processing',
    titleBn: 'কনফার্ম ও প্রসেসিং',
    titleEn: 'Confirmed & Processing',
    descBn: 'অর্ডার নিশ্চিত করে প্যাকিংয়ের কাজ শুরু হয়েছে।',
    descEn: 'Order verified and sent for packaging.'
  },
  {
    status: 'shipped',
    titleBn: 'কুরিয়ারে হস্তান্তর',
    titleEn: 'Handed to Courier',
    descBn: 'পার্সেল কুরিয়ার পার্টনারের (SteadFast/Pathao) কাছে পাঠানো হয়েছে।',
    descEn: 'Parcel handed over to delivery courier partner.'
  },
  {
    status: 'delivered',
    titleBn: 'সফলভাবে ডেলিভারি সম্পন্ন',
    titleEn: 'Delivered',
    descBn: 'পণ্যটি আপনার ঠিকানায় সফলভাবে পৌঁছে দেওয়া হয়েছে।',
    descEn: 'Package successfully delivered to your address.'
  }
];

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  language,
  orders: propOrders = [],
  initialQuery = ''
}) => {
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [matchedOrders, setMatchedOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [hasCopiedId, setHasCopiedId] = useState(false);

  // Auto search if opened with an initialQuery
  useEffect(() => {
    if (isOpen) {
      if (initialQuery) {
        setSearchQuery(initialQuery);
        executeSearch(initialQuery);
      } else {
        setSearchQuery('');
        setHasSearched(false);
        setMatchedOrders([]);
        setSelectedOrder(null);
      }
    }
  }, [isOpen, initialQuery]);

  if (!isOpen) return null;

  const executeSearch = async (term: string) => {
    const raw = term.trim();
    if (!raw) return;

    const normalizedQuery = toEnglishNumber(raw).toLowerCase().replace(/^#/, '').trim();
    const cleanDigits = normalizedQuery.replace(/[^0-9]/g, '');

    setIsSearching(true);
    setHasSearched(true);
    setSelectedOrder(null);

    try {
      // 1. Check local & props orders
      const localOrders = getStoredOrders();
      const combinedPool = [...propOrders, ...localOrders];

      const isMatch = (o: Order) => {
        if (!o) return false;
        const oId = String(o.id || o.orderId || '').toLowerCase().replace(/^#/, '');
        const oPhone = toEnglishNumber(String(o.phone || '')).replace(/[^0-9]/g, '');
        const oName = String(o.customerName || '').toLowerCase();
        const oTracking = String(o.trackingCode || o.courierTrackingCode || '').toLowerCase();
        const oEmail = String(o.userEmail || '').toLowerCase();

        if (oId === normalizedQuery || oId.includes(normalizedQuery)) return true;
        if (cleanDigits && cleanDigits.length >= 4 && oPhone.includes(cleanDigits)) return true;
        if (cleanDigits && cleanDigits.length >= 4 && oId.includes(cleanDigits)) return true;
        if (oTracking && (oTracking === normalizedQuery || oTracking.includes(normalizedQuery))) return true;
        if (oName && oName.includes(normalizedQuery)) return true;
        if (oEmail && oEmail.includes(normalizedQuery)) return true;
        return false;
      };

      let results = combinedPool.filter(isMatch);

      // 2. Fallback check Firestore if local results are empty
      if (results.length === 0) {
        try {
          const firestoreOrders = await getAllOrdersFromFirestore();
          results = firestoreOrders.filter(isMatch);
        } catch {
          // ignore error
        }
      }

      // Deduplicate results by order ID
      const seen = new Set<string>();
      const deduplicated = results.filter(o => {
        const id = String(o.id || o.orderId);
        if (seen.has(id)) return false;
        seen.add(id);
        return true;
      });

      setMatchedOrders(deduplicated);
      if (deduplicated.length === 1) {
        setSelectedOrder(deduplicated[0]);
      }
    } catch (err) {
      console.error('Tracking search error:', err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    executeSearch(searchQuery);
  };

  const getStepStatus = (stepIndex: number, currentStatus: OrderStatus) => {
    if (currentStatus === 'cancelled') return 'cancelled';
    if (currentStatus === 'returned') return 'returned';

    const orderStatusMap: Record<string, number> = {
      pending: 0,
      placed: 0,
      confirmed: 1,
      processing: 1,
      packed: 1,
      shipped: 2,
      out_for_delivery: 2,
      delivered: 3,
      cancelled: -1,
      returned: -1,
      refunded: -1
    };

    const currentLevel = orderStatusMap[currentStatus] ?? 0;
    if (currentLevel > stepIndex) return 'completed';
    if (currentLevel === stepIndex) return 'current';
    return 'upcoming';
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setHasCopiedId(true);
    setTimeout(() => setHasCopiedId(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B0616] via-[#800020] to-neutral-950 p-5 sm:p-6 text-white relative">
          <button
            id="close-tracking-modal-btn"
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-2.5 text-amber-300 text-xs font-bold uppercase tracking-wider mb-1">
            <Truck className="w-4 h-4" />
            <span>{language === 'bn' ? 'লাইভ পার্সেল ট্র্যাকিং' : 'Live Order Tracking'}</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            {language === 'bn' ? 'অর্ডার ট্র্যাক করুন' : 'Track Your Delivery'}
          </h3>
          <p className="text-xs text-rose-100/90 mt-1 max-w-md">
            {language === 'bn'
              ? 'আপনার অর্ডার নম্বর (যেমন: ORD-xxx) অথবা মোবাইল নম্বর দিয়ে অর্ডারের বর্তমান অবস্থা জানুন।'
              : 'Enter your Order ID (e.g. ORD-xxx) or mobile phone number to check delivery progress.'}
          </p>

          {/* Search Input Bar */}
          <form onSubmit={handleSearch} className="mt-4 flex gap-2">
            <div className="relative flex-1">
              <input
                id="order-tracking-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={language === 'bn' ? 'অর্ডার আইডি বা মোবাইল নম্বর দিন (যেমন: 017xxxxxxxx)...' : 'Enter Order ID or 11-digit phone number...'}
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white/95 text-neutral-900 placeholder:text-neutral-500 text-xs sm:text-sm font-medium outline-none focus:ring-2 focus:ring-amber-400 shadow-inner"
              />
              <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3.5" />
            </div>
            <button
              id="submit-order-tracking-btn"
              type="submit"
              disabled={isSearching || !searchQuery.trim()}
              className="px-5 py-2.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-md transition cursor-pointer disabled:opacity-50"
            >
              {isSearching ? (
                <span>{language === 'bn' ? 'খোঁজা হচ্ছে...' : 'Searching...'}</span>
              ) : (
                <>
                  <Truck className="w-4 h-4" />
                  <span>{language === 'bn' ? 'ট্র্যাক' : 'Track'}</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Multiple matches list */}
          {!selectedOrder && matchedOrders.length > 1 && (
            <div className="space-y-3">
              <p className="text-xs font-bold text-neutral-700">
                {language === 'bn'
                  ? `আপনার নম্বরে ${toBengaliNumber(matchedOrders.length)}টি অর্ডার পাওয়া গেছে। বিস্তারিত দেখতে সিলেক্ট করুন:`
                  : `Found ${matchedOrders.length} orders. Select one to view tracking details:`}
              </p>
              <div className="divide-y divide-neutral-100 border border-neutral-200 rounded-2xl overflow-hidden">
                {matchedOrders.map((ord) => (
                  <button
                    key={ord.id}
                    onClick={() => setSelectedOrder(ord)}
                    className="w-full p-3.5 text-left flex items-center justify-between hover:bg-rose-50/50 transition cursor-pointer group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-neutral-900">#{ord.id}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          ord.orderStatus === 'delivered' ? 'bg-emerald-100 text-emerald-800' :
                          ord.orderStatus === 'shipped' ? 'bg-blue-100 text-blue-800' :
                          ord.orderStatus === 'cancelled' ? 'bg-red-100 text-red-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {ord.orderStatus?.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-500 mt-1">
                        {ord.date} • {ord.items?.length || 0} {language === 'bn' ? 'টি আইটেম' : 'items'} • {formatPrice(ord.total, language)}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-neutral-400 group-hover:text-[#800020] group-hover:translate-x-1 transition" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Selected Order Details View */}
          {selectedOrder && (
            <div className="space-y-5 animate-fadeIn">
              {matchedOrders.length > 1 && (
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="text-xs text-[#800020] hover:underline font-bold flex items-center gap-1 cursor-pointer"
                >
                  <span>← {language === 'bn' ? 'সকল অর্ডারে ফিরে যান' : 'Back to matching orders'}</span>
                </button>
              )}

              {/* Order Info Card */}
              <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-neutral-500">{language === 'bn' ? 'অর্ডার আইডি:' : 'Order ID:'}</span>
                    <span className="font-mono font-black text-sm text-neutral-900">#{selectedOrder.id}</span>
                    <button
                      onClick={() => handleCopy(selectedOrder.id)}
                      className="p-1 hover:bg-neutral-200 rounded text-neutral-500 transition cursor-pointer"
                      title="Copy Order ID"
                    >
                      {hasCopiedId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <div className="flex items-center flex-wrap gap-2 text-[11px] text-neutral-500 mt-0.5">
                    <span>{language === 'bn' ? 'তারিখ:' : 'Date:'} {selectedOrder.date || selectedOrder.createdAt?.split('T')[0]}</span>
                    <span>•</span>
                    <span>{selectedOrder.paymentMethod === 'bkash' ? 'bKash' : selectedOrder.paymentMethod === 'nagad' ? 'Nagad' : (language === 'bn' ? 'ক্যাশ অন ডেলিভারি (COD)' : 'Cash on Delivery')}</span>
                    <span>•</span>
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      (selectedOrder.paymentStatus === 'paid' || (selectedOrder.orderStatus === 'delivered' && (!selectedOrder.paymentMethod || selectedOrder.paymentMethod === 'cod')))
                        ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-100 text-amber-700 border border-amber-200'
                    }`}>
                      {(selectedOrder.paymentStatus === 'paid' || (selectedOrder.orderStatus === 'delivered' && (!selectedOrder.paymentMethod || selectedOrder.paymentMethod === 'cod')))
                        ? (language === 'bn' ? '✓ পেমেন্ট: পরিশোধিত (Paid)' : '✓ Payment: Paid')
                        : (language === 'bn' ? 'পেমেন্ট: বকেয়া (COD)' : 'Payment: Pending (COD)')}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-bold text-neutral-500">{language === 'bn' ? 'সর্বমোট মূল্য:' : 'Total Amount:'}</span>
                  <p className="text-base font-black text-[#800020]">
                    {formatPrice(selectedOrder.total, language)}
                  </p>
                </div>
              </div>

              {/* Courier Tracking Banner (if available) */}
              {(selectedOrder.courierTrackingCode || selectedOrder.trackingCode) && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs text-emerald-900">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="font-bold">
                        {selectedOrder.courierName || 'SteadFast Courier'} {language === 'bn' ? 'ট্র্যাকিং কোড:' : 'Tracking Code:'}
                      </span>
                      <span className="font-mono font-black ml-1.5">{selectedOrder.courierTrackingCode || selectedOrder.trackingCode}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleCopy(selectedOrder.courierTrackingCode || selectedOrder.trackingCode || '')}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] transition cursor-pointer"
                  >
                    {language === 'bn' ? 'কপি কোড' : 'Copy'}
                  </button>
                </div>
              )}

              {/* Stepper Timeline Tracker */}
              <div className="space-y-3 pt-1">
                <h4 className="text-xs font-black uppercase tracking-wider text-neutral-700">
                  {language === 'bn' ? 'ডেলিভারি অগ্রগতি' : 'Delivery Progress'}
                </h4>

                {selectedOrder.orderStatus === 'cancelled' ? (
                  <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-800 text-xs font-semibold flex items-center gap-2.5">
                    <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
                    <span>{language === 'bn' ? 'এই অর্ডারটি বাতিল (Cancelled) করা হয়েছে।' : 'This order has been cancelled.'}</span>
                  </div>
                ) : (
                  <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-2.5 sm:before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-neutral-200">
                    {TRACKING_STEPS.map((step, idx) => {
                      const state = getStepStatus(idx, selectedOrder.orderStatus);
                      return (
                        <div key={step.status} className="relative group">
                          {/* Dot / Icon */}
                          <div className={`absolute -left-6 sm:-left-8 top-0.5 w-5 sm:w-7 h-5 sm:h-7 rounded-full flex items-center justify-center transition-all ${
                            state === 'completed'
                              ? 'bg-emerald-500 text-white ring-4 ring-emerald-100'
                              : state === 'current'
                              ? 'bg-[#800020] text-white ring-4 ring-rose-100 animate-pulse'
                              : 'bg-neutral-200 text-neutral-400'
                          }`}>
                            {state === 'completed' ? (
                              <Check className="w-3 sm:w-4 h-3 sm:h-4 stroke-[3]" />
                            ) : (
                              <span className="text-[10px] font-bold">{idx + 1}</span>
                            )}
                          </div>

                          {/* Content */}
                          <div>
                            <div className="flex items-center gap-2">
                              <h5 className={`text-xs sm:text-sm font-bold ${
                                state === 'current' ? 'text-[#800020]' : state === 'completed' ? 'text-neutral-900' : 'text-neutral-400'
                              }`}>
                                {language === 'bn' ? step.titleBn : step.titleEn}
                              </h5>
                              {state === 'current' && (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-[#800020]">
                                  {language === 'bn' ? 'চলমান' : 'Current'}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] sm:text-xs text-neutral-500 mt-0.5">
                              {language === 'bn' ? step.descBn : step.descEn}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Delivery Address & Customer Info */}
              <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2 text-xs">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-[#800020] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-neutral-900">{selectedOrder.customerName}</span>
                    <p className="text-neutral-600 mt-0.5">{selectedOrder.address}</p>
                    <p className="text-neutral-500 font-mono text-[11px] mt-0.5">{selectedOrder.phone}</p>
                  </div>
                </div>
              </div>

              {/* Items in this order */}
              {selectedOrder.items && selectedOrder.items.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-neutral-700">
                    {language === 'bn' ? 'অর্ডারের পণ্যসমূহ:' : 'Ordered Items:'}
                  </h4>
                  <div className="divide-y divide-neutral-100 border border-neutral-200 rounded-2xl overflow-hidden">
                    {selectedOrder.items.map((item, i) => (
                      <div key={i} className="p-3 flex items-center justify-between gap-3 text-xs bg-white">
                        <div className="flex items-center gap-2.5 min-w-0">
                          {item.product?.image && (
                            <img
                              src={item.product.image}
                              alt=""
                              className="w-10 h-10 rounded-lg object-cover border border-neutral-200 shrink-0"
                            />
                          )}
                          <div className="min-w-0">
                            <p className="font-semibold text-neutral-900 truncate">
                              {language === 'bn' ? item.product?.titleBn : item.product?.titleEn}
                            </p>
                            <p className="text-[11px] text-neutral-500">
                              {language === 'bn' ? 'পরিমাণ:' : 'Qty:'} {item.quantity} {item.selectedColor ? `• ${item.selectedColor}` : ''} {item.selectedSize ? `• ${item.selectedSize}` : ''}
                            </p>
                          </div>
                        </div>
                        <span className="font-bold text-neutral-900 shrink-0">
                          {formatPrice((item.product?.price || 0) * item.quantity, language)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Empty / Not Found State */}
          {hasSearched && !isSearching && matchedOrders.length === 0 && (
            <div className="py-8 text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-rose-50 text-[#800020] flex items-center justify-center mx-auto">
                <Search className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-neutral-800 text-sm">
                {language === 'bn' ? 'কোনো অর্ডার পাওয়া যায়নি' : 'No Order Found'}
              </h4>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                {language === 'bn'
                  ? 'আপনার দেওয়া অর্ডার আইডি অথবা মোবাইল নম্বরটি সঠিক কিনা যাচাই করুন। অথবা সরাসরি হেল্পলাইনে যোগাযোগ করুন।'
                  : 'Please verify the Order ID or phone number entered. You can also contact our support helpline.'}
              </p>
            </div>
          )}

          {/* Initial Helper / Guidelines */}
          {!hasSearched && (
            <div className="py-6 text-center space-y-3 text-neutral-500">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <p className="text-xs max-w-sm mx-auto">
                {language === 'bn'
                  ? 'অর্ডার করার সময় ব্যবহৃত মোবাইল নম্বর অথবা প্রাপ্ত অর্ডার আইডি উপরে লিখে "ট্র্যাক" বাটনে চাপুন।'
                  : 'Enter the mobile number or Order ID provided during checkout to track delivery status.'}
              </p>
            </div>
          )}
        </div>

        {/* Footer Helpline */}
        <div className="p-3.5 sm:p-4 bg-neutral-50 border-t border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs text-neutral-600">
          <div className="flex items-center flex-wrap gap-2.5">
            <a
              href="https://wa.me/8801732408652?text=Hello%20Happy%20Shopping,%20I%20want%20to%20track%20my%20order"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition shadow-xs cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-emerald-100 text-emerald-100" />
              <span>{language === 'bn' ? 'হোয়াটসঅ্যাপে সাহায্য নিন' : 'WhatsApp Support'}</span>
            </a>
            <span className="font-bold text-neutral-800 font-mono">০১৭৩২৪০৮৬৫২</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-200 hover:bg-neutral-300 font-bold text-neutral-800 transition cursor-pointer"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
