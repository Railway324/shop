import React from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Clock, 
  Heart,
  Globe
} from 'lucide-react';
import { Language, WebsiteCustomizerSettings } from '../types';
import { translations } from '../utils/translations';
import { PolicyTab } from './LegalPolicyModal';

interface FooterProps {
  language: Language;
  onOpenAdmin?: () => void;
  onOpenPolicy?: (tab: PolicyTab) => void;
  onOpenTracking?: () => void;
  customizerSettings?: WebsiteCustomizerSettings;
}

export const Footer: React.FC<FooterProps> = React.memo(({
  language,
  onOpenPolicy,
  onOpenTracking,
  customizerSettings,
}) => {
  const t = translations[language];

  // Dynamic values
  const aboutText = customizerSettings
    ? (language === 'bn' ? customizerSettings.footerAboutBn : customizerSettings.footerAboutEn)
    : t.aboutShopDesc;

  const addressText = customizerSettings
    ? (language === 'bn' ? customizerSettings.officeAddressBn : customizerSettings.officeAddressEn)
    : t.addressText;

  const copyrightText = customizerSettings
    ? (language === 'bn' ? customizerSettings.copyrightTextBn : customizerSettings.copyrightTextEn)
    : t.allRightsReserved;

  const hotlineEmail = customizerSettings?.hotlineEmail || 'support@happyshopping.com';
  const rawFooterLogo = customizerSettings?.logoUrl || '/favicon.png';
  const logoUrl = rawFooterLogo.startsWith('/logo.png') ? '/favicon.png' : rawFooterLogo;
  const brandName = customizerSettings
    ? (language === 'bn' ? customizerSettings.brandNameBn : customizerSettings.brandNameEn)
    : (language === 'bn' ? 'হ্যাপি শপিং' : 'Happy Shopping');
  const tagline = customizerSettings
    ? (language === 'bn' ? customizerSettings.taglineBn : customizerSettings.taglineEn)
    : 'Better Product • Happier You';

  // Feature icon mapping
  const renderFeatureIcon = (iconName: string) => {
    switch (iconName) {
      case 'truck':
        return <Truck className="w-5 h-5" />;
      case 'shield':
        return <ShieldCheck className="w-5 h-5" />;
      case 'refresh':
        return <RotateCcw className="w-5 h-5" />;
      case 'clock':
        return <Clock className="w-5 h-5" />;
      default:
        return <ShieldCheck className="w-5 h-5" />;
    }
  };

  const features = customizerSettings?.features && customizerSettings.features.length > 0
    ? customizerSettings.features
    : [
        {
          id: '1',
          icon: 'truck' as const,
          titleBn: t.codAvailable,
          titleEn: 'Cash on Delivery',
          descBn: 'সারা দেশে দ্রুততম হোম ডেলিভারি',
          descEn: 'Nationwide express home delivery'
        },
        {
          id: '2',
          icon: 'shield' as const,
          titleBn: t.authenticGuaranteed,
          titleEn: '100% Authentic',
          descBn: 'সরাসরি খাঁটি ও অরিজিনাল পণ্য',
          descEn: 'Guaranteed original authentic products'
        },
        {
          id: '3',
          icon: 'refresh' as const,
          titleBn: t.easyReturn,
          titleEn: 'Easy Replacement',
          descBn: 'সমস্যা হলে ঝামেলাহীন রিপ্লেসমেন্ট',
          descEn: 'Hassle-free return on defects'
        },
        {
          id: '4',
          icon: 'clock' as const,
          titleBn: '২৪/৭ সাপোর্ট',
          titleEn: '24/7 Support',
          descBn: 'হটলাইন ও মেসেঞ্জারে সবসময় পাশে',
          descEn: 'Always ready to help on helpline'
        }
      ];

  return (
    <footer className="bg-[#1C0104] text-neutral-300 pt-12 pb-24 md:pb-24 border-t border-[#6B0B1D] text-xs">
      {/* Trust Assurance Strip */}
      {customizerSettings?.showFeaturesBar !== false && (
        <div className="max-w-7xl mx-auto px-4 mb-10 pb-8 border-b border-[#520510]">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((feat, idx) => (
              <div key={feat.id || idx} className="flex items-center gap-3 p-3 rounded-2xl bg-[#240106] border border-[#520510] shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
                  {renderFeatureIcon(feat.icon)}
                </div>
                <div>
                  <p className="font-bold text-white text-xs">
                    {language === 'bn' ? feat.titleBn : feat.titleEn}
                  </p>
                  <p className="text-[11px] text-neutral-400 line-clamp-1">
                    {language === 'bn' ? feat.descBn : feat.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full overflow-hidden ring-2 ring-amber-400 bg-white shrink-0">
                <img
                  src={logoUrl}
                  alt="Happy Shopping Logo"
                  width={40}
                  height={40}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <span className="text-xl font-black text-white">{brandName}</span>
                <p className="text-[10px] text-amber-400 font-semibold tracking-tight">{tagline}</p>
              </div>
            </div>
            <p className="text-neutral-300 text-xs leading-relaxed">
              {aboutText}
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-2 pt-2">
              {customizerSettings?.facebookUrl && (
                <a 
                  href={customizerSettings.facebookUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-lg bg-[#240106] border border-[#520510] hover:border-amber-400 text-neutral-300 hover:text-amber-300 flex items-center justify-center transition shadow-2xs"
                  title="Facebook"
                >
                  <Globe className="w-4 h-4" />
                </a>
              )}
              <a 
                href="https://wa.me/8801732408652" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 hover:text-emerald-300 flex items-center justify-center transition shadow-2xs"
                title="WhatsApp Chat: 01732408652"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Customer Service & Links */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">{t.customerServiceTitle}</h4>
            <ul className="space-y-2 text-neutral-300">
              <li>
                <button 
                  onClick={onOpenTracking} 
                  className="hover:text-amber-300 text-amber-400 font-bold transition cursor-pointer text-left flex items-center gap-1.5"
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'অর্ডার ট্র্যাক করুন (Live Tracking)' : 'Track Order (Live Tracking)'}</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onOpenPolicy?.('refund')} 
                  className="hover:text-amber-300 transition cursor-pointer text-left"
                >
                  {t.returnRefund}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onOpenPolicy?.('privacy')} 
                  className="hover:text-amber-300 transition cursor-pointer text-left"
                >
                  {t.privacyPolicy}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onOpenPolicy?.('terms')} 
                  className="hover:text-amber-300 transition cursor-pointer text-left"
                >
                  {t.termsConditions}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onOpenPolicy?.('shipping')} 
                  className="hover:text-amber-300 transition cursor-pointer text-left"
                >
                  {language === 'bn' ? 'শিপিং ও ডেলিভারি পলিসি' : 'Shipping Policy'}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onOpenPolicy?.('about')} 
                  className="hover:text-amber-300 transition cursor-pointer text-left"
                >
                  {language === 'bn' ? 'আমাদের সম্পর্কে ও নীতিমালা' : 'About Happy Shopping'}
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">{t.contactUs}</h4>
            <ul className="space-y-2.5 text-neutral-300">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{addressText}</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <a href={`mailto:${hotlineEmail}`} className="hover:text-amber-300 transition font-mono">
                  {hotlineEmail}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a 
                  href="https://wa.me/8801732408652" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-emerald-300 transition font-mono font-bold text-emerald-400"
                  title="WhatsApp: 01732408652 (Direct Chat, No Phone Call)"
                >
                  01732408652 (WhatsApp)
                </a>
              </li>
            </ul>
          </div>

          {/* Payment Methods & Courier Partners */}
          <div className="space-y-4">
            <div>
              <h4 className="text-neutral-900 font-bold text-xs uppercase tracking-wider mb-2">
                {language === 'bn' ? 'পেমেন্ট পদ্ধতি' : 'Payment Method'}
              </h4>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold text-xs flex items-center gap-1.5 shadow-2xs">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  {language === 'bn' ? '১০০% ক্যাশ অন ডেলিভারি (COD)' : '100% Cash on Delivery (COD)'}
                </span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-2">
                {language === 'bn' ? 'পণ্য হাতে পেয়ে সম্পূর্ণ চেক করে মূল্য পরিশোধ করুন।' : 'Inspect your parcel upon delivery and pay cash to the courier.'}
              </p>
            </div>

            <div>
              <h4 className="text-neutral-900 font-bold text-xs uppercase tracking-wider mb-1.5">
                {language === 'bn' ? 'কুরিয়ার ডেলিভারি পার্টনার্স' : 'Courier Delivery Partners'}
              </h4>
              <p className="text-[11px] text-neutral-500">
                SteadFast Courier, Pathao Courier, RedX Logistics
              </p>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-10 pt-6 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-neutral-500 text-[11px]">
          <p>{copyrightText}</p>
          <p className="flex items-center gap-1">
            <span>Made with</span>
            <Heart className="w-3 h-3 text-rose-600 fill-rose-600" />
            <span>for Bangladeshi Shoppers</span>
          </p>
        </div>
      </div>
    </footer>
  );
});
