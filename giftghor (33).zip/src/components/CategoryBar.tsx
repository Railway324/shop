import React from 'react';
import { 
  LayoutGrid, 
  Watch, 
  Shirt, 
  Laptop, 
  BookOpen, 
  Home, 
  ShoppingBag,
  Flame, 
  Sparkles, 
  Trophy, 
  Zap, 
  Headphones, 
  Baby,
  Bike,
  Package,
  Gift,
  UtensilsCrossed,
  Gem
} from 'lucide-react';
import { Category, CategoryId, Language } from '../types';
import { translations } from '../utils/translations';

interface CategoryBarProps {
  categories: Category[];
  selectedCategory: CategoryId;
  onSelectCategory: (cat: CategoryId) => void;
  language: Language;
}

export const CategoryBar: React.FC<CategoryBarProps> = React.memo(({
  categories,
  selectedCategory,
  onSelectCategory,
  language,
}) => {
  const t = translations[language];

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Watch':
        return <Watch className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Shirt':
        return <Shirt className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Laptop':
        return <Laptop className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'BookOpen':
        return <BookOpen className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Home':
        return <Home className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Sparkles':
        return <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Flame':
        return <Flame className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Trophy':
        return <Trophy className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Zap':
        return <Zap className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Headphones':
        return <Headphones className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Baby':
        return <Baby className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Bike':
        return <Bike className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Gem':
        return <Gem className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'UtensilsCrossed':
        return <UtensilsCrossed className="w-4 h-4 sm:w-5 sm:h-5" />;
      case 'Package':
      case 'Gift':
        return <Package className="w-4 h-4 sm:w-5 sm:h-5" />;
      default:
        return <LayoutGrid className="w-4 h-4 sm:w-5 sm:h-5" />;
    }
  };

  return (
    <div className="my-4 sm:my-6">
      <div className="flex items-center justify-between mb-2.5 sm:mb-3 px-1">
        <h2 className="text-sm sm:text-base md:text-lg font-bold text-white flex items-center gap-1.5 sm:gap-2">
          <Flame className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 fill-amber-400" />
          <span>{t.categoriesTitle}</span>
        </h2>
        <button
          onClick={() => onSelectCategory('all')}
          className="text-xs font-semibold text-amber-300 hover:text-amber-200 transition cursor-pointer"
        >
          {t.viewAll} →
        </button>
      </div>

      {/* Responsive Horizontal Scroll & Multi-Column Grid */}
      <div className="flex sm:grid sm:grid-cols-5 md:grid-cols-10 gap-2 sm:gap-2.5 overflow-x-auto no-scrollbar pb-1.5 pt-0.5 -mx-1 px-1">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              id={`cat-btn-${cat.id}`}
              onClick={() => onSelectCategory(cat.id)}
              className={`shrink-0 w-24 sm:w-auto flex flex-col items-center justify-center p-2 sm:p-2.5 rounded-xl sm:rounded-2xl transition-colors duration-150 cursor-pointer border text-center group ${
                isSelected
                  ? 'bg-gradient-to-b from-[#6B0B1D] to-[#45030C] text-white border-amber-400 shadow-md shadow-amber-500/10 font-bold'
                  : 'bg-[#240106] text-neutral-200 hover:text-white border-[#520510] hover:border-amber-400/50'
              }`}
            >
              <div 
                className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center mb-1 transition-transform duration-150 sm:group-hover:scale-110 ${
                  isSelected ? 'bg-amber-400/20 text-amber-300' : 'bg-[#3D030C] text-amber-300 group-hover:text-amber-200'
                }`}
              >
                {getCategoryIcon(cat.iconName)}
              </div>
              <span className="text-[10px] sm:text-[11px] font-semibold leading-tight line-clamp-2">
                {language === 'bn' ? cat.nameBn : cat.nameEn}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
});
