import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  ArrowLeft,
  AlertCircle
} from 'lucide-react';
import { 
  Product, 
  Order, 
  OrderStatus, 
  PaymentStatus,
  Language, 
  UserProfile, 
  AdminTab, 
  CategoryId,
  Customer, 
  Coupon, 
  ProductReview, 
  StockLog, 
  AdminUser, 
  StoreSettings, 
  DeliverySettings, 
  SeoSettings, 
  ActivityLogItem, 
  AdminNotification,
  Banner,
  Category
} from '../types';
import { initialCategories } from '../data/initialData';
import { 
  getStoredCoupons, 
  saveCouponsToStorage, 
  getStoredReviews, 
  saveReviewsToStorage, 
  getStoredStockLogs, 
  saveStockLogsToStorage, 
  getStoredAdminUsers, 
  saveAdminUsersToStorage, 
  getStoredStoreSettings, 
  saveStoreSettingsToStorage, 
  getStoredDeliverySettings, 
  saveDeliverySettingsToStorage, 
  getStoredSeoSettings, 
  saveSeoSettingsToStorage, 
  getStoredActivityLogs, 
  saveActivityLogsToStorage, 
  getStoredNotifications, 
  saveNotificationsToStorage,
  getStoredCustomizerSettings,
  saveCustomizerSettingsToStorage,
  saveSettingsToServer
} from '../utils/storage';
import { 
  saveCouponToFirestore, 
  deleteCouponFromFirestore,
  saveReviewToFirestore,
  deleteReviewFromFirestore,
  getAllCouponsFromFirestore,
  getAllReviewsFromFirestore,
  saveCategoryToFirestore,
  deleteCategoryFromFirestore,
  getAllCategoriesFromFirestore,
  subscribeToAllCategories,
  saveSettingsToFirestore
} from '../lib/firebase';

// Modular Admin Views
import { AdminLayout } from './admin/AdminLayout';
import { AdminDashboardView } from './admin/AdminDashboardView';
import { AdminCategoriesView } from './admin/AdminCategoriesView';
import { AdminProductsView } from './admin/AdminProductsView';
import { AdminInventoryView } from './admin/AdminInventoryView';
import { AdminOrdersView } from './admin/AdminOrdersView';
import { AdminCustomersView } from './admin/AdminCustomersView';
import { AdminPaymentsView } from './admin/AdminPaymentsView';
import { AdminCouponsView } from './admin/AdminCouponsView';
import { AdminReportsView } from './admin/AdminReportsView';
import { AdminDeliveryView } from './admin/AdminDeliveryView';
import { AdminReviewsView } from './admin/AdminReviewsView';
import { AdminBannersView } from './admin/AdminBannersView';
import { AdminUsersView } from './admin/AdminUsersView';
import { AdminActivityLogView } from './admin/AdminActivityLogView';
import { AdminSettingsView } from './admin/AdminSettingsView';
import { AdminSeoView } from './admin/AdminSeoView';
import { AdminAppearanceView } from './admin/AdminAppearanceView';
import { AdminAiMerchandiserView } from './admin/AdminAiMerchandiserView';
import { AdminNotificationsDrawer } from './admin/AdminNotificationsDrawer';
import { AdminInvoiceModal } from './admin/AdminInvoiceModal';
import { FirebaseDiagnosticsModal } from './admin/FirebaseDiagnosticsModal';
import { LiveSyncPublishModal } from './admin/LiveSyncPublishModal';
import { AdminErrorBoundary } from './admin/AdminErrorBoundary';
import { isUserAdmin } from '../lib/firebase';
import { WebsiteCustomizerSettings } from '../types';

interface AdminPanelProps {
  products: Product[];
  categories?: Category[];
  onCategoriesChange?: (categories: Category[]) => void;
  onSaveCategory?: (category: Category) => Promise<void> | void;
  onDeleteCategory?: (categoryId: string) => Promise<void> | void;
  orders: Order[];
  language: Language;
  currentUserProfile?: UserProfile | null;
  reviews?: ProductReview[];
  onReviewsChange?: (reviews: ProductReview[]) => void;
  customizerSettings?: WebsiteCustomizerSettings;
  onCustomizerSettingsChange?: (settings: WebsiteCustomizerSettings) => void;
  onProductsChange?: (products: Product[]) => void;
  onOpenLogin: () => void;
  onAddProduct: (p: Omit<Product, 'id' | 'createdAt'>) => void;
  onUpdateProduct: (p: Product) => void;
  onReorderProduct?: (productId: string, newOrder: number) => void;
  onDeleteProduct: (productId: string) => void;
  onBulkDeleteProducts?: (productIds: string[]) => void;
  onUpdateOrderStatus: (
    orderId: string, 
    status: OrderStatus, 
    paymentStatus?: PaymentStatus, 
    courierTracking?: string,
    courierName?: string
  ) => void;
  onDeleteOrder?: (orderId: string) => void;
  onBulkDeleteOrders?: (orderIds: string[]) => void;
  onBackToShop: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  products,
  categories: propCategories,
  onCategoriesChange,
  onSaveCategory,
  onDeleteCategory,
  orders,
  language,
  currentUserProfile,
  reviews: propReviews,
  onReviewsChange,
  customizerSettings: propCustomizerSettings,
  onCustomizerSettingsChange,
  onProductsChange,
  onOpenLogin,
  onAddProduct,
  onUpdateProduct,
  onReorderProduct,
  onDeleteProduct,
  onBulkDeleteProducts,
  onUpdateOrderStatus,
  onDeleteOrder,
  onBulkDeleteOrders,
  onBackToShop,
}) => {
  const isAdmin = isUserAdmin(currentUserProfile);

  // Active Admin Tab
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  const [isLivePublishModalOpen, setIsLivePublishModalOpen] = useState(false);

  // Secondary State Layers with Persistence
  const [coupons, setCoupons] = useState<Coupon[]>(getStoredCoupons);
  const [reviews, setReviews] = useState<ProductReview[]>(() => propReviews || getStoredReviews());

  useEffect(() => {
    if (propReviews) {
      setReviews(propReviews);
    }
  }, [propReviews]);

  // Load persistent coupons & reviews from Firestore on mount
  useEffect(() => {
    getAllCouponsFromFirestore().then(remoteCoupons => {
      if (Array.isArray(remoteCoupons) && remoteCoupons.length > 0) {
        setCoupons(remoteCoupons);
      }
    }).catch(err => console.warn('Firestore coupons load note:', err));

    getAllReviewsFromFirestore().then(remoteReviews => {
      if (Array.isArray(remoteReviews) && remoteReviews.length > 0) {
        setReviews(remoteReviews);
        onReviewsChange?.(remoteReviews);
      }
    }).catch(err => console.warn('Firestore reviews load note:', err));
  }, []);

  // Persistent Categories state with Firestore sync
  const [adminCategories, setAdminCategories] = useState<Category[]>(() => {
    return propCategories && propCategories.length > 0 ? propCategories : initialCategories;
  });

  useEffect(() => {
    if (propCategories && propCategories.length > 0) {
      setAdminCategories(propCategories);
    }
  }, [propCategories]);

  useEffect(() => {
    getAllCategoriesFromFirestore().then(remoteCats => {
      if (Array.isArray(remoteCats) && remoteCats.length > 0) {
        const map = new Map<string, Category>();
        initialCategories.forEach(c => map.set(c.id, c));
        remoteCats.forEach(c => map.set(c.id, { ...(map.get(c.id) || {}), ...c }));
        const merged = Array.from(map.values());
        setAdminCategories(merged);
        if (onCategoriesChange) onCategoriesChange(merged);
      }
    }).catch(err => console.warn('Categories load note:', err));

    const unsubscribe = subscribeToAllCategories((remoteCats) => {
      if (Array.isArray(remoteCats) && remoteCats.length > 0) {
        const map = new Map<string, Category>();
        initialCategories.forEach(c => map.set(c.id, c));
        remoteCats.forEach(c => map.set(c.id, { ...(map.get(c.id) || {}), ...c }));
        const merged = Array.from(map.values());
        setAdminCategories(merged);
        if (onCategoriesChange) onCategoriesChange(merged);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleSaveCategory = async (cat: Category) => {
    setAdminCategories(prev => {
      const exists = prev.some(c => c.id === cat.id);
      const updated = exists ? prev.map(c => c.id === cat.id ? cat : c) : [...prev, cat];
      if (onCategoriesChange) onCategoriesChange(updated);
      return updated;
    });
    await saveCategoryToFirestore(cat);
    if (onSaveCategory) await onSaveCategory(cat);
    recordActivity('ক্যাটাগরি সংরক্ষণ', `ক্যাটাগরি তৈরি বা আপডেট: ${cat.nameBn} (${cat.id})`, 'settings');
  };

  const handleDeleteCategory = async (catId: string) => {
    setAdminCategories(prev => {
      const updated = prev.filter(c => c.id !== catId);
      if (onCategoriesChange) onCategoriesChange(updated);
      return updated;
    });
    await deleteCategoryFromFirestore(catId);
    if (onDeleteCategory) await onDeleteCategory(catId);
    recordActivity('ক্যাটাগরি মুছে ফেলা', `ক্যাটাগরি ডিলিট: ${catId}`, 'settings');
  };
  const [stockLogs, setStockLogs] = useState<StockLog[]>(getStoredStockLogs);
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(getStoredAdminUsers);
  const [storeSettings, setStoreSettings] = useState<StoreSettings>(getStoredStoreSettings);
  const [deliverySettings, setDeliverySettings] = useState<DeliverySettings>(getStoredDeliverySettings);
  const [seoSettings, setSeoSettings] = useState<SeoSettings>(getStoredSeoSettings);
  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>(getStoredActivityLogs);
  const [notifications, setNotifications] = useState<AdminNotification[]>(getStoredNotifications);
  const [customizerSettings, setCustomizerSettings] = useState<WebsiteCustomizerSettings>(() => {
    return propCustomizerSettings || getStoredCustomizerSettings();
  });

  // Modals & Drawers
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);

  // Sync to Storage
  useEffect(() => { saveCouponsToStorage(coupons); }, [coupons]);
  useEffect(() => { saveReviewsToStorage(reviews); }, [reviews]);
  useEffect(() => { saveStockLogsToStorage(stockLogs); }, [stockLogs]);
  useEffect(() => { saveAdminUsersToStorage(adminUsers); }, [adminUsers]);
  useEffect(() => { saveStoreSettingsToStorage(storeSettings); }, [storeSettings]);
  useEffect(() => { saveDeliverySettingsToStorage(deliverySettings); }, [deliverySettings]);
  useEffect(() => { saveSeoSettingsToStorage(seoSettings); }, [seoSettings]);
  useEffect(() => { saveActivityLogsToStorage(activityLogs); }, [activityLogs]);
  useEffect(() => { saveNotificationsToStorage(notifications); }, [notifications]);

  // Derived Customers Data from Orders
  const customers: Customer[] = useMemo(() => {
    const map = new Map<string, Customer>();

    orders.forEach(order => {
      const key = (order.phone || order.customerName).toLowerCase().trim();
      const existing = map.get(key);

      if (existing) {
        existing.totalOrders += 1;
        if (order.orderStatus !== 'cancelled') {
          existing.totalSpent += order.total;
        }
        if (!existing.email && order.email) existing.email = order.email;
        if (!existing.address && order.address) existing.address = order.address;
      } else {
        map.set(key, {
          id: `cust-${order.id.slice(0, 8)}`,
          name: order.customerName,
          email: order.email,
          phone: order.phone,
          address: order.address,
          totalOrders: 1,
          totalSpent: order.orderStatus !== 'cancelled' ? order.total : 0,
          createdAt: order.date || new Date().toISOString(),
          status: 'active'
        });
      }
    });

    return Array.from(map.values());
  }, [orders]);

  // Audit Log Helper
  const recordActivity = (action: string, details: string, category: 'order' | 'product' | 'inventory' | 'coupon' | 'settings' | 'user') => {
    const newLog: ActivityLogItem = {
      id: `act-${Date.now()}`,
      adminName: currentUserProfile?.displayName || 'Admin (winlucky414@gmail.com)',
      adminEmail: currentUserProfile?.email || 'winlucky414@gmail.com',
      action,
      details,
      timestamp: new Date().toISOString(),
      category
    };
    setActivityLogs(prev => [newLog, ...prev.slice(0, 200)]);
  };

  // Inventory Adjustment Handler
  const handleAdjustStock = (productId: string, adjustment: number, reason: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const previousStock = product.stock || 0;
    const newStock = Math.max(0, previousStock + adjustment);

    onUpdateProduct({ ...product, stock: newStock });

    // Record Stock Log
    const newStockLog: StockLog = {
      id: `stk-${Date.now()}`,
      productId: product.id,
      productName: product.titleEn,
      type: adjustment >= 0 ? 'stock_in' : 'stock_out',
      quantity: adjustment,
      previousStock,
      newStock,
      reason,
      adminName: currentUserProfile?.displayName || 'Admin',
      date: new Date().toLocaleString()
    };
    setStockLogs(prev => [newStockLog, ...prev]);

    recordActivity(
      `Adjusted stock for ${product.titleEn}`,
      `Changed by ${adjustment > 0 ? `+${adjustment}` : adjustment} (Now: ${newStock}). Reason: ${reason}`,
      'inventory'
    );
  };

  // Order Handlers with Audit & Notifications
  const handleUpdateOrderStatusWrapper = (
    orderId: string,
    status: OrderStatus,
    paymentStatus?: PaymentStatus,
    courierTracking?: string,
    courierName?: string
  ) => {
    const targetOrder = orders.find(o => o.id === orderId);
    const isCOD = !targetOrder?.paymentMethod || targetOrder.paymentMethod === 'cod';
    const isDelivered = status === 'delivered';
    let resolvedPayment: PaymentStatus = targetOrder?.paymentStatus || 'pending';
    if (isDelivered && isCOD) {
      resolvedPayment = 'paid';
    } else if (paymentStatus !== undefined) {
      resolvedPayment = paymentStatus;
    } else if (isDelivered && targetOrder?.paymentStatus === 'pending') {
      resolvedPayment = 'paid';
    }

    onUpdateOrderStatus(orderId, status, resolvedPayment, courierTracking, courierName);
    recordActivity(
      `Updated Order #${orderId}`,
      `Status: '${status}'${resolvedPayment ? `, Payment: '${resolvedPayment}' ${isDelivered && isCOD ? '(COD Auto-Paid)' : ''}` : ''}${courierTracking ? `, Tracking: ${courierTracking}` : ''}`,
      'order'
    );
  };

  const handleBulkUpdateOrderStatus = (orderIds: string[], status: OrderStatus) => {
    orderIds.forEach(id => {
      const targetOrder = orders.find(o => o.id === id);
      const isCOD = !targetOrder?.paymentMethod || targetOrder.paymentMethod === 'cod';
      const resolvedPayment = (status === 'delivered' && isCOD) ? 'paid' : targetOrder?.paymentStatus;
      onUpdateOrderStatus(id, status, resolvedPayment);
    });
    recordActivity(
      `Bulk updated ${orderIds.length} orders`,
      `Set status to '${status}'${status === 'delivered' ? ' (COD orders auto-completed to Paid)' : ''} for orders: ${orderIds.join(', ')}`,
      'order'
    );
  };

  const handleDeleteOrderWrapper = (orderId: string) => {
    if (onDeleteOrder) {
      onDeleteOrder(orderId);
      recordActivity(`Deleted Order #${orderId}`, `Permanently deleted order record`, 'order');
    }
  };

  const handleBulkDeleteOrdersWrapper = (orderIds: string[]) => {
    if (onBulkDeleteOrders) {
      onBulkDeleteOrders(orderIds);
      recordActivity(`Bulk deleted ${orderIds.length} orders`, `Permanently deleted orders: ${orderIds.join(', ')}`, 'order');
    } else if (onDeleteOrder) {
      orderIds.forEach(id => onDeleteOrder(id));
    }
  };

  // Product Wrapper with Logging
  const handleAddProductWrapper = (p: Omit<Product, 'id' | 'createdAt'>) => {
    onAddProduct(p);
    recordActivity(`Added Product`, `Added "${p.titleEn}" with stock ${p.stock}`, 'product');
  };

  const handleUpdateProductWrapper = (p: Product) => {
    onUpdateProduct(p);
    recordActivity(`Updated Product`, `Updated details for "${p.titleEn}"`, 'product');
  };

  const handleDeleteProductWrapper = (id: string) => {
    const prod = products.find(p => p.id === id);
    onDeleteProduct(id);
    recordActivity(`Deleted Product`, `Deleted product: ${prod?.titleEn || id}`, 'product');
  };

  const handleDuplicateProductWrapper = (p: Product) => {
    const duplicated: Omit<Product, 'id' | 'createdAt'> = {
      ...p,
      titleBn: `${p.titleBn} (কপি)`,
      titleEn: `${p.titleEn} (Copy)`,
      sku: `${p.sku || 'SKU'}-COPY-${Date.now().toString().slice(-4)}`,
    };
    onAddProduct(duplicated);
    recordActivity(`Duplicated Product`, `Created copy of "${p.titleEn}"`, 'product');
  };

  const handleBulkDeleteProductsWrapper = (productIds: string[]) => {
    if (onBulkDeleteProducts) {
      onBulkDeleteProducts(productIds);
    } else {
      productIds.forEach(id => onDeleteProduct(id));
    }
    recordActivity(`Bulk Deleted Products`, `Removed ${productIds.length} products`, 'product');
  };

  const handleBulkStatusUpdateProductsWrapper = (productIds: string[], status: 'active' | 'inactive') => {
    productIds.forEach(id => {
      const prod = products.find(p => p.id === id);
      if (prod) {
        onUpdateProduct({ ...prod, status });
      }
    });
    recordActivity(`Bulk Status Update`, `Set ${productIds.length} products to ${status}`, 'product');
  };

  const handleBulkStockUpdateProductsWrapper = (productIds: string[], stock: number) => {
    productIds.forEach(id => {
      const prod = products.find(p => p.id === id);
      if (prod) {
        onUpdateProduct({ ...prod, stock });
      }
    });
    recordActivity(`Bulk Stock Update`, `Updated stock to ${stock} for ${productIds.length} products`, 'product');
  };

  const handleBulkCategoryUpdateProductsWrapper = (productIds: string[], category: CategoryId) => {
    productIds.forEach(id => {
      const prod = products.find(p => p.id === id);
      if (prod) {
        onUpdateProduct({ ...prod, category });
      }
    });
    recordActivity(`Bulk Category Update`, `Changed category to ${category} for ${productIds.length} products`, 'product');
  };

  // Coupon Handlers
  const handleSaveCoupon = (coupon: Coupon) => {
    setCoupons(prev => {
      const exists = prev.some(c => c.id === coupon.id);
      if (exists) {
        return prev.map(c => c.id === coupon.id ? coupon : c);
      }
      return [coupon, ...prev];
    });
    saveCouponToFirestore(coupon).catch(err => console.warn('Firestore coupon save note:', err));
    recordActivity(`Saved Coupon`, `Code: ${coupon.code}, Discount: ${coupon.discountValue}${coupon.discountType === 'percentage' ? '%' : ' BDT'}`, 'coupon');
  };

  const handleDeleteCoupon = (couponId: string) => {
    setCoupons(prev => prev.filter(c => c.id !== couponId));
    deleteCouponFromFirestore(couponId).catch(err => console.warn('Firestore coupon delete note:', err));
    recordActivity(`Deleted Coupon`, `Coupon ID: ${couponId}`, 'coupon');
  };

  const handleToggleCouponStatus = (couponId: string) => {
    setCoupons(prev => prev.map(c => {
      if (c.id === couponId) {
        const updated = { ...c, isActive: !c.isActive };
        saveCouponToFirestore(updated).catch(err => console.warn('Firestore coupon status note:', err));
        return updated;
      }
      return c;
    }));
  };

  // Customer Notes & Block
  const handleToggleBlockCustomer = (customerId: string) => {
    recordActivity(`Customer Block Toggle`, `Toggled block state for customer ${customerId}`, 'user');
  };

  const handleSaveCustomerNote = (customerId: string, note: string) => {
    recordActivity(`Saved Customer Note`, `Note updated for customer ${customerId}`, 'user');
  };

  // Review Handlers
  const handleUpdateReviewStatus = (reviewId: string, status: 'approved' | 'rejected' | 'pending') => {
    setReviews(prev => {
      const next = prev.map(r => {
        if (r.id === reviewId) {
          const updated = { ...r, status };
          saveReviewToFirestore(updated).catch(err => console.warn('Firestore review status note:', err));
          return updated;
        }
        return r;
      });
      onReviewsChange?.(next);
      return next;
    });
    recordActivity(`Review Moderation`, `Review ${reviewId} marked as ${status}`, 'product');
  };

  const handleDeleteReview = (reviewId: string) => {
    setReviews(prev => {
      const next = prev.filter(r => r.id !== reviewId);
      onReviewsChange?.(next);
      return next;
    });
    deleteReviewFromFirestore(reviewId).catch(err => console.warn('Firestore review delete note:', err));
    recordActivity(`Deleted Review`, `Review ID: ${reviewId}`, 'product');
  };

  // Admin User Handlers
  const handleSaveAdminUser = (user: AdminUser) => {
    setAdminUsers(prev => {
      const exists = prev.some(u => u.id === user.id);
      if (exists) {
        return prev.map(u => u.id === user.id ? user : u);
      }
      return [...prev, user];
    });
    recordActivity(`Staff Account Updated`, `User: ${user.name} (${user.email}), Role: ${user.role}`, 'user');
  };

  const handleDeleteAdminUser = (userId: string) => {
    setAdminUsers(prev => prev.filter(u => u.id !== userId));
    recordActivity(`Deleted Staff Account`, `User ID: ${userId}`, 'user');
  };

  const handleToggleUserStatus = (userId: string) => {
    setAdminUsers(prev => prev.map(u => u.id === userId ? {
      ...u,
      status: u.status === 'active' ? 'disabled' : 'active'
    } : u));
  };

  // Notifications
  const handleMarkNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const handleClearNotifications = () => {
    setNotifications([]);
  };

  // Non-admin Auth Gate
  if (!isAdmin) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-8 text-center space-y-6 shadow-2xl animate-fadeIn">
          <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 text-red-400 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
            <Lock className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-xl font-black text-white">
              {language === 'bn' ? 'এডমিন প্যানেল সুরক্ষিত' : 'Administrator Portal Restricted'}
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed">
              {language === 'bn' 
                ? 'এই পোর্টালটি শুধুমাত্র অনুমোদিত স্টোর এডমিনদের জন্য। অনুগ্রহ করে এডমিন ইমেইল (rmd474915@gmail.com অথবা winlucky414@gmail.com) দিয়ে লগইন করুন।' 
                : 'Access restricted to authenticated store administrators only (rmd474915@gmail.com / winlucky414@gmail.com).'}
            </p>
          </div>

          <div className="space-y-3 pt-2">
            <button
              onClick={onOpenLogin}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-sm shadow-lg shadow-rose-950/50 transition cursor-pointer"
            >
              {language === 'bn' ? 'এডমিন লগইন করুন' : 'Sign In as Administrator'}
            </button>

            <button
              onClick={onBackToShop}
              className="w-full py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{language === 'bn' ? 'মূল ওয়েবসাইটে ফিরে যান' : 'Return to Storefront'}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <AdminLayout
      activeTab={activeTab}
      onSelectTab={setActiveTab}
      language={language}
      notifications={notifications}
      unreadNotificationsCount={(notifications || []).filter(n => !n.isRead && !n.read).length}
      currentUserProfile={currentUserProfile}
      onOpenNotifications={() => setIsNotificationsOpen(true)}
      onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
      onOpenLivePublish={() => setIsLivePublishModalOpen(true)}
      onBackToShop={onBackToShop}
    >
      <AdminErrorBoundary language={language} onBackToShop={onBackToShop}>
        {/* 1. DASHBOARD VIEW */}
      {activeTab === 'dashboard' && (
        <AdminDashboardView
          orders={orders}
          products={products}
          customers={customers}
          language={language}
          onNavigateTab={setActiveTab}
          onUpdateOrderStatus={handleUpdateOrderStatusWrapper}
          onOpenLivePublish={() => setIsLivePublishModalOpen(true)}
          onViewOrderDetails={(order) => {
            setActiveTab('orders');
          }}
        />
      )}

      {/* 2. CATEGORIES MANAGEMENT */}
      {activeTab === 'categories' && (
        <AdminCategoriesView
          categories={adminCategories}
          products={products}
          language={language}
          onSaveCategory={handleSaveCategory}
          onDeleteCategory={handleDeleteCategory}
          onSelectCategoryFilter={(catId) => {
            setActiveTab('products');
          }}
        />
      )}

      {/* 3. PRODUCTS CATALOG */}
      {activeTab === 'products' && (
        <AdminProductsView
          products={products}
          categories={adminCategories}
          language={language}
          onAddProduct={handleAddProductWrapper}
          onUpdateProduct={handleUpdateProductWrapper}
          onReorderProduct={onReorderProduct}
          onDeleteProduct={handleDeleteProductWrapper}
          onDuplicateProduct={handleDuplicateProductWrapper}
          onBulkDelete={handleBulkDeleteProductsWrapper}
          onBulkStatusUpdate={handleBulkStatusUpdateProductsWrapper}
          onBulkStockUpdate={handleBulkStockUpdateProductsWrapper}
          onBulkCategoryUpdate={handleBulkCategoryUpdateProductsWrapper}
          onNavigateToOrdering={() => setActiveTab('aiMerchandiser')}
        />
      )}

      {/* 3. INVENTORY & STOCK */}
      {activeTab === 'inventory' && (
        <AdminInventoryView
          products={products}
          stockLogs={stockLogs}
          language={language}
          onAdjustStock={handleAdjustStock}
        />
      )}

      {/* 4. ORDERS & SHIPMENTS */}
      {activeTab === 'orders' && (
        <AdminOrdersView
          orders={orders}
          language={language}
          onUpdateOrderStatus={handleUpdateOrderStatusWrapper}
          onBulkUpdateStatus={handleBulkUpdateOrderStatus}
          onDeleteOrder={handleDeleteOrderWrapper}
          onBulkDeleteOrders={handleBulkDeleteOrdersWrapper}
          onPrintInvoice={(order) => setInvoiceOrder(order)}
        />
      )}

      {/* 5. CUSTOMERS DIRECTORY */}
      {activeTab === 'customers' && (
        <AdminCustomersView
          customers={customers}
          orders={orders}
          language={language}
          onToggleBlockCustomer={handleToggleBlockCustomer}
          onSaveCustomerNote={handleSaveCustomerNote}
          onViewCustomerOrders={() => setActiveTab('orders')}
        />
      )}

      {/* 6. PAYMENTS & MFS */}
      {activeTab === 'payments' && (
        <AdminPaymentsView
          orders={orders}
          language={language}
          onUpdatePaymentStatus={(orderId, status, trxId) => {
            const ord = orders.find(o => o.id === orderId);
            if (ord) {
              handleUpdateOrderStatusWrapper(orderId, ord.orderStatus, status, ord.trackingCode, ord.courierName);
            }
          }}
        />
      )}

      {/* 7. COUPONS & PROMOS */}
      {activeTab === 'coupons' && (
        <AdminCouponsView
          coupons={coupons}
          language={language}
          onSaveCoupon={handleSaveCoupon}
          onDeleteCoupon={handleDeleteCoupon}
          onToggleCouponStatus={handleToggleCouponStatus}
        />
      )}

      {/* 8. SALES REPORTS & ANALYTICS */}
      {activeTab === 'reports' && (
        <AdminReportsView
          orders={orders}
          products={products}
          customers={customers}
          language={language}
        />
      )}

      {/* 9. DELIVERY & COURIERS */}
      {activeTab === 'delivery' && (
        <AdminDeliveryView
          deliverySettings={deliverySettings}
          language={language}
          onSaveSettings={(s) => {
            setDeliverySettings(s);
            saveDeliverySettingsToStorage(s);
            saveSettingsToFirestore(undefined, { deliverySettings: s }).catch(() => {});
            // Also sync to server if available
            fetch('/api/settings', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ deliverySettings: s })
            }).catch(() => {});
            recordActivity('Updated Delivery Settings', 'Saved new regional shipping rates and courier configurations', 'settings');
          }}
        />
      )}

      {/* 10. REVIEWS MODERATION */}
      {activeTab === 'reviews' && (
        <AdminReviewsView
          reviews={reviews}
          language={language}
          onUpdateReviewStatus={handleUpdateReviewStatus}
          onDeleteReview={handleDeleteReview}
        />
      )}

      {/* 11. WEBSITE DESIGN & APPEARANCE STUDIO */}
      {activeTab === 'appearance' && (
        <AdminAppearanceView
          settings={customizerSettings}
          language={language}
          onSaveSettings={(updated) => {
            setCustomizerSettings(updated);
            saveCustomizerSettingsToStorage(updated);
            saveSettingsToServer(updated);
            saveSettingsToFirestore(updated).catch(() => {});
            if (onCustomizerSettingsChange) {
              onCustomizerSettingsChange(updated);
            }
            recordActivity('Updated Website Appearance', 'Customized theme colors, header, banners, and layout text', 'settings');
          }}
        />
      )}

      {/* 11b. BANNERS & FLASH SALE */}
      {activeTab === 'banners' && (
        <AdminBannersView
          language={language}
          customizerSettings={customizerSettings}
          onSaveCustomizerSettings={(updated) => {
            setCustomizerSettings(updated);
            saveCustomizerSettingsToStorage(updated);
            saveSettingsToServer(updated);
            saveSettingsToFirestore(updated).catch(() => {});
            if (onCustomizerSettingsChange) {
              onCustomizerSettingsChange(updated);
            }
            recordActivity('Updated Banners & Flash Sale', 'Modified promotional banners and flash deal campaign', 'settings');
          }}
        />
      )}

      {/* 11c. AI MARKET TREND MERCHANDISER */}
      {activeTab === 'aiMerchandiser' && (
        <AdminAiMerchandiserView
          products={products}
          language={language}
          customizerSettings={customizerSettings}
          onProductsChange={onProductsChange || ((newProds) => newProds.forEach(p => onUpdateProduct(p)))}
          onSaveCustomizerSettings={(updated) => {
            setCustomizerSettings(updated);
            saveCustomizerSettingsToStorage(updated);
            saveSettingsToServer(updated);
            saveSettingsToFirestore(updated).catch(() => {});
            if (onCustomizerSettingsChange) {
              onCustomizerSettingsChange(updated);
            }
          }}
          onRecordActivity={(action, details, cat) => {
            const mappedCat = cat === 'security' ? 'settings' : cat;
            recordActivity(action, details, mappedCat);
          }}
        />
      )}

      {/* 12. ADMIN TEAM & ROLES */}
      {activeTab === 'users' && (
        <AdminUsersView
          adminUsers={adminUsers}
          language={language}
          onSaveAdminUser={handleSaveAdminUser}
          onDeleteAdminUser={handleDeleteAdminUser}
          onToggleUserStatus={handleToggleUserStatus}
        />
      )}

      {/* 13. AUDIT ACTIVITY LOGS */}
      {activeTab === 'activity' && (
        <AdminActivityLogView
          activityLogs={activityLogs}
          language={language}
          onClearLogs={() => setActivityLogs([])}
        />
      )}

      {/* 14. STORE SETTINGS */}
      {activeTab === 'settings' && (
        <AdminSettingsView
          settings={storeSettings}
          language={language}
          onSaveSettings={(s) => {
            setStoreSettings(s);
            saveStoreSettingsToStorage(s);
            saveSettingsToFirestore(undefined, { storeSettings: s }).catch(() => {});
            fetch('/api/settings', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ storeSettings: s })
            }).catch(() => {});
            recordActivity('Updated Store Settings', 'Modified general store identity and configurations', 'settings');
          }}
        />
      )}

      {/* 15. SEO CONFIGURATION */}
      {activeTab === 'seo' && (
        <AdminSeoView
          settings={storeSettings}
          language={language}
          onSaveSettings={(s) => {
            setStoreSettings(s);
            saveStoreSettingsToStorage(s);
            saveSettingsToFirestore(undefined, { storeSettings: s }).catch(() => {});
            fetch('/api/settings', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ seoSettings: s })
            }).catch(() => {});
            recordActivity('Updated SEO Tags', 'Modified search engine metadata & open graph settings', 'settings');
          }}
        />
      )}
      </AdminErrorBoundary>

      {/* Invoice Modal */}
      {invoiceOrder && (
        <AdminInvoiceModal
          order={invoiceOrder}
          language={language}
          onClose={() => setInvoiceOrder(null)}
        />
      )}

      {/* Notifications Drawer */}
      <AdminNotificationsDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        language={language}
        onMarkAsRead={handleMarkNotificationRead}
        onClearAll={handleClearNotifications}
        onSelectNotification={(n) => {
          setIsNotificationsOpen(false);
          if (n.type === 'order') setActiveTab('orders');
          else if (n.type === 'low_stock') setActiveTab('inventory');
          else if (n.type === 'payment') setActiveTab('payments');
        }}
      />

      {/* Firebase Real-Time Diagnostics Modal */}
      <FirebaseDiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        language={language}
        currentUserProfile={currentUserProfile}
        orders={orders}
      />

      {/* 1-Click Live Website Publisher & Real-Time Sync Modal */}
      <LiveSyncPublishModal
        isOpen={isLivePublishModalOpen}
        onClose={() => setIsLivePublishModalOpen(false)}
        products={products}
        customizerSettings={customizerSettings}
        currentUserProfile={currentUserProfile}
        language={language}
        onSyncComplete={(res) => {
          recordActivity(
            'Live Website Sync & Publish', 
            `Published ${res.productsCount} products and design updates to live site`, 
            'settings'
          );
        }}
      />
    </AdminLayout>
  );
};
