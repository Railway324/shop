import React, { useState, useRef } from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  ShoppingBag, 
  CheckCircle2, 
  Clock, 
  Truck, 
  RotateCcw, 
  DollarSign, 
  Edit3, 
  LogOut, 
  ChevronRight, 
  Package, 
  Calendar, 
  CreditCard, 
  ShieldCheck, 
  Save, 
  X, 
  ExternalLink,
  Camera,
  Upload,
  Image as ImageIcon,
  Sparkles,
  Trash2,
  Check,
  Star,
  XCircle,
  Info,
  Search,
  Ban
} from 'lucide-react';
import { UserProfile, Order, Language, OrderStatus, ProductReview } from '../types';
import { translations, formatPrice, toBengaliNumber, getStatusLabel } from '../utils/translations';
import { saveUserProfileToFirestore, auth, updateProfile } from '../lib/firebase';
import { 
  BD_DIVISIONS_LIST, 
  getDistrictsForDivision, 
  getThanasForDistrict, 
  findDistrict 
} from '../data/bangladeshGeoData';
import { CancelOrderModal } from './CancelOrderModal';
import { canUserCancelOrder } from '../utils/orderUtils';

interface AccountProfileViewProps {
  userProfile: UserProfile | null;
  orders?: Order[];
  reviews?: ProductReview[];
  language: Language;
  onUpdateProfile: (updated: UserProfile) => void;
  onLogout: () => void;
  onGoShopping: () => void;
  onOpenLogin: () => void;
  onOpenAdmin?: () => void;
  onCancelOrder?: (orderId: string, reason?: string) => Promise<void> | void;
  onOpenWriteReview?: (
    product: { id: string; titleBn: string; titleEn: string; image: string; price?: number }, 
    orderId: string, 
    existingReview?: ProductReview | null
  ) => void;
  onDeleteOrder?: (orderId: string) => void;
  onBulkDeleteOrders?: (orderIds: string[]) => void;
}

// Preset Avatars for Instant Selection
const PRESET_AVATARS = [
  { id: 'av-1', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=250&q=80', label: 'Male Casual' },
  { id: 'av-2', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80', label: 'Female Chic' },
  { id: 'av-3', url: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=250&q=80', label: 'Professional' },
  { id: 'av-4', url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=250&q=80', label: 'Female Elegant' },
  { id: 'av-5', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80', label: 'Youth' },
  { id: 'av-6', url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=250&q=80', label: 'Modern Female' },
  { id: 'av-7', url: 'https://images.unsplash.com/photo-1628157582853-a796fa650a6a?auto=format&fit=crop&w=250&q=80', label: 'Techie Male' },
  { id: 'av-8', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80', label: 'Creative' },
];

export const AccountProfileView: React.FC<AccountProfileViewProps> = ({
  userProfile,
  orders = [],
  reviews = [],
  language,
  onUpdateProfile,
  onLogout,
  onGoShopping,
  onOpenLogin,
  onOpenAdmin,
  onCancelOrder,
  onOpenWriteReview,
  onDeleteOrder,
  onBulkDeleteOrders,
}) => {
  const t = translations[language];

  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'edit'>('overview');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [expandedTrackingOrderId, setExpandedTrackingOrderId] = useState<string | null>(null);
  const [cancellingOrder, setCancellingOrder] = useState<Order | null>(null);
  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);
  const [deletingOrderId, setDeletingOrderId] = useState<string | null>(null);

  // Guest order lookup state
  const [guestLookupQuery, setGuestLookupQuery] = useState('');
  const [guestLookupOrders, setGuestLookupOrders] = useState<Order[]>([]);
  const [hasSearchedGuest, setHasSearchedGuest] = useState(false);

  // Edit Profile Form State
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(userProfile?.displayName || '');
  const [editPhone, setEditPhone] = useState(userProfile?.phone || '');
  const [editAddress, setEditAddress] = useState(userProfile?.address || '');
  const [editPhotoURL, setEditPhotoURL] = useState(userProfile?.photoURL || '');
  const [photoUploadTab, setPhotoUploadTab] = useState<'upload' | 'presets' | 'url'>('upload');
  const [customPhotoInputUrl, setCustomPhotoInputUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showPhotoPickerModal, setShowPhotoPickerModal] = useState(false);
  const [photoUploadError, setPhotoUploadError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const orderList = Array.isArray(orders) ? orders : [];

  const handleGuestSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = guestLookupQuery.trim().toLowerCase();
    if (!query) return;

    const matched = orderList.filter(o => 
      o.id.toLowerCase() === query || 
      (o.id.toLowerCase().replace('#', '') === query.replace('#', '')) ||
      (o.phone && o.phone.replace(/\D/g, '').includes(query.replace(/\D/g, ''))) ||
      (o.trxId && o.trxId.toLowerCase() === query)
    );
    setGuestLookupOrders(matched);
    setHasSearchedGuest(true);
  };

  // If user not logged in
  if (!userProfile) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12 space-y-8 animate-fadeIn">
        <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-xl border border-neutral-200 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
            <User className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-neutral-900">
            {language === 'bn' ? 'অ্যাকাউন্টে প্রবেশ করুন' : 'Sign in to your Account'}
          </h2>
          <p className="text-xs text-neutral-500 max-w-md mx-auto">
            {language === 'bn'
              ? 'আপনার পূর্ববর্তী সব অর্ডার দেখতে, অর্ডারের বিবরণ জানতে এবং প্রোফাইল তথ্য পরিচালনা করতে লগইন করুন।'
              : 'Log in to view order history, order details, and manage your account profile.'}
          </p>
          <div className="pt-2 max-w-xs mx-auto">
            <button
              onClick={onOpenLogin}
              className="w-full py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
            >
              {language === 'bn' ? 'লগইন অথবা অ্যাকাউন্ট তৈরি করুন' : 'Sign In or Create Account'}
            </button>
          </div>
        </div>

        {/* Guest Order Lookup Card */}
        <div className="bg-white p-6 rounded-3xl shadow-md border border-neutral-200 space-y-4">
          <div className="border-b border-neutral-100 pb-3">
            <h3 className="text-base font-black text-neutral-900 flex items-center gap-2">
              <Search className="w-4 h-4 text-rose-600" />
              <span>{language === 'bn' ? 'গেস্ট হিসেবে অর্ডার ট্র্যাক ও বাতিল করুন' : 'Track & Manage Guest Orders'}</span>
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              {language === 'bn' 
                ? 'লগইন ছাড়াই আপনার অর্ডার নম্বর (যেমন: #GG-...) বা মোবাইল নম্বর দিয়ে অর্ডার খুঁজুন ও কুরিয়ারে পাঠানোর পূর্বে বাতিল করুন।' 
                : 'Search with your Order ID or phone number to track live status and cancel before courier dispatch.'}
            </p>
          </div>

          <form onSubmit={handleGuestSearch} className="flex gap-2">
            <input
              type="text"
              value={guestLookupQuery}
              onChange={(e) => setGuestLookupQuery(e.target.value)}
              placeholder={language === 'bn' ? 'অর্ডার নম্বর বা মোবাইল নম্বর লিখুন...' : 'Enter Order ID or phone number...'}
              className="flex-1 px-4 py-2.5 rounded-xl border border-neutral-300 focus:outline-hidden focus:ring-2 focus:ring-rose-400 text-xs bg-neutral-50"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0"
            >
              <Search className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'খুঁজুন' : 'Search'}</span>
            </button>
          </form>

          {/* Guest Order Search Results */}
          {hasSearchedGuest && (
            <div className="pt-2 space-y-3">
              {guestLookupOrders.length === 0 ? (
                <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-2xl text-center text-xs text-neutral-500">
                  {language === 'bn' ? 'এই নম্বরে কোনো সক্রিয় অর্ডার খুঁজে পাওয়া যায়নি।' : 'No orders found matching this query.'}
                </div>
              ) : (
                guestLookupOrders.map(order => {
                  const cancellable = canUserCancelOrder(order);
                  return (
                    <div key={order.id} className="p-4 rounded-2xl border border-neutral-200 bg-neutral-50/50 space-y-3 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-200 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-rose-600 text-sm">#{order.id}</span>
                          <span className="text-neutral-400">•</span>
                          <span className="text-neutral-500">{order.date}</span>
                        </div>
                        <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                          order.orderStatus === 'delivered' ? 'bg-emerald-100 text-emerald-800' :
                          order.orderStatus === 'shipped' || order.orderStatus === 'out_for_delivery' ? 'bg-indigo-100 text-indigo-800' :
                          order.orderStatus === 'confirmed' || order.orderStatus === 'processing' || order.orderStatus === 'packed' ? 'bg-blue-100 text-blue-800' :
                          order.orderStatus === 'cancelled' || order.orderStatus === 'returned' ? 'bg-red-100 text-red-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {getStatusLabel(order.orderStatus, language)}
                        </span>
                      </div>

                      <div className="flex justify-between items-center text-neutral-700">
                        <span>{order.customerName} • {order.phone}</span>
                        <span className="font-mono font-black text-rose-600">{formatPrice(order.total, language)}</span>
                      </div>

                      {/* Items */}
                      <div className="text-[11px] text-neutral-500 line-clamp-1">
                        {order.items.map(i => `${language === 'bn' ? i.product.titleBn : i.product.titleEn} (${i.quantity})`).join(', ')}
                      </div>

                      {/* Cancellation Action for Guest */}
                      <div className="pt-2 border-t border-neutral-200 flex flex-wrap items-center justify-between gap-2">
                        {order.orderStatus === 'cancelled' ? (
                          <div className="flex items-center gap-1.5 text-red-600 font-bold text-[11px]">
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>{language === 'bn' ? 'অর্ডারটি ইতিমধ্যে বাতিল করা হয়েছে' : 'Order is cancelled'}</span>
                          </div>
                        ) : cancellable ? (
                          <div className="flex flex-wrap items-center justify-between gap-2 w-full">
                            <span className="text-emerald-700 font-medium text-[11px] flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>{language === 'bn' ? 'কুরিয়ারে হস্তান্তরের অপেক্ষায় (বাতিলযোগ্য)' : 'Awaiting courier dispatch (Cancellable)'}</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => setCancellingOrder(order)}
                              className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl font-bold text-xs flex items-center gap-1 transition cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5 text-red-600" />
                              <span>{language === 'bn' ? 'অর্ডার বাতিল করুন' : 'Cancel Order'}</span>
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 text-neutral-500 text-[11px]">
                            <Truck className="w-3.5 h-3.5 text-neutral-400" />
                            <span>{language === 'bn' ? 'কুরিয়ারে পাঠানো হয়েছে (বাতিল করা সম্ভব নয়)' : 'Dispatched to courier (Non-cancellable)'}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>

        {/* Modal for guest order cancellation */}
        <CancelOrderModal
          order={cancellingOrder}
          isOpen={Boolean(cancellingOrder)}
          onClose={() => setCancellingOrder(null)}
          onConfirmCancel={async (orderId, reason) => {
            if (onCancelOrder) {
              await onCancelOrder(orderId, reason);
              setGuestLookupOrders(prev => prev.map(o => o.id === orderId ? { ...o, orderStatus: 'cancelled' } : o));
            }
            setCancellingOrder(null);
          }}
          language={language}
        />
      </div>
    );
  }

  // Filter orders belonging to this user
  const userOrders = orderList.filter(o => 
    (o.userId && userProfile?.uid && o.userId === userProfile.uid) || 
    (o.userEmail && userProfile?.email && o.userEmail.toLowerCase() === userProfile.email.toLowerCase()) ||
    (o.phone && userProfile?.phone && o.phone.trim() === userProfile.phone.trim())
  );

  // Calculate Order Statistics
  const totalOrdersCount = userOrders.length;
  
  const totalSpentAmount = userOrders
    .filter(o => o.orderStatus !== 'cancelled')
    .reduce((acc, o) => acc + o.total, 0);

  const confirmedOrdersCount = userOrders.filter(
    o => o.orderStatus === 'confirmed' || o.orderStatus === 'processing' || o.orderStatus === 'packed'
  ).length;
  
  const pendingOrdersCount = userOrders.filter(
    o => o.orderStatus === 'placed' || o.orderStatus === 'pending'
  ).length;

  const shippingOrdersCount = userOrders.filter(
    o => o.orderStatus === 'shipped' || o.orderStatus === 'out_for_delivery'
  ).length;

  const deliveredOrdersCount = userOrders.filter(o => o.orderStatus === 'delivered').length;

  const returnedOrCancelledCount = userOrders.filter(
    o => o.orderStatus === 'cancelled' || o.orderStatus === 'returned'
  ).length;

  // Handle local image file upload & resize
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhotoUploadError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      setPhotoUploadError(language === 'bn' ? 'ছবির সাইজ সর্বোচ্চ ৮ এমবি হতে পারবে।' : 'Image size cannot exceed 8MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Compress to max 400x400 for snappy storage in Firestore/state
        const canvas = document.createElement('canvas');
        const maxDim = 400;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
        
        setEditPhotoURL(dataUrl);
        // If photo picker modal is open, auto-apply and close or show preview
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Direct quick photo update
  const handleQuickPhotoSave = async (newPhoto: string) => {
    setIsSaving(true);
    const updated: UserProfile = {
      ...userProfile,
      photoURL: newPhoto,
      updatedAt: new Date().toISOString(),
    };

    try {
      // Firebase Auth photoURL only allows HTTP/HTTPS URLs up to 2048 characters.
      // Base64 data URLs are stored directly in Firestore without length limits.
      if (auth.currentUser && newPhoto && !newPhoto.startsWith('data:') && newPhoto.length <= 2000) {
        try {
          await updateProfile(auth.currentUser, { photoURL: newPhoto });
        } catch (authErr) {
          console.warn('Firebase Auth photoURL update warning:', authErr);
        }
      }
      await saveUserProfileToFirestore(userProfile.uid, updated);
      onUpdateProfile(updated);
      setEditPhotoURL(newPhoto);
      setShowPhotoPickerModal(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to update photo:', err);
    } finally {
      setIsSaving(false);
    }
  };

  // Save Profile Handler
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    const updated: UserProfile = {
      ...userProfile,
      displayName: editName.trim() || userProfile.displayName,
      phone: editPhone.trim(),
      address: editAddress.trim(),
      photoURL: editPhotoURL || userProfile.photoURL,
      updatedAt: new Date().toISOString(),
    };

    try {
      if (auth.currentUser) {
        try {
          const authUpdate: { displayName?: string; photoURL?: string } = {
            displayName: updated.displayName
          };
          if (updated.photoURL && !updated.photoURL.startsWith('data:') && updated.photoURL.length <= 2000) {
            authUpdate.photoURL = updated.photoURL;
          }
          await updateProfile(auth.currentUser, authUpdate);
        } catch (authErr) {
          console.warn('Firebase Auth updateProfile warning:', authErr);
        }
      }
      await saveUserProfileToFirestore(userProfile.uid, updated);
      onUpdateProfile(updated);
      setSaveSuccess(true);
      setIsEditing(false);
      setShowPhotoPickerModal(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to save profile:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const filteredOrders = orderStatusFilter === 'all'
    ? userOrders
    : userOrders.filter(o => {
        if (orderStatusFilter === 'pending') {
          return o.orderStatus === 'placed' || o.orderStatus === 'pending';
        }
        if (orderStatusFilter === 'confirmed') {
          return o.orderStatus === 'confirmed' || o.orderStatus === 'processing' || o.orderStatus === 'packed';
        }
        if (orderStatusFilter === 'shipped') {
          return o.orderStatus === 'shipped' || o.orderStatus === 'out_for_delivery';
        }
        if (orderStatusFilter === 'cancelled') {
          return o.orderStatus === 'cancelled' || o.orderStatus === 'returned';
        }
        return o.orderStatus === orderStatusFilter;
      });

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6 animate-fadeIn">
      {/* Hidden File Input for Image Upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept="image/*"
        className="hidden"
      />

      {/* Header Profile Card */}
      <div className="bg-white rounded-3xl p-5 sm:p-8 border border-neutral-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4 sm:gap-5">
          {/* Profile Photo with Clickable Camera Badge */}
          <div className="relative group shrink-0">
            <div 
              onClick={() => {
                setEditPhotoURL(userProfile.photoURL || '');
                setShowPhotoPickerModal(true);
              }}
              className="w-18 h-18 sm:w-22 sm:h-22 rounded-2xl sm:rounded-3xl bg-gradient-to-tr from-rose-600 to-red-500 text-white flex items-center justify-center text-2xl sm:text-3xl font-black shadow-md shadow-rose-200 overflow-hidden cursor-pointer relative border-2 border-white"
              title={language === 'bn' ? 'ছবি পরিবর্তন করতে ক্লিক করুন' : 'Click to change photo'}
            >
              {userProfile.photoURL ? (
                <img 
                  src={userProfile.photoURL} 
                  alt={userProfile.displayName} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform" 
                />
              ) : (
                userProfile.displayName ? userProfile.displayName.charAt(0).toUpperCase() : 'U'
              )}

              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[10px] font-bold gap-1">
                <Camera className="w-5 h-5" />
                <span>{language === 'bn' ? 'ছবি পরিবর্তন' : 'Change'}</span>
              </div>
            </div>

            {/* Quick Camera Action Button */}
            <button
              onClick={() => {
                setEditPhotoURL(userProfile.photoURL || '');
                setShowPhotoPickerModal(true);
              }}
              className="absolute -bottom-1 -right-1 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-rose-600 text-white shadow-md flex items-center justify-center hover:bg-rose-700 transition cursor-pointer border-2 border-white"
              title={language === 'bn' ? 'ছবি পরিবর্তন করুন' : 'Change profile picture'}
            >
              <Camera className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
          </div>

          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-neutral-900">
                {userProfile.displayName || 'সম্মানিত গ্রাহক'}
              </h1>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                <span>Verified Account</span>
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-500">
              <span className="flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                <span className="truncate max-w-[200px] sm:max-w-none">{userProfile.email}</span>
              </span>
              {userProfile.phone && (
                <span className="flex items-center gap-1 font-mono">
                  <Phone className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                  <span>{userProfile.phone}</span>
                </span>
              )}
              {userProfile.address && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                  <span className="line-clamp-1">{userProfile.address}</span>
                </span>
              )}
            </div>

            {/* Change photo link */}
            <button
              onClick={() => {
                setEditPhotoURL(userProfile.photoURL || '');
                setShowPhotoPickerModal(true);
              }}
              className="text-xs text-rose-600 hover:text-rose-700 font-bold flex items-center gap-1 pt-1 cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'প্রোফাইল ছবি পরিবর্তন বা আপলোড করুন' : 'Update Profile Photo'}</span>
            </button>
          </div>
        </div>

        {/* Top actions: Edit profile & Logout */}
        <div className="flex flex-wrap items-center gap-2 self-end md:self-center">
          {userProfile.email?.toLowerCase() === 'winlucky414@gmail.com' && onOpenAdmin && (
            <button
              id="account-admin-btn"
              onClick={onOpenAdmin}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm shadow-amber-200 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t.adminNav}</span>
            </button>
          )}

          <button
            id="edit-profile-btn"
            onClick={() => {
              setEditName(userProfile.displayName || '');
              setEditPhone(userProfile.phone || '');
              setEditAddress(userProfile.address || '');
              setEditPhotoURL(userProfile.photoURL || '');
              setIsEditing(true);
            }}
            className="px-4 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'তথ্য পরিবর্তন' : 'Edit Profile'}</span>
          </button>

          <button
            id="account-logout-btn"
            onClick={onLogout}
            className="px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'লগআউট' : 'Sign Out'}</span>
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{language === 'bn' ? 'আপনার প্রোফাইল তথ্য ও ছবি সফলভাবে সংরক্ষণ করা হয়েছে!' : 'Profile and photo updated successfully!'}</span>
        </div>
      )}

      {/* Analytics Breakdown Grid */}
      <div className="space-y-2">
        <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-neutral-600">
          {language === 'bn' ? 'আপনার অর্ডার পরিসংখ্যান ও হিসাব' : 'Your Order Analytics & Summary'}
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 sm:gap-3">
          {/* Total Spent */}
          <div className="bg-gradient-to-br from-rose-500 to-red-600 text-white p-3.5 sm:p-4 rounded-2xl shadow-xs space-y-1">
            <span className="text-[11px] font-medium text-rose-100 block">
              {language === 'bn' ? 'মোট কেনাকাটা' : 'Total Spent'}
            </span>
            <p className="text-base sm:text-xl font-black">
              {formatPrice(totalSpentAmount, language)}
            </p>
            <span className="text-[10px] text-rose-100 block">
              {language === 'bn' ? `${toBengaliNumber(totalOrdersCount)} টি অর্ডারে` : `Across ${totalOrdersCount} orders`}
            </span>
          </div>

          {/* Total Orders */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-neutral-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-blue-600">
              <span className="text-[11px] font-semibold text-neutral-500">{language === 'bn' ? 'মোট অর্ডার' : 'Total Orders'}</span>
              <ShoppingBag className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-black text-neutral-900">
              {language === 'bn' ? toBengaliNumber(totalOrdersCount) : totalOrdersCount}
            </p>
            <span className="text-[10px] text-neutral-400 block">{language === 'bn' ? 'সর্বমোট অর্ডার' : 'All time orders'}</span>
          </div>

          {/* Confirmed Orders */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-neutral-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-emerald-600">
              <span className="text-[11px] font-semibold text-neutral-500">{language === 'bn' ? 'কনফার্ম হয়েছে' : 'Confirmed'}</span>
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-black text-emerald-600">
              {language === 'bn' ? toBengaliNumber(confirmedOrdersCount) : confirmedOrdersCount}
            </p>
            <span className="text-[10px] text-neutral-400 block">{language === 'bn' ? 'নিশ্চিতকৃত অর্ডার' : 'Confirmed'}</span>
          </div>

          {/* Pending / Processing */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-neutral-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-amber-600">
              <span className="text-[11px] font-semibold text-neutral-500">{language === 'bn' ? 'পেন্ডিং / প্রসেসিং' : 'Pending'}</span>
              <Clock className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-black text-amber-600">
              {language === 'bn' ? toBengaliNumber(pendingOrdersCount) : pendingOrdersCount}
            </p>
            <span className="text-[10px] text-neutral-400 block">{language === 'bn' ? 'অপেক্ষমান অর্ডার' : 'In processing'}</span>
          </div>

          {/* Shipping / In-Transit */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-neutral-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-indigo-600">
              <span className="text-[11px] font-semibold text-neutral-500">{language === 'bn' ? 'শিপিং হয়েছে' : 'Shipping'}</span>
              <Truck className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-black text-indigo-600">
              {language === 'bn' ? toBengaliNumber(shippingOrdersCount) : shippingOrdersCount}
            </p>
            <span className="text-[10px] text-neutral-400 block">{language === 'bn' ? 'কুরিয়ারে পথে আছে' : 'In transit'}</span>
          </div>

          {/* Cancelled / Returned */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-neutral-200 shadow-xs space-y-1">
            <div className="flex items-center justify-between text-rose-600">
              <span className="text-[11px] font-semibold text-neutral-500">{language === 'bn' ? 'রিটার্ন / বাতিল' : 'Return/Cancel'}</span>
              <RotateCcw className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-black text-rose-600">
              {language === 'bn' ? toBengaliNumber(returnedOrCancelledCount) : returnedOrCancelledCount}
            </p>
            <span className="text-[10px] text-neutral-400 block">{language === 'bn' ? 'বাতিল বা রিটার্ন' : 'Returned / Void'}</span>
          </div>
        </div>
      </div>

      {/* Main Content Area: My Orders & Account Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: My Orders */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-neutral-200 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-100 pb-3">
              <div>
                <h3 className="text-base font-black text-neutral-900 flex items-center gap-2">
                  <Package className="w-4 h-4 text-rose-600" />
                  <span>{language === 'bn' ? 'আমার অর্ডারসমূহ' : 'My Orders'}</span>
                </h3>
                <p className="text-xs text-neutral-500">
                  {language === 'bn' ? 'আপনার সকল অর্ডারের তালিকা ও বিবরণ' : 'Order history and details'}
                </p>
              </div>

              {/* Status Filter buttons */}
              <div className="flex items-center gap-1 overflow-x-auto text-xs pb-1">
                {[
                  { id: 'all', labelBn: 'সব', labelEn: 'All' },
                  { id: 'pending', labelBn: 'পেন্ডিং', labelEn: 'Pending' },
                  { id: 'confirmed', labelBn: 'কনফার্ম', labelEn: 'Confirmed' },
                  { id: 'shipped', labelBn: 'শিপিং', labelEn: 'Shipped' },
                  { id: 'delivered', labelBn: 'ডেলিভার্ড', labelEn: 'Delivered' },
                  { id: 'cancelled', labelBn: 'বাতিল/রিটার্ন', labelEn: 'Cancelled' },
                ].map(f => (
                  <button
                    key={f.id}
                    onClick={() => setOrderStatusFilter(f.id)}
                    className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition cursor-pointer whitespace-nowrap ${
                      orderStatusFilter === f.id
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                    }`}
                  >
                    {language === 'bn' ? f.labelBn : f.labelEn}
                  </button>
                ))}
              </div>
            </div>

            {/* Orders List Header & Bulk Selection */}
            {filteredOrders.length > 0 && (
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    if (selectedOrderIds.length === filteredOrders.length) {
                      setSelectedOrderIds([]);
                    } else {
                      setSelectedOrderIds(filteredOrders.map(o => o.id));
                    }
                  }}
                  className="inline-flex items-center gap-2 text-xs font-bold text-neutral-700 hover:text-neutral-900 cursor-pointer bg-neutral-100 hover:bg-neutral-200 px-3 py-1.5 rounded-xl transition"
                >
                  <input
                    type="checkbox"
                    checked={filteredOrders.length > 0 && selectedOrderIds.length === filteredOrders.length}
                    onChange={() => {}}
                    className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer pointer-events-none"
                  />
                  <span>
                    {selectedOrderIds.length === filteredOrders.length
                      ? (language === 'bn' ? 'সব ডিসিলেক্ট করুন' : 'Deselect All')
                      : (language === 'bn' ? 'সব সিলেক্ট করুন' : 'Select All')}
                  </span>
                </button>

                {selectedOrderIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm(language === 'bn' ? `আপনি কি নির্বাচিত ${toBengaliNumber(selectedOrderIds.length)} টি অর্ডার মুছে ফেলতে চান?` : `Are you sure you want to delete ${selectedOrderIds.length} selected orders?`)) {
                        if (onBulkDeleteOrders) {
                          onBulkDeleteOrders(selectedOrderIds);
                        } else if (onDeleteOrder) {
                          selectedOrderIds.forEach(id => onDeleteOrder(id));
                        }
                        setSelectedOrderIds([]);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl shadow-xs transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>
                      {language === 'bn'
                        ? `মুছে ফেলুন (${toBengaliNumber(selectedOrderIds.length)})`
                        : `Delete Selected (${selectedOrderIds.length})`}
                    </span>
                  </button>
                )}
              </div>
            )}

            {/* Orders List */}
            {filteredOrders.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-rose-50 text-rose-400 flex items-center justify-center mx-auto">
                  <ShoppingBag className="w-7 h-7" />
                </div>
                <p className="text-xs font-semibold text-neutral-600">
                  {language === 'bn' ? 'এই ক্যাটাগরিতে কোনো অর্ডার পাওয়া যায়নি।' : 'No orders found for this filter.'}
                </p>
                <button
                  onClick={onGoShopping}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? 'পণ্য কেনাকাটা শুরু করুন' : 'Start Shopping'}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredOrders.map(order => {
                  const isSelected = selectedOrderIds.includes(order.id);
                  return (
                  <div
                    key={order.id}
                    className={`p-4 rounded-2xl border transition space-y-3 ${
                      isSelected
                        ? 'border-rose-400 bg-rose-50/40 ring-2 ring-rose-200'
                        : 'border-neutral-200 hover:border-rose-200 bg-neutral-50/50'
                    }`}
                  >
                    {/* Top Row: Order ID, Date, Status */}
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-200 pb-2.5">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {
                            setSelectedOrderIds(prev =>
                              prev.includes(order.id)
                                ? prev.filter(id => id !== order.id)
                                : [...prev, order.id]
                            );
                          }}
                          className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                        />
                        <span className="font-mono font-black text-rose-600 text-sm">{order.id}</span>
                        <span className="text-xs text-neutral-400">•</span>
                        <span className="text-xs text-neutral-500 flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                          <span>{order.date}</span>
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Order status badge */}
                        <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                          order.orderStatus === 'delivered' ? 'bg-emerald-100 text-emerald-800' :
                          order.orderStatus === 'shipped' || order.orderStatus === 'out_for_delivery' ? 'bg-indigo-100 text-indigo-800' :
                          order.orderStatus === 'confirmed' || order.orderStatus === 'processing' || order.orderStatus === 'packed' ? 'bg-blue-100 text-blue-800' :
                          order.orderStatus === 'cancelled' || order.orderStatus === 'returned' ? 'bg-red-100 text-red-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {getStatusLabel(order.orderStatus, language)}
                        </span>

                        {canUserCancelOrder(order) && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 border border-rose-200">
                            {language === 'bn' ? 'কুরিয়ারের পূর্বে বাতিলযোগ্য' : 'Cancellable'}
                          </span>
                        )}

                        {/* Payment badge */}
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                          order.paymentStatus === 'paid' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                          'bg-neutral-200 text-neutral-700'
                        }`}>
                          {order.paymentStatus === 'paid' 
                            ? (language === 'bn' ? 'পরিশোধিত' : 'Paid') 
                            : (language === 'bn' ? 'বাকি' : 'Pending')}
                        </span>
                      </div>
                    </div>

                    {/* Delivered Order Notification Banner */}
                    {order.orderStatus === 'delivered' && (
                      <div className="p-2.5 bg-emerald-50/90 border border-emerald-200/90 rounded-xl flex items-center justify-between text-xs text-emerald-900 gap-2">
                        <span className="flex items-center gap-1.5 font-bold">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>
                            {language === 'bn' 
                              ? 'পণ্যটি সফলভাবে ডেলিভারি হয়েছে! নিচের পণ্যে আপনার মূল্যবান রিভিউ দিন।' 
                              : 'Order delivered successfully! Please leave a review on the items below.'}
                          </span>
                        </span>
                      </div>
                    )}

                    {/* Items row */}
                    <div className="space-y-2.5">
                      {order.items.map((item, idx) => {
                        const existingItemReview = reviews.find(r => 
                          (r.productId === item.product.id || r.productTitle === item.product.titleBn) &&
                          (r.orderId === order.id || (userProfile?.email && r.userEmail?.toLowerCase() === userProfile.email.toLowerCase()))
                        );

                        return (
                          <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-3 p-2.5 rounded-xl bg-white border border-neutral-200/80">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <img
                                src={item.product.image}
                                alt={item.product.titleEn}
                                className="w-11 h-11 rounded-lg object-cover border border-neutral-200 shrink-0 bg-neutral-50"
                              />
                              <div className="min-w-0">
                                <p className="font-bold text-neutral-900 truncate">
                                  {language === 'bn' ? item.product.titleBn : item.product.titleEn}
                                </p>
                                <p className="text-[11px] text-neutral-500">
                                  {language === 'bn' ? toBengaliNumber(item.quantity) : item.quantity} x {formatPrice(item.product.price, language)}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center justify-between sm:justify-end gap-3 pt-1 sm:pt-0 border-t sm:border-t-0 border-neutral-100">
                              <span className="font-mono font-bold text-neutral-900 shrink-0">
                                {formatPrice(item.product.price * item.quantity, language)}
                              </span>

                              {/* Review Action on Delivered Status */}
                              {order.orderStatus === 'delivered' ? (
                                existingItemReview ? (
                                  <button
                                    onClick={() => onOpenWriteReview && onOpenWriteReview(item.product, order.id, existingItemReview)}
                                    className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 rounded-lg text-[11px] font-bold flex items-center gap-1 transition cursor-pointer shadow-2xs"
                                    title={language === 'bn' ? 'রিভিউ এডিট করুন' : 'Edit your review'}
                                  >
                                    <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                                    <span>{language === 'bn' ? `রিভিউ (${toBengaliNumber(existingItemReview.rating)}★)` : `Reviewed (${existingItemReview.rating}★)`}</span>
                                    <Edit3 className="w-3 h-3 text-amber-700 ml-0.5" />
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => onOpenWriteReview && onOpenWriteReview(item.product, order.id, null)}
                                    className="px-3 py-1.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs shadow-rose-200"
                                  >
                                    <Star className="w-3 h-3 fill-amber-300 text-amber-300" />
                                    <span>{language === 'bn' ? '⭐ রিভিউ দিন' : 'Rate & Review'}</span>
                                  </button>
                                )
                              ) : order.orderStatus !== 'cancelled' ? (
                                <span className="text-[10px] text-neutral-400 italic">
                                  {language === 'bn' ? 'ডেলিভারির পর রিভিউ দেয়া যাবে' : 'Review upon delivery'}
                                </span>
                              ) : null}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Bottom Row: Total & Track Button */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-neutral-200 text-xs">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-neutral-500">{language === 'bn' ? 'মোট প্রদেয় মূল্য:' : 'Total Payable:'} </span>
                        <span className="font-black text-neutral-900 text-sm">
                          {formatPrice(order.total, language)}
                        </span>
                        
                        {/* Payment Method Badge */}
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded uppercase font-mono bg-neutral-200/70 text-neutral-800">
                          {order.paymentMethod === 'card' 
                            ? `${order.cardBrand === 'mastercard' ? 'Mastercard' : 'Visa'} ${order.cardLast4 ? `(****${order.cardLast4})` : ''}` 
                            : order.paymentMethod}
                        </span>

                        {order.trxId && (
                          <span className="text-[10px] font-mono text-rose-700 bg-rose-50 border border-rose-200 px-1.5 py-0.5 rounded">
                            Trx: {order.trxId}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1.5 text-xs text-neutral-600 bg-neutral-100 px-2.5 py-1 rounded-xl">
                          <MapPin className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                          <span className="line-clamp-1 max-w-[140px] sm:max-w-[200px]">{order.address}</span>
                        </div>

                        {canUserCancelOrder(order) && (
                          <button
                            type="button"
                            onClick={() => setCancellingOrder(order)}
                            className="px-2.5 py-1 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold text-[11px] flex items-center gap-1 transition cursor-pointer shadow-2xs"
                            title={language === 'bn' ? 'কুরিয়ারে হস্তান্তরের পূর্বে অর্ডার বাতিল করুন' : 'Cancel order before courier dispatch'}
                          >
                            <XCircle className="w-3.5 h-3.5 text-red-600" />
                            <span>{language === 'bn' ? 'অর্ডার বাতিল' : 'Cancel'}</span>
                          </button>
                        )}

                        {onDeleteOrder && (
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(language === 'bn' ? `আপনি কি নিশ্চিত যে অর্ডার #${order.id} আপনার অ্যাকাউন্ট থেকে মুছে ফেলতে চান? এটি স্থায়ীভাবে মুছে যাবে।` : `Are you sure you want to delete order #${order.id}? This will remove it permanently.`)) {
                                onDeleteOrder(order.id);
                                setSelectedOrderIds(prev => prev.filter(id => id !== order.id));
                              }
                            }}
                            className="px-2.5 py-1 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 font-bold text-[11px] flex items-center gap-1 transition cursor-pointer shadow-2xs"
                            title={language === 'bn' ? 'অর্ডারটি মুছে ফেলুন' : 'Delete order'}
                          >
                            <Trash2 className="w-3.5 h-3.5 text-red-600" />
                            <span>{language === 'bn' ? 'মুছুন' : 'Delete'}</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => setExpandedTrackingOrderId(expandedTrackingOrderId === order.id ? null : order.id)}
                          className="px-2.5 py-1 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-[11px] flex items-center gap-1 transition cursor-pointer"
                        >
                          <Truck className="w-3 h-3 text-rose-400" />
                          <span>{expandedTrackingOrderId === order.id ? (language === 'bn' ? 'লুকান' : 'Hide') : (language === 'bn' ? 'ট্র্যাকিং' : 'Track')}</span>
                        </button>
                      </div>
                    </div>

                    {/* Expanded Live Order Tracking Timeline */}
                    {expandedTrackingOrderId === order.id && (
                      <div className="pt-3 border-t border-neutral-200/80 bg-white p-4 rounded-2xl space-y-3 animate-fadeIn">
                        <div className="flex items-center justify-between">
                          <h4 className="font-black text-neutral-900 text-xs flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-rose-600" />
                            <span>{language === 'bn' ? 'লাইভ অর্ডার স্ট্যাটাস ও ট্র্যাকিং' : 'Live Order Progress & Tracking'}</span>
                          </h4>
                          {order.trackingCode && (
                            <span className="text-[11px] font-mono font-bold text-neutral-700 bg-neutral-100 px-2 py-0.5 rounded-md border border-neutral-200">
                              {order.courierName?.toUpperCase() || 'COURIER'}: {order.trackingCode}
                            </span>
                          )}
                        </div>

                        {/* 4-Step Visual Tracker */}
                        {(() => {
                          const isCancelled = order.orderStatus === 'cancelled' || order.orderStatus === 'returned';
                          if (isCancelled) {
                            return (
                              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-bold flex items-center gap-2">
                                <RotateCcw className="w-4 h-4 text-red-600" />
                                <span>{language === 'bn' ? 'এই অর্ডারটি বাতিল বা ফেরত হয়েছে।' : 'This order has been cancelled or returned.'}</span>
                              </div>
                            );
                          }

                          const step1Done = true;
                          const step2Done = order.orderStatus === 'confirmed' || order.orderStatus === 'processing' || order.orderStatus === 'packed' || order.orderStatus === 'shipped' || order.orderStatus === 'out_for_delivery' || order.orderStatus === 'delivered';
                          const step3Done = order.orderStatus === 'shipped' || order.orderStatus === 'out_for_delivery' || order.orderStatus === 'delivered';
                          const step4Done = order.orderStatus === 'delivered';

                          return (
                            <div className="grid grid-cols-4 gap-2 pt-2">
                              {/* Step 1 */}
                              <div className="flex flex-col items-center text-center space-y-1">
                                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                                  step1Done ? 'bg-emerald-600 text-white' : 'bg-neutral-200 text-neutral-500'
                                }`}>
                                  <Check className="w-4 h-4" />
                                </div>
                                <span className="text-[10px] font-bold text-neutral-800 leading-tight">
                                  {language === 'bn' ? 'অর্ডার গ্রহণ' : 'Placed'}
                                </span>
                              </div>

                              {/* Step 2 */}
                              <div className="flex flex-col items-center text-center space-y-1">
                                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                                  step2Done ? 'bg-emerald-600 text-white' : 'bg-neutral-200 text-neutral-500'
                                }`}>
                                  {step2Done ? <Check className="w-4 h-4" /> : '2'}
                                </div>
                                <span className="text-[10px] font-bold text-neutral-800 leading-tight">
                                  {language === 'bn' ? 'অ্যাপ্রুভড' : 'Confirmed'}
                                </span>
                              </div>

                              {/* Step 3 */}
                              <div className="flex flex-col items-center text-center space-y-1">
                                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                                  step3Done ? 'bg-emerald-600 text-white' : 'bg-neutral-200 text-neutral-500'
                                }`}>
                                  {step3Done ? <Check className="w-4 h-4" /> : '3'}
                                </div>
                                <span className="text-[10px] font-bold text-neutral-800 leading-tight">
                                  {language === 'bn' ? 'কুরিয়ারে পাঠানো' : 'Shipped'}
                                </span>
                              </div>

                              {/* Step 4 */}
                              <div className="flex flex-col items-center text-center space-y-1">
                                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                                  step4Done ? 'bg-emerald-600 text-white' : 'bg-neutral-200 text-neutral-500'
                                }`}>
                                  {step4Done ? <Check className="w-4 h-4" /> : '4'}
                                </div>
                                <span className="text-[10px] font-bold text-neutral-800 leading-tight">
                                  {language === 'bn' ? 'ডেলিভার্ড' : 'Delivered'}
                                </span>
                              </div>
                            </div>
                          );
                        })()}

                        {/* Cancellation Status & Action Banner inside Tracking Timeline */}
                        {order.orderStatus !== 'cancelled' && order.orderStatus !== 'returned' && (
                          canUserCancelOrder(order) ? (
                            <div className="mt-2 p-3 bg-rose-50/80 border border-rose-200 rounded-xl text-xs flex flex-wrap items-center justify-between gap-2">
                              <div className="flex items-center gap-2 text-rose-900">
                                <Info className="w-4 h-4 text-rose-600 shrink-0" />
                                <span>
                                  {language === 'bn'
                                    ? 'অর্ডারটি এখনও কুরিয়ার সার্ভিসে দেওয়া হয়নি। আপনি চাইলে সরাসরি এখান থেকে বাতিল করতে পারেন।'
                                    : 'Order is not handed to courier yet. You can cancel it directly.'}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => setCancellingOrder(order)}
                                className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg transition cursor-pointer shadow-2xs flex items-center gap-1"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>{language === 'bn' ? 'অর্ডার বাতিল করুন' : 'Cancel Order'}</span>
                              </button>
                            </div>
                          ) : (
                            <div className="mt-2 p-2.5 bg-neutral-100 border border-neutral-200 rounded-xl text-xs text-neutral-600 flex items-center gap-2">
                              <Truck className="w-4 h-4 text-neutral-500 shrink-0" />
                              <span>
                                {language === 'bn'
                                  ? 'অর্ডারটি ইতিমধ্যে কুরিয়ার সার্ভিসে হস্তান্তর করা হয়েছে, তাই এখন আর বাতিল করা সম্ভব নয়।'
                                  : 'Order has already been dispatched to courier and cannot be cancelled.'}
                              </span>
                            </div>
                          )
                        )}
                      </div>
                    )}
                  </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right 1 Col: Saved Addresses & Profile Details */}
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-xs space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <h3 className="text-base font-black text-neutral-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-rose-600" />
                <span>{language === 'bn' ? 'ডেলিভারি ঠিকানা ও তথ্য' : 'Default Delivery Info'}</span>
              </h3>
              <button
                onClick={() => setIsEditing(true)}
                className="text-rose-600 hover:text-rose-700 font-bold cursor-pointer"
              >
                {language === 'bn' ? 'এডিট' : 'Edit'}
              </button>
            </div>

            <div className="space-y-3 text-neutral-700">
              <div>
                <span className="text-neutral-400 block text-[11px] uppercase font-semibold">
                  {language === 'bn' ? 'পূর্ণ নাম' : 'Full Name'}
                </span>
                <p className="font-bold text-neutral-900">{userProfile.displayName || '-'}</p>
              </div>

              <div>
                <span className="text-neutral-400 block text-[11px] uppercase font-semibold">
                  {language === 'bn' ? 'ইমেইল অ্যাড্রেস' : 'Email Address'}
                </span>
                <p className="font-mono">{userProfile.email || '-'}</p>
              </div>

              <div>
                <span className="text-neutral-400 block text-[11px] uppercase font-semibold">
                  {language === 'bn' ? 'মোবাইল নম্বর' : 'Phone Number'}
                </span>
                <p className="font-mono">{userProfile.phone || (language === 'bn' ? 'যুক্ত করা হয়নি' : 'Not added')}</p>
              </div>

              <div>
                <span className="text-neutral-400 block text-[11px] uppercase font-semibold">
                  {language === 'bn' ? 'পূর্ণ ঠিকানা' : 'Address Details'}
                </span>
                <p className="leading-relaxed">
                  {userProfile.address || (language === 'bn' ? 'চেকআউটে স্বয়ংক্রিয় পূরণের জন্য আপনার ঠিকানা যুক্ত করুন।' : 'Add your street address for quick checkout.')}
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-neutral-100 flex flex-col gap-2">
              <button
                onClick={() => {
                  setEditPhotoURL(userProfile.photoURL || '');
                  setShowPhotoPickerModal(true);
                }}
                className="w-full py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl transition text-center cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'নিজের ছবি আপলোড করুন' : 'Upload Profile Picture'}</span>
              </button>

              <button
                onClick={() => setIsEditing(true)}
                className="w-full py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold rounded-xl transition text-center cursor-pointer"
              >
                {language === 'bn' ? 'ঠিকানা ও নাম আপডেট করুন' : 'Update Details'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================================================================ */}
      {/* Photo Picker & Upload Modal (User Request Feature) */}
      {/* ================================================================ */}
      {showPhotoPickerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-neutral-100 space-y-5 my-auto relative">
            <button
              onClick={() => setShowPhotoPickerModal(false)}
              className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-600 p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <h3 className="text-lg font-black text-neutral-900 flex items-center gap-2">
                <Camera className="w-5 h-5 text-rose-600" />
                <span>{language === 'bn' ? 'প্রোফাইল ছবি সেট করুন' : 'Set Profile Photo'}</span>
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                {language === 'bn' ? 'আপনার ডিভাইস থেকে ছবি আপলোড করুন অথবা স্টাইলিশ অবতার বেছে নিন।' : 'Upload a photo from device or pick a stylish avatar.'}
              </p>
            </div>

            {/* Current Preview */}
            <div className="flex items-center gap-4 p-3 bg-neutral-50 rounded-2xl border border-neutral-200">
              <div className="w-16 h-16 rounded-2xl overflow-hidden bg-rose-600 text-white flex items-center justify-center text-xl font-bold border-2 border-white shadow-md shrink-0">
                {editPhotoURL ? (
                  <img src={editPhotoURL} alt="Preview" className="w-full h-full object-cover" />
                ) : (
                  userProfile.displayName ? userProfile.displayName.charAt(0).toUpperCase() : 'U'
                )}
              </div>
              <div className="space-y-1 text-xs">
                <p className="font-bold text-neutral-800">
                  {language === 'bn' ? 'বর্তমান প্রিভিউ (Preview)' : 'Current Photo Preview'}
                </p>
                <p className="text-[11px] text-neutral-500">
                  {editPhotoURL ? (language === 'bn' ? 'ছবি প্রস্তুত আছে।' : 'Ready to save.') : (language === 'bn' ? 'কোনো ছবি সেট করা নেই।' : 'No photo chosen.')}
                </p>
                {editPhotoURL && (
                  <button
                    type="button"
                    onClick={() => setEditPhotoURL('')}
                    className="text-red-600 hover:text-red-700 font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>{language === 'bn' ? 'ছবি মুছে ফেলুন' : 'Remove Photo'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Selection Tabs */}
            <div className="flex border-b border-neutral-200 text-xs font-bold">
              <button
                type="button"
                onClick={() => setPhotoUploadTab('upload')}
                className={`flex-1 pb-2.5 border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
                  photoUploadTab === 'upload' ? 'border-rose-600 text-rose-600' : 'border-transparent text-neutral-500'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'গ্যালারি / ডিভাইস' : 'Upload File'}</span>
              </button>
              <button
                type="button"
                onClick={() => setPhotoUploadTab('presets')}
                className={`flex-1 pb-2.5 border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
                  photoUploadTab === 'presets' ? 'border-rose-600 text-rose-600' : 'border-transparent text-neutral-500'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'স্টাইলিশ অবতার' : 'Avatars'}</span>
              </button>
              <button
                type="button"
                onClick={() => setPhotoUploadTab('url')}
                className={`flex-1 pb-2.5 border-b-2 flex items-center justify-center gap-1.5 cursor-pointer ${
                  photoUploadTab === 'url' ? 'border-rose-600 text-rose-600' : 'border-transparent text-neutral-500'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'অনলাইন লিংক' : 'Image URL'}</span>
              </button>
            </div>

            {/* Tab 1: Device Upload */}
            {photoUploadTab === 'upload' && (
              <div className="space-y-3 text-xs">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-rose-300 hover:border-rose-500 bg-rose-50/40 hover:bg-rose-50/80 rounded-2xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2"
                >
                  <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shadow-xs">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-neutral-800 text-xs">
                      {language === 'bn' ? 'এখানে ক্লিক করে ছবি নির্বাচন বা আপলোড করুন' : 'Click to select photo from device'}
                    </p>
                    <p className="text-[11px] text-neutral-500 mt-0.5">
                      JPG, PNG, WEBP (ক্যামেরা বা গ্যালারি থেকে)
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Preset Avatars */}
            {photoUploadTab === 'presets' && (
              <div className="space-y-2 text-xs">
                <p className="text-[11px] text-neutral-500">
                  {language === 'bn' ? 'যেকোনো একটি অবতারে ক্লিক করুন:' : 'Select any profile avatar:'}
                </p>
                <div className="grid grid-cols-4 gap-2.5 max-h-48 overflow-y-auto p-1">
                  {PRESET_AVATARS.map((av) => (
                    <div
                      key={av.id}
                      onClick={() => setEditPhotoURL(av.url)}
                      className={`relative aspect-square rounded-2xl overflow-hidden border-2 cursor-pointer transition hover:scale-105 shadow-2xs ${
                        editPhotoURL === av.url ? 'border-rose-600 ring-2 ring-rose-200' : 'border-neutral-200 hover:border-neutral-400'
                      }`}
                    >
                      <img src={av.url} alt={av.label} className="w-full h-full object-cover" />
                      {editPhotoURL === av.url && (
                        <div className="absolute inset-0 bg-rose-600/30 flex items-center justify-center text-white">
                          <Check className="w-5 h-5 drop-shadow-md stroke-[3]" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tab 3: URL input */}
            {photoUploadTab === 'url' && (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">
                    {language === 'bn' ? 'ছবির সরাসরি লিংক (Direct Image URL)' : 'Direct Image URL'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      placeholder="https://example.com/my-photo.jpg"
                      value={customPhotoInputUrl}
                      onChange={(e) => setCustomPhotoInputUrl(e.target.value)}
                      className="flex-1 px-3 py-2 bg-white text-neutral-900 placeholder:text-neutral-400 border border-neutral-300 rounded-xl focus:border-rose-500 focus:outline-hidden text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (customPhotoInputUrl.trim()) {
                          setEditPhotoURL(customPhotoInputUrl.trim());
                        }
                      }}
                      className="px-3 py-2 bg-neutral-800 text-white rounded-xl font-bold hover:bg-neutral-900 cursor-pointer"
                    >
                      {language === 'bn' ? 'যুক্ত করুন' : 'Apply'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-100">
              <button
                type="button"
                onClick={() => setShowPhotoPickerModal(false)}
                className="px-4 py-2 border rounded-xl text-neutral-600 hover:bg-neutral-100 text-xs font-semibold cursor-pointer"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={() => handleQuickPhotoSave(editPhotoURL)}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-70"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{isSaving ? (language === 'bn' ? 'সেভ হচ্ছে...' : 'Saving...') : (language === 'bn' ? 'ছবি সেভ করুন' : 'Save Photo')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Profile & Address Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
          <div className="bg-white text-neutral-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-neutral-100 space-y-4 my-auto relative">
            <button
              onClick={() => setIsEditing(false)}
              className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-600 p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="border-b pb-3">
              <h3 className="text-base font-black text-neutral-900">
                {language === 'bn' ? 'প্রোফাইল ও ঠিকানা পরিবর্তন' : 'Edit Profile & Address'}
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                {language === 'bn' ? 'এই তথ্যগুলো আপনার পরবর্তী অর্ডারে সরাসরি ব্যবহৃত হবে।' : 'These details will auto-fill your checkouts.'}
              </p>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs text-neutral-900">
              {/* Profile Photo Field inside Edit Form */}
              <div>
                <label className="block font-bold text-neutral-800 mb-1">
                  {language === 'bn' ? 'প্রোফাইল ছবি' : 'Profile Picture'}
                </label>
                <div className="flex items-center gap-3 p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-rose-600 text-white flex items-center justify-center font-bold shrink-0">
                    {editPhotoURL ? (
                      <img src={editPhotoURL} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      editName ? editName.charAt(0).toUpperCase() : 'U'
                    )}
                  </div>
                  <div className="flex-1">
                    <button
                      type="button"
                      onClick={() => setShowPhotoPickerModal(true)}
                      className="px-3 py-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-lg font-bold text-[11px] text-neutral-800 shadow-2xs cursor-pointer flex items-center gap-1"
                    >
                      <Camera className="w-3 h-3 text-rose-600" />
                      <span>{language === 'bn' ? 'ছবি পরিবর্তন / আপলোড' : 'Change Photo'}</span>
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-neutral-800 mb-1">
                  {language === 'bn' ? 'পূর্ণ নাম' : 'Full Name'} *
                </label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 bg-white text-neutral-900 placeholder:text-neutral-400 font-medium border border-neutral-300 rounded-xl focus:border-rose-500 focus:outline-hidden text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-neutral-800 mb-1">
                  {language === 'bn' ? 'মোবাইল নম্বর' : 'Phone Number'}
                </label>
                <input
                  type="tel"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  placeholder="017xxxxxxxx"
                  className="w-full px-3 py-2 bg-white text-neutral-900 placeholder:text-neutral-400 font-mono font-medium border border-neutral-300 rounded-xl focus:border-rose-500 focus:outline-hidden text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-neutral-800 mb-1">
                  {language === 'bn' ? 'বিস্তারিত ডেলিভারি ঠিকানা' : 'Street Address'}
                </label>
                <textarea
                  rows={2}
                  value={editAddress}
                  onChange={(e) => setEditAddress(e.target.value)}
                  placeholder="বাড়ি নং, রোড নং, থানা, জেলা"
                  className="w-full px-3 py-2 bg-white text-neutral-900 placeholder:text-neutral-400 font-medium border border-neutral-300 rounded-xl focus:border-rose-500 focus:outline-hidden text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 border rounded-xl text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-70"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? (language === 'bn' ? 'সংরক্ষণ হচ্ছে...' : 'Saving...') : (language === 'bn' ? 'সংরক্ষণ করুন' : 'Save Changes')}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Cancel Order Modal for Logged-in User */}
      <CancelOrderModal
        order={cancellingOrder}
        isOpen={Boolean(cancellingOrder)}
        onClose={() => setCancellingOrder(null)}
        onConfirmCancel={async (orderId, reason) => {
          if (onCancelOrder) {
            await onCancelOrder(orderId, reason);
          }
          setCancellingOrder(null);
        }}
        language={language}
      />
    </div>
  );
};

