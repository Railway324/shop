import React from 'react';
import { Star, Zap, Eye, ShoppingBag, Truck } from 'lucide-react';
import { Product, Language } from '../types';
import { translations, formatPrice, toBengaliNumber } from '../utils/translations';
import { useProgressiveImage } from '../utils/imageOptimizer';

interface ProductCardProps {
  product: Product;
  language: Language;
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product, e: React.MouseEvent) => void;
  isInCart?: boolean;
  priority?: boolean;
}

const ProductCardInner: React.FC<ProductCardProps> = ({
  product,
  language,
  onSelectProduct,
  onAddToCart,
  priority = false
}) => {
  const t = translations[language];
  const {
    containerRef,
    isInView,
    isLoaded,
    currentSrc,
    handleLoad,
    handleError
  } = useProgressiveImage(product.image, priority);

  const ratingVal = typeof product.rating === 'number' ? product.rating : 5.0;
  const ratingFormatted = ratingVal.toFixed(1);

  return (
    <div
      ref={containerRef}
      id={`product-card-${product.id}`}
      onClick={() => onSelectProduct(product)}
      className="group bg-[#240106] rounded-2xl border border-[#6B0B1D] hover:border-amber-400/60 shadow-md sm:hover:shadow-xl sm:hover:-translate-y-0.5 transition-[transform,border-color] duration-200 flex flex-col overflow-hidden cursor-pointer relative"
    >
      {/* Top badges */}
      <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1 items-start max-w-[85%] pointer-events-none">
        {product.discountPercent && product.discountPercent > 0 ? (
          <span className="bg-amber-400 text-neutral-950 text-[10px] sm:text-[11px] font-black px-2 py-0.5 rounded-md shadow-md tracking-tight">
            -{language === 'bn' ? toBengaliNumber(product.discountPercent) : product.discountPercent}%
          </span>
        ) : null}
        {product.freeDelivery && (
          <span className="bg-emerald-600 text-white text-[9px] sm:text-[10px] font-black px-2 py-0.5 rounded-md shadow-md flex items-center gap-1">
            <Truck className="w-3 h-3 text-white" />
            <span>{language === 'bn' ? 'ফ্রি ডেলিভারি' : 'Free Delivery'}</span>
          </span>
        )}
        {product.aiTrendScore && product.aiTrendScore >= 75 && (
          <span 
            className="bg-neutral-950/90 backdrop-blur-xs text-amber-300 text-[9px] sm:text-[10px] font-bold px-1.5 sm:px-2 py-0.5 rounded-md shadow-xs flex items-center gap-1 border border-amber-400/20"
          >
            <span>🔥</span>
            <span className="truncate">
              {language === 'bn' ? 'হট ট্রেন্ড' : 'Trending'}
            </span>
          </span>
        )}
      </div>

      {/* Quick view button on hover */}
      <div className="absolute top-2.5 right-2.5 z-10 opacity-0 group-hover:opacity-100 transition-opacity hidden sm:block">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onSelectProduct(product);
          }}
          className="w-8 h-8 rounded-full bg-neutral-900/90 hover:bg-neutral-900 text-amber-300 border border-amber-400/40 shadow-md flex items-center justify-center transition-all hover:scale-110 cursor-pointer"
          title="Quick View"
        >
          <Eye className="w-4 h-4" />
        </button>
      </div>

      {/* Image container with subtle aspect ratio and zoom */}
      <div className="relative aspect-square w-full overflow-hidden bg-[#180004] flex items-center justify-center border-b border-[#6B0B1D]/60">
        {/* Placeholder shimmer only when near viewport and not yet decoded */}
        {isInView && !isLoaded && (
          <div className="absolute inset-0 bg-[#250107] overflow-hidden">
            <div className="w-full h-full bg-gradient-to-r from-transparent via-[#450510]/50 to-transparent animate-shimmer" />
          </div>
        )}
        {isInView && (
          <img
            src={currentSrc}
            alt={product.titleEn || product.titleBn || 'Product'}
            className={`w-full h-full object-cover object-center sm:group-hover:scale-105 transition-[opacity,transform] duration-200 ease-out ${
              isLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            loading={priority ? 'eager' : 'lazy'}
            fetchPriority={priority ? 'high' : 'low'}
            decoding="async"
            onLoad={handleLoad}
            referrerPolicy="no-referrer"
            onError={handleError}
          />
        )}
        {(product.stock ?? 1) <= 0 && (
          <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-[2px] flex items-center justify-center z-10">
            <span className="bg-red-600 text-white font-bold text-[10px] sm:text-xs px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
              {t.outOfStock}
            </span>
          </div>
        )}
      </div>

      {/* Product Information */}
      <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between bg-[#240106]">
        <div>
          {/* Metadata: Category & Rating unboxed with dot separator */}
          <div className="flex items-center gap-1.5 text-[11px] text-neutral-300 mb-1.5">
            <span className="text-amber-200/80 font-medium truncate max-w-[100px] sm:max-w-none">
              {language === 'bn' ? 'প্রিমিয়াম কোয়ালিটি' : 'Premium Quality'}
            </span>
            <span aria-hidden="true" className="text-neutral-500">·</span>
            <div className="flex items-center gap-0.5 text-amber-400 font-semibold text-[11px]">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{language === 'bn' ? toBengaliNumber(ratingFormatted) : ratingFormatted}</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="text-xs sm:text-sm font-bold text-neutral-100 line-clamp-2 leading-snug group-hover:text-amber-300 transition-colors">
            {language === 'bn' ? (product.titleBn || product.titleEn) : (product.titleEn || product.titleBn)}
          </h3>
        </div>

        {/* Pricing & CTA */}
        <div className="mt-3 pt-2.5 border-t border-[#6B0B1D]/80">
          <div className="flex items-baseline gap-2 mb-2.5">
            <span className="text-base sm:text-lg font-black text-amber-400 tracking-tight">
              {formatPrice(product.price, language)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-[11px] sm:text-xs text-neutral-400 line-through">
                {formatPrice(product.originalPrice, language)}
              </span>
            )}
          </div>

          {/* Action Button: Direct Order */}
          <button
            id={`order-now-btn-${product.id}`}
            onClick={(e) => onAddToCart(product, e)}
            disabled={product.stock <= 0}
            className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer ${
              product.stock <= 0
                ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
                : 'bg-gradient-to-r from-[#9B111E] via-[#800020] to-[#5B0616] hover:from-[#C00030] hover:to-[#800020] text-amber-200 border border-amber-500/40 active:scale-95 shadow-xs'
            }`}
          >
            <Zap className="w-3.5 h-3.5 shrink-0 fill-amber-300 text-amber-300" />
            <span className="truncate">{language === 'bn' ? 'অর্ডার করুন' : 'Order Now'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export const ProductCard = React.memo(
  ProductCardInner,
  (prev, next) =>
    prev.product === next.product &&
    prev.language === next.language &&
    prev.priority === next.priority
);
