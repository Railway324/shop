import React, { useState, useRef } from 'react';
import { 
  X, 
  Star, 
  CheckCircle2, 
  Upload, 
  Camera, 
  Image as ImageIcon, 
  Trash2, 
  ShieldCheck, 
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { ProductReview, Language, UserProfile } from '../types';
import { toBengaliNumber } from '../utils/translations';

interface WriteReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: {
    id: string;
    titleBn: string;
    titleEn: string;
    image: string;
    price?: number;
  };
  orderId?: string;
  currentUser: UserProfile | null;
  language: Language;
  onSubmitReview: (review: Omit<ProductReview, 'id' | 'createdAt'>) => void;
  existingReview?: ProductReview | null;
}

export const WriteReviewModal: React.FC<WriteReviewModalProps> = ({
  isOpen,
  onClose,
  product,
  orderId,
  currentUser,
  language,
  onSubmitReview,
  existingReview,
}) => {
  const [rating, setRating] = useState<number>(existingReview?.rating || 5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [comment, setComment] = useState<string>(existingReview?.comment || '');
  const [reviewerName, setReviewerName] = useState<string>(
    existingReview?.userName || existingReview?.customerName || currentUser?.displayName || 'সম্মানিত ক্রেতা'
  );
  const [reviewImage, setReviewImage] = useState<string>(existingReview?.reviewImage || '');
  const [imageError, setImageError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const currentActiveRating = hoverRating || rating;

  const getRatingFeedback = (stars: number) => {
    switch (stars) {
      case 5:
        return language === 'bn' 
          ? '⭐⭐⭐⭐⭐ চমৎকার! দারুণ কোয়ালিটি ও দ্রুত ডেলিভারি' 
          : '⭐⭐⭐⭐⭐ Excellent! Outstanding quality & delivery';
      case 4:
        return language === 'bn' 
          ? '⭐⭐⭐⭐ খুব ভালো! পছন্দ হয়েছে' 
          : '⭐⭐⭐⭐ Very Good! Satisfied with the product';
      case 3:
        return language === 'bn' 
          ? '⭐⭐⭐ মোটামুটি ভালো / সাধারণ' 
          : '⭐⭐⭐ Average / Meets basic expectation';
      case 2:
        return language === 'bn' 
          ? '⭐⭐ প্রত্যাশার চেয়ে কম ভালো' 
          : '⭐⭐ Below Expectation / Needs improvement';
      case 1:
        return language === 'bn' 
          ? '⭐ সন্তুষ্ট নই / সমস্যা হয়েছে' 
          : '⭐ Dissatisfied / Not recommended';
      default:
        return '';
    }
  };

  // Image Upload handler with compression
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImageError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setImageError(language === 'bn' ? 'ছবির আকার সর্বোচ্চ ৫ মেগাবাইট হতে পারবে।' : 'Image size cannot exceed 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          setReviewImage(compressedDataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (rating < 1 || rating > 5) {
      setFormError(language === 'bn' ? 'অনুগ্রহ করে রেটিং স্টার সিলেক্ট করুন।' : 'Please select a star rating.');
      return;
    }

    if (!comment.trim() || comment.trim().length < 5) {
      setFormError(
        language === 'bn' 
          ? 'অনুগ্রহ করে অন্তত ৫ অক্ষরের একটি রিভিউ মতামত লিখুন।' 
          : 'Please write a review comment with at least 5 characters.'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const reviewPayload: Omit<ProductReview, 'id' | 'createdAt'> = {
        productId: product.id,
        productTitle: language === 'bn' ? product.titleBn : product.titleEn,
        productName: language === 'bn' ? product.titleBn : product.titleEn,
        productImage: product.image,
        customerName: reviewerName.trim() || (currentUser?.displayName || 'Verified Buyer'),
        userName: reviewerName.trim() || (currentUser?.displayName || 'Verified Buyer'),
        userEmail: currentUser?.email || '',
        userPhoto: currentUser?.photoURL || '',
        rating,
        comment: comment.trim(),
        status: 'approved', // Verified buyers who received the delivery are automatically approved and visible to all users
        verifiedPurchase: true,
        orderId: orderId || '',
        reviewImage: reviewImage || undefined,
        date: new Date().toISOString().split('T')[0],
      };

      onSubmitReview(reviewPayload);
      setIsSubmitting(false);
      onClose();
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
      setFormError(language === 'bn' ? 'রিভিউ সাবমিট করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।' : 'Failed to submit review.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div 
        className="relative bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-neutral-200 my-auto text-neutral-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-rose-600 to-red-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center">
              <Star className="w-5 h-5 fill-amber-300 text-amber-300" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black leading-tight">
                {existingReview 
                  ? (language === 'bn' ? 'রিভিউ এডিট করুন' : 'Edit Your Review') 
                  : (language === 'bn' ? 'পণ্যের রিভিউ ও রেটিং দিন' : 'Rate & Review Product')}
              </h3>
              <p className="text-[11px] text-rose-100 font-medium">
                {language === 'bn' ? 'আপনার মতামত সকল ক্রেতাকে সাহায্য করবে' : 'Your feedback helps other shoppers'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Purchased Product Preview Card */}
          <div className="flex items-center gap-3 p-3 bg-neutral-50 rounded-2xl border border-neutral-200">
            <img 
              src={product.image} 
              alt={product.titleEn} 
              className="w-14 h-14 object-cover rounded-xl border border-neutral-200 shrink-0 bg-white"
            />
            <div className="min-w-0 flex-1">
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full mb-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                <span>{language === 'bn' ? 'ডেলিভারি নিশ্চিতকৃত ক্রেতা' : 'Verified Delivered Buyer'}</span>
              </span>
              <h4 className="text-xs sm:text-sm font-bold text-neutral-900 truncate">
                {language === 'bn' ? product.titleBn : product.titleEn}
              </h4>
              {orderId && (
                <p className="text-[11px] text-neutral-500 font-mono">
                  {language === 'bn' ? `অর্ডার নং: #${orderId}` : `Order #${orderId}`}
                </p>
              )}
            </div>
          </div>

          {/* Star Rating Interactive Selector */}
          <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200/80 text-center space-y-2">
            <label className="text-xs font-bold text-neutral-700 uppercase tracking-wider block">
              {language === 'bn' ? 'আপনার রেটিং নির্বাচন করুন' : 'Select Your Overall Rating'}
            </label>
            
            <div className="flex items-center justify-center gap-1.5 sm:gap-2 pt-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(null)}
                  className="p-1 transition-transform hover:scale-125 focus:outline-none cursor-pointer"
                  title={`${star} Star`}
                >
                  <Star 
                    className={`w-7 h-7 sm:w-8 sm:h-8 transition-colors ${
                      star <= currentActiveRating 
                        ? 'fill-amber-400 text-amber-500 drop-shadow-xs' 
                        : 'text-neutral-300'
                    }`} 
                  />
                </button>
              ))}
            </div>

            <p className="text-xs font-bold text-amber-900 min-h-[18px] transition-all">
              {getRatingFeedback(currentActiveRating)}
            </p>
          </div>

          {/* Reviewer Name */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-neutral-700">
              {language === 'bn' ? 'আপনার নাম (রিভিউতে প্রদর্শিত হবে):' : 'Your Name (Displayed with review):'}
            </label>
            <input
              type="text"
              value={reviewerName}
              onChange={(e) => setReviewerName(e.target.value)}
              placeholder={language === 'bn' ? 'নাম লিখুন' : 'Enter your name'}
              required
              className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs font-medium text-neutral-900 focus:bg-white focus:border-rose-500 outline-none transition"
            />
          </div>

          {/* Review Text / Feedback */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-neutral-700">
                {language === 'bn' ? 'আপনার বিস্তারিত অভিজ্ঞতা ও মতামত:' : 'Your Detailed Experience & Feedback:'}
              </label>
              <span className="text-[11px] text-neutral-400 font-mono">
                {language === 'bn' ? toBengaliNumber(comment.length) : comment.length}/500
              </span>
            </div>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value.slice(0, 500))}
              rows={4}
              placeholder={
                language === 'bn'
                  ? 'পণ্যটির কাপড়ের মান, সাইজ, ডেলিভারি সার্ভিস এবং ব্যবহারের অনুভূতি সম্পর্কে লিখুন যাতে অন্যান্য গ্রাহকরা উপকৃত হতে পারেন...'
                  : 'Write about the product quality, fabric, fitting, delivery experience, etc...'
              }
              required
              className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs text-neutral-900 focus:bg-white focus:border-rose-500 outline-none transition leading-relaxed resize-none"
            />
          </div>

          {/* Photo Upload Section */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-neutral-700 flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-rose-600" />
              <span>{language === 'bn' ? 'পণ্যটির ছবি যুক্ত করুন (ঐচ্ছিক):' : 'Add Photo of Product (Optional):'}</span>
            </label>

            {reviewImage ? (
              <div className="relative inline-block border-2 border-dashed border-rose-300 rounded-2xl p-1 bg-rose-50/50">
                <img 
                  src={reviewImage} 
                  alt="Review preview" 
                  className="w-24 h-24 sm:w-28 sm:h-28 object-cover rounded-xl shadow-xs"
                />
                <button
                  type="button"
                  onClick={() => setReviewImage('')}
                  className="absolute -top-2 -right-2 w-7 h-7 bg-red-600 text-white rounded-full flex items-center justify-center shadow-md hover:bg-red-700 transition cursor-pointer"
                  title="Remove Image"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handlePhotoUpload}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full py-3 px-4 border-2 border-dashed border-neutral-300 hover:border-rose-400 bg-neutral-50 hover:bg-rose-50/40 rounded-2xl flex items-center justify-center gap-2 text-xs font-bold text-neutral-600 hover:text-rose-700 transition cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-rose-500" />
                  <span>{language === 'bn' ? 'গ্যালারি বা ক্যামেরা থেকে ছবি আপলোড করুন' : 'Upload from Gallery or Camera'}</span>
                </button>
              </div>
            )}
            {imageError && (
              <p className="text-[11px] text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{imageError}</span>
              </p>
            )}
          </div>

          {/* Form Error */}
          {formError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2 animate-fadeIn">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{formError}</span>
            </div>
          )}

          {/* Visibility Info Banner */}
          <div className="p-3 bg-neutral-100 rounded-xl border border-neutral-200 text-[11px] text-neutral-600 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p>
              {language === 'bn'
                ? 'আপনার সাবমিট করা রিভিউটি সরাসরি এই পণ্যের পেজে এবং স্টোরে সকল ভিজিটর ও ক্রেতাদের জন্য উন্মুক্ত থাকবে।'
                : 'Your submitted review will be published and visible to all store visitors and shoppers.'}
            </p>
          </div>

          {/* Modal Action Buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-neutral-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-bold transition cursor-pointer"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white text-xs font-bold shadow-md shadow-rose-200 flex items-center gap-2 transition cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                {isSubmitting
                  ? (language === 'bn' ? 'সাবমিট হচ্ছে...' : 'Submitting...')
                  : (existingReview 
                      ? (language === 'bn' ? 'রিভিউ আপডেট করুন' : 'Update Review') 
                      : (language === 'bn' ? 'রিভিউ প্রকাশ করুন' : 'Submit Review'))}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
