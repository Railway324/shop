import React, { useState, useMemo } from 'react';
import { 
  ArrowLeft, 
  MapPin, 
  Phone, 
  User, 
  ShieldCheck, 
  Truck, 
  CheckCircle2, 
  ShoppingBag, 
  Plus, 
  Minus, 
  AlertCircle,
  Lock,
  Check,
  Package,
  Sparkles,
  Tag,
  Search,
  X,
  ChevronDown
} from 'lucide-react';
import { CartItem, Language, PaymentMethod, Order, UserProfile } from '../types';
import { translations, formatPrice } from '../utils/translations';
import { getProductSizes, getProductColors } from '../utils/variantUtils';
import { 
  BD_DIVISIONS_LIST, 
  BD_64_DISTRICTS, 
  getDistrictsForDivision, 
  getThanasForDistrict,
  DROPSHIPPING_DELIVERY_ZONES,
  DROPSHIPPING_64_CITIES,
  DropshippingCity,
  resolveDeliveryZone,
  DeliveryZoneId
} from '../data/bangladeshGeoData';

interface CheckoutPageProps {
  items: CartItem[];
  language: Language;
  onBack: () => void;
  onOrderSuccess: (order: Order) => void;
  currentUserProfile?: UserProfile | null;
  appliedCoupon?: { code: string; discount: number };
  onOpenLogin?: () => void;
  onUpdateQuantity?: (productId: string, delta: number) => void;
}

// Strictly return ONLY real sizes and colors defined on the product (never invent fake options)
function getAvailableColorsForItem(item: CartItem): string[] {
  return getProductColors(item.product);
}

function getAvailableSizesForItem(item: CartItem): string[] {
  return getProductSizes(item.product);
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  items = [],
  language,
  onBack,
  onOrderSuccess,
  currentUserProfile,
  appliedCoupon,
  onOpenLogin,
  onUpdateQuantity
}) => {
  // Customer Form State
  const [customerName, setCustomerName] = useState(currentUserProfile?.displayName || '');
  const [phone, setPhone] = useState(currentUserProfile?.phone || '');
  const [address, setAddress] = useState(currentUserProfile?.address || '');
  const [divisionId, setDivisionId] = useState('dhaka');
  const [districtId, setDistrictId] = useState('dhaka');
  const [thanaName, setThanaName] = useState('');
  const [customerNote, setCustomerNote] = useState('');
  // Strictly Cash on Delivery (COD) as requested - no bKash / Nagad
  const paymentMethod: PaymentMethod = 'cod';

  // City Picker Modal State (Matching DropshippingBD Search City)
  const [isCityModalOpen, setIsCityModalOpen] = useState(false);
  const [citySearchQuery, setCitySearchQuery] = useState('');

  // Validation errors
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Manage Order Items with selected Color, Size, and Quantity directly on the Order Page
  const [orderItems, setOrderItems] = useState<CartItem[]>(() => {
    return items.map(item => {
      const colors = getAvailableColorsForItem(item);
      const sizes = getAvailableSizesForItem(item);
      return {
        ...item,
        selectedColor: item.selectedColor || (colors.length === 1 ? colors[0] : undefined),
        selectedSize: item.selectedSize || (sizes.length === 1 ? sizes[0] : undefined),
      };
    });
  });

  // Keep orderItems synced whenever parent items change
  React.useEffect(() => {
    if (items.length > 0) {
      setOrderItems(prev => {
        const prevKey = prev.map(p => `${p.product.id}:${p.selectedSize || ''}:${p.selectedColor || ''}`).join('|');
        const nextKey = items.map(p => `${p.product.id}:${p.selectedSize || ''}:${p.selectedColor || ''}`).join('|');
        if (prevKey !== nextKey) {
          return items.map(item => {
            const colors = getAvailableColorsForItem(item);
            const sizes = getAvailableSizesForItem(item);
            return {
              ...item,
              selectedColor: item.selectedColor || (colors.length === 1 ? colors[0] : undefined),
              selectedSize: item.selectedSize || (sizes.length === 1 ? sizes[0] : undefined),
            };
          });
        }
        return prev;
      });
    }
  }, [items]);

  const handleColorSelect = (index: number, color: string) => {
    setOrderItems(prev => {
      const next = [...prev];
      next[index] = { ...next[index], selectedColor: color };
      return next;
    });
    if (errors[`color_${index}`] || errors.variant) {
      setErrors(prev => ({ ...prev, [`color_${index}`]: '', variant: '' }));
    }
  };

  const handleSizeSelect = (index: number, size: string) => {
    setOrderItems(prev => {
      const next = [...prev];
      next[index] = { ...next[index], selectedSize: size };
      return next;
    });
    if (errors[`size_${index}`] || errors.variant) {
      setErrors(prev => ({ ...prev, [`size_${index}`]: '', variant: '' }));
    }
  };

  const handleQuantityAdjust = (index: number, delta: number) => {
    setOrderItems(prev => {
      const next = [...prev];
      const maxStock = next[index].product.stock || 99;
      const newQty = Math.max(1, Math.min(maxStock, next[index].quantity + delta));
      next[index] = { ...next[index], quantity: newQty };
      return next;
    });
    if (onUpdateQuantity && orderItems[index]) {
      onUpdateQuantity(orderItems[index].product.id, delta);
    }
  };

  // Delivery Zone State: Inside Dhaka 65.00 ৳, Outside Dhaka 120.00 ৳
  const [selectedDeliveryZone, setSelectedDeliveryZone] = useState<DeliveryZoneId>('inside_dhaka');

  // Auto-resolve delivery zone when division, district, thana, or address changes
  const autoResolved = useMemo(() => {
    return resolveDeliveryZone(districtId, thanaName, address);
  }, [districtId, thanaName, address]);

  // Sync selected delivery zone if autoResolved changes
  React.useEffect(() => {
    setSelectedDeliveryZone(autoResolved.zone);
  }, [autoResolved.zone]);

  // Free delivery check if items qualify
  const isFreeDelivery = useMemo(() => {
    return orderItems.length > 0 && orderItems.every(item => item.product.freeDelivery);
  }, [orderItems]);

  // Delivery Fee Calculation based on active delivery zone or Free Delivery
  const deliveryFee = useMemo(() => {
    if (isFreeDelivery) return 0;
    const zoneObj = DROPSHIPPING_DELIVERY_ZONES.find(z => z.id === selectedDeliveryZone);
    return zoneObj ? zoneObj.fee : 65;
  }, [selectedDeliveryZone, isFreeDelivery]);

  // Filtered 64 Cities for the searchable modal
  const filteredCities = useMemo(() => {
    if (!citySearchQuery.trim()) return DROPSHIPPING_64_CITIES;
    const q = citySearchQuery.toLowerCase().trim();
    return DROPSHIPPING_64_CITIES.filter(
      c => c.nameEn.toLowerCase().includes(q) || c.nameBn.includes(q)
    );
  }, [citySearchQuery]);

  // Current selected city
  const currentCity = useMemo(() => {
    return DROPSHIPPING_64_CITIES.find(c => c.id === districtId || c.nameEn.toLowerCase() === districtId.toLowerCase()) || 
           DROPSHIPPING_64_CITIES.find(c => c.id === 'dhaka')!;
  }, [districtId]);

  const handleSelectCity = (city: DropshippingCity) => {
    setDistrictId(city.id);
    const matchedDist = BD_64_DISTRICTS.find(d => d.id === city.id || d.nameEn.toLowerCase() === city.nameEn.toLowerCase());
    if (matchedDist) {
      setDivisionId(matchedDist.divisionId);
      const thanas = matchedDist.thanas;
      setThanaName(thanas.length > 0 ? (language === 'bn' ? thanas[0].nameBn : thanas[0].nameEn) : '');
    }
    if (city.isDhaka) {
      setSelectedDeliveryZone('inside_dhaka');
    } else {
      setSelectedDeliveryZone('outside_dhaka');
    }
    setIsCityModalOpen(false);
    setCitySearchQuery('');
  };

  // Available districts for selected division
  const availableDistricts = useMemo(() => {
    return getDistrictsForDivision(divisionId);
  }, [divisionId]);

  // Available thanas for selected district
  const availableThanas = useMemo(() => {
    return getThanasForDistrict(districtId);
  }, [districtId]);

  // Subtotal calculation based on order items
  const subtotal = useMemo(() => {
    return orderItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  }, [orderItems]);

  const discount = appliedCoupon?.discount || 0;
  const total = Math.max(0, subtotal + deliveryFee - discount);

  const handleDivisionChange = (newDivId: string) => {
    setDivisionId(newDivId);
    const districts = getDistrictsForDivision(newDivId);
    if (districts.length > 0) {
      setDistrictId(districts[0].id);
      const thanas = getThanasForDistrict(districts[0].id);
      setThanaName(thanas.length > 0 ? thanas[0].nameBn : '');
    }
  };

  const handleDistrictChange = (newDistId: string) => {
    setDistrictId(newDistId);
    const thanas = getThanasForDistrict(newDistId);
    setThanaName(thanas.length > 0 ? thanas[0].nameBn : '');
  };

  const validateForm = (): boolean => {
    const newErrors: { [key: string]: string } = {};

    if (!currentUserProfile) {
      newErrors.auth = language === 'bn' 
        ? 'অর্ডার নিশ্চিত করতে অনুগ্রহ করে একটি অ্যাকাউন্ট তৈরি করুন অথবা লগইন করুন।' 
        : 'Account required: Please create an account or sign in to confirm your order.';
    }

    if (!customerName.trim()) {
      newErrors.name = language === 'bn' ? 'অনুগ্রহ করে আপনার পুরো নাম লিখুন।' : 'Please enter your full name.';
    }

    const cleanPhone = phone.replace(/[^0-9+]/g, '');
    if (!cleanPhone) {
      newErrors.phone = language === 'bn' ? 'মোবাইল নম্বর দেওয়া বাধ্যতামূলক।' : 'Mobile number is required.';
    } else if (!/(^(?:\+88|88)?(01[3-9]\d{8})$)/.test(cleanPhone) && cleanPhone.length < 11) {
      newErrors.phone = language === 'bn' ? 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 017xxxxxxxx)।' : 'Please provide a valid 11-digit phone number.';
    }

    if (!address.trim() || address.trim().length < 5) {
      newErrors.address = language === 'bn' ? 'সঠিক ও পূর্ণাঙ্গ ডেলিভারি ঠিকানা দিন (বাড়ি/রোড/এলাকা)।' : 'Please provide a complete delivery address.';
    }

    orderItems.forEach((item, idx) => {
      const colors = getAvailableColorsForItem(item);
      const sizes = getAvailableSizesForItem(item);
      if (colors.length > 1 && !item.selectedColor) {
        newErrors[`color_${idx}`] = language === 'bn' ? 'অনুগ্রহ করে পণ্যের কালার সিলেক্ট করুন।' : 'Please select a color.';
        newErrors.variant = newErrors[`color_${idx}`];
      }
      if (sizes.length > 1 && !item.selectedSize) {
        newErrors[`size_${idx}`] = language === 'bn' ? 'অনুগ্রহ করে পণ্যের সাইজ সিলেক্ট করুন।' : 'Please select a size.';
        newErrors.variant = newErrors[`size_${idx}`];
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;

    if (!currentUserProfile) {
      setErrors(prev => ({
        ...prev,
        auth: language === 'bn' 
          ? 'অর্ডার নিশ্চিত করতে একটি অ্যাকাউন্ট থাকা আবশ্যক। অনুগ্রহ করে লগইন বা সাইন আপ করুন।' 
          : 'An account is required to place an order. Please sign in or register.'
      }));
      if (onOpenLogin) {
        onOpenLogin();
      }
      return;
    }

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const selectedDistrictObj = BD_64_DISTRICTS.find(d => d.id === districtId);
      const selectedDivisionObj = BD_DIVISIONS_LIST.find(d => d.id === divisionId);

      const districtName = selectedDistrictObj 
        ? (language === 'bn' ? selectedDistrictObj.nameBn : selectedDistrictObj.nameEn)
        : districtId;

      const divisionName = selectedDivisionObj
        ? (language === 'bn' ? selectedDivisionObj.nameBn : selectedDivisionObj.nameEn)
        : divisionId;

      const orderId = `ORD-${Date.now().toString().slice(-6)}`;
      const now = new Date().toISOString();

      const newOrder: Order = {
        id: orderId,
        orderId: orderId,
        userId: currentUserProfile.uid,
        userEmail: currentUserProfile.email || '',
        customerName: customerName.trim(),
        phone: phone.trim(),
        email: currentUserProfile.email || '',
        divisionId,
        districtId,
        thanaId: thanaName,
        address: `${address.trim()}, ${thanaName ? thanaName + ', ' : ''}${districtName} (${selectedDeliveryZone === 'inside_dhaka' ? 'ঢাকার ভিতরে' : 'ঢাকার বাইরে'})`,
        items: [...orderItems],
        subtotal,
        deliveryFee,
        discount,
        total,
        paymentMethod: 'cod',
        paymentStatus: 'pending',
        orderStatus: 'placed',
        notes: customerNote.trim() || undefined,
        date: new Date().toLocaleDateString('en-GB'),
        createdAt: now,
        updatedAt: now,
        statusHistory: [
          {
            id: `hist-${Date.now()}`,
            status: 'placed',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            date: now,
            note: language === 'bn' ? 'ক্যাশ অন ডেলিভারিতে অর্ডার প্লেস করা হয়েছে' : 'Order placed via Cash on Delivery'
          }
        ]
      };

      onOrderSuccess(newOrder);
    } catch (err) {
      console.error('Order creation error:', err);
      setIsSubmitting(false);
    }
  };

  if (orderItems.length === 0) {
    return (
      <div className="min-h-screen bg-[#380208] text-white py-12 px-4 flex items-center justify-center animate-fadeIn">
        <div className="max-w-md w-full bg-[#240106] border border-[#6B0B1D] rounded-3xl p-8 text-center space-y-4 shadow-md">
          <div className="w-16 h-16 rounded-3xl bg-[#3D030C] text-amber-400 flex items-center justify-center mx-auto">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white">
            {language === 'bn' ? 'অর্ডার করার জন্য কোনো পণ্য নির্বাচন করা নেই' : 'No items selected for checkout'}
          </h2>
          <p className="text-xs text-neutral-300">
            {language === 'bn' ? 'দয়া করে পণ্য নির্বাচন করে “অর্ডার করুন” বাটনে ক্লিক করুন।' : 'Please select a product and click Order Now to proceed.'}
          </p>
          <button
            onClick={onBack}
            className="w-full py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-sm transition cursor-pointer shadow-sm"
          >
            {language === 'bn' ? '← কেনাকাটা চালিয়ে যান' : '← Continue Shopping'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#380208] text-white py-4 sm:py-6 px-3 sm:px-4 md:px-6 animate-fadeIn">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Top Header with Back Button */}
        <div className="flex items-center justify-between pb-4 border-b border-[#520510]">
          <button
            onClick={onBack}
            className="group px-4 py-2 rounded-2xl bg-[#240106] hover:bg-[#3D030C] text-neutral-200 hover:text-white border border-[#6B0B1D] text-xs sm:text-sm font-bold flex items-center gap-2 transition cursor-pointer shadow-xs active:scale-95"
            title="Go back"
          >
            <ArrowLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-1 transition-transform" />
            <span>{language === 'bn' ? '← আগের পেজে ফিরে যান' : '← Back'}</span>
          </button>

          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span className="text-xs font-bold text-neutral-200">
              {language === 'bn' ? '১০০% নিরাপদ চেকআউট' : '100% Secure Checkout'}
            </span>
          </div>
        </div>

        {/* Page Title */}
        <div className="space-y-1">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white">
            {language === 'bn' ? 'অর্ডার ও চেকআউট পেজ' : 'Checkout & Confirm Order'}
          </h1>
          <p className="text-xs text-neutral-300">
            {language === 'bn' 
              ? 'নিচের তথ্যগুলো দিয়ে অর্ডারটি কনফার্ম করুন। ডেলিভারির সময় পণ্য হাতে পেয়ে সম্পূর্ণ দেখে মূল্য পরিশোধ করুন।' 
              : 'Complete the details below to confirm your order. Pay cash upon delivery.'}
          </p>
        </div>

        {/* 2-Column Grid Layout */}
        <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          
          {/* Left Column: Customer Delivery Details (7 cols) */}
          <div className="lg:col-span-7 space-y-5">

            {/* Account Requirement / Status Banner */}
            {currentUserProfile ? (
              <div className="p-4 rounded-3xl bg-emerald-50 border border-emerald-200/80 text-emerald-900 flex items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-2xl bg-emerald-600 text-white flex items-center justify-center text-sm font-bold shadow-xs shrink-0">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                      <span>{language === 'bn' ? 'লগইন করা অ্যাকাউন্ট:' : 'Logged in as:'}</span>
                      <span className="truncate">{currentUserProfile.displayName}</span>
                    </p>
                    <p className="text-[11px] text-emerald-700 font-mono truncate">
                      {currentUserProfile.email || currentUserProfile.phone || 'অ্যাকাউন্ট ভেরিফাইড'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-200/80 text-emerald-900 font-bold px-2.5 py-1 rounded-full shrink-0">
                  {language === 'bn' ? '✓ ভেরিফাইড ইউজার' : '✓ Verified'}
                </span>
              </div>
            ) : (
              <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 text-amber-950 space-y-3 shadow-xs">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 shadow-2xs mt-0.5">
                    <Lock className="w-5 h-5 text-amber-800" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-black text-amber-950 flex items-center gap-1.5">
                      <span>{language === 'bn' ? '⚠️ অর্ডার কনফার্ম করতে অ্যাকাউন্ট প্রয়োজন' : '⚠️ Account Required to Place Order'}</span>
                    </h4>
                    <p className="text-xs text-amber-800 mt-1 leading-relaxed font-medium">
                      {language === 'bn'
                        ? 'আপনার অর্ডার ট্র্যাকিং এবং ডেলিভারি স্ট্যাটাস নিশ্চিত করতে অনুগ্রহ করে একটি অ্যাকাউন্ট তৈরি করুন অথবা লগইন করুন।'
                        : 'To track your package and verify delivery, please create an account or sign in.'}
                    </p>
                  </div>
                </div>
                <div className="pt-1 flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={onOpenLogin}
                    className="px-4 py-2.5 bg-[#800020] hover:bg-[#68001a] text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-2 cursor-pointer active:scale-98"
                  >
                    <User className="w-4 h-4 text-amber-300" />
                    <span>{language === 'bn' ? 'লগইন / নতুন অ্যাকাউন্ট তৈরি করুন' : 'Login / Create Account'}</span>
                  </button>
                  <span className="text-[11px] text-amber-800 font-medium">
                    {language === 'bn' ? '• মাত্র ৩০ সেকেন্ডে সহজে অ্যাকাউন্ট তৈরি করুন' : '• Takes only 30 seconds'}
                  </span>
                </div>
                {errors.auth && (
                  <div className="p-2.5 rounded-xl bg-red-100 border border-red-300 text-red-700 text-xs font-bold flex items-center gap-2 animate-shake">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errors.auth}</span>
                  </div>
                )}
              </div>
            )}
            
            {/* Delivery Info Box */}
            <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-7 space-y-4 shadow-xs">
              <div className="flex items-center gap-2.5 pb-3 border-b border-neutral-100 text-rose-600">
                <MapPin className="w-5 h-5" />
                <h3 className="text-sm sm:text-base font-black text-neutral-900">
                  {language === 'bn' ? 'ডেলিভারি তথ্য ও ঠিকানা' : 'Shipping & Customer Address'}
                </h3>
              </div>

              {/* Customer Full Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-neutral-500" />
                  <span>{language === 'bn' ? 'আপনার পুরো নাম' : 'Full Name'} <strong className="text-rose-600">*</strong></span>
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'bn' ? 'উদা: মোঃ তানভীর হাসান' : 'e.g. Tanvir Hasan'}
                  value={customerName}
                  onChange={(e) => {
                    setCustomerName(e.target.value);
                    if (errors.name) setErrors(prev => ({ ...prev, name: '' }));
                  }}
                  className={`w-full px-4 py-3 bg-neutral-50 border rounded-2xl text-xs sm:text-sm text-neutral-900 placeholder-neutral-400 focus:bg-white focus:outline-none focus:ring-2 transition ${
                    errors.name ? 'border-red-500 ring-1 ring-red-500' : 'border-neutral-200 focus:border-rose-500 focus:ring-rose-500/20'
                  }`}
                />
                {errors.name && (
                  <p className="text-[11px] text-red-600 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.name}</span>
                  </p>
                )}
              </div>

              {/* Mobile Number */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-neutral-500" />
                  <span>{language === 'bn' ? 'মোবাইল নম্বর (১১ ডিজিট)' : 'Mobile Number (11 digits)'} <strong className="text-rose-600">*</strong></span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder={language === 'bn' ? 'উদা: 01712345678' : 'e.g. 01712345678'}
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                    if (errors.phone) setErrors(prev => ({ ...prev, phone: '' }));
                  }}
                  className={`w-full px-4 py-3 bg-neutral-50 border rounded-2xl text-xs sm:text-sm text-neutral-900 placeholder-neutral-400 font-mono focus:bg-white focus:outline-none focus:ring-2 transition ${
                    errors.phone ? 'border-red-500 ring-1 ring-red-500' : 'border-neutral-200 focus:border-rose-500 focus:ring-rose-500/20'
                  }`}
                />
                {errors.phone && (
                  <p className="text-[11px] text-red-600 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.phone}</span>
                  </p>
                )}
              </div>

              {/* City / District Selection (Matching DropshippingBD Search City) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800 flex items-center justify-between">
                  <span>{language === 'bn' ? 'শহর / জেলা (Select City)' : 'City / District'} <strong className="text-rose-600">*</strong></span>
                  <span className="text-[10px] text-neutral-500">দেশের ৬৪টি জেলা</span>
                </label>
                
                {/* Clickable button to open Search City modal */}
                <button
                  type="button"
                  onClick={() => setIsCityModalOpen(true)}
                  className="w-full px-4 py-3 bg-neutral-50 hover:bg-neutral-100/80 border border-neutral-200 rounded-2xl text-xs sm:text-sm text-neutral-900 flex items-center justify-between transition cursor-pointer text-left shadow-2xs group"
                >
                  <div className="flex items-center gap-2.5">
                    <MapPin className="w-4 h-4 text-rose-600 shrink-0" />
                    <span className="font-black text-neutral-900">
                      {currentCity.nameEn}
                    </span>
                    <span className="text-neutral-500 text-xs font-medium">
                      ({currentCity.nameBn})
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-rose-600 font-bold text-xs group-hover:translate-x-0.5 transition-transform">
                    <span>{language === 'bn' ? 'পরিবর্তন করুন' : 'Change City'}</span>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>
              </div>

              {/* Thana / Sub-area / Area */}
              {availableThanas.length > 0 ? (
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-neutral-800">
                    {language === 'bn' ? 'থানা / উপজেলা (Area / Thana)' : 'Area / Thana'}
                  </label>
                  <select
                    value={thanaName}
                    onChange={(e) => setThanaName(e.target.value)}
                    className="w-full px-3 py-3 bg-neutral-50 border border-neutral-200 rounded-2xl text-xs sm:text-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-rose-500 cursor-pointer"
                  >
                    <option value="">{language === 'bn' ? '-- থানা বা এলাকা নির্বাচন করুন --' : '-- Select Thana / Area --'}</option>
                    {availableThanas.map((t, idx) => (
                      <option key={idx} value={language === 'bn' ? t.nameBn : t.nameEn}>
                        {language === 'bn' ? t.nameBn : t.nameEn}
                      </option>
                    ))}
                  </select>
                </div>
              ) : null}

              {/* DELIVERY CHARGE SELECTION CARDS (Inside Dhaka: 65.00 ৳, Outside Dhaka: 120.00 ৳) */}
              <div className="space-y-2 pt-2 border-t border-neutral-100">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-neutral-800 flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-rose-600" />
                    <span>{language === 'bn' ? 'ডেলিভারি চার্জ (Delivery Rate)' : 'Delivery Rate'}</span>
                    <strong className="text-rose-600">*</strong>
                  </label>
                  <span className="text-[11px] text-neutral-500 font-medium">
                    {currentCity.isDhaka ? 'ঢাকা জেলা সিলেক্টেড' : `${currentCity.nameEn} সিলেক্টেড`}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {DROPSHIPPING_DELIVERY_ZONES.map((zone) => {
                    const isSelected = selectedDeliveryZone === zone.id;
                    return (
                      <button
                        key={zone.id}
                        type="button"
                        onClick={() => setSelectedDeliveryZone(zone.id)}
                        className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex items-center justify-between gap-3 ${
                          isSelected
                            ? 'bg-rose-50/80 border-rose-600 ring-2 ring-rose-500/20 shadow-xs'
                            : 'bg-neutral-50 hover:bg-white border-neutral-200 text-neutral-700'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="font-black text-xs sm:text-sm text-neutral-900 flex items-center gap-1.5">
                            <span>{zone.id === 'inside_dhaka' ? '🏠' : '🚚'}</span>
                            <span>{language === 'bn' ? zone.nameBn : zone.nameEn}</span>
                          </div>
                          <p className="text-[10px] text-neutral-500">
                            ⏱️ {language === 'bn' ? zone.estimatedDaysBn : zone.estimatedDaysEn}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-xs sm:text-sm font-black px-2.5 py-1 rounded-xl shrink-0 font-mono ${
                            isSelected ? 'bg-rose-600 text-white shadow-xs' : 'bg-neutral-200 text-neutral-800'
                          }`}>
                            {zone.fee}.00 ৳
                          </span>
                          <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 ${
                            isSelected ? 'border-rose-600 bg-rose-600' : 'border-neutral-400'
                          }`}>
                            {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Full Address */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {language === 'bn' ? 'সম্পূর্ণ ডেলিভারি ঠিকানা (বাসা নং, রোড, এলাকা)' : 'Full Delivery Address (House, Road, Area)'} <strong className="text-rose-600">*</strong>
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder={language === 'bn' ? 'উদা: বাড়ি নং ১২, রোড নং ৫, ব্লক বি, মিরপুর ১০, ঢাকা' : 'e.g. House #12, Road #5, Block B, Mirpur 10, Dhaka'}
                  value={address}
                  onChange={(e) => {
                    setAddress(e.target.value);
                    if (errors.address) setErrors(prev => ({ ...prev, address: '' }));
                  }}
                  className={`w-full px-4 py-3 bg-neutral-50 border rounded-2xl text-xs sm:text-sm text-neutral-900 placeholder-neutral-400 focus:bg-white focus:outline-none focus:ring-2 transition ${
                    errors.address ? 'border-red-500 ring-1 ring-red-500' : 'border-neutral-200 focus:border-rose-500 focus:ring-rose-500/20'
                  }`}
                />
                {errors.address && (
                  <p className="text-[11px] text-red-600 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.address}</span>
                  </p>
                )}
              </div>

              {/* Optional Customer Note */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-600">
                  {language === 'bn' ? 'ডেলিভারি নোট / স্পেশাল নির্দেশ (অপশনাল)' : 'Special Delivery Note (Optional)'}
                </label>
                <input
                  type="text"
                  placeholder={language === 'bn' ? 'উদা: বিকাল ৫টার পর ডেলিভারি দিন' : 'e.g. Please deliver after 5 PM'}
                  value={customerNote}
                  onChange={(e) => setCustomerNote(e.target.value)}
                  className="w-full px-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-2xl text-xs text-neutral-900 placeholder-neutral-400 focus:bg-white focus:outline-none focus:border-neutral-400"
                />
              </div>
            </div>

            {/* Payment Method - Strictly Cash on Delivery, NO bKash / Nagad */}
            <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-7 space-y-4 shadow-xs">
              <h3 className="text-sm sm:text-base font-black text-neutral-900 flex items-center gap-2">
                <Truck className="w-5 h-5 text-rose-600" />
                <span>{language === 'bn' ? 'পেমেন্ট পদ্ধতি (Payment Method)' : 'Payment Method'}</span>
              </h3>

              <div className="p-4 rounded-2xl border border-emerald-300 bg-emerald-50/60 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-neutral-900">
                      {language === 'bn' ? 'ক্যাশ অন ডেলিভারি (Cash on Delivery)' : 'Cash on Delivery (COD)'}
                    </div>
                    <p className="text-[11px] sm:text-xs text-neutral-600">
                      {language === 'bn' 
                        ? 'পণ্য হাতে পেয়ে দেখে মূল্য পরিশোধ করুন। কোনো অগ্রিম পেমেন্টের প্রয়োজন নেই।' 
                        : 'Pay cash upon delivery after inspecting your items.'}
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full shrink-0">
                  {language === 'bn' ? '১০০% নিরাপদ' : 'Safe & Simple'}
                </span>
              </div>
            </div>

          </div>

          {/* Right Column: Order Summary & Confirmation CTA (5 cols) */}
          <div className="lg:col-span-5 space-y-5">
            <div className="bg-white border border-neutral-200 rounded-3xl p-5 sm:p-7 space-y-5 shadow-xs sticky top-6">
              
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
                <h3 className="text-base font-black text-neutral-900 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-rose-600" />
                  <span>{language === 'bn' ? 'অর্ডার সারাংশ ও পণ্যের তথ্য' : 'Order Items & Details'}</span>
                </h3>
                <span className="text-xs text-neutral-500 font-bold">
                  {orderItems.length} {language === 'bn' ? 'টি আইটেম' : 'items'}
                </span>
              </div>

              {/* Items List with Full Product Details, Color & Size Selection */}
              <div className="space-y-4 max-h-[520px] overflow-y-auto pr-1 custom-scrollbar">
                {orderItems.map((item, idx) => {
                  const availableColors = getAvailableColorsForItem(item);
                  const availableSizes = getAvailableSizesForItem(item);

                  return (
                    <div 
                      key={`${item.product.id}-${idx}`} 
                      className="p-3.5 bg-neutral-50/90 rounded-2xl border border-neutral-200 space-y-3"
                    >
                      {/* Top Info: Photo, Title, Sku, Stock & Price */}
                      <div className="flex gap-3 items-start">
                        <img
                          src={item.product.image}
                          alt={item.product.titleEn || item.product.titleBn}
                          className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover bg-white shrink-0 border border-neutral-200 shadow-2xs"
                        />
                        <div className="flex-1 min-w-0 space-y-1">
                          <h4 className="text-xs sm:text-sm font-bold text-neutral-900 leading-snug">
                            {language === 'bn' ? (item.product.titleBn || item.product.titleEn) : (item.product.titleEn || item.product.titleBn)}
                          </h4>

                          <div className="flex items-center gap-2 flex-wrap text-[10px]">
                            {/* SKU */}
                            <span className="font-mono bg-white border border-neutral-200 text-neutral-700 px-1.5 py-0.5 rounded font-bold">
                              SKU: {item.product.sku || item.product.id.slice(0, 8)}
                            </span>
                            {/* Category */}
                            {item.product.category && (
                              <span className="bg-rose-50 border border-rose-200 text-rose-700 px-1.5 py-0.5 rounded font-bold capitalize">
                                {item.product.category}
                              </span>
                            )}
                            {/* Stock status */}
                            <span className="text-emerald-700 font-bold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" />
                              {language === 'bn' ? 'স্টক এভেইলেবল' : 'In Stock'}
                            </span>
                          </div>

                          {/* Unit price & total */}
                          <div className="flex items-baseline gap-2 pt-0.5">
                            <span className="text-sm font-black text-rose-600 font-mono">
                              {formatPrice(item.product.price, language)}
                            </span>
                            {item.product.originalPrice && item.product.originalPrice > item.product.price && (
                              <span className="text-xs text-neutral-400 line-through font-mono">
                                {formatPrice(item.product.originalPrice, language)}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Product Description & Size/Measurement Details */}
                      {(item.product.descriptionBn || item.product.descriptionEn) && (
                        <details className="group bg-white/80 rounded-xl border border-neutral-200/80 overflow-hidden text-[11px] text-neutral-700">
                          <summary className="px-2.5 py-2 cursor-pointer font-bold text-neutral-800 flex items-center justify-between select-none hover:bg-neutral-100/70">
                            <span>📋 {language === 'bn' ? 'পণ্যের বিবরণ ও মাপ দেখুন' : 'View Product Details & Measurements'}</span>
                            <ChevronDown className="w-3.5 h-3.5 text-neutral-500 group-open:rotate-180 transition-transform" />
                          </summary>
                          <div className="px-2.5 pb-2.5 pt-1 border-t border-neutral-100 whitespace-pre-line leading-relaxed max-h-44 overflow-y-auto">
                            {language === 'bn' ? (item.product.descriptionBn || item.product.descriptionEn) : (item.product.descriptionEn || item.product.descriptionBn)}
                          </div>
                        </details>
                      )}

                      {/* 1. COLOR SELECTION (শুধুমাত্র যে পণ্যের কালার আছে সেটিতে দেখাবে) */}
                      {availableColors.length > 0 && (
                        <div className={`space-y-1.5 pt-1.5 border-t ${errors[`color_${idx}`] ? 'border-red-300 bg-red-50/50 p-2 rounded-xl' : 'border-neutral-200/70'}`}>
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="font-bold text-neutral-800 flex items-center gap-1">
                              <span>🎨 {language === 'bn' ? 'কালার:' : 'Color:'}</span>
                              <span className="text-rose-600 font-black">
                                {item.selectedColor || (language === 'bn' ? 'সিলেক্ট করুন *' : 'Select *')}
                              </span>
                            </span>
                            {availableColors.length > 1 && (
                              <span className="text-[10px] text-neutral-500">
                                {language === 'bn' ? 'কালার বেছে নিন' : 'Tap to select'}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {availableColors.map((color) => {
                              const isSelected = item.selectedColor === color;
                              return (
                                <button
                                  key={color}
                                  type="button"
                                  onClick={() => handleColorSelect(idx, color)}
                                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition flex items-center gap-1 cursor-pointer border ${
                                    isSelected
                                      ? 'bg-rose-50 border-rose-600 text-rose-700 ring-2 ring-rose-500/20 shadow-xs'
                                      : 'bg-white border-neutral-200 text-neutral-700 hover:border-neutral-300'
                                  }`}
                                >
                                  {isSelected && <Check className="w-3 h-3 text-rose-600" />}
                                  <span>{color}</span>
                                </button>
                              );
                            })}
                          </div>
                          {errors[`color_${idx}`] && (
                            <p className="text-[10px] text-red-600 font-bold flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" />
                              <span>{errors[`color_${idx}`]}</span>
                            </p>
                          )}
                        </div>
                      )}

                      {/* 2. SIZE SELECTION (শুধুমাত্র যে পণ্যের সাইজ আছে সেটিতে দেখাবে) */}
                      {availableSizes.length > 0 && (
                        <div className={`space-y-1.5 pt-1.5 border-t ${errors[`size_${idx}`] ? 'border-red-300 bg-red-50/50 p-2 rounded-xl' : 'border-neutral-200/70'}`}>
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="font-bold text-neutral-800 flex items-center gap-1">
                              <span>📏 {language === 'bn' ? 'সাইজ:' : 'Size:'}</span>
                              <span className="text-rose-600 font-black">
                                {item.selectedSize || (language === 'bn' ? 'সিলেক্ট করুন *' : 'Select *')}
                              </span>
                            </span>
                            {availableSizes.length > 1 && (
                              <span className="text-[10px] text-neutral-500">
                                {language === 'bn' ? 'সাইজ বেছে নিন' : 'Tap to select'}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {availableSizes.map((size) => {
                              const isSelected = item.selectedSize === size;
                              return (
                                <button
                                  key={size}
                                  type="button"
                                  onClick={() => handleSizeSelect(idx, size)}
                                  className={`min-w-[36px] px-2.5 py-1 rounded-xl text-[11px] font-bold transition flex items-center justify-center gap-1 cursor-pointer border ${
                                    isSelected
                                      ? 'bg-rose-600 border-rose-600 text-white shadow-xs'
                                      : 'bg-white border-neutral-200 text-neutral-700 hover:border-neutral-300'
                                  }`}
                                >
                                  <span>{size}</span>
                                  {isSelected && <Check className="w-3 h-3 text-white" />}
                                </button>
                              );
                            })}
                          </div>
                          {errors[`size_${idx}`] && (
                            <p className="text-[10px] text-red-600 font-bold flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" />
                              <span>{errors[`size_${idx}`]}</span>
                            </p>
                          )}
                        </div>
                      )}

                      {/* Quantity Selector & Item Total */}
                      <div className="flex items-center justify-between pt-1.5 border-t border-neutral-200/70 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-bold text-neutral-600 uppercase">
                            {language === 'bn' ? 'পরিমাণ:' : 'Qty:'}
                          </span>
                          <div className="flex items-center border border-neutral-300 rounded-xl overflow-hidden bg-white shadow-2xs">
                            <button
                              type="button"
                              onClick={() => handleQuantityAdjust(idx, -1)}
                              disabled={item.quantity <= 1}
                              className="w-7 h-7 flex items-center justify-center text-neutral-600 hover:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-7 text-center font-mono font-bold text-neutral-900 text-xs">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleQuantityAdjust(idx, 1)}
                              disabled={item.quantity >= (item.product.stock || 99)}
                              className="w-7 h-7 flex items-center justify-center text-neutral-600 hover:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] text-neutral-500 block">মোট মূল্য:</span>
                          <span className="text-sm font-black text-rose-600 font-mono">
                            {formatPrice(item.product.price * item.quantity, language)}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Price Calculation Breakdown */}
              <div className="pt-3 border-t border-neutral-100 space-y-2.5 text-xs text-neutral-700">
                <div className="flex justify-between items-center">
                  <span className="text-neutral-600">{language === 'bn' ? 'পণ্যের মোট মূল্য (Subtotal):' : 'Subtotal:'}</span>
                  <span className="font-mono font-bold text-neutral-900">{formatPrice(subtotal, language)}</span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-neutral-600 flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-rose-600" />
                    <span>{language === 'bn' ? 'ডেলিভারি চার্জ:' : 'Delivery Charge:'}</span>
                  </span>
                  <span className="font-mono font-bold text-neutral-900">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-600 font-bold">
                        {language === 'bn' ? 'ফ্রি (০.০০ ৳)' : 'FREE (0.00 ৳)'}
                      </span>
                    ) : (
                      <>
                        {formatPrice(deliveryFee, language)} 
                        <span className="text-[10px] text-neutral-500 font-normal ml-1">
                          ({selectedDeliveryZone === 'inside_dhaka' 
                            ? (language === 'bn' ? 'ঢাকার ভিতরে — 65.00 ৳' : 'Inside Dhaka — 65.00 ৳') 
                            : (language === 'bn' ? 'ঢাকার বাইরে — 120.00 ৳' : 'Outside Dhaka — 120.00 ৳')})
                        </span>
                      </>
                    )}
                  </span>
                </div>

                {discount > 0 && (
                  <div className="flex justify-between items-center text-emerald-700 font-bold">
                    <span>{language === 'bn' ? 'কুপন ডিসকাউন্ট:' : 'Discount:'}</span>
                    <span className="font-mono">-{formatPrice(discount, language)}</span>
                  </div>
                )}

                <div className="pt-3 border-t border-neutral-100 flex justify-between items-baseline">
                  <span className="text-sm font-black text-neutral-900">
                    {language === 'bn' ? 'সর্বমোট পরিশোধযোগ্য:' : 'Total Payable:'}
                  </span>
                  <span className="text-2xl font-black text-[#800020] font-mono tracking-tight">
                    {formatPrice(total, language)}
                  </span>
                </div>
              </div>

              {/* Confirm Order Button */}
              <button
                type="submit"
                id="confirm-order-submit-btn"
                disabled={isSubmitting}
                className="w-full py-4 px-6 rounded-2xl bg-[#800020] hover:bg-[#68001a] text-white font-black text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-md shadow-[#800020]/20 transition cursor-pointer active:scale-[0.98] disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>{language === 'bn' ? 'অর্ডার প্রসেস হচ্ছে...' : 'Processing Order...'}</span>
                ) : !currentUserProfile ? (
                  <>
                    <Lock className="w-5 h-5 text-amber-300" />
                    <span>{language === 'bn' ? '🔒 অ্যাকাউন্ট তৈরি / লগইন করে অর্ডার করুন' : '🔒 Login / Register to Place Order'}</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span>{language === 'bn' ? 'অর্ডার নিশ্চিত করুন (Confirm Order)' : 'Confirm & Place Order'}</span>
                  </>
                )}
              </button>

              <div className="text-center pt-1">
                <p className="text-[10px] text-neutral-500 flex items-center justify-center gap-1">
                  <Lock className="w-3 h-3 text-neutral-400" />
                  <span>{language === 'bn' ? 'আপনার তথ্য সম্পূর্ণ নিরাপদ ও সুরক্ষিত' : 'Your information is completely safe and secure'}</span>
                </p>
              </div>

            </div>
          </div>

        </form>

        {/* SEARCH CITY MODAL (Exactly matching DropshippingBD reseller app screenshots) */}
        {isCityModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
            <div className="bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-slideUp">
              
              {/* Modal Header */}
              <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-rose-500" />
                    <span>{language === 'bn' ? 'শহর / জেলা নির্বাচন করুন' : 'Select City / District'}</span>
                  </h3>
                  <p className="text-[11px] text-neutral-400 mt-0.5">
                    {language === 'bn' ? 'ঢাকা: 65.00 ৳ • ঢাকার বাইরে: 120.00 ৳' : 'Inside Dhaka: 65.00 ৳ • Outside Dhaka: 120.00 ৳'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCityModalOpen(false)}
                  className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Search City Input Box (Matching Screenshot: "Search City...") */}
              <div className="p-3 border-b border-neutral-800/80 bg-neutral-950/60">
                <div className="relative">
                  <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    autoFocus
                    placeholder="Search City..."
                    value={citySearchQuery}
                    onChange={(e) => setCitySearchQuery(e.target.value)}
                    className="w-full pl-9 pr-9 py-2.5 bg-neutral-900 border border-neutral-700/80 rounded-2xl text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition"
                  />
                  {citySearchQuery && (
                    <button
                      type="button"
                      onClick={() => setCitySearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* 64 Cities Radio List */}
              <div className="overflow-y-auto flex-1 divide-y divide-neutral-800/50 custom-scrollbar">
                {filteredCities.length > 0 ? (
                  filteredCities.map((city) => {
                    const isSelected = districtId === city.id || districtId.toLowerCase() === city.nameEn.toLowerCase();
                    return (
                      <button
                        key={city.id}
                        type="button"
                        onClick={() => handleSelectCity(city)}
                        className={`w-full py-3.5 px-4 sm:px-5 flex items-center justify-between text-left transition cursor-pointer ${
                          isSelected
                            ? 'bg-neutral-800/50 text-white font-bold'
                            : 'text-neutral-300 hover:text-white hover:bg-neutral-800/30'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{city.nameEn}</span>
                          <span className="text-xs text-neutral-500 font-normal">({city.nameBn})</span>
                          {city.isDhaka ? (
                            <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.2 rounded-md">
                              65.00 ৳
                            </span>
                          ) : (
                            <span className="text-[10px] bg-neutral-800 border border-neutral-700 text-neutral-400 font-bold px-1.5 py-0.2 rounded-md">
                              120.00 ৳
                            </span>
                          )}
                        </div>

                        {/* Radio Indicator (Matching screenshot's purple/rose active state) */}
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${
                          isSelected 
                            ? 'border-rose-500 bg-rose-500' 
                            : 'border-neutral-600'
                        }`}>
                          {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                        </div>
                      </button>
                    );
                  })
                ) : (
                  <div className="p-8 text-center text-neutral-500 text-xs">
                    {language === 'bn' ? 'কোনো শহর বা জেলা পাওয়া যায়নি' : 'No city found matching your search.'}
                  </div>
                )}
              </div>

            </div>
          </div>
        )}
      </div>
    </div>
  );
};
