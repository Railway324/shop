import React, { useRef, useState } from 'react';
import { Upload, Image as ImageIcon, X, RefreshCw, Camera, AlertCircle } from 'lucide-react';

interface ImageUploadFieldProps {
  label?: string;
  sublabel?: string;
  value: string;
  onChange: (base64Image: string) => void;
  aspectRatio?: 'square' | 'banner' | 'video' | 'any';
  language?: 'en' | 'bn';
  id?: string;
}

// Compress and convert file to Base64
export const convertFileToBase64 = (file: File, maxWidth = 1200, maxHeight = 1200, quality = 0.85): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/jpeg', quality));
        } else {
          resolve(event.target?.result as string);
        }
      };
      img.onerror = () => resolve(event.target?.result as string);
    };
    reader.onerror = (error) => reject(error);
  });
};

export const ImageUploadField: React.FC<ImageUploadFieldProps> = ({
  label,
  sublabel,
  value,
  onChange,
  aspectRatio = 'square',
  language = 'bn',
  id = 'image-uploader',
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await processFile(file);
    }
    // reset input value so re-selecting the same file triggers onChange
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const processFile = async (file: File) => {
    setErrorMessage(null);
    if (!file.type.startsWith('image/')) {
      setErrorMessage(language === 'bn' ? 'অনুগ্রহ করে শুধুমাত্র ছবি (JPG, PNG, WEBP) সিলেক্ট করুন।' : 'Please select an image file (JPG, PNG, WEBP).');
      return;
    }
    try {
      setIsProcessing(true);
      const base64 = await convertFileToBase64(file);
      onChange(base64);
    } catch (err) {
      console.error('Image processing error:', err);
      setErrorMessage(language === 'bn' ? 'ছবি প্রসেস করতে সমস্যা হয়েছে।' : 'Error processing image.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processFile(file);
    }
  };

  const aspectClass = aspectRatio === 'banner' 
    ? 'aspect-[21/9] sm:aspect-[3/1]' 
    : aspectRatio === 'video' 
      ? 'aspect-video' 
      : aspectRatio === 'square' 
        ? 'aspect-square max-h-56' 
        : 'min-h-[160px]';

  return (
    <div className="space-y-1.5" id={id}>
      {label && (
        <div className="flex items-center justify-between">
          <label className="text-xs sm:text-sm font-bold text-neutral-800 flex items-center gap-1.5">
            <Camera className="w-3.5 h-3.5 text-rose-600" />
            <span>{label}</span>
          </label>
          {sublabel && (
            <span className="text-[11px] text-neutral-500">{sublabel}</span>
          )}
        </div>
      )}

      {/* Hidden Native File Input (Direct from phone/camera/gallery) */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {value ? (
        <div className={`relative rounded-2xl overflow-hidden border-2 border-rose-200 bg-neutral-900 group shadow-xs ${aspectClass}`}>
          <img
            src={value}
            alt="Uploaded preview"
            className="w-full h-full object-cover"
          />
          {/* Action Overlay */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-white text-neutral-800 text-xs font-bold hover:bg-neutral-100 flex items-center gap-1.5 shadow-md cursor-pointer transition"
            >
              <RefreshCw className="w-3.5 h-3.5 text-rose-600" />
              <span>{language === 'bn' ? 'ছবি পরিবর্তন' : 'Change Photo'}</span>
            </button>
            <button
              type="button"
              onClick={() => onChange('')}
              className="p-1.5 rounded-xl bg-rose-600 text-white hover:bg-rose-700 shadow-md cursor-pointer transition"
              title={language === 'bn' ? 'মুছে ফেলুন' : 'Remove'}
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick change button always visible on mobile */}
          <div className="absolute bottom-2 right-2 sm:hidden flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-2.5 py-1 rounded-lg bg-neutral-900/80 backdrop-blur-xs text-white text-[10px] font-bold flex items-center gap-1 border border-white/20"
            >
              <RefreshCw className="w-3 h-3 text-rose-400" />
              <span>{language === 'bn' ? 'বদলান' : 'Change'}</span>
            </button>
            <button
              type="button"
              onClick={() => onChange('')}
              className="p-1 rounded-lg bg-rose-600/90 text-white"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>
      ) : (
        <div
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-2xl p-4 sm:p-6 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2 ${
            isDragging
              ? 'border-rose-500 bg-rose-50/50'
              : 'border-neutral-300 hover:border-rose-400 bg-neutral-50/80 hover:bg-rose-50/20'
          } ${aspectClass}`}
        >
          <div className="w-12 h-12 rounded-2xl bg-white shadow-xs border border-neutral-200/80 flex items-center justify-center text-rose-600 group-hover:scale-105 transition">
            {isProcessing ? (
              <RefreshCw className="w-6 h-6 animate-spin text-rose-600" />
            ) : (
              <Upload className="w-6 h-6 text-rose-600" />
            )}
          </div>
          <div className="space-y-0.5 text-center">
            <p className="text-xs sm:text-sm font-black text-neutral-800">
              {isProcessing
                ? (language === 'bn' ? 'ছবি প্রসেস হচ্ছে...' : 'Processing image...')
                : (language === 'bn' ? 'ফোন থেকে ছবি সিলেক্ট করুন' : 'Click to Upload from Device')}
            </p>
            <p className="text-[11px] text-neutral-500">
              {language === 'bn' 
                ? 'গ্যালারি বা ক্যামেরা থেকে সরাসরি ছবি আপলোড করুন' 
                : 'Upload directly from phone gallery or camera'}
            </p>
          </div>
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 shadow-2xs">
            <ImageIcon className="w-3 h-3 text-rose-600" />
            {language === 'bn' ? 'ফাইল সিলেক্ট করুন' : 'Choose File'}
          </span>
        </div>
      )}

      {errorMessage && (
        <p className="text-[11px] font-bold text-red-600 animate-fadeIn flex items-center gap-1 mt-1">
          <AlertCircle className="w-3.5 h-3.5" />
          <span>{errorMessage}</span>
        </p>
      )}
    </div>
  );
};

interface MultiImageUploadProps {
  label?: string;
  images: string[];
  onChange: (images: string[]) => void;
  language?: 'en' | 'bn';
  maxImages?: number;
}

export const MultiImageUpload: React.FC<MultiImageUploadProps> = ({
  label,
  images,
  onChange,
  language = 'bn',
  maxImages = 6,
}) => {
  const multiFileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleMultipleFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsProcessing(true);
    try {
      const newBase64s: string[] = [];
      for (let i = 0; i < files.length; i++) {
        if (files[i].type.startsWith('image/')) {
          const b64 = await convertFileToBase64(files[i]);
          newBase64s.push(b64);
        }
      }
      const combined = [...images, ...newBase64s].slice(0, maxImages);
      onChange(combined);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
      if (multiFileInputRef.current) {
        multiFileInputRef.current.value = '';
      }
    }
  };

  const handleRemove = (index: number) => {
    const updated = images.filter((_, i) => i !== index);
    onChange(updated);
  };

  return (
    <div className="space-y-2">
      {label && (
        <div className="flex items-center justify-between">
          <label className="text-xs sm:text-sm font-bold text-neutral-800 flex items-center gap-1.5">
            <ImageIcon className="w-3.5 h-3.5 text-rose-600" />
            <span>{label}</span>
          </label>
          <span className="text-[11px] text-neutral-500">
            {images.length}/{maxImages} {language === 'bn' ? 'টি ছবি যুক্ত' : 'images'}
          </span>
        </div>
      )}

      <input
        type="file"
        ref={multiFileInputRef}
        onChange={handleMultipleFiles}
        accept="image/*"
        multiple
        className="hidden"
      />

      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
        {images.map((img, idx) => (
          <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-neutral-200 bg-neutral-100 group shadow-2xs">
            <img src={img} alt={`Gallery ${idx}`} className="w-full h-full object-cover" />
            <button
              type="button"
              onClick={() => handleRemove(idx)}
              className="absolute top-1 right-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center hover:bg-rose-700 transition cursor-pointer shadow-xs"
              title={language === 'bn' ? 'মুছে ফেলুন' : 'Remove'}
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}

        {images.length < maxImages && (
          <button
            type="button"
            onClick={() => multiFileInputRef.current?.click()}
            disabled={isProcessing}
            className="aspect-square rounded-xl border-2 border-dashed border-neutral-300 hover:border-rose-500 hover:bg-rose-50/30 flex flex-col items-center justify-center gap-1 text-neutral-500 hover:text-rose-600 transition cursor-pointer p-1"
          >
            {isProcessing ? (
              <RefreshCw className="w-4 h-4 animate-spin text-rose-600" />
            ) : (
              <Upload className="w-4 h-4 text-rose-600" />
            )}
            <span className="text-[10px] font-bold text-center leading-tight">
              {language === 'bn' ? '+ ছবি যোগ' : '+ Add Photo'}
            </span>
          </button>
        )}
      </div>
    </div>
  );
};
