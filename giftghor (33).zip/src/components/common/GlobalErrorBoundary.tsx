import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class GlobalErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error caught by GlobalErrorBoundary:', error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleReset = () => {
    try {
      this.setState({ hasError: false, error: null });
      window.location.href = '/';
    } catch {
      window.location.reload();
    }
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#380208] text-white flex items-center justify-center p-4">
          <div className="bg-[#240106] max-w-md w-full rounded-2xl shadow-2xl border border-[#6B0B1D] p-6 sm:p-8 text-center space-y-5">
            <div className="w-16 h-16 bg-amber-400/20 text-amber-400 rounded-full flex items-center justify-center mx-auto ring-8 ring-[#3D030C]">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-xl font-bold text-white">
                কিছু একটা সমস্যা হয়েছে (Something went wrong)
              </h2>
              <p className="text-sm text-neutral-300">
                পেজটি পুনরায় লোড করুন অথবা হোমপেজে ফিরে যান।
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={this.handleReload}
                className="flex-1 inline-flex items-center justify-center gap-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold py-2.5 px-4 rounded-xl shadow-sm transition cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>রিলোড করুন (Reload)</span>
              </button>
              <button
                onClick={this.handleReset}
                className="flex-1 inline-flex items-center justify-center gap-2 bg-[#3D030C] hover:bg-[#4E0410] text-white border border-[#6B0B1D] font-bold py-2.5 px-4 rounded-xl transition cursor-pointer"
              >
                <Home className="w-4 h-4" />
                <span>হোমপেজ (Home)</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
