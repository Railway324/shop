import React, { useState } from 'react';
import { 
  Globe, 
  Search, 
  Save, 
  Check, 
  Share2, 
  Sparkles,
  Layers,
  FileCode
} from 'lucide-react';
import { StoreSettings, Language } from '../../types';
import { ImageUploadField } from '../common/ImageUploadField';

interface AdminSeoViewProps {
  settings: StoreSettings;
  language: Language;
  onSaveSettings: (settings: StoreSettings) => void;
}

export const AdminSeoView: React.FC<AdminSeoViewProps> = ({
  settings,
  language,
  onSaveSettings,
}) => {
  const [metaTitle, setMetaTitle] = useState(settings.seoMetaTitle || 'Shopping Mall BD | Authentic Lifestyle & Premium Fashion Online');
  const [metaDesc, setMetaDesc] = useState(settings.seoMetaDescription || 'Explore trending t-shirts, exclusive menswear, and premium lifestyle collections at best prices with fast nationwide delivery in Bangladesh.');
  const [keywords, setKeywords] = useState(settings.seoKeywords || 'online shopping bangladesh, oversized t shirt bd, premium streetwear dhaka, best ecommerce shop bd');
  const [ogImage, setOgImage] = useState(settings.seoOgImage || 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      ...settings,
      seoMetaTitle: metaTitle,
      seoMetaDescription: metaDesc,
      seoKeywords: keywords,
      seoOgImage: ogImage
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Globe className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'সার্চ ইঞ্জিন অপটিমাইজেশন (SEO)' : 'Search Engine Optimization (SEO) & Social Graph'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'গুগল সার্চ ও ফেসবুক শেয়ার প্রিভিউয়ের মেটা ট্যাগ ও কিওয়ার্ডস কনফিগার করুন।' 
              : 'Optimize metadata, social share cards (Open Graph), and Google indexation tags.'}
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold animate-fadeIn">
            <Check className="w-4 h-4" />
            <span>SEO Settings Saved!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Google Search Result Preview */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-neutral-400 flex items-center gap-2">
            <Search className="w-4 h-4 text-blue-400" />
            <span>Live Google Search SERP Snippet Preview</span>
          </h3>

          <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-neutral-400">
              <span className="font-medium text-emerald-400">https://www.shoppingmall.com.bd</span>
              <span>›</span>
              <span>home</span>
            </div>
            <h4 className="text-base text-blue-400 hover:underline cursor-pointer font-medium leading-snug">
              {metaTitle || 'Shopping Mall - Buy Online in BD'}
            </h4>
            <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
              {metaDesc || 'Official online store for authentic goods.'}
            </p>
          </div>
        </div>

        {/* Input Fields */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-neutral-300 font-bold">SEO Meta Title: *</label>
                <span className={`text-[10px] ${metaTitle.length > 60 ? 'text-amber-400' : 'text-neutral-500'}`}>
                  {metaTitle.length} / 60 characters
                </span>
              </div>
              <input
                type="text"
                required
                value={metaTitle}
                onChange={(e) => setMetaTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-neutral-300 font-bold">SEO Meta Description: *</label>
                <span className={`text-[10px] ${metaDesc.length > 160 ? 'text-amber-400' : 'text-neutral-500'}`}>
                  {metaDesc.length} / 160 characters
                </span>
              </div>
              <textarea
                rows={3}
                required
                value={metaDesc}
                onChange={(e) => setMetaDesc(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="text-neutral-300 font-bold">Target Search Keywords (Comma Separated):</label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="online shopping bd, clothing, electronics..."
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white outline-none mt-1"
              />
            </div>

            <div>
              <ImageUploadField
                label={language === 'bn' ? 'সোশ্যাল শেয়ার / ওপেনগ্রাফ ছবি আপলোড (ফোন থেকে সরাসরি সিলেক্ট করুন)' : 'Open Graph / Social Card Share Image (Upload from Phone)'}
                sublabel={language === 'bn' ? 'ফেসবুক ও গুগল শেয়ার প্রিভিউ' : 'Facebook & Google Preview'}
                value={ogImage}
                onChange={(img) => setOgImage(img)}
                aspectRatio="banner"
                language={language}
              />
            </div>
          </div>
        </div>

        {/* Action button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save SEO Configurations</span>
          </button>
        </div>
      </form>
    </div>
  );
};
