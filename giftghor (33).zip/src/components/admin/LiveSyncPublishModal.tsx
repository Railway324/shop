import React, { useState } from 'react';
import { 
  CloudUpload, 
  CheckCircle2, 
  RefreshCw, 
  Globe, 
  ExternalLink, 
  Sparkles, 
  Layers, 
  Check, 
  AlertCircle,
  X,
  Radio,
  Zap,
  ShieldCheck,
  Copy,
  ChevronDown,
  ChevronUp,
  Server,
  Database
} from 'lucide-react';
import { Product, WebsiteCustomizerSettings, Language, UserProfile } from '../../types';
import { publishAllToLiveWebsite, LivePublishResult, firebaseConfig } from '../../lib/firebase';
import { toBengaliNumber } from '../../utils/translations';

interface LiveSyncPublishModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  customizerSettings?: WebsiteCustomizerSettings;
  currentUserProfile?: UserProfile | null;
  language: Language;
  onSyncComplete?: (result: LivePublishResult) => void;
}

const FIRESTORE_RULES_SNIPPET = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}`;

export const LiveSyncPublishModal: React.FC<LiveSyncPublishModalProps> = ({
  isOpen,
  onClose,
  products,
  customizerSettings,
  currentUserProfile,
  language,
  onSyncComplete
}) => {
  const [isPublishing, setIsPublishing] = useState(false);
  const [syncStep, setSyncStep] = useState<number>(0);
  const [publishResult, setPublishResult] = useState<LivePublishResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showRulesHelper, setShowRulesHelper] = useState(false);
  const [hasCopiedRules, setHasCopiedRules] = useState(false);

  if (!isOpen) return null;

  const handleStartPublish = async () => {
    setIsPublishing(true);
    setErrorMessage(null);
    setPublishResult(null);
    setSyncStep(1); // 1. Uploading Products

    try {
      setTimeout(() => setSyncStep(2), 500); // 2. Syncing Design & Banners
      setTimeout(() => setSyncStep(3), 1000); // 3. Broadcasting to Live Site

      const result = await publishAllToLiveWebsite(
        products,
        customizerSettings,
        undefined,
        currentUserProfile?.email || undefined
      );

      setSyncStep(4); // 4. Complete
      setPublishResult(result);
      if (result.permissionDenied) {
        setShowRulesHelper(true);
      }
      if (onSyncComplete) {
        onSyncComplete(result);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'সিঙ্ক করতে সমস্যা হয়েছে। দয়া করে আবার চেষ্টা করুন।');
    } finally {
      setIsPublishing(false);
    }
  };

  const handleCopyRules = () => {
    navigator.clipboard.writeText(FIRESTORE_RULES_SNIPPET);
    setHasCopiedRules(true);
    setTimeout(() => setHasCopiedRules(false), 2500);
  };

  const steps = [
    { titleBn: 'পণ্য ক্যাটালগ ও ছবি সিঙ্ক', titleEn: 'Syncing Product Catalog & Images' },
    { titleBn: 'ব্যানার, থিম ও ডিজাইন আপডেট', titleEn: 'Syncing Theme & Banners' },
    { titleBn: 'লাইভ ওয়েবসাইটে অটোমেটিক ব্রডকাস্ট', titleEn: 'Broadcasting to Live Site' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl w-full max-w-lg shadow-2xl border border-neutral-200 overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-rose-600 via-rose-700 to-orange-600 text-white p-5 sm:p-6 relative shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-inner">
              <CloudUpload className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black tracking-tight">
                  {language === 'bn' ? '১-ক্লিক লাইভ সাইট পাবলিশার' : '1-Click Live Website Publisher'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-400 text-neutral-900 text-[10px] font-black uppercase tracking-wider">
                  Live Cloud
                </span>
              </div>
              <p className="text-xs text-rose-100 mt-0.5">
                {language === 'bn' 
                  ? 'গুগল স্টুডিওর আপডেট সরাসরি ডিপ্লয় করা ওয়েবসাইটে পাঠিয়ে দিন' 
                  : 'Instantly push all changes to your deployed live website'}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="p-5 sm:p-6 space-y-4 overflow-y-auto flex-1">
          {/* Target Live URL Card */}
          <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-700">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-semibold text-neutral-500">
                  {language === 'bn' ? 'টার্গেট লাইভ ওয়েবসাইট লিংক' : 'Target Live Website URL'}
                </p>
                <a 
                  href="https://gift-ghor.ai.studio" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="text-xs font-bold text-rose-700 hover:text-rose-800 flex items-center gap-1 hover:underline"
                >
                  <span>https://gift-ghor.ai.studio</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>{language === 'bn' ? 'লাইভ অনলাইন' : 'Live Online'}</span>
            </div>
          </div>

          {/* Sync Stats Summary */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-neutral-50/70 border border-neutral-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                {language === 'bn' ? 'মোট সিঙ্কযোগ্য পণ্য' : 'Products to Sync'}
              </span>
              <p className="text-lg font-black text-neutral-900 mt-0.5">
                {language === 'bn' ? toBengaliNumber(products.length) : products.length} {language === 'bn' ? 'টি' : 'Items'}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-neutral-50/70 border border-neutral-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                {language === 'bn' ? 'থিম ও ব্যানার' : 'Design & Banners'}
              </span>
              <p className="text-lg font-black text-neutral-900 mt-0.5 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>{language === 'bn' ? 'রেডি টু পাবলিশ' : 'Ready'}</span>
              </p>
            </div>
          </div>

          {/* Publishing Progress */}
          {isPublishing && (
            <div className="p-4 rounded-xl bg-rose-50/70 border border-rose-200 space-y-3">
              <div className="flex items-center gap-2 text-rose-800 text-xs font-bold">
                <RefreshCw className="w-4 h-4 animate-spin text-rose-600" />
                <span>{language === 'bn' ? 'লাইভ সাইটে ডেটা পাঠানো হচ্ছে...' : 'Publishing updates to live website...'}</span>
              </div>
              <div className="space-y-2">
                {steps.map((st, idx) => {
                  const isDone = syncStep > idx + 1;
                  const isCurrent = syncStep === idx + 1;
                  return (
                    <div key={idx} className="flex items-center gap-2 text-xs">
                      {isDone ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : isCurrent ? (
                        <div className="w-4 h-4 rounded-full border-2 border-rose-600 border-t-transparent animate-spin shrink-0" />
                      ) : (
                        <div className="w-4 h-4 rounded-full border border-neutral-300 shrink-0" />
                      )}
                      <span className={isDone ? 'text-emerald-800 font-semibold' : isCurrent ? 'text-rose-900 font-bold' : 'text-neutral-400'}>
                        {language === 'bn' ? st.titleBn : st.titleEn}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Publish Result Overview */}
          {publishResult && (
            <div className="space-y-3 animate-in fade-in">
              <div className={`p-4 rounded-xl border ${publishResult.success ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'} space-y-2`}>
                <div className="flex items-center gap-2 font-black text-sm text-neutral-900">
                  {publishResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-rose-600" />
                  )}
                  <span>
                    {publishResult.success
                      ? (language === 'bn' ? '🎉 সফলভাবে সিঙ্ক ও পাবলিশ সম্পন্ন হয়েছে!' : '🎉 Successfully Synced & Published!')
                      : (language === 'bn' ? '⚠️ সিঙ্কে সমস্যা পাওয়া গেছে' : '⚠️ Sync issue detected')}
                  </span>
                </div>
                <p className="text-xs text-neutral-700 leading-relaxed">
                  {publishResult.details || (language === 'bn'
                    ? `মোট ${toBengaliNumber(publishResult.productsCount)}টি পণ্য ও ডিজাইন আপডেট প্রস্তুত করা হয়েছে।`
                    : `Processed ${publishResult.productsCount} products and design assets.`)}
                </p>

                {/* Status Pills */}
                <div className="pt-1 flex flex-wrap gap-2 text-[11px]">
                  <span className={`px-2 py-0.5 rounded-md font-semibold flex items-center gap-1 ${publishResult.serverSynced ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-100 text-neutral-600'}`}>
                    <Server className="w-3 h-3" />
                    <span>সার্ভার ফাইল সিঙ্ক: {publishResult.serverSynced ? 'সফল ✅' : 'অপেক্ষমান'}</span>
                  </span>
                  <span className={`px-2 py-0.5 rounded-md font-semibold flex items-center gap-1 ${publishResult.firestoreSynced ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'}`}>
                    <Database className="w-3 h-3" />
                    <span>ফায়ারবেস ক্লাউড: {publishResult.firestoreSynced ? 'সফল ✅' : 'রুল আপডেট প্রয়োজন ⚠️'}</span>
                  </span>
                </div>
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-2.5 text-rose-800 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Firebase Rules Helper Drawer (Collapsible) */}
          <div className="rounded-xl border border-amber-200 bg-amber-50/70 overflow-hidden">
            <button
              type="button"
              onClick={() => setShowRulesHelper(!showRulesHelper)}
              className="w-full p-3 flex items-center justify-between text-left text-amber-900 hover:bg-amber-100/50 transition cursor-pointer"
            >
              <div className="flex items-center gap-2 text-xs font-bold">
                <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  {language === 'bn' ? 'ফায়ারবেস সিকিউরিটি রুলস গাইড (Firebase Rules Update)' : 'Firebase Firestore Rules Guide'}
                </span>
              </div>
              {showRulesHelper ? <ChevronUp className="w-4 h-4 text-amber-700" /> : <ChevronDown className="w-4 h-4 text-amber-700" />}
            </button>

            {showRulesHelper && (
              <div className="p-3.5 pt-0 text-xs text-amber-950 space-y-3 border-t border-amber-200/60 bg-amber-50">
                <p className="text-[11px] leading-relaxed text-amber-900 mt-2">
                  {language === 'bn'
                    ? `আপনার ফায়ারবেস প্রজেক্টে (${firebaseConfig.projectId}) ক্লাউড রাইট পারমিশন সক্রিয় করতে Firebase Console-এর Firestore Rules ট্যাবে নিচের রুলটি পেস্ট করে "Publish" বাটনে ক্লিক করুন:`
                    : `To enable full cloud writing on project ${firebaseConfig.projectId}, paste the rules below into Firebase Console Firestore Rules tab and click Publish:`}
                </p>

                {/* Rules Code Box */}
                <div className="relative rounded-lg bg-neutral-900 p-3 text-neutral-100 font-mono text-[11px] overflow-x-auto">
                  <button
                    onClick={handleCopyRules}
                    className="absolute top-2 right-2 px-2 py-1 rounded bg-white/20 hover:bg-white/30 text-[10px] font-bold text-white flex items-center gap-1 transition cursor-pointer"
                  >
                    {hasCopiedRules ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{hasCopiedRules ? 'কপি হয়েছে!' : 'Copy Rule'}</span>
                  </button>
                  <pre className="text-amber-300">{FIRESTORE_RULES_SNIPPET}</pre>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-neutral-600 font-semibold">
                    প্রজেক্ট: <span className="text-neutral-900 font-bold">{firebaseConfig.projectId}</span>
                  </span>
                  <a
                    href={`https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore/rules`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 underline"
                  >
                    <span>Firebase Console Rules খুলুন</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 sm:p-5 bg-neutral-50 border-t border-neutral-200 flex items-center justify-end gap-3 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-bold text-neutral-700 hover:bg-neutral-200/80 transition cursor-pointer"
          >
            {publishResult ? (language === 'bn' ? 'বন্ধ করুন' : 'Close') : (language === 'bn' ? 'বাতিল' : 'Cancel')}
          </button>

          {publishResult?.success ? (
            <a
              href="https://gift-ghor.ai.studio"
              target="_blank"
              rel="noreferrer"
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md hover:shadow-lg transition flex items-center gap-2 cursor-pointer"
            >
              <Globe className="w-4 h-4" />
              <span>{language === 'bn' ? 'লাইভ ওয়েবসাইট দেখুন' : 'Visit Live Store'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          ) : (
            <button
              onClick={handleStartPublish}
              disabled={isPublishing}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-700 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white text-xs font-black shadow-md hover:shadow-lg transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isPublishing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{language === 'bn' ? 'সিঙ্ক হচ্ছে...' : 'Publishing...'}</span>
                </>
              ) : (
                <>
                  <RocketIcon className="w-4 h-4 text-amber-300" />
                  <span>{language === 'bn' ? 'লাইভ সাইটে পাবলিশ ও সিঙ্ক করুন' : 'Publish & Sync to Live Site'}</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

function RocketIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      width="24" 
      height="24" 
      stroke="currentColor" 
      strokeWidth="2" 
      fill="none" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
      <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" />
      <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" />
      <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" />
    </svg>
  );
}
