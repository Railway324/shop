import React, { useState, useMemo } from 'react';
import { 
  Sparkles, 
  ArrowUp, 
  ArrowDown, 
  Pin, 
  CheckCircle2, 
  RotateCcw, 
  Save, 
  Search, 
  Layers, 
  Package, 
  Sliders, 
  Eye, 
  TrendingUp, 
  ShoppingBag, 
  Watch, 
  Zap, 
  Home, 
  Baby, 
  Flame, 
  Shirt, 
  Bike,
  ArrowUpDown,
  Check,
  Plus,
  Trash2,
  ArrowRightLeft,
  Filter,
  CheckSquare,
  Square,
  FolderPlus,
  FolderMinus,
  ArrowRight
} from 'lucide-react';
import { Product, Language, WebsiteCustomizerSettings, CategoryId } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';
import { syncProductsToServer, saveProductsToStorage } from '../../utils/storage';

interface AdminAiMerchandiserViewProps {
  products: Product[];
  language: Language;
  customizerSettings?: WebsiteCustomizerSettings;
  onProductsChange: (products: Product[]) => void;
  onSaveCustomizerSettings?: (settings: WebsiteCustomizerSettings) => void;
  onRecordActivity: (action: string, details: string, category: 'product' | 'settings' | 'security') => void;
}

// 9 Standard Manageable Store Categories strictly aligned with Top Category Bar
export const ALL_MANAGEABLE_CATEGORIES: { id: CategoryId; nameBn: string; nameEn: string; icon: any; badgeBg: string; badgeText: string }[] = [
  { id: 'clothes', nameBn: 'পোশাক ও ফ্যাশন (Clothes & Dresses)', nameEn: 'Clothes & Dresses', icon: Shirt, badgeBg: 'bg-rose-50 border-rose-200', badgeText: 'text-rose-700' },
  { id: 'saree', nameBn: 'শাড়ি কালেকশন (Saree Collection)', nameEn: 'Saree Collection', icon: Sparkles, badgeBg: 'bg-rose-50 border-rose-200', badgeText: 'text-rose-700' },
  { id: 'bags', nameBn: 'ব্যাগ ও ব্যাকপ্যাক (Bags & Backpacks)', nameEn: 'Bags & Backpacks', icon: ShoppingBag, badgeBg: 'bg-amber-50 border-amber-200', badgeText: 'text-amber-800' },
  { id: 'watch', nameBn: 'ঘড়ি (WATCH)', nameEn: 'WATCH', icon: Watch, badgeBg: 'bg-cyan-50 border-cyan-200', badgeText: 'text-cyan-800' },
  { id: 'gadgets-electronics', nameBn: 'গ্যাজেটস ও ইলেকট্রনিক্স', nameEn: 'Gadgets & Electronics', icon: Zap, badgeBg: 'bg-blue-50 border-blue-200', badgeText: 'text-blue-700' },
  { id: 'home-lifestyle', nameBn: 'হোম ও লাইফস্টাইল', nameEn: 'Home & Lifestyle', icon: Home, badgeBg: 'bg-emerald-50 border-emerald-200', badgeText: 'text-emerald-800' },
  { id: 'kids-zone', nameBn: 'কিডস জোন', nameEn: 'Kids Zone', icon: Baby, badgeBg: 'bg-pink-50 border-pink-200', badgeText: 'text-pink-700' },
  { id: 'bike-accessories', nameBn: 'বাইক এক্সেসরিজ', nameEn: 'Bike Accessories', icon: Bike, badgeBg: 'bg-purple-50 border-purple-200', badgeText: 'text-purple-700' },
  { id: 'combo-product', nameBn: 'কম্বো প্রোডাক্ট', nameEn: 'Combo Product', icon: Flame, badgeBg: 'bg-orange-50 border-orange-200', badgeText: 'text-orange-700' },
  { id: 'beauty-skincare', nameBn: 'বিউটি ও স্কিনকেয়ার', nameEn: 'Beauty & Skincare', icon: Sparkles, badgeBg: 'bg-pink-50 border-pink-200', badgeText: 'text-pink-700' },
  { id: 'others', nameBn: 'অন্যান্য (Other\'s)', nameEn: 'Other\'s', icon: Package, badgeBg: 'bg-neutral-100 border-neutral-300', badgeText: 'text-neutral-700' },
];

export const AdminAiMerchandiserView: React.FC<AdminAiMerchandiserViewProps> = ({
  products,
  language,
  customizerSettings,
  onProductsChange,
  onSaveCustomizerSettings,
  onRecordActivity,
}) => {
  // Main Sub-Tab: 'category-assignment' | 'categories' | 'products'
  const [activeSubTab, setActiveSubTab] = useState<'category-assignment' | 'categories' | 'products'>('category-assignment');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // --- Category Ordering State (Home page sections) ---
  const [categoryOrder, setCategoryOrder] = useState<string[]>(() => {
    const existing = customizerSettings?.homeCategoryOrder;
    if (Array.isArray(existing) && existing.length > 0) {
      const set = new Set(existing);
      const remaining = ALL_MANAGEABLE_CATEGORIES.filter(c => c.id !== 'others').map(c => c.id).filter(id => !set.has(id));
      return [...existing, ...remaining];
    }
    return ALL_MANAGEABLE_CATEGORIES.filter(c => c.id !== 'others').map(c => c.id);
  });

  // --- Local Products State ---
  const [localProducts, setLocalProducts] = useState<Product[]>(() => [...products]);

  React.useEffect(() => {
    setLocalProducts([...products]);
  }, [products]);

  const showNotification = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  // Helper to commit product updates to parent, storage, and server API
  const commitProductsUpdate = (updatedList: Product[], activityAction: string, activityDetails: string) => {
    setLocalProducts(updatedList);
    onProductsChange(updatedList);
    saveProductsToStorage(updatedList);
    syncProductsToServer(updatedList).catch(err => console.error('Failed to sync products to server', err));
    onRecordActivity(activityAction, activityDetails, 'product');
  };

  // =========================================================================
  // SUB-TAB 1: CATEGORY PRODUCT ASSIGNMENT & MANAGEMENT STATE
  // =========================================================================
  const [selectedManageCategory, setSelectedManageCategory] = useState<CategoryId>('clothes');
  const [assignSubMode, setAssignSubMode] = useState<'current' | 'add-new'>('current');
  const [currentSearch, setCurrentSearch] = useState('');
  const [availableSearch, setAvailableSearch] = useState('');
  const [availableSourceFilter, setAvailableSourceFilter] = useState<string>('all');
  const [selectedCurrentIds, setSelectedCurrentIds] = useState<string[]>([]);
  const [selectedAvailableIds, setSelectedAvailableIds] = useState<string[]>([]);
  const [bulkMoveTargetCategory, setBulkMoveTargetCategory] = useState<CategoryId>('others');

  // Helper to check if a product belongs to the selected manage category
  const matchesManageCategory = (p: Product, catId: CategoryId): boolean => {
    if (catId === 'clothes') return p.category === 'clothes' || p.category === 'fashion';
    if (catId === 'gadgets-electronics') return p.category === 'gadgets-electronics' || p.category === 'gadgets' || p.category === 'electronics';
    if (catId === 'home-lifestyle') return p.category === 'home-lifestyle' || p.category === 'home-living';
    if (catId === 'kids-zone') return p.category === 'kids-zone' || p.category === 'baby';
    return p.category === catId;
  };

  // Products currently inside the selected category
  const currentCategoryProducts = useMemo(() => {
    return localProducts.filter(p => {
      if (!matchesManageCategory(p, selectedManageCategory)) return false;
      if (currentSearch.trim()) {
        const q = currentSearch.toLowerCase();
        const text = (p.id + ' ' + (p.titleBn || '') + ' ' + (p.titleEn || '') + ' ' + (p.sku || '')).toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    }).sort((a, b) => {
      if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
      if (!a.isPinnedToTop && b.isPinnedToTop) return 1;
      const orderA = typeof a.displayOrder === 'number' ? a.displayOrder : 99999;
      const orderB = typeof b.displayOrder === 'number' ? b.displayOrder : 99999;
      return orderA - orderB;
    });
  }, [localProducts, selectedManageCategory, currentSearch]);

  // Other products that can be added into this category
  const availableToAddProducts = useMemo(() => {
    return localProducts.filter(p => {
      // Must NOT be in the currently selected category
      if (matchesManageCategory(p, selectedManageCategory)) return false;
      // Filter by source category if chosen
      if (availableSourceFilter !== 'all' && p.category !== availableSourceFilter) return false;
      // Search
      if (availableSearch.trim()) {
        const q = availableSearch.toLowerCase();
        const text = (p.id + ' ' + (p.titleBn || '') + ' ' + (p.titleEn || '') + ' ' + (p.sku || '')).toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    });
  }, [localProducts, selectedManageCategory, availableSourceFilter, availableSearch]);

  // Count products for each category badge
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    ALL_MANAGEABLE_CATEGORIES.forEach(c => {
      counts[c.id] = localProducts.filter(p => matchesManageCategory(p, c.id)).length;
    });
    return counts;
  }, [localProducts]);

  // 1. Assign a single product to a category
  const handleAssignProduct = (productId: string, targetCategory: CategoryId) => {
    const updated = localProducts.map(p => {
      if (p.id === productId) {
        return {
          ...p,
          category: targetCategory,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });

    const targetCatDef = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === targetCategory);
    const catName = language === 'bn' ? targetCatDef?.nameBn : targetCatDef?.nameEn;
    commitProductsUpdate(updated, 'Assigned Product to Category', `Moved product ${productId} to ${targetCategory}`);
    showNotification(language === 'bn' ? `পণ্যটি সফলভাবে "${catName}" ক্যাটাগরিতে যুক্ত করা হয়েছে!` : `Product assigned to ${catName}!`);
  };

  // 2. Remove a single product from category (moves to 'others')
  const handleRemoveProductFromCategory = (productId: string) => {
    const updated = localProducts.map(p => {
      if (p.id === productId) {
        return {
          ...p,
          category: 'others' as CategoryId,
          isPinnedToTop: false,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });

    const currentCatDef = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === selectedManageCategory);
    const catName = language === 'bn' ? currentCatDef?.nameBn : currentCatDef?.nameEn;
    commitProductsUpdate(updated, 'Removed Product from Category', `Removed product ${productId} from ${selectedManageCategory}`);
    showNotification(language === 'bn' ? `পণ্যটি "${catName}" ক্যাটাগরি থেকে সরানো হয়েছে!` : `Product removed from ${catName}!`);
  };

  // 3. Bulk Add selected available products into the active category
  const handleBulkAddToCategory = () => {
    if (selectedAvailableIds.length === 0) return;
    const set = new Set(selectedAvailableIds);
    const updated = localProducts.map(p => {
      if (set.has(p.id)) {
        return {
          ...p,
          category: selectedManageCategory,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });

    const currentCatDef = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === selectedManageCategory);
    const catName = language === 'bn' ? currentCatDef?.nameBn : currentCatDef?.nameEn;
    commitProductsUpdate(updated, 'Bulk Assigned Products', `Added ${selectedAvailableIds.length} products to ${selectedManageCategory}`);
    showNotification(language === 'bn' ? `একসাথে ${toBengaliNumber(selectedAvailableIds.length)} টি পণ্য "${catName}" ক্যাটাগরিতে যুক্ত করা হয়েছে!` : `${selectedAvailableIds.length} products added to ${catName}!`);
    setSelectedAvailableIds([]);
  };

  // 4. Bulk Remove selected current products from the active category
  const handleBulkRemoveFromCategory = () => {
    if (selectedCurrentIds.length === 0) return;
    const set = new Set(selectedCurrentIds);
    const updated = localProducts.map(p => {
      if (set.has(p.id)) {
        return {
          ...p,
          category: 'others' as CategoryId,
          isPinnedToTop: false,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });

    const currentCatDef = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === selectedManageCategory);
    const catName = language === 'bn' ? currentCatDef?.nameBn : currentCatDef?.nameEn;
    commitProductsUpdate(updated, 'Bulk Removed Products', `Removed ${selectedCurrentIds.length} products from ${selectedManageCategory}`);
    showNotification(language === 'bn' ? `একসাথে ${toBengaliNumber(selectedCurrentIds.length)} টি পণ্য "${catName}" ক্যাটাগরি থেকে সরানো হয়েছে!` : `${selectedCurrentIds.length} products removed from ${catName}!`);
    setSelectedCurrentIds([]);
  };

  // 5. Bulk Move selected current products to another category
  const handleBulkMoveToAnotherCategory = () => {
    if (selectedCurrentIds.length === 0 || !bulkMoveTargetCategory) return;
    const set = new Set(selectedCurrentIds);
    const updated = localProducts.map(p => {
      if (set.has(p.id)) {
        return {
          ...p,
          category: bulkMoveTargetCategory,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });

    const targetCatDef = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === bulkMoveTargetCategory);
    const catName = language === 'bn' ? targetCatDef?.nameBn : targetCatDef?.nameEn;
    commitProductsUpdate(updated, 'Bulk Moved Products', `Moved ${selectedCurrentIds.length} products to ${bulkMoveTargetCategory}`);
    showNotification(language === 'bn' ? `একসাথে ${toBengaliNumber(selectedCurrentIds.length)} টি পণ্য "${catName}" ক্যাটাগরিতে স্থানান্তর করা হয়েছে!` : `${selectedCurrentIds.length} products moved to ${catName}!`);
    setSelectedCurrentIds([]);
  };

  // =========================================================================
  // SUB-TAB 2: CATEGORY SECTION ORDERING ON HOME PAGE
  // =========================================================================
  const handleMoveCategory = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === categoryOrder.length - 1) return;

    const newOrder = [...categoryOrder];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    const temp = newOrder[index];
    newOrder[index] = newOrder[targetIndex];
    newOrder[targetIndex] = temp;
    setCategoryOrder(newOrder);
  };

  const handleMoveCategoryToTop = (index: number) => {
    if (index === 0) return;
    const newOrder = [...categoryOrder];
    const item = newOrder.splice(index, 1)[0];
    newOrder.unshift(item);
    setCategoryOrder(newOrder);
  };

  const handleResetCategoryOrder = () => {
    const defaultIds = ALL_MANAGEABLE_CATEGORIES.filter(c => c.id !== 'others').map(c => c.id);
    setCategoryOrder(defaultIds);
  };

  const handleSaveCategoryOrder = () => {
    if (!customizerSettings) return;
    const updated: WebsiteCustomizerSettings = {
      ...customizerSettings,
      homeCategoryOrder: categoryOrder,
    };
    if (onSaveCustomizerSettings) {
      onSaveCustomizerSettings(updated);
    }
    onRecordActivity('Updated Home Category Order', `Reordered categories: ${categoryOrder.join(' -> ')}`, 'settings');
    showNotification(language === 'bn' ? 'হোমপেজ ক্যাটাগরির নতুন ক্রম সফলভাবে সংরক্ষিত হয়েছে!' : 'Category order saved successfully!');
  };

  // =========================================================================
  // SUB-TAB 3: PRODUCT ORDERING & PINNING
  // =========================================================================
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('all');
  const [productSearch, setProductSearch] = useState<string>('');

  const filteredProductsForOrdering = useMemo(() => {
    return localProducts.filter(p => {
      if (productCategoryFilter !== 'all') {
        if (!matchesManageCategory(p, productCategoryFilter as CategoryId)) return false;
      }
      if (productSearch.trim()) {
        const q = productSearch.toLowerCase();
        const text = (p.id + ' ' + (p.titleEn || '') + ' ' + (p.titleBn || '') + ' ' + (p.sku || '')).toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    }).sort((a, b) => {
      if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
      if (!a.isPinnedToTop && b.isPinnedToTop) return 1;
      const orderA = typeof a.displayOrder === 'number' ? a.displayOrder : 99999;
      const orderB = typeof b.displayOrder === 'number' ? b.displayOrder : 99999;
      return orderA - orderB;
    });
  }, [localProducts, productCategoryFilter, productSearch]);

  const handleTogglePinProduct = (productId: string) => {
    const updated = localProducts.map(p => {
      if (p.id === productId) {
        const isPinned = !p.isPinnedToTop;
        return {
          ...p,
          isPinnedToTop: isPinned,
          displayOrder: isPinned ? 1 : undefined
        };
      }
      return p;
    });
    commitProductsUpdate(updated, 'Toggled Product Pin', `Toggled pin for ${productId}`);
  };

  const handleSetProductDisplayOrder = (productId: string, orderVal: number) => {
    const updated = localProducts.map(p => {
      if (p.id === productId) {
        return {
          ...p,
          displayOrder: orderVal
        };
      }
      return p;
    });
    setLocalProducts(updated);
  };

  const handleMoveProductUp = (index: number) => {
    if (index === 0) return;
    const targetProduct = filteredProductsForOrdering[index];
    const prevProduct = filteredProductsForOrdering[index - 1];

    const updated = localProducts.map(p => {
      if (p.id === targetProduct.id) {
        return { ...p, displayOrder: (prevProduct.displayOrder || index) - 1, isPinnedToTop: true };
      }
      return p;
    });
    commitProductsUpdate(updated, 'Moved Product Up', `Moved product ${targetProduct.id} up`);
  };

  const handleMoveProductDown = (index: number) => {
    if (index >= filteredProductsForOrdering.length - 1) return;
    const targetProduct = filteredProductsForOrdering[index];
    const nextProduct = filteredProductsForOrdering[index + 1];

    const updated = localProducts.map(p => {
      if (p.id === targetProduct.id) {
        return { ...p, displayOrder: (nextProduct.displayOrder || index + 1) + 1 };
      }
      return p;
    });
    commitProductsUpdate(updated, 'Moved Product Down', `Moved product ${targetProduct.id} down`);
  };

  const handleSaveAllProductOrders = () => {
    commitProductsUpdate(localProducts, 'Updated Product Display Orders', `Saved custom merchandise order for ${localProducts.length} products`);
    showNotification(language === 'bn' ? 'সকল পণ্যের নতুন প্রদর্শনী ক্রম সফলভাবে সংরক্ষিত হয়েছে!' : 'Product display orders saved successfully!');
  };

  const activeCategoryObj = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === selectedManageCategory) || ALL_MANAGEABLE_CATEGORIES[0];
  const ActiveCatIcon = activeCategoryObj.icon;

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Top Banner / Heading */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-neutral-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#800020]/10 text-[#800020] flex items-center justify-center shrink-0">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-neutral-900 tracking-tight">
                {language === 'bn' ? 'ক্যাটাগরি ও পণ্য নিয়ন্ত্রণ সেন্টার' : 'Category & Product Merchandiser'}
              </h1>
              <p className="text-xs sm:text-sm text-neutral-500 font-medium">
                {language === 'bn' 
                  ? 'কোন ক্যাটাগরিতে কোন কোন পণ্য থাকবে/বাদ যাবে এবং হোমপেজে ক্যাটাগরি ও পণ্যের প্রদর্শন ক্রম নির্ধারণ করুন।'
                  : 'Assign or remove products from categories, arrange home category sections and prioritize products.'}
              </p>
            </div>
          </div>
        </div>

        {/* Global Save Toast / Feedback */}
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold px-4 py-2.5 rounded-2xl flex items-center gap-2 animate-popIn shadow-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('category-assignment')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'category-assignment'
              ? 'bg-[#800020] text-white shadow-xs'
              : 'bg-white text-neutral-700 hover:bg-neutral-100 border border-neutral-200'
          }`}
        >
          <ArrowRightLeft className="w-4 h-4" />
          <span>{language === 'bn' ? '১. ক্যাটাগরিতে পণ্য যুক্ত ও সরানো (Assign / Remove)' : '1. Assign / Remove Products'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('categories')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'categories'
              ? 'bg-[#800020] text-white shadow-xs'
              : 'bg-white text-neutral-700 hover:bg-neutral-100 border border-neutral-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>{language === 'bn' ? '২. হোমপেজ ক্যাটাগরি ক্রম সাজানো' : '2. Home Category Ordering'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('products')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'products'
              ? 'bg-[#800020] text-white shadow-xs'
              : 'bg-white text-neutral-700 hover:bg-neutral-100 border border-neutral-200'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>{language === 'bn' ? '৩. পণ্যের প্রদর্শন ক্রম ও শীর্ষে পিন' : '3. Product Priority & Pinning'}</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* SUB-TAB 1: CATEGORY PRODUCT ASSIGNMENT & REMOVAL */}
      {/* ========================================================================= */}
      {activeSubTab === 'category-assignment' && (
        <div className="space-y-6 animate-fadeIn">
          {/* 1. Category Selector Cards Bar */}
          <div className="bg-white rounded-3xl p-4 sm:p-6 border border-neutral-200/80 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs sm:text-sm font-bold text-neutral-800 flex items-center gap-2">
                <Filter className="w-4 h-4 text-[#800020]" />
                <span>{language === 'bn' ? 'যে ক্যাটাগরিটির পণ্য আপনি নিয়ন্ত্রণ করতে চান সিলেক্ট করুন:' : 'Select Category to Manage:'}</span>
              </h2>
              <span className="text-[11px] text-neutral-500 font-medium">
                {language === 'bn' ? `মোট ${toBengaliNumber(localProducts.length)} টি পণ্য` : `Total ${localProducts.length} Products`}
              </span>
            </div>

            {/* Grid of category selector buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
              {ALL_MANAGEABLE_CATEGORIES.map(cat => {
                const IconComp = cat.icon;
                const isSelected = selectedManageCategory === cat.id;
                const count = categoryCounts[cat.id] || 0;

                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setSelectedManageCategory(cat.id);
                      setSelectedCurrentIds([]);
                      setSelectedAvailableIds([]);
                    }}
                    className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center text-center transition cursor-pointer relative group ${
                      isSelected
                        ? 'bg-[#800020] text-white border-[#800020] shadow-md shadow-[#800020]/20 font-bold scale-[1.02]'
                        : 'bg-neutral-50 hover:bg-white text-neutral-700 border-neutral-200/80 hover:border-[#800020]/40'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center mb-1 transition-transform group-hover:scale-110 ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-[#800020]/10 text-[#800020]'
                    }`}>
                      <IconComp className="w-4 h-4" />
                    </div>
                    <span className="text-[11px] font-bold line-clamp-1 leading-tight">
                      {language === 'bn' ? cat.nameBn : cat.nameEn}
                    </span>
                    <span className={`text-[10px] mt-0.5 px-1.5 py-0.2 rounded-full font-mono font-bold ${
                      isSelected ? 'bg-white/30 text-white' : 'bg-neutral-200/70 text-neutral-600'
                    }`}>
                      {language === 'bn' ? toBengaliNumber(count) : count} {language === 'bn' ? 'টি' : 'items'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Active Category Workspace */}
          <div className="bg-white rounded-3xl p-5 sm:p-7 border border-neutral-200/80 shadow-xs space-y-5">
            {/* Active Category Header Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#800020] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <ActiveCatIcon className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-black text-neutral-900">
                      {language === 'bn' ? activeCategoryObj.nameBn : activeCategoryObj.nameEn}
                    </h3>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-[#800020]/10 text-[#800020] border border-[#800020]/20">
                      {language === 'bn' ? `${toBengaliNumber(currentCategoryProducts.length)} টি পণ্য যুক্ত আছে` : `${currentCategoryProducts.length} products`}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 mt-0.5">
                    {language === 'bn' 
                      ? 'এখান থেকে পণ্য এই ক্যাটাগরিতে যুক্ত করুন, সরিয়ে ফেলুন বা অন্য ক্যাটাগরিতে স্থানান্তর করুন।' 
                      : 'Add new products to this category, remove them, or move to another category.'}
                  </p>
                </div>
              </div>

              {/* View Switcher: Current Products vs Add Other Products */}
              <div className="flex items-center gap-1.5 bg-neutral-100 p-1 rounded-2xl self-start sm:self-center">
                <button
                  onClick={() => setAssignSubMode('current')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    assignSubMode === 'current'
                      ? 'bg-white text-neutral-900 shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <FolderMinus className="w-3.5 h-3.5 text-[#800020]" />
                  <span>{language === 'bn' ? `বর্তমান পণ্যসমূহ (${toBengaliNumber(currentCategoryProducts.length)})` : `Current (${currentCategoryProducts.length})`}</span>
                </button>

                <button
                  onClick={() => setAssignSubMode('add-new')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    assignSubMode === 'add-new'
                      ? 'bg-[#800020] text-white shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? `+ অন্য পণ্য যোগ করুন (${toBengaliNumber(availableToAddProducts.length)})` : `+ Add Others (${availableToAddProducts.length})`}</span>
                </button>
              </div>
            </div>

            {/* ------------------------------------------------------------- */}
            {/* VIEW A: CURRENT PRODUCTS IN THIS CATEGORY */}
            {/* ------------------------------------------------------------- */}
            {assignSubMode === 'current' && (
              <div className="space-y-4 animate-fadeIn">
                {/* Search & Bulk Action Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-neutral-50 p-3.5 rounded-2xl border border-neutral-200">
                  {/* Search inside category */}
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder={language === 'bn' ? `"${activeCategoryObj.nameBn}" এর পণ্য খুঁজুন...` : `Search products in this category...`}
                      value={currentSearch}
                      onChange={(e) => setCurrentSearch(e.target.value)}
                      className="w-full pl-9 pr-4 py-1.5 rounded-xl border border-neutral-300 text-xs bg-white focus:outline-hidden focus:ring-1 focus:ring-[#800020]"
                    />
                  </div>

                  {/* Bulk Actions for selected items */}
                  {selectedCurrentIds.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-bold text-neutral-700">
                        {language === 'bn' ? `${toBengaliNumber(selectedCurrentIds.length)} টি সিলেক্টেড:` : `${selectedCurrentIds.length} selected:`}
                      </span>

                      {/* Bulk Remove Button */}
                      <button
                        onClick={handleBulkRemoveFromCategory}
                        className="px-3 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                        title="এই ক্যাটাগরি থেকে বাদ দিন"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-600" />
                        <span>{language === 'bn' ? 'ক্যাটাগরি থেকে সরান' : 'Remove Selected'}</span>
                      </button>

                      {/* Bulk Move Target Dropdown */}
                      <div className="flex items-center gap-1 bg-white border border-neutral-300 px-2 py-1 rounded-xl">
                        <span className="text-[11px] text-neutral-500 font-semibold">{language === 'bn' ? 'স্থানান্তর:' : 'Move to:'}</span>
                        <select
                          value={bulkMoveTargetCategory}
                          onChange={(e) => setBulkMoveTargetCategory(e.target.value as CategoryId)}
                          className="text-xs font-semibold bg-transparent outline-none cursor-pointer"
                        >
                          {ALL_MANAGEABLE_CATEGORIES.filter(c => c.id !== selectedManageCategory).map(c => (
                            <option key={c.id} value={c.id}>
                              {language === 'bn' ? c.nameBn : c.nameEn}
                            </option>
                          ))}
                        </select>
                        <button
                          onClick={handleBulkMoveToAnotherCategory}
                          className="px-2 py-0.5 bg-[#800020] text-white rounded text-[11px] font-bold cursor-pointer hover:bg-[#600018]"
                        >
                          {language === 'bn' ? 'পাঠান' : 'Move'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Select All Bar */}
                {currentCategoryProducts.length > 0 && (
                  <div className="flex items-center justify-between px-2 text-xs text-neutral-500 font-medium">
                    <button
                      onClick={() => {
                        if (selectedCurrentIds.length === currentCategoryProducts.length) {
                          setSelectedCurrentIds([]);
                        } else {
                          setSelectedCurrentIds(currentCategoryProducts.map(p => p.id));
                        }
                      }}
                      className="flex items-center gap-1.5 font-bold text-neutral-700 hover:text-[#800020] cursor-pointer"
                    >
                      {selectedCurrentIds.length === currentCategoryProducts.length ? (
                        <CheckSquare className="w-4 h-4 text-[#800020]" />
                      ) : (
                        <Square className="w-4 h-4 text-neutral-400" />
                      )}
                      <span>{language === 'bn' ? 'সবগুলো পণ্য নির্বাচন করুন' : 'Select All'}</span>
                    </button>

                    <span>
                      {language === 'bn' 
                        ? `মোট ${toBengaliNumber(currentCategoryProducts.length)} টি পণ্যের তালিকা` 
                        : `${currentCategoryProducts.length} items`}
                    </span>
                  </div>
                )}

                {/* List of Current Products */}
                {currentCategoryProducts.length === 0 ? (
                  <div className="py-12 text-center bg-neutral-50 rounded-2xl border border-dashed border-neutral-300 space-y-3">
                    <div className="w-12 h-12 rounded-2xl bg-neutral-200/70 text-neutral-400 flex items-center justify-center mx-auto">
                      <Package className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-neutral-800">
                        {language === 'bn' ? 'এই ক্যাটাগরিতে বর্তমানে কোনো পণ্য নেই' : 'No products in this category'}
                      </h4>
                      <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                        {language === 'bn' 
                          ? 'অন্য কোনো ক্যাটাগরি বা আনক্যাটাগোরাইজড তালিকা থেকে পণ্য যুক্ত করতে ওপরের "+ অন্য পণ্য যোগ করুন" বাটনে ক্লিক করুন।'
                          : 'Click "+ Add Others" above to assign products from other categories.'}
                      </p>
                    </div>
                    <button
                      onClick={() => setAssignSubMode('add-new')}
                      className="px-4 py-2 rounded-xl bg-[#800020] text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{language === 'bn' ? '+ নতুন পণ্য যুক্ত করুন' : '+ Add Products Now'}</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[550px] overflow-y-auto pr-1">
                    {currentCategoryProducts.map((product, index) => {
                      const isSelected = selectedCurrentIds.includes(product.id);

                      return (
                        <div
                          key={product.id}
                          className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                            isSelected 
                              ? 'bg-rose-50/50 border-[#800020]/40' 
                              : product.isPinnedToTop 
                                ? 'bg-amber-50/60 border-amber-200' 
                                : 'bg-white hover:bg-neutral-50 border-neutral-200'
                          }`}
                        >
                          {/* Left: Checkbox + Thumbnail + Details */}
                          <div className="flex items-center gap-3 min-w-0">
                            <button
                              onClick={() => {
                                if (isSelected) {
                                  setSelectedCurrentIds(selectedCurrentIds.filter(id => id !== product.id));
                                } else {
                                  setSelectedCurrentIds([...selectedCurrentIds, product.id]);
                                }
                              }}
                              className="cursor-pointer text-neutral-400 hover:text-[#800020]"
                            >
                              {isSelected ? (
                                <CheckSquare className="w-4 h-4 text-[#800020]" />
                              ) : (
                                <Square className="w-4 h-4" />
                              )}
                            </button>

                            <img
                              src={product.image}
                              alt=""
                              className="w-12 h-12 rounded-xl object-cover border border-neutral-200 shrink-0 bg-neutral-100"
                            />

                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-xs sm:text-sm font-bold text-neutral-900 truncate max-w-xs sm:max-w-md">
                                  {language === 'bn' ? (product.titleBn || product.titleEn) : (product.titleEn || product.titleBn)}
                                </h4>
                                {product.isPinnedToTop && (
                                  <span className="bg-amber-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-2xs">
                                    📌 #১ শীর্ষে পিন
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-neutral-500 font-mono mt-0.5">
                                {formatPrice(product.price, language)} · SKU: {product.sku || product.id} · স্টক: {product.stock}
                              </p>
                            </div>
                          </div>

                          {/* Right: Category Action Controls */}
                          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                            {/* Move to another category dropdown */}
                            <div className="flex items-center gap-1 bg-neutral-100 border border-neutral-200 px-2 py-1 rounded-xl text-xs">
                              <span className="text-[10px] text-neutral-400 font-semibold">{language === 'bn' ? 'স্থানান্তর:' : 'Move:'}</span>
                              <select
                                value=""
                                onChange={(e) => {
                                  if (e.target.value) {
                                    handleAssignProduct(product.id, e.target.value as CategoryId);
                                  }
                                }}
                                className="text-xs font-bold text-neutral-700 bg-transparent outline-none cursor-pointer"
                              >
                                <option value="">{language === 'bn' ? 'অন্য ক্যাটাগরি...' : 'Select Category...'}</option>
                                {ALL_MANAGEABLE_CATEGORIES.filter(c => c.id !== selectedManageCategory).map(c => (
                                  <option key={c.id} value={c.id}>
                                    {language === 'bn' ? c.nameBn : c.nameEn}
                                  </option>
                                ))}
                              </select>
                            </div>

                            {/* Pin Button */}
                            <button
                              onClick={() => handleTogglePinProduct(product.id)}
                              className={`p-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                                product.isPinnedToTop
                                  ? 'bg-amber-500 text-white shadow-2xs'
                                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                              }`}
                              title="ক্যাটাগরির শীর্ষে পিন করুন"
                            >
                              <Pin className="w-3.5 h-3.5" />
                            </button>

                            {/* Remove from Category Button */}
                            <button
                              onClick={() => handleRemoveProductFromCategory(product.id)}
                              className="px-2.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center gap-1 cursor-pointer transition active:scale-95"
                              title="এই ক্যাটাগরি থেকে বাদ দিন"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-600" />
                              <span className="hidden sm:inline">{language === 'bn' ? 'ক্যাটাগরি থেকে সরান' : 'Remove'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* VIEW B: ADD PRODUCTS FROM OTHER CATEGORIES TO THIS CATEGORY */}
            {/* ------------------------------------------------------------- */}
            {assignSubMode === 'add-new' && (
              <div className="space-y-4 animate-fadeIn">
                {/* Search, Filter & Bulk Add Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-neutral-50 p-3.5 rounded-2xl border border-neutral-200">
                  {/* Category Filter */}
                  <div className="w-full sm:w-56">
                    <select
                      value={availableSourceFilter}
                      onChange={(e) => setAvailableSourceFilter(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl border border-neutral-300 text-xs font-semibold bg-white outline-none focus:ring-1 focus:ring-[#800020]"
                    >
                      <option value="all">{language === 'bn' ? 'সকল অন্যান্য ক্যাটাগরি' : 'All Other Categories'}</option>
                      {ALL_MANAGEABLE_CATEGORIES.filter(c => c.id !== selectedManageCategory).map(c => (
                        <option key={c.id} value={c.id}>
                          {language === 'bn' ? c.nameBn : c.nameEn}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Search Input */}
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder={language === 'bn' ? 'যুক্ত করার জন্য পণ্য খুঁজুন (নাম বা কোড)...' : 'Search products to add...'}
                      value={availableSearch}
                      onChange={(e) => setAvailableSearch(e.target.value)}
                      className="w-full pl-9 pr-4 py-1.5 rounded-xl border border-neutral-300 text-xs bg-white focus:outline-hidden focus:ring-1 focus:ring-[#800020]"
                    />
                  </div>

                  {/* Bulk Add Button */}
                  {selectedAvailableIds.length > 0 && (
                    <button
                      onClick={handleBulkAddToCategory}
                      className="px-4 py-1.5 rounded-xl bg-[#800020] hover:bg-[#600018] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs animate-popIn"
                    >
                      <Plus className="w-4 h-4" />
                      <span>
                        {language === 'bn' 
                          ? `সিলেক্টেড (${toBengaliNumber(selectedAvailableIds.length)}) টি "${activeCategoryObj.nameBn}"-এ যোগ করুন` 
                          : `Add (${selectedAvailableIds.length}) to ${activeCategoryObj.nameEn}`}
                      </span>
                    </button>
                  )}
                </div>

                {/* Select All Bar */}
                {availableToAddProducts.length > 0 && (
                  <div className="flex items-center justify-between px-2 text-xs text-neutral-500 font-medium">
                    <button
                      onClick={() => {
                        if (selectedAvailableIds.length === availableToAddProducts.length) {
                          setSelectedAvailableIds([]);
                        } else {
                          setSelectedAvailableIds(availableToAddProducts.map(p => p.id));
                        }
                      }}
                      className="flex items-center gap-1.5 font-bold text-neutral-700 hover:text-[#800020] cursor-pointer"
                    >
                      {selectedAvailableIds.length === availableToAddProducts.length ? (
                        <CheckSquare className="w-4 h-4 text-[#800020]" />
                      ) : (
                        <Square className="w-4 h-4 text-neutral-400" />
                      )}
                      <span>{language === 'bn' ? 'সবগুলো পণ্য নির্বাচন করুন' : 'Select All'}</span>
                    </button>

                    <span>
                      {language === 'bn' 
                        ? `মোট ${toBengaliNumber(availableToAddProducts.length)} টি পণ্য যুক্ত করার জন্য প্রস্তুত` 
                        : `${availableToAddProducts.length} items available`}
                    </span>
                  </div>
                )}

                {/* Available Products List */}
                {availableToAddProducts.length === 0 ? (
                  <div className="py-12 text-center bg-neutral-50 rounded-2xl border border-neutral-200 space-y-2">
                    <p className="text-xs text-neutral-500">
                      {language === 'bn' ? 'যুক্ত করার মতো কোনো পণ্য পাওয়া যায়নি।' : 'No other products found to add.'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[550px] overflow-y-auto pr-1">
                    {availableToAddProducts.map((product) => {
                      const isSelected = selectedAvailableIds.includes(product.id);
                      const currentSourceDef = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === product.category);

                      return (
                        <div
                          key={product.id}
                          className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                            isSelected 
                              ? 'bg-rose-50/60 border-[#800020]/40' 
                              : 'bg-white hover:bg-neutral-50 border-neutral-200'
                          }`}
                        >
                          {/* Left: Checkbox + Thumbnail + Details */}
                          <div className="flex items-center gap-3 min-w-0">
                            <button
                              onClick={() => {
                                if (isSelected) {
                                  setSelectedAvailableIds(selectedAvailableIds.filter(id => id !== product.id));
                                } else {
                                  setSelectedAvailableIds([...selectedAvailableIds, product.id]);
                                }
                              }}
                              className="cursor-pointer text-neutral-400 hover:text-[#800020]"
                            >
                              {isSelected ? (
                                <CheckSquare className="w-4 h-4 text-[#800020]" />
                              ) : (
                                <Square className="w-4 h-4" />
                              )}
                            </button>

                            <img
                              src={product.image}
                              alt=""
                              className="w-12 h-12 rounded-xl object-cover border border-neutral-200 shrink-0 bg-neutral-100"
                            />

                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-xs sm:text-sm font-bold text-neutral-900 truncate max-w-xs sm:max-w-md">
                                  {language === 'bn' ? (product.titleBn || product.titleEn) : (product.titleEn || product.titleBn)}
                                </h4>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-600 border border-neutral-200">
                                  বর্তমান: {language === 'bn' ? currentSourceDef?.nameBn || product.category : currentSourceDef?.nameEn || product.category}
                                </span>
                              </div>
                              <p className="text-[11px] text-neutral-500 font-mono mt-0.5">
                                {formatPrice(product.price, language)} · SKU: {product.sku || product.id}
                              </p>
                            </div>
                          </div>

                          {/* Right: 1-Click Add Button */}
                          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                            <button
                              onClick={() => handleAssignProduct(product.id, selectedManageCategory)}
                              className="px-3.5 py-1.5 rounded-xl bg-[#800020] hover:bg-[#600018] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95 transition"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? `+ "${activeCategoryObj.nameBn}"-এ যোগ করুন` : `+ Add to Category`}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 2: CATEGORY SECTION ORDERING ON HOME PAGE */}
      {/* ========================================================================= */}
      {activeSubTab === 'categories' && (
        <div className="space-y-5 animate-fadeIn">
          <div className="bg-white rounded-3xl p-5 sm:p-7 border border-neutral-200/80 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-100">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <ArrowUpDown className="w-4 h-4 text-[#800020]" />
                  <span>{language === 'bn' ? 'হোমপেজে ক্যাটাগরি প্রদর্শনের ক্রম নির্ধারণ করুন' : 'Set Category Order for Home Page'}</span>
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {language === 'bn' 
                    ? 'যে ক্যাটাগরিটি আপনি হোমপেজের সবার ওপরে দেখতে চান, সেটিকে ⬆️ বাটন বা "শীর্ষে নিন" চেপে ১ নম্বরে রাখুন।' 
                    : 'Use ⬆️ or "Move to Top" to place any category at rank #1 on your Home page.'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleResetCategoryOrder}
                  className="px-3 py-1.5 rounded-xl border border-neutral-200 text-neutral-600 hover:bg-neutral-50 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'ডিফল্ট ক্রমে ফিরুন' : 'Reset Default'}</span>
                </button>

                <button
                  onClick={handleSaveCategoryOrder}
                  className="px-5 py-2 rounded-xl bg-[#800020] hover:bg-[#600018] text-white text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'ক্যাটাগরি ক্রম সংরক্ষণ করুন' : 'Save Category Order'}</span>
                </button>
              </div>
            </div>

            {/* Interactive Category List */}
            <div className="space-y-2.5">
              {categoryOrder.map((catId, index) => {
                const def = ALL_MANAGEABLE_CATEGORIES.find(c => c.id === catId);
                if (!def) return null;
                const IconComp = def.icon;

                return (
                  <div
                    key={catId}
                    className="p-3 sm:p-4 rounded-2xl border border-neutral-200 bg-neutral-50/50 hover:bg-white transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs hover:shadow-sm"
                  >
                    {/* Category Info */}
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-[#800020] text-white font-black text-sm flex items-center justify-center shrink-0 shadow-xs">
                        #{index + 1}
                      </div>

                      <div className="w-8 h-8 rounded-lg bg-neutral-200/70 text-neutral-700 flex items-center justify-center shrink-0">
                        <IconComp className="w-4 h-4" />
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-neutral-900">
                          {language === 'bn' ? def.nameBn : def.nameEn}
                        </h4>
                        <span className="text-[11px] text-neutral-400 font-mono">
                          ID: {def.id} · {index === 0 ? (language === 'bn' ? '🌟 হোমপেজে সবার প্রথমে দেখাবে' : '🌟 Shows 1st on Home') : `${index + 1}-তম অবস্থান`}
                        </span>
                      </div>
                    </div>

                    {/* Action Controls */}
                    <div className="flex items-center gap-1.5 self-end sm:self-center">
                      <button
                        onClick={() => handleMoveCategoryToTop(index)}
                        disabled={index === 0}
                        className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold border transition cursor-pointer flex items-center gap-1 ${
                          index === 0
                            ? 'bg-neutral-100 text-neutral-300 border-neutral-200 cursor-not-allowed'
                            : 'bg-white hover:bg-[#800020]/10 text-[#800020] border-[#800020]/30'
                        }`}
                        title="এক ক্লিকে ১ নম্বরে আনুন"
                      >
                        <Pin className="w-3 h-3" />
                        <span>{language === 'bn' ? 'শীর্ষে নিন' : 'Move to Top'}</span>
                      </button>

                      <button
                        onClick={() => handleMoveCategory(index, 'up')}
                        disabled={index === 0}
                        className={`w-8 h-8 rounded-lg border flex items-center justify-center transition cursor-pointer ${
                          index === 0
                            ? 'bg-neutral-100 text-neutral-300 border-neutral-200 cursor-not-allowed'
                            : 'bg-white hover:bg-neutral-100 text-neutral-700 border-neutral-200'
                        }`}
                        title="উপরে নিন"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleMoveCategory(index, 'down')}
                        disabled={index === categoryOrder.length - 1}
                        className={`w-8 h-8 rounded-lg border flex items-center justify-center transition cursor-pointer ${
                          index === categoryOrder.length - 1
                            ? 'bg-neutral-100 text-neutral-300 border-neutral-200 cursor-not-allowed'
                            : 'bg-white hover:bg-neutral-100 text-neutral-700 border-neutral-200'
                        }`}
                        title="নিচে নিন"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 3: PRODUCT PRIORITY & PIN TO TOP */}
      {/* ========================================================================= */}
      {activeSubTab === 'products' && (
        <div className="space-y-5 animate-fadeIn">
          <div className="bg-white rounded-3xl p-5 sm:p-7 border border-neutral-200/80 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-100">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-neutral-900 flex items-center gap-2">
                  <Package className="w-4 h-4 text-[#800020]" />
                  <span>{language === 'bn' ? 'কোন পণ্যগুলো আগে থাকবে আর কোনগুলো শেষে থাকবে নির্ধারণ করুন' : 'Set Product Priority & Pin to Top'}</span>
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {language === 'bn' 
                    ? 'যেকোনো পণ্যকে "📌 শীর্ষে পিন করুন" চাপলে সেটি সবসময় তালিকায় সবার প্রথমে দেখাবে, অথবা ক্রম নম্বর ১, ২, ৩ লিখে সাজান।' 
                    : 'Pin any product to always display first, or enter custom numeric order (1, 2, 3...).'}
                </p>
              </div>

              <button
                onClick={handleSaveAllProductOrders}
                className="px-5 py-2 rounded-xl bg-[#800020] hover:bg-[#600018] text-white text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer active:scale-95 self-start sm:self-center"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'সকল পণ্যের ক্রম সংরক্ষণ করুন' : 'Save Product Orders'}</span>
              </button>
            </div>

            {/* Filter & Search Bar */}
            <div className="flex flex-col sm:flex-row items-center gap-3">
              {/* Category selector */}
              <div className="w-full sm:w-64">
                <select
                  value={productCategoryFilter}
                  onChange={(e) => setProductCategoryFilter(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs font-semibold focus:outline-hidden focus:ring-1 focus:ring-[#800020] bg-neutral-50"
                >
                  <option value="all">{language === 'bn' ? 'সব ক্যাটাগরির পণ্য' : 'All Categories'}</option>
                  {ALL_MANAGEABLE_CATEGORIES.map(c => (
                    <option key={c.id} value={c.id}>
                      {language === 'bn' ? c.nameBn : c.nameEn}
                    </option>
                  ))}
                </select>
              </div>

              {/* Search input */}
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={language === 'bn' ? 'পণ্যের নাম বা আইডি দিয়ে খুঁজুন...' : 'Search by product title or ID...'}
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-hidden focus:ring-1 focus:ring-[#800020] bg-neutral-50"
                />
              </div>
            </div>

            {/* Product List */}
            <div className="space-y-2 max-h-[550px] overflow-y-auto pr-1 divide-y divide-neutral-100">
              {filteredProductsForOrdering.slice(0, 80).map((product, index) => (
                <div
                  key={product.id}
                  className={`pt-2.5 pb-2.5 px-3 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                    product.isPinnedToTop ? 'bg-amber-50/70 border border-amber-200' : 'hover:bg-neutral-50'
                  }`}
                >
                  {/* Left: Thumbnail & Info */}
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="font-mono text-xs font-black text-neutral-400 w-6 text-center">
                      #{index + 1}
                    </span>

                    <img
                      src={product.image}
                      alt={product.titleEn}
                      className="w-12 h-12 rounded-xl object-cover border border-neutral-200 shrink-0 bg-neutral-100"
                    />

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-xs sm:text-sm font-bold text-neutral-900 truncate max-w-xs sm:max-w-md">
                          {language === 'bn' ? (product.titleBn || product.titleEn) : (product.titleEn || product.titleBn)}
                        </h4>
                        {product.isPinnedToTop && (
                          <span className="bg-amber-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-2xs">
                            📌 {language === 'bn' ? 'শীর্ষে পিন করা' : 'Pinned'}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-500 font-mono mt-0.5">
                        {formatPrice(product.price, language)} · ক্যাটাগরি: {product.category} · স্টক: {product.stock}
                      </p>
                    </div>
                  </div>

                  {/* Right: Ordering controls */}
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    {/* Pin to Top Button */}
                    <button
                      onClick={() => handleTogglePinProduct(product.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                        product.isPinnedToTop
                          ? 'bg-amber-500 text-white hover:bg-amber-600 shadow-xs'
                          : 'bg-white hover:bg-neutral-100 text-neutral-700 border border-neutral-200'
                      }`}
                      title="তালিকায় সবার প্রথমে দেখানোর জন্য পিন করুন"
                    >
                      <Pin className="w-3.5 h-3.5" />
                      <span>{product.isPinnedToTop ? (language === 'bn' ? 'আনপিন' : 'Unpin') : (language === 'bn' ? 'শীর্ষে পিন' : 'Pin #1')}</span>
                    </button>

                    {/* Numeric Order Input */}
                    <div className="flex items-center gap-1">
                      <span className="text-[11px] text-neutral-400 font-semibold">ক্রম:</span>
                      <input
                        type="number"
                        min="1"
                        max="999"
                        value={product.displayOrder || ''}
                        placeholder={String(index + 1)}
                        onChange={(e) => handleSetProductDisplayOrder(product.id, parseInt(e.target.value) || 0)}
                        className="w-14 px-2 py-1 text-xs text-center font-bold border border-neutral-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-[#800020]"
                      />
                    </div>

                    {/* Up / Down buttons */}
                    <button
                      onClick={() => handleMoveProductUp(index)}
                      disabled={index === 0}
                      className={`w-7 h-7 rounded-lg border flex items-center justify-center transition cursor-pointer ${
                        index === 0 ? 'bg-neutral-100 text-neutral-300 border-neutral-200' : 'bg-white hover:bg-neutral-100 text-neutral-700 border-neutral-200'
                      }`}
                      title="উপরে নিন"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => handleMoveProductDown(index)}
                      disabled={index === filteredProductsForOrdering.length - 1}
                      className={`w-7 h-7 rounded-lg border flex items-center justify-center transition cursor-pointer ${
                        index === filteredProductsForOrdering.length - 1 ? 'bg-neutral-100 text-neutral-300 border-neutral-200' : 'bg-white hover:bg-neutral-100 text-neutral-700 border-neutral-200'
                      }`}
                      title="নিচে নিন"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
