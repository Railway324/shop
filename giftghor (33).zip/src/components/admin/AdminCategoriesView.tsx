import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Layers, 
  Sparkles, 
  Check, 
  X, 
  FolderPlus,
  Tag,
  Shirt,
  ShoppingBag,
  Watch,
  Zap,
  Home,
  Baby,
  Bike,
  Package,
  Heart,
  Star,
  Flame,
  Gem,
  Scissors,
  Gift,
  Smile,
  Palette
} from 'lucide-react';
import { Category, Product, Language } from '../../types';

interface AdminCategoriesViewProps {
  categories: Category[];
  products: Product[];
  language: Language;
  onSaveCategory: (category: Category) => Promise<void> | void;
  onDeleteCategory: (categoryId: string) => Promise<void> | void;
  onSelectCategoryFilter?: (categoryId: string) => void;
}

const AVAILABLE_ICONS = [
  { name: 'Sparkles', icon: Sparkles, label: 'Sparkles (Beauty/Glow)' },
  { name: 'Gem', icon: Gem, label: 'Gem (Jewelry/Luxury)' },
  { name: 'Heart', icon: Heart, label: 'Heart (Care/Beauty)' },
  { name: 'Shirt', icon: Shirt, label: 'Shirt (Clothes)' },
  { name: 'ShoppingBag', icon: ShoppingBag, label: 'ShoppingBag (Bags/Fashion)' },
  { name: 'Watch', icon: Watch, label: 'Watch (Timepieces)' },
  { name: 'Zap', icon: Zap, label: 'Zap (Electronics/Gadgets)' },
  { name: 'Home', icon: Home, label: 'Home (Lifestyle/Decor)' },
  { name: 'Baby', icon: Baby, label: 'Baby (Kids Zone)' },
  { name: 'Bike', icon: Bike, label: 'Bike (Accessories)' },
  { name: 'Package', icon: Package, label: 'Package (Combos/Deals)' },
  { name: 'Gift', icon: Gift, label: 'Gift (Presents/Special)' },
  { name: 'Flame', icon: Flame, label: 'Flame (Hot Deals)' },
  { name: 'Star', icon: Star, label: 'Star (Featured)' },
  { name: 'Scissors', icon: Scissors, label: 'Scissors (Styling/Grooming)' },
  { name: 'Palette', icon: Palette, label: 'Palette (Cosmetics/Art)' },
  { name: 'Tag', icon: Tag, label: 'Tag (General)' },
];

const ACCENT_COLORS = [
  { id: 'rose', name: 'Rose', bg: 'bg-rose-500', text: 'text-rose-400', border: 'border-rose-500' },
  { id: 'pink', name: 'Pink', bg: 'bg-pink-500', text: 'text-pink-400', border: 'border-pink-500' },
  { id: 'purple', name: 'Purple', bg: 'bg-purple-500', text: 'text-purple-400', border: 'border-purple-500' },
  { id: 'amber', name: 'Amber', bg: 'bg-amber-500', text: 'text-amber-400', border: 'border-amber-500' },
  { id: 'cyan', name: 'Cyan', bg: 'bg-cyan-500', text: 'text-cyan-400', border: 'border-cyan-500' },
  { id: 'indigo', name: 'Indigo', bg: 'bg-indigo-500', text: 'text-indigo-400', border: 'border-indigo-500' },
  { id: 'emerald', name: 'Emerald', bg: 'bg-emerald-500', text: 'text-emerald-400', border: 'border-emerald-500' },
  { id: 'orange', name: 'Orange', bg: 'bg-orange-500', text: 'text-orange-400', border: 'border-orange-500' },
];

export const AdminCategoriesView: React.FC<AdminCategoriesViewProps> = ({
  categories,
  products,
  language,
  onSaveCategory,
  onDeleteCategory,
  onSelectCategoryFilter,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [formId, setFormId] = useState('');
  const [formNameBn, setFormNameBn] = useState('');
  const [formNameEn, setFormNameEn] = useState('');
  const [formSubtitleBn, setFormSubtitleBn] = useState('');
  const [formSubtitleEn, setFormSubtitleEn] = useState('');
  const [formIconName, setFormIconName] = useState('Sparkles');
  const [formAccentColor, setFormAccentColor] = useState('rose');

  const openCreateModal = () => {
    setEditingCategory(null);
    setFormId('');
    setFormNameBn('');
    setFormNameEn('');
    setFormSubtitleBn('');
    setFormSubtitleEn('');
    setFormIconName('Sparkles');
    setFormAccentColor('rose');
    setIsModalOpen(true);
  };

  const openEditModal = (cat: Category) => {
    setEditingCategory(cat);
    setFormId(cat.id);
    setFormNameBn(cat.nameBn);
    setFormNameEn(cat.nameEn);
    setFormSubtitleBn(cat.subtitleBn || '');
    setFormSubtitleEn(cat.subtitleEn || '');
    setFormIconName(cat.iconName || 'Tag');
    setFormAccentColor(cat.accentColor || 'rose');
    setIsModalOpen(true);
  };

  const handleNameEnChange = (val: string) => {
    setFormNameEn(val);
    if (!editingCategory && !formId) {
      const slug = val
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '');
      setFormId(slug);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNameBn.trim() || !formId.trim()) return;

    setIsSubmitting(true);
    try {
      const cleanId = formId.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-');
      const cleanNameBn = formNameBn.trim();
      const cleanNameEn = formNameEn.trim() || cleanNameBn;

      const categoryData: Category = {
        id: cleanId,
        nameBn: cleanNameBn,
        nameEn: cleanNameEn,
        iconName: formIconName,
        subtitleBn: formSubtitleBn.trim() || undefined,
        subtitleEn: formSubtitleEn.trim() || undefined,
        badgeBn: cleanNameBn,
        badgeEn: cleanNameEn,
        accentColor: formAccentColor,
        itemCount: products.filter(p => p.category === cleanId).length,
        isCustom: editingCategory ? editingCategory.isCustom : true,
      };

      await onSaveCategory(categoryData);
      setIsModalOpen(false);
    } catch (err) {
      console.error('Error saving category:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getIconComponent = (iconName: string) => {
    const found = AVAILABLE_ICONS.find(i => i.name.toLowerCase() === (iconName || '').toLowerCase());
    return found ? found.icon : Tag;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-rose-500/20 to-purple-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">
                {language === 'bn' ? 'ক্যাটাগরি ম্যানেজমেন্ট (Firebase Sync)' : 'Category Management'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                {categories.length} {language === 'bn' ? 'টি ক্যাটাগরি' : 'Categories'}
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              {language === 'bn' 
                ? 'নতুন ক্যাটাগরি তৈরি করুন, নাম ও আইকন পরিবর্তন করুন এবং ফায়ারবেসে রিয়েল-টাইম সংরক্ষণ করুন।' 
                : 'Create new categories, customize names & icons, and sync in real-time with Firebase.'}
            </p>
          </div>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white rounded-2xl text-xs font-black shadow-lg shadow-rose-900/30 transition transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'bn' ? 'নতুন ক্যাটাগরি তৈরি করুন' : 'Create New Category'}</span>
        </button>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((cat) => {
          const IconComp = getIconComponent(cat.iconName);
          const count = products.filter(p => p.status !== 'inactive' && (p.category === cat.id || (cat.id === 'all'))).length;
          const isDefault = cat.id === 'all' || !cat.isCustom;

          return (
            <div
              key={cat.id}
              className="bg-neutral-900/90 border border-neutral-800 hover:border-neutral-700 rounded-3xl p-5 space-y-4 transition shadow-lg group relative overflow-hidden"
            >
              {/* Top Row: Icon & Status */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-neutral-800 border border-neutral-700 flex items-center justify-center text-rose-400 group-hover:scale-110 transition">
                    <IconComp className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{language === 'bn' ? cat.nameBn : cat.nameEn}</span>
                      {cat.isCustom && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          {language === 'bn' ? 'কাস্টম' : 'Custom'}
                        </span>
                      )}
                    </h3>
                    <p className="text-[11px] text-neutral-400 font-mono mt-0.5">
                      id: {cat.id}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {cat.id !== 'all' && (
                    <button
                      onClick={() => openEditModal(cat)}
                      className="p-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-700 transition cursor-pointer"
                      title={language === 'bn' ? 'এডিট করুন' : 'Edit'}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {cat.id !== 'all' && (
                    <button
                      onClick={() => setDeleteConfirmId(cat.id)}
                      className="p-2 rounded-xl bg-neutral-800 text-red-400 hover:text-red-300 hover:bg-red-500/20 transition cursor-pointer"
                      title={language === 'bn' ? 'ডিলিট করুন' : 'Delete'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Subtitle / Description if any */}
              {(cat.subtitleBn || cat.subtitleEn) && (
                <p className="text-xs text-neutral-300 line-clamp-2">
                  {language === 'bn' ? cat.subtitleBn : (cat.subtitleEn || cat.subtitleBn)}
                </p>
              )}

              {/* Stats Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-neutral-800/80 text-xs">
                <div className="flex items-center gap-1.5 text-neutral-400">
                  <Package className="w-3.5 h-3.5 text-neutral-500" />
                  <span>
                    <strong className="text-white font-mono">{count}</strong> {language === 'bn' ? 'টি পণ্য' : 'products'}
                  </span>
                </div>

                {onSelectCategoryFilter && cat.id !== 'all' && (
                  <button
                    onClick={() => onSelectCategoryFilter(cat.id)}
                    className="text-rose-400 hover:text-rose-300 font-bold text-[11px] underline cursor-pointer"
                  >
                    {language === 'bn' ? 'পণ্য দেখুন →' : 'View Items →'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Create / Edit Category Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 max-w-lg w-full rounded-3xl p-6 space-y-5 shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center shadow-xs">
                  <FolderPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-neutral-900">
                    {editingCategory 
                      ? (language === 'bn' ? 'ক্যাটাগরি এডিট করুন' : 'Edit Category')
                      : (language === 'bn' ? 'নতুন ক্যাটাগরি তৈরি করুন' : 'Create New Category')}
                  </h3>
                  <p className="text-[11px] text-neutral-500">
                    {language === 'bn' ? 'ক্যাটাগরির নাম, আইকন ও স্লাগ নির্ধারণ করুন' : 'Configure name, icon & category slug'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
              {/* Category Name Bn */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {language === 'bn' ? '১. ক্যাটাগরির নাম (বাংলা)' : '1. Category Name (Bengali)'} *
                </label>
                <input
                  type="text"
                  required
                  value={formNameBn}
                  onChange={(e) => setFormNameBn(e.target.value)}
                  placeholder="যেমন: বিউটি ও স্কিনকেয়ার, জুয়েলারি, শুজ..."
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none shadow-2xs"
                />
              </div>

              {/* Category Name En */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-600">
                  {language === 'bn' ? '২. ক্যাটাগরির নাম (ইংরেজি)' : '2. Category Name (English)'}
                </label>
                <input
                  type="text"
                  value={formNameEn}
                  onChange={(e) => handleNameEnChange(e.target.value)}
                  placeholder="e.g. Beauty & Skincare / Jewelry / Shoes"
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none shadow-2xs"
                />
              </div>

              {/* Category ID (Slug) */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800 flex items-center justify-between">
                  <span>{language === 'bn' ? '৩. ক্যাটাগরি আইডি (Slug / Identifier)' : '3. Category ID (Slug)'} *</span>
                  <span className="text-[10px] text-neutral-400 font-mono">lowercase, no spaces</span>
                </label>
                <input
                  type="text"
                  required
                  disabled={!!editingCategory}
                  value={formId}
                  onChange={(e) => setFormId(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, '-'))}
                  placeholder="beauty-skincare"
                  className="w-full px-3.5 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xl text-xs text-neutral-900 font-mono focus:border-rose-500 outline-none disabled:opacity-60 shadow-2xs"
                />
              </div>

              {/* Icon Selector */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {language === 'bn' ? '৪. আইকন নির্বাচন করুন' : '4. Select Icon'}
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 p-3 bg-neutral-50 border border-neutral-200 rounded-2xl max-h-40 overflow-y-auto">
                  {AVAILABLE_ICONS.map((item) => {
                    const Icon = item.icon;
                    const isSelected = formIconName.toLowerCase() === item.name.toLowerCase();
                    return (
                      <button
                        type="button"
                        key={item.name}
                        onClick={() => setFormIconName(item.name)}
                        className={`flex flex-col items-center justify-center p-2 rounded-xl transition cursor-pointer border ${
                          isSelected
                            ? 'bg-rose-50 border-rose-500 text-rose-600 font-bold shadow-xs'
                            : 'bg-white border-neutral-200 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                        }`}
                        title={item.label}
                      >
                        <Icon className="w-5 h-5 mb-1" />
                        <span className="text-[9px] truncate w-full text-center">{item.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Accent Color */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {language === 'bn' ? '৫. হাইলাইট কালার (Accent Color)' : '5. Accent Color'}
                </label>
                <div className="flex items-center gap-2 flex-wrap">
                  {ACCENT_COLORS.map(c => (
                    <button
                      type="button"
                      key={c.id}
                      onClick={() => setFormAccentColor(c.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border ${
                        formAccentColor === c.id
                          ? 'border-neutral-900 text-neutral-900 bg-neutral-100 shadow-xs ring-1 ring-neutral-400'
                          : 'border-neutral-200 text-neutral-600 bg-white hover:bg-neutral-50'
                      }`}
                    >
                      <span className={`w-3 h-3 rounded-full ${c.bg}`} />
                      <span>{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Subtitle / Short Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {language === 'bn' ? '৬. সংক্ষিপ্ত বিবরণ / সাবটাইটেল (বাংলা)' : '6. Subtitle (Bengali)'}
                </label>
                <input
                  type="text"
                  value={formSubtitleBn}
                  onChange={(e) => setFormSubtitleBn(e.target.value)}
                  placeholder="যেমন: প্রিমিয়াম কোরিয়ান স্কিনকেয়ার ও গ্লোয়িং কম্বো প্যাক"
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none shadow-2xs"
                />
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-neutral-600 hover:text-neutral-900 bg-neutral-100 hover:bg-neutral-200 transition cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-black text-white bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 transition shadow-md shadow-rose-600/20 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>{language === 'bn' ? 'সংরক্ষণ হচ্ছে...' : 'Saving...'}</span>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{editingCategory ? (language === 'bn' ? 'আপডেট করুন' : 'Update') : (language === 'bn' ? 'ক্যাটাগরি তৈরি করুন' : 'Create Category')}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 max-w-sm w-full rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-200 flex items-center justify-center mx-auto shadow-2xs">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-neutral-900">
                {language === 'bn' ? 'ক্যাটাগরি ডিলিট করবেন?' : 'Delete Category?'}
              </h4>
              <p className="text-xs text-neutral-500 mt-1">
                {language === 'bn' 
                  ? 'এই ক্যাটাগরি ফায়ারবেস ডেটাবেস থেকে মুছে ফেলা হবে। এর ভেতরের পণ্যগুলো সুরক্ষিত থাকবে।' 
                  : 'This category will be removed from Firebase. Products will remain safe.'}
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-neutral-100 hover:bg-neutral-200 text-neutral-700 cursor-pointer transition"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={async () => {
                  if (onDeleteCategory && deleteConfirmId) {
                    await onDeleteCategory(deleteConfirmId);
                  }
                  setDeleteConfirmId(null);
                }}
                className="px-4 py-2.5 rounded-xl text-xs font-black bg-red-600 hover:bg-red-500 text-white cursor-pointer shadow-md shadow-red-600/20 transition"
              >
                {language === 'bn' ? 'হ্যাঁ, ডিলিট করুন' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
