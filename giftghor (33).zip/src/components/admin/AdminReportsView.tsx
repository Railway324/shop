import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Download, 
  Printer, 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Package, 
  Users, 
  Calendar, 
  Layers,
  ArrowUpRight
} from 'lucide-react';
import { Order, Product, Language, Customer } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';
import { safeParseDate, safeDateToISODate } from '../../utils/dateUtils';

interface AdminReportsViewProps {
  orders?: Order[];
  products?: Product[];
  customers?: Customer[];
  language: Language;
}

export const AdminReportsView: React.FC<AdminReportsViewProps> = ({
  orders = [],
  products = [],
  customers = [],
  language,
}) => {
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');

  // Calculate Metrics based on reportPeriod
  const periodOrders = useMemo(() => {
    const now = new Date();
    return orders.filter(o => {
      if (o.orderStatus === 'cancelled') return false;
      const d = safeParseDate(o.date);
      if (reportPeriod === 'daily') {
        return d.toDateString() === now.toDateString();
      }
      if (reportPeriod === 'weekly') {
        const past7 = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return d >= past7;
      }
      if (reportPeriod === 'monthly') {
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      }
      if (reportPeriod === 'yearly') {
        return d.getFullYear() === now.getFullYear();
      }
      return true;
    });
  }, [orders, reportPeriod]);

  const totalRevenue = useMemo(() => periodOrders.reduce((s, o) => s + (Number(o.total) || 0), 0), [periodOrders]);
  const totalOrdersCount = periodOrders.length;
  const avgOrderValue = totalOrdersCount > 0 ? Math.round(totalRevenue / totalOrdersCount) : 0;

  // Category Distribution
  const categoryStats = useMemo(() => {
    const catMap: Record<string, { count: number; revenue: number }> = {};
    periodOrders.forEach(o => {
      if (!Array.isArray(o?.items)) return;
      o.items.forEach(item => {
        if (!item?.product) return;
        const cat = item.product.category || 'other';
        if (!catMap[cat]) catMap[cat] = { count: 0, revenue: 0 };
        const qty = Number(item.quantity) || 1;
        const price = typeof item.product.price === 'number' ? item.product.price : (Number(item.product.price) || 0);
        catMap[cat].count += qty;
        catMap[cat].revenue += qty * price;
      });
    });
    return Object.entries(catMap).map(([category, data]) => ({
      category,
      ...data
    })).sort((a, b) => b.revenue - a.revenue);
  }, [periodOrders]);

  // Top Products
  const topProducts = useMemo(() => {
    const prodMap: Record<string, { name: string; quantity: number; revenue: number }> = {};
    periodOrders.forEach(o => {
      if (!Array.isArray(o?.items)) return;
      o.items.forEach(item => {
        if (!item?.product) return;
        const name = item.product.titleEn || item.product.titleBn || 'Product';
        if (!prodMap[name]) prodMap[name] = { name, quantity: 0, revenue: 0 };
        const qty = Number(item.quantity) || 1;
        const price = typeof item.product.price === 'number' ? item.product.price : (Number(item.product.price) || 0);
        prodMap[name].quantity += qty;
        prodMap[name].revenue += qty * price;
      });
    });
    return Object.values(prodMap).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  }, [periodOrders]);

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['Order ID', 'Date', 'Customer Name', 'Phone', 'Payment Method', 'Payment Status', 'Order Status', 'Total (BDT)'];
    const rows = periodOrders.map(o => [
      o.id,
      safeDateToISODate(o.date),
      `"${String(o.customerName || '').replace(/"/g, '""')}"`,
      `"${String(o.phone || '')}"`,
      o.paymentMethod || 'cod',
      o.paymentStatus || 'pending',
      o.orderStatus || 'pending',
      Number(o.total) || 0
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sales_report_${reportPeriod}_${safeDateToISODate(new Date())}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'সেলস রিপোর্ট ও ব্যবসায়িক অ্যানালিটিক্স' : 'Executive Business Analytics'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'দৈনিক, সাপ্তাহিক ও মাসিক রাজস্ব বিশ্লেষণ, ক্যাটাগরি পারফরম্যান্স এবং স্প্রেডশিট এক্সপোর্ট।' 
              : 'Detailed revenue breakdowns, category distribution and CSV spreadsheet export.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-4 py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold flex items-center gap-2 border border-neutral-700 transition cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Period Filter Tabs */}
      <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 p-2 rounded-2xl">
        {[
          { id: 'daily', labelBn: 'আজকের রিপোর্ট', labelEn: 'Today (Daily)' },
          { id: 'weekly', labelBn: 'গত ৭ দিন', labelEn: 'Weekly (7 Days)' },
          { id: 'monthly', labelBn: 'চলতি মাস', labelEn: 'Monthly (This Month)' },
          { id: 'yearly', labelBn: 'বার্ষিক রিপোর্ট', labelEn: 'Yearly (2026)' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setReportPeriod(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              reportPeriod === tab.id 
                ? 'bg-rose-600 text-white shadow-md shadow-rose-950/40' 
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
            }`}
          >
            {language === 'bn' ? tab.labelBn : tab.labelEn}
          </button>
        ))}
      </div>

      {/* Key Aggregate Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400">Total Net Revenue</span>
            <DollarSign className="w-5 h-5 text-emerald-400" />
          </div>
          <h3 className="text-2xl font-black text-white mt-2">
            {formatPrice(totalRevenue, language)}
          </h3>
          <p className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>Active transactions only</span>
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400">Total Orders Placed</span>
            <ShoppingBag className="w-5 h-5 text-purple-400" />
          </div>
          <h3 className="text-2xl font-black text-white mt-2">
            {language === 'bn' ? toBengaliNumber(totalOrdersCount) : totalOrdersCount} Orders
          </h3>
          <p className="text-[10px] text-neutral-400 mt-1">
            Period order volume
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400">Average Order Value (AOV)</span>
            <ArrowUpRight className="w-5 h-5 text-rose-400" />
          </div>
          <h3 className="text-2xl font-black text-white mt-2">
            {formatPrice(avgOrderValue, language)}
          </h3>
          <p className="text-[10px] text-neutral-400 mt-1">
            Mean customer transaction
          </p>
        </div>
      </div>

      {/* Category Distribution & Top Selling Products */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-rose-400" />
            <span>Revenue by Product Category</span>
          </h3>

          <div className="space-y-3 pt-2">
            {categoryStats.length === 0 ? (
              <p className="text-xs text-neutral-500 text-center py-6">No sales in this period.</p>
            ) : (
              categoryStats.map(cat => {
                const percent = totalRevenue > 0 ? Math.round((cat.revenue / totalRevenue) * 100) : 0;
                return (
                  <div key={cat.category} className="space-y-1.5">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="capitalize text-neutral-200">{cat.category}</span>
                      <span className="text-white">{formatPrice(cat.revenue, language)} ({percent}%)</span>
                    </div>
                    <div className="w-full bg-neutral-950 h-2.5 rounded-full overflow-hidden">
                      <div 
                        style={{ width: `${percent}%` }}
                        className="h-full bg-gradient-to-r from-rose-600 to-red-500 rounded-full"
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Top Product Performers */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Package className="w-4 h-4 text-amber-400" />
            <span>Top Performing Items</span>
          </h3>

          <div className="space-y-2.5 pt-2">
            {topProducts.length === 0 ? (
              <p className="text-xs text-neutral-500 text-center py-6">No product sales in this period.</p>
            ) : (
              topProducts.map((p, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-xs">
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <span className="w-5 h-5 rounded-lg bg-neutral-800 font-bold text-[10px] text-neutral-400 flex items-center justify-center shrink-0">
                      #{idx + 1}
                    </span>
                    <span className="font-bold text-neutral-200 truncate">{p.name}</span>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-black text-emerald-400">{formatPrice(p.revenue, language)}</p>
                    <p className="text-[10px] text-neutral-500">{p.quantity} units</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
