import React, { useState, useEffect } from 'react';
import { 
  X, 
  Activity, 
  Database, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  ShieldCheck, 
  UserCheck, 
  Clock, 
  Layers, 
  Copy, 
  Check, 
  Send,
  Radio,
  Server
} from 'lucide-react';
import { 
  auth, 
  firebaseConfig, 
  isUserAdmin, 
  liveDiagnosticState, 
  saveOrderToFirestore,
  getAllOrdersFromFirestore
} from '../../lib/firebase';
import { Language, UserProfile, Order } from '../../types';

interface FirebaseDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  currentUserProfile?: UserProfile | null;
  orders: Order[];
  onRefreshOrders?: () => void;
}

export const FirebaseDiagnosticsModal: React.FC<FirebaseDiagnosticsModalProps> = ({
  isOpen,
  onClose,
  language,
  currentUserProfile,
  orders,
  onRefreshOrders,
}) => {
  const [copiedRules, setCopiedRules] = useState(false);
  const [testResult, setTestResult] = useState<{ status: 'idle' | 'loading' | 'success' | 'error'; message: string }>({
    status: 'idle',
    message: ''
  });
  const [lastRefreshedAt, setLastRefreshedAt] = useState<string>(new Date().toLocaleTimeString());

  if (!isOpen) return null;

  const currentAuthUser = auth.currentUser;
  const currentEmail = currentAuthUser?.email || currentUserProfile?.email || 'unauthenticated';
  const currentUid = currentAuthUser?.uid || currentUserProfile?.uid || 'guest-session';
  const isSuperAdmin = isUserAdmin(currentUserProfile, currentEmail);

  const handleCopyRules = () => {
    const rulesText = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}`;
    navigator.clipboard.writeText(rulesText);
    setCopiedRules(true);
    setTimeout(() => setCopiedRules(false), 2000);
  };

  const handleTestProbe = async () => {
    setTestResult({ status: 'loading', message: 'Testing Firestore & Real-Time Sync...' });
    try {
      const probeId = `PROBE-${Date.now().toString().slice(-6)}`;
      const probeOrder: Order = {
        id: probeId,
        orderId: probeId,
        userId: currentUid,
        customerName: 'Diagnostic Probe Test',
        phone: '01700000000',
        address: 'Dhaka, Bangladesh',
        date: new Date().toISOString().split('T')[0],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        items: [],
        subtotal: 100,
        deliveryFee: 60,
        discount: 0,
        total: 160,
        paymentMethod: 'cod',
        paymentStatus: 'pending',
        orderStatus: 'pending'
      };

      await saveOrderToFirestore(probeOrder);
      if (onRefreshOrders) {
        onRefreshOrders();
      }
      setLastRefreshedAt(new Date().toLocaleTimeString());
      setTestResult({
        status: 'success',
        message: `Success! Probe order (${probeId}) synced to Firestore & Server API successfully.`
      });
    } catch (err: any) {
      setTestResult({
        status: 'error',
        message: `Probe failed: ${err.message || 'Network / Permission error'}`
      });
    }
  };

  const latestOrder = orders.length > 0 ? orders[0] : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div 
        className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden text-neutral-100 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Firebase Real-Time Diagnostic Hub
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Live Sync
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Single Source of Truth Multi-Browser Verification
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 divide-y divide-neutral-800/80">
          {/* Grid of Diagnostic Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {/* Project ID */}
            <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="flex items-center gap-2 text-neutral-400 text-xs mb-1">
                <Database className="w-3.5 h-3.5 text-amber-400" />
                <span>Firebase Project ID</span>
              </div>
              <p className="font-mono text-sm font-semibold text-white truncate">
                {firebaseConfig.projectId}
              </p>
              <p className="text-[11px] text-neutral-500 mt-0.5">
                Auth Domain: {firebaseConfig.authDomain}
              </p>
            </div>

            {/* Current Auth User */}
            <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="flex items-center gap-2 text-neutral-400 text-xs mb-1">
                <UserCheck className="w-3.5 h-3.5 text-blue-400" />
                <span>Current Auth User & UID</span>
              </div>
              <p className="font-medium text-sm text-white truncate">
                {currentEmail}
              </p>
              <p className="font-mono text-[10px] text-neutral-500 mt-0.5 truncate">
                UID: {currentUid}
              </p>
            </div>

            {/* Admin Role Status */}
            <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="flex items-center gap-2 text-neutral-400 text-xs mb-1">
                <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
                <span>Admin Access Authority</span>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 text-xs font-semibold rounded-md border ${
                  isSuperAdmin 
                    ? 'bg-rose-500/15 text-rose-300 border-rose-500/40'
                    : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                }`}>
                  {isSuperAdmin ? 'Authorized Super Admin' : 'Customer Account / Guest'}
                </span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">
                Primary Super Admins: rmd474915@gmail.com, winlucky414@gmail.com
              </p>
            </div>

            {/* Firestore Connection & Listener */}
            <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="flex items-center gap-2 text-neutral-400 text-xs mb-1">
                <Radio className="w-3.5 h-3.5 text-emerald-400" />
                <span>Firestore Listener & Connection</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-semibold text-emerald-300">
                  {liveDiagnosticState.listenerStatus.toUpperCase()} (WebSocket onSnapshot)
                </span>
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">
                Sync Engine: Firestore Realtime + Dual-Channel Auto-Refresh
              </p>
            </div>

            {/* Orders Collection Count */}
            <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="flex items-center gap-2 text-neutral-400 text-xs mb-1">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                <span>Orders In Memory / Synced</span>
              </div>
              <p className="text-xl font-bold text-white">
                {orders.length} <span className="text-xs font-normal text-neutral-400">Total Orders</span>
              </p>
              <p className="text-[11px] text-neutral-500 mt-0.5">
                Last Synced: {new Date(liveDiagnosticState.lastSyncTime).toLocaleTimeString()}
              </p>
            </div>

            {/* Latest Order Details */}
            <div className="p-3.5 rounded-xl bg-neutral-950/60 border border-neutral-800">
              <div className="flex items-center gap-2 text-neutral-400 text-xs mb-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Latest Order In Sync</span>
              </div>
              {latestOrder ? (
                <div>
                  <p className="text-xs font-mono font-semibold text-amber-300 truncate">
                    {latestOrder.id} - {latestOrder.customerName}
                  </p>
                  <p className="text-[11px] text-neutral-400 mt-0.5">
                    Status: <span className="text-white capitalize">{latestOrder.orderStatus}</span> | ৳{latestOrder.total}
                  </p>
                </div>
              ) : (
                <p className="text-xs text-neutral-500">No orders recorded yet</p>
              )}
            </div>
          </div>

          {/* Real-Time Probe Test Action */}
          <div className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
                Multi-Browser Synchronization Test
              </h3>
              <button
                onClick={handleTestProbe}
                disabled={testResult.status === 'loading'}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-50"
              >
                <Send className={`w-3.5 h-3.5 ${testResult.status === 'loading' ? 'animate-spin' : ''}`} />
                {testResult.status === 'loading' ? 'Testing...' : 'Send Test Order Ping'}
              </button>
            </div>

            {testResult.message && (
              <div className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
                testResult.status === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : testResult.status === 'error'
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  : 'bg-neutral-800 border-neutral-700 text-neutral-300'
              }`}>
                {testResult.status === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                ) : testResult.status === 'error' ? (
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                ) : (
                  <RefreshCw className="w-4 h-4 shrink-0 animate-spin text-amber-400 mt-0.5" />
                )}
                <span>{testResult.message}</span>
              </div>
            )}
          </div>

          {/* Firestore Security Rules Guide */}
          <div className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Recommended Firebase Console Rules
              </h3>
              <button
                onClick={handleCopyRules}
                className="px-2.5 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-[11px] font-medium text-neutral-300 flex items-center gap-1.5 transition-colors border border-neutral-700"
              >
                {copiedRules ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copy Rules
                  </>
                )}
              </button>
            </div>
            <p className="text-[11px] text-neutral-400 mb-2">
              If your external Firebase Console has custom restrictions, paste this in <strong>Firebase Console &gt; Firestore Database &gt; Rules</strong>:
            </p>
            <pre className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-[11px] font-mono text-amber-200/90 overflow-x-auto">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}`}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-neutral-800 bg-neutral-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <Server className="w-3.5 h-3.5 text-neutral-500" />
            <span>Dual Sync Engine Active</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (onRefreshOrders) onRefreshOrders();
                setLastRefreshedAt(new Date().toLocaleTimeString());
              }}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 border border-neutral-700 transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Force Refresh Now
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-neutral-700 hover:bg-neutral-600 text-xs font-semibold text-white transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
