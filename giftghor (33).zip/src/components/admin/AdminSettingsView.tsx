import React, { useState } from 'react';
import { 
  Settings, 
  Save, 
  Check, 
  Store, 
  Mail, 
  Phone, 
  MapPin, 
  Percent, 
  Globe, 
  AlertTriangle,
  Share2
} from 'lucide-react';
import { StoreSettings, Language } from '../../types';

interface AdminSettingsViewProps {
  settings: StoreSettings;
  language: Language;
  onSaveSettings: (settings: StoreSettings) => void;
}

export const AdminSettingsView: React.FC<AdminSettingsViewProps> = ({
  settings,
  language,
  onSaveSettings,
}) => {
  const [storeNameBn, setStoreNameBn] = useState(settings.storeNameBn);
  const [storeNameEn, setStoreNameEn] = useState(settings.storeNameEn);
  const [taglineBn, setTaglineBn] = useState(settings.taglineBn);
  const [taglineEn, setTaglineEn] = useState(settings.taglineEn);
  const [email, setEmail] = useState(settings.email);
  const [phone, setPhone] = useState(settings.phone);
  const [address, setAddress] = useState(settings.address);
  const [currency, setCurrency] = useState(settings.currency);
  const [taxRate, setTaxRate] = useState(String(settings.taxRate || 0));
  const [maintenanceMode, setMaintenanceMode] = useState(settings.maintenanceMode);
  const [allowGuestCheckout, setAllowGuestCheckout] = useState(settings.allowGuestCheckout);
  const [facebook, setFacebook] = useState(settings.socialLinks?.facebook || 'https://facebook.com');
  const [instagram, setInstagram] = useState(settings.socialLinks?.instagram || 'https://instagram.com');
  const [whatsapp, setWhatsapp] = useState(settings.socialLinks?.whatsapp || '+8801888888888');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: StoreSettings = {
      storeNameBn,
      storeNameEn,
      taglineBn,
      taglineEn,
      email,
      phone,
      address,
      currency,
      taxRate: Number(taxRate) || 0,
      maintenanceMode,
      allowGuestCheckout,
      socialLinks: {
        facebook,
        instagram,
        whatsapp,
      }
    };
    onSaveSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Settings className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'ওয়েবসাইট ও স্টোর সাধারণ সেটিংস' : 'General Store & Branding Settings'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'দোকানের নাম, যোগাযোগ নম্বর, ঠিকানা, ভ্যাট রেট এবং সোশ্যাল লিঙ্ক কনফিগার করুন।' 
              : 'Configure company identity, customer support channels, currency and checkout preferences.'}
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold animate-fadeIn">
            <Check className="w-4 h-4" />
            <span>Settings Saved!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Brand Information */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Store className="w-4 h-4 text-rose-400" />
            <span>Brand Identity</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-neutral-300 font-bold">Store Name (English):</label>
              <input
                type="text"
                value={storeNameEn}
                onChange={(e) => setStoreNameEn(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="text-neutral-300 font-bold">Store Name (Bengali):</label>
              <input
                type="text"
                value={storeNameBn}
                onChange={(e) => setStoreNameBn(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="text-neutral-300">Tagline / Slogan (English):</label>
              <input
                type="text"
                value={taglineEn}
                onChange={(e) => setTaglineEn(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>

            <div>
              <label className="text-neutral-300">Tagline / Slogan (Bengali):</label>
              <input
                type="text"
                value={taglineBn}
                onChange={(e) => setTaglineBn(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Contact & Physical Address */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Mail className="w-4 h-4 text-rose-400" />
            <span>Support & Operations Contact</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-neutral-300 font-bold">Customer Helpline / Phone:</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>

            <div>
              <label className="text-neutral-300 font-bold">Official Support Email:</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="text-neutral-300 font-bold">Physical Store / Warehouse Address:</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Currency & Policies */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Percent className="w-4 h-4 text-rose-400" />
            <span>Commerce & Checkout Logic</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-neutral-300 font-bold">Currency Symbol:</label>
              <input
                type="text"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>

            <div>
              <label className="text-neutral-300">Estimated VAT / Tax Rate (%):</label>
              <input
                type="number"
                value={taxRate}
                onChange={(e) => setTaxRate(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-neutral-200">
              <input
                type="checkbox"
                checked={allowGuestCheckout}
                onChange={(e) => setAllowGuestCheckout(e.target.checked)}
                className="w-4 h-4 accent-rose-600 rounded"
              />
              <span>Allow Instant Guest Checkout (Without Login)</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-amber-400">
              <input
                type="checkbox"
                checked={maintenanceMode}
                onChange={(e) => setMaintenanceMode(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded"
              />
              <span>Maintenance Mode (Temporarily Pause New Orders)</span>
            </label>
          </div>
        </div>

        {/* Social Media Links */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Share2 className="w-4 h-4 text-rose-400" />
            <span>Official Social Handles</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="text-neutral-300">Facebook Page URL:</label>
              <input
                type="text"
                value={facebook}
                onChange={(e) => setFacebook(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>

            <div>
              <label className="text-neutral-300">Instagram Handle / URL:</label>
              <input
                type="text"
                value={instagram}
                onChange={(e) => setInstagram(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>

            <div>
              <label className="text-neutral-300">WhatsApp Order Chat Number:</label>
              <input
                type="text"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white mt-1 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Store Configuration</span>
          </button>
        </div>
      </form>
    </div>
  );
};
