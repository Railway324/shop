import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Boxes, 
  ShoppingBag, 
  Users, 
  CreditCard, 
  TicketPercent, 
  BarChart3, 
  Truck, 
  MessageSquare, 
  Image as ImageIcon, 
  ShieldCheck, 
  History, 
  Settings, 
  Search as SearchIcon, 
  Bell, 
  Menu, 
  X, 
  ExternalLink, 
  LogOut, 
  Globe, 
  ChevronRight, 
  UserCheck, 
  Sparkles,
  AlertTriangle,
  Lock,
  ChevronDown,
  Palette,
  CloudUpload,
  Sliders,
  Layers
} from 'lucide-react';
import { Language, AdminRole, AdminUser, UserProfile, AdminNotification, AdminTab } from '../../types';
import { toBengaliNumber } from '../../utils/translations';

interface AdminLayoutProps {
  activeTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  language: Language;
  currentUserProfile?: UserProfile | null;
  currentAdminUser?: AdminUser | null;
  notifications?: AdminNotification[];
  unreadNotificationsCount?: number;
  onOpenNotifications: () => void;
  onOpenDiagnostics?: () => void;
  onOpenLivePublish?: () => void;
  onBackToShop: () => void;
  onLogout?: () => void;
  children: React.ReactNode;
}

// Role Permissions Matrix
export const ROLE_PERMISSIONS: Record<AdminRole, AdminTab[]> = {
  super_admin: [
    'dashboard', 'appearance', 'aiMerchandiser', 'categories', 'products', 'inventory', 'orders', 'customers', 
    'payments', 'coupons', 'reports', 'delivery', 'reviews', 
    'banners', 'users', 'activity', 'settings', 'seo'
  ],
  product_manager: [
    'dashboard', 'aiMerchandiser', 'categories', 'products', 'inventory', 'reviews', 'banners', 'seo'
  ],
  order_manager: [
    'dashboard', 'orders', 'inventory', 'delivery', 'payments', 'customers'
  ],
  customer_support: [
    'dashboard', 'orders', 'customers', 'reviews'
  ],
  marketing_manager: [
    'dashboard', 'appearance', 'aiMerchandiser', 'categories', 'coupons', 'banners', 'reports', 'reviews', 'seo'
  ]
};

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  activeTab,
  onSelectTab,
  language,
  currentUserProfile,
  currentAdminUser,
  notifications = [],
  unreadNotificationsCount,
  onOpenNotifications,
  onOpenDiagnostics,
  onOpenLivePublish,
  onBackToShop,
  onLogout,
  children,
}) => {
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const role: AdminRole = currentAdminUser?.role || 'super_admin';
  const permittedTabs = ROLE_PERMISSIONS[role] || ROLE_PERMISSIONS.super_admin;

  const notifList = Array.isArray(notifications) ? notifications : [];
  const unreadNotifCount = typeof unreadNotificationsCount === 'number' 
    ? unreadNotificationsCount 
    : notifList.filter(n => !n.isRead && !n.read).length;

  const navigationGroups = [
    {
      titleBn: 'মূল ড্যাশবোর্ড',
      titleEn: 'Core Dashboard',
      items: [
        { id: 'dashboard' as AdminTab, nameBn: 'ওভারভিউ ড্যাশবোর্ড', nameEn: 'Dashboard Overview', icon: LayoutDashboard },
        { id: 'reports' as AdminTab, nameBn: 'সেলস ও রিপোর্টস', nameEn: 'Sales & Reports', icon: BarChart3 },
      ]
    },
    {
      titleBn: 'ই-কমার্স অপারেশন',
      titleEn: 'Commerce Operations',
      items: [
        { id: 'orders' as AdminTab, nameBn: 'অর্ডার ম্যানেজমেন্ট', nameEn: 'Orders Management', icon: ShoppingBag, badge: 'Live' },
        { id: 'categories' as AdminTab, nameBn: 'ক্যাটাগরি তৈরি ও পরিচালনা', nameEn: 'Category Management', icon: Layers, badge: 'Firebase' },
        { id: 'products' as AdminTab, nameBn: 'পণ্য পরিচালনা', nameEn: 'Product Catalog', icon: Package },
        { id: 'inventory' as AdminTab, nameBn: 'ইনভেন্টরি ও স্টক', nameEn: 'Inventory & Stock', icon: Boxes },
        { id: 'customers' as AdminTab, nameBn: 'গ্রাহক তালিকা', nameEn: 'Customers Directory', icon: Users },
        { id: 'payments' as AdminTab, nameBn: 'পেমেন্ট ভেরিফিকেশন', nameEn: 'Payments & MFS', icon: CreditCard },
      ]
    },
    {
      titleBn: 'মার্কেটিং ও গ্রোথ',
      titleEn: 'Marketing & Growth',
      items: [
        { id: 'aiMerchandiser' as AdminTab, nameBn: 'ক্যাটাগরি ও পণ্য সাজানো', nameEn: 'Category & Product Ordering', icon: Sliders, badge: 'কাস্টম ক্রম' },
        { id: 'appearance' as AdminTab, nameBn: 'ডিজাইন ও কন্টেন্ট স্টুডিও', nameEn: 'Design & Content Studio', icon: Palette, badge: 'Full Control' },
        { id: 'coupons' as AdminTab, nameBn: 'কুপন ও ডিসকাউন্ট', nameEn: 'Coupons & Promo', icon: TicketPercent },
        { id: 'banners' as AdminTab, nameBn: 'ব্যানার ও হোমপেজ', nameEn: 'Banners & Home', icon: ImageIcon },
        { id: 'reviews' as AdminTab, nameBn: 'রিভিউ মডারেশন', nameEn: 'Product Reviews', icon: MessageSquare },
        { id: 'seo' as AdminTab, nameBn: 'এসইও ম্যানেজমেন্ট', nameEn: 'SEO Settings', icon: Globe },
      ]
    },
    {
      titleBn: 'সিস্টেম ও কনফিগারেশন',
      titleEn: 'System & Config',
      items: [
        { id: 'delivery' as AdminTab, nameBn: 'ডেলিভারি সেটিংস', nameEn: 'Delivery & Courier', icon: Truck },
        { id: 'users' as AdminTab, nameBn: 'এডমিন ও রোলস', nameEn: 'Admin Users & Roles', icon: ShieldCheck },
        { id: 'activity' as AdminTab, nameBn: 'অ্যাক্টিভিটি লগ', nameEn: 'Audit Activity Log', icon: History },
        { id: 'settings' as AdminTab, nameBn: 'ওয়েবসাইট সেটিংস', nameEn: 'Website Settings', icon: Settings },
      ]
    }
  ];

  const getRoleBadge = (r: AdminRole) => {
    switch (r) {
      case 'super_admin':
        return { label: 'Super Admin', color: 'bg-rose-500/15 text-rose-400 border-rose-500/30' };
      case 'product_manager':
        return { label: 'Product Lead', color: 'bg-blue-500/15 text-blue-400 border-blue-500/30' };
      case 'order_manager':
        return { label: 'Order Dispatcher', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' };
      case 'customer_support':
        return { label: 'Customer Support', color: 'bg-amber-500/15 text-amber-400 border-amber-500/30' };
      case 'marketing_manager':
        return { label: 'Marketing Lead', color: 'bg-purple-500/15 text-purple-400 border-purple-500/30' };
      default:
        return { label: 'Manager', color: 'bg-neutral-500/15 text-neutral-400 border-neutral-500/30' };
    }
  };

  const roleInfo = getRoleBadge(role);

  return (
    <div className="min-h-screen bg-white text-neutral-900 flex flex-col font-sans selection:bg-rose-500 selection:text-white">
      {/* Mobile Drawer Backdrop */}
      {isMobileDrawerOpen && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden animate-fadeIn"
          onClick={() => setIsMobileDrawerOpen(false)}
        />
      )}

      {/* Main Flex Wrapper */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop & Mobile Sidebar */}
        <aside className={`
          fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white border-r border-neutral-200 flex flex-col
          transition-transform duration-300 ease-in-out shadow-xs
          ${isMobileDrawerOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}>
          {/* Brand Header */}
          <div className="h-16 px-5 flex items-center justify-between border-b border-neutral-200 bg-white">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full overflow-hidden ring-1 ring-orange-400 bg-white flex items-center justify-center shrink-0">
                <img src="/logo.png?v=20260924_2" alt="Happy Shopping" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="font-black text-sm tracking-tight text-neutral-900">Happy Shopping</h1>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-neutral-100 text-orange-700 border border-neutral-200">PRO</span>
                </div>
                <p className="text-[10px] text-neutral-500 font-medium">Enterprise Control Hub</p>
              </div>
            </div>
            <button 
              onClick={() => setIsMobileDrawerOpen(false)}
              className="lg:hidden p-1.5 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Current Admin Role Pill */}
          <div className="px-4 py-3 border-b border-neutral-200 bg-neutral-50/60">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-white border border-neutral-200 flex items-center justify-center text-neutral-700 shadow-2xs">
                  <ShieldCheck className="w-4 h-4 text-rose-600" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-xs font-bold text-neutral-900 truncate">{currentUserProfile?.displayName || 'Admin Manager'}</p>
                  <span className={`inline-block px-1.5 py-0.2 text-[9px] font-bold rounded border ${roleInfo.color}`}>
                    {roleInfo.label}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Links (Scrollable) */}
          <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5 custom-scrollbar">
            {navigationGroups.map((group, gIdx) => {
              const visibleItems = group.items.filter(item => permittedTabs.includes(item.id));
              if (visibleItems.length === 0) return null;

              return (
                <div key={gIdx} className="space-y-1">
                  <h3 className="px-3 text-[10px] font-bold uppercase tracking-wider text-neutral-500">
                    {language === 'bn' ? group.titleBn : group.titleEn}
                  </h3>
                  <div className="space-y-0.5">
                    {visibleItems.map(item => {
                      const Icon = item.icon;
                      const isActive = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            onSelectTab(item.id);
                            setIsMobileDrawerOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition group cursor-pointer ${
                            isActive 
                              ? 'bg-rose-600 text-white shadow-xs' 
                              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <Icon className={`w-4 h-4 transition ${isActive ? 'text-white' : 'text-neutral-500 group-hover:text-neutral-800'}`} />
                            <span>{language === 'bn' ? item.nameBn : item.nameEn}</span>
                          </div>
                          {item.badge && (
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                              isActive ? 'bg-white/20 text-white' : 'bg-rose-100 text-rose-700 border border-rose-200'
                            }`}>
                              {item.badge}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Sidebar Footer Quick Action */}
          <div className="p-3 border-t border-neutral-200 bg-white space-y-2">
            {onOpenLivePublish && (
              <button
                onClick={onOpenLivePublish}
                className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-rose-600 via-rose-700 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white text-xs font-black flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                <CloudUpload className="w-4 h-4 text-amber-300" />
                <span>{language === 'bn' ? '🚀 ১-ক্লিক লাইভ পাবলিশ' : '🚀 1-Click Live Publish'}</span>
              </button>
            )}
            <button
              onClick={onBackToShop}
              className="w-full py-2 px-3 rounded-xl bg-neutral-100 hover:bg-neutral-200/80 text-neutral-800 text-xs font-bold flex items-center justify-center gap-2 border border-neutral-200 transition cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5 text-neutral-600" />
              <span>{language === 'bn' ? 'কাস্টমার স্টোর ভিউ' : 'Go to Storefront'}</span>
            </button>
          </div>
        </aside>

        {/* Right Content Area */}
        <div className="flex-1 flex flex-col min-w-0 bg-neutral-50/50 overflow-y-auto">
          {/* Top Header Bar */}
          <header className="h-16 px-4 sm:px-6 border-b border-neutral-200 bg-white sticky top-0 z-30 flex items-center justify-between gap-4 shadow-2xs">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsMobileDrawerOpen(true)}
                className="lg:hidden p-2 rounded-xl text-neutral-600 hover:text-neutral-900 bg-neutral-100 border border-neutral-200 cursor-pointer"
              >
                <Menu className="w-5 h-5" />
              </button>

              {/* Breadcrumb Navigation */}
              <div className="hidden sm:flex items-center gap-2 text-xs text-neutral-500">
                <span className="font-semibold text-neutral-600">Admin</span>
                <ChevronRight className="w-3.5 h-3.5 text-neutral-400" />
                <span className="font-bold text-neutral-900 capitalize">
                  {activeTab.replace('_', ' ')}
                </span>
              </div>
            </div>

            {/* Header Right Tools */}
            <div className="flex items-center gap-2 sm:gap-2.5">
              {/* 1-Click Live Publish / Sync Button */}
              {onOpenLivePublish && (
                <button
                  onClick={onOpenLivePublish}
                  className="px-2.5 py-1.5 sm:px-3.5 sm:py-2 rounded-xl bg-gradient-to-r from-rose-600 via-rose-700 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md hover:shadow-lg transition cursor-pointer"
                  title="Publish all updates live to https://gift-ghor.ai.studio"
                >
                  <CloudUpload className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-300" />
                  <span className="hidden sm:inline">
                    {language === 'bn' ? 'লাইভ সাইটে পাবলিশ' : 'Publish Live'}
                  </span>
                  <span className="sm:hidden text-[11px]">
                    {language === 'bn' ? 'পাবলিশ' : 'Publish'}
                  </span>
                </button>
              )}

              {/* Firebase Real-Time Diagnostics Button */}
              {onOpenDiagnostics && (
                <button
                  onClick={onOpenDiagnostics}
                  className="p-2 sm:px-3 sm:py-2 rounded-xl bg-white hover:bg-neutral-50 text-neutral-700 border border-neutral-200 flex items-center gap-2 transition cursor-pointer shadow-2xs"
                  title="Firebase Real-Time Diagnostic Hub"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  <span className="hidden md:inline text-xs font-semibold text-emerald-700">
                    Live Sync
                  </span>
                </button>
              )}

              {/* Notifications Toggle */}
              <button
                onClick={onOpenNotifications}
                className="relative p-2 sm:px-3 sm:py-2 rounded-xl bg-white hover:bg-neutral-50 text-neutral-700 border border-neutral-200 flex items-center gap-2 transition cursor-pointer shadow-2xs"
                title="Notifications"
              >
                <Bell className="w-4 h-4 text-neutral-600" />
                <span className="hidden md:inline text-xs font-semibold">
                  {language === 'bn' ? 'বিজ্ঞপ্তি' : 'Alerts'}
                </span>
                {unreadNotifCount > 0 && (
                  <span className="absolute -top-1 -right-1 sm:static sm:top-auto sm:right-auto px-1.5 py-0.5 text-[10px] font-black rounded-full bg-rose-600 text-white shadow-md animate-pulse">
                    {language === 'bn' ? toBengaliNumber(unreadNotifCount) : unreadNotifCount}
                  </span>
                )}
              </button>

              {/* Storefront Switch Button */}
              <button
                onClick={onBackToShop}
                className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold border border-neutral-200 transition cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-rose-600" />
                <span>{language === 'bn' ? 'দোকান দেখুন' : 'Live Shop'}</span>
              </button>

              {/* User Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-white hover:bg-neutral-50 border border-neutral-200 transition cursor-pointer shadow-2xs"
                >
                  <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-rose-600 to-orange-500 flex items-center justify-center text-white text-xs font-bold">
                    {currentUserProfile?.displayName?.charAt(0) || 'A'}
                  </div>
                  <span className="hidden md:inline text-xs font-bold text-neutral-800 max-w-[120px] truncate">
                    {currentUserProfile?.displayName || 'Admin'}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
                </button>

                {isUserMenuOpen && (
                  <div 
                    className="absolute right-0 mt-2 w-56 bg-white border border-neutral-200 rounded-2xl shadow-xl p-2 z-50 animate-fadeIn divide-y divide-neutral-100"
                    onMouseLeave={() => setIsUserMenuOpen(false)}
                  >
                    <div className="px-3 py-2 pb-2.5">
                      <p className="text-xs font-bold text-neutral-900 truncate">{currentUserProfile?.displayName || 'Admin User'}</p>
                      <p className="text-[10px] text-neutral-500 truncate">{currentUserProfile?.email || 'winlucky414@gmail.com'}</p>
                    </div>

                    <div className="py-1">
                      <button
                        onClick={() => {
                          onSelectTab('settings');
                          setIsUserMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-neutral-700 hover:bg-neutral-100 text-left transition cursor-pointer"
                      >
                        <Settings className="w-3.5 h-3.5 text-neutral-500" />
                        <span>{language === 'bn' ? 'স্টোর সেটিংস' : 'Store Settings'}</span>
                      </button>

                      <button
                        onClick={() => {
                          onSelectTab('users');
                          setIsUserMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-neutral-700 hover:bg-neutral-100 text-left transition cursor-pointer"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-neutral-500" />
                        <span>{language === 'bn' ? 'রোল ও পারমিশন' : 'Roles & Permissions'}</span>
                      </button>
                    </div>

                    {onLogout && (
                      <div className="pt-1">
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            onLogout();
                          }}
                          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-red-600 hover:bg-red-50 text-left transition cursor-pointer font-semibold"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'লগআউট করুন' : 'Sign Out'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </header>

          {/* Tab Content Container */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
};
