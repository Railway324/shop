import React, { useState, useMemo } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Filter, 
  Eye, 
  Printer, 
  Truck, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  RefreshCw, 
  Package, 
  Phone, 
  MapPin, 
  CreditCard, 
  RotateCcw, 
  DollarSign, 
  FileText, 
  Send, 
  ChevronRight,
  User,
  ShieldAlert,
  Save,
  Check,
  X,
  ExternalLink,
  SlidersHorizontal,
  CheckSquare,
  Square,
  AlertCircle,
  Trash2
} from 'lucide-react';
import { Order, OrderStatus, Language, CourierName, PaymentStatus } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';
import { safeDateToLocaleString, safeDateToDateTimeString } from '../../utils/dateUtils';

interface AdminOrdersViewProps {
  orders?: Order[];
  language: Language;
  onUpdateOrderStatus?: (orderId: string, status: OrderStatus, paymentStatus?: any, tracking?: string, courierName?: string) => void;
  onBulkUpdateStatus?: (orderIds: string[], status: OrderStatus) => void;
  onDeleteOrder?: (orderId: string) => void;
  onBulkDeleteOrders?: (orderIds: string[]) => void;
  onUpdateCourierTracking?: (orderId: string, courierName: CourierName, trackingCode: string) => void;
  onUpdatePaymentStatus?: (orderId: string, paymentStatus: PaymentStatus, trxId?: string) => void;
  onCancelOrder?: (orderId: string, reason: string) => void;
  onProcessRefund?: (orderId: string, amount: number, method: string, note: string) => void;
  onSaveOrderNote?: (orderId: string, note: string) => void;
  onPrintInvoice?: (order: Order) => void;
}

export const SUPPORTED_COURIERS: { id: CourierName; name: string; trackingUrlPrefix?: string }[] = [
  { id: 'steadfast', name: 'Steadfast Courier', trackingUrlPrefix: 'https://steadfast.com.bd/t/' },
  { id: 'pathao', name: 'Pathao Courier', trackingUrlPrefix: 'https://merchant.pathao.com/tracking?consignment_id=' },
  { id: 'redx', name: 'RedX Delivery', trackingUrlPrefix: 'https://redx.com.bd/track-order?trackingId=' },
  { id: 'paperfly', name: 'Paperfly GO', trackingUrlPrefix: 'https://paperfly.com.bd/tracking.php?code=' },
  { id: 'sundarban', name: 'Sundarban Courier Service', trackingUrlPrefix: 'https://sundarbancourierltd.com/track/' },
  { id: 'ecourier', name: 'eCourier', trackingUrlPrefix: 'https://ecourier.com.bd/tracking?id=' },
  { id: 'sa_paribahan', name: 'SA Paribahan', trackingUrlPrefix: '' },
];

export const ORDER_STATUS_DETAILS: Record<OrderStatus, { labelBn: string; labelEn: string; color: string; icon: any }> = {
  placed: { labelBn: 'নতুন অর্ডার (Placed)', labelEn: 'New Placed', color: 'bg-neutral-800 text-neutral-300 border-neutral-700', icon: Clock },
  pending: { labelBn: 'পেন্ডিং / অপেক্ষারত', labelEn: 'Pending Verification', color: 'bg-amber-500/15 text-amber-400 border-amber-500/30', icon: Clock },
  confirmed: { labelBn: 'অনুমোদিত / কনফার্মড (Approved)', labelEn: 'Approved / Confirmed', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: CheckCircle2 },
  processing: { labelBn: 'প্রসেসিং হচ্ছে', labelEn: 'Processing & Packaging', color: 'bg-blue-500/15 text-blue-400 border-blue-500/30', icon: RefreshCw },
  packed: { labelBn: 'প্যাকিং সম্পন্ন', labelEn: 'Packed in Box', color: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30', icon: Package },
  shipped: { labelBn: 'কুরিয়ারে পাঠানো হয়েছে', labelEn: 'Dispatched to Courier', color: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30', icon: Truck },
  out_for_delivery: { labelBn: 'ডেলিভারির পথে', labelEn: 'Out for Delivery', color: 'bg-purple-500/15 text-purple-400 border-purple-500/30', icon: Truck },
  delivered: { labelBn: 'ডেলিভারি সম্পন্ন', labelEn: 'Delivered Successfully', color: 'bg-emerald-600/20 text-emerald-300 border-emerald-500/40', icon: CheckCircle2 },
  cancelled: { labelBn: 'অর্ডার বাতিল / রিজেক্টেড', labelEn: 'Cancelled / Rejected', color: 'bg-red-500/15 text-red-400 border-red-500/30', icon: XCircle },
  returned: { labelBn: 'রিটার্ন / ফেরত', labelEn: 'Returned / RTO', color: 'bg-orange-500/15 text-orange-400 border-orange-500/30', icon: RotateCcw },
  refunded: { labelBn: 'টাকা রিফান্ডেড', labelEn: 'Refunded', color: 'bg-pink-500/15 text-pink-400 border-pink-500/30', icon: DollarSign },
};

export const AdminOrdersView: React.FC<AdminOrdersViewProps> = ({
  orders = [],
  language,
  onUpdateOrderStatus,
  onBulkUpdateStatus,
  onDeleteOrder,
  onBulkDeleteOrders,
  onUpdateCourierTracking,
  onUpdatePaymentStatus,
  onCancelOrder,
  onProcessRefund,
  onSaveOrderNote,
  onPrintInvoice,
}) => {
  const [selectedStatusTab, setSelectedStatusTab] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPaymentFilter, setSelectedPaymentFilter] = useState('all');
  const [selectedOrderIds, setSelectedOrderIds] = useState<string[]>([]);

  // Selected Order for Details Drawer
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // Delete Order Confirmation Modal
  const [orderToDelete, setOrderToDelete] = useState<Order | null>(null);

  // Status Change in Drawer
  const [newStatus, setNewStatus] = useState<OrderStatus>('confirmed');
  const [statusChangeNote, setStatusChangeNote] = useState('');

  // Courier Assignment Form
  const [selectedCourier, setSelectedCourier] = useState<CourierName>('steadfast');
  const [trackingCode, setTrackingCode] = useState('');

  // Note Form
  const [adminInternalNote, setAdminInternalNote] = useState('');

  // Cancel / Refund Modals
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('Customer requested cancellation via phone');

  const [isRefundModalOpen, setIsRefundModalOpen] = useState(false);
  const [refundAmount, setRefundAmount] = useState(0);
  const [refundMethod, setRefundMethod] = useState('bKash');
  const [refundNote, setRefundNote] = useState('Full refund for returned damaged package');

  // Keep activeOrder synced with the latest orders list from Firestore
  React.useEffect(() => {
    if (activeOrder) {
      const latest = orders.find(o => o.id === activeOrder.id);
      if (latest && (latest.orderStatus !== activeOrder.orderStatus || latest.paymentStatus !== activeOrder.paymentStatus || latest.trackingCode !== activeOrder.trackingCode)) {
        setActiveOrder(latest);
      }
    }
  }, [orders, activeOrder]);

  // Filtered Orders
  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      // Status Filter
      if (selectedStatusTab !== 'all') {
        if (selectedStatusTab === 'pending' && !(order.orderStatus === 'placed' || order.orderStatus === 'pending')) return false;
        if (selectedStatusTab === 'processing' && !(order.orderStatus === 'confirmed' || order.orderStatus === 'processing' || order.orderStatus === 'packed')) return false;
        if (selectedStatusTab === 'shipped' && !(order.orderStatus === 'shipped' || order.orderStatus === 'out_for_delivery')) return false;
        if (selectedStatusTab === 'delivered' && order.orderStatus !== 'delivered') return false;
        if (selectedStatusTab === 'cancelled_returned' && !(order.orderStatus === 'cancelled' || order.orderStatus === 'returned' || order.orderStatus === 'refunded')) return false;
      }

      // Payment Filter
      if (selectedPaymentFilter !== 'all') {
        if (order.paymentMethod !== selectedPaymentFilter && order.paymentStatus !== selectedPaymentFilter) return false;
      }

      // Search Query (ID, Name, Phone, Address)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchId = String(order.id || '').toLowerCase().includes(q);
        const matchName = String(order.customerName || (order as any).name || '').toLowerCase().includes(q);
        const matchPhone = String(order.phone || '').toLowerCase().includes(q);
        const matchAddress = String(order.address || '').toLowerCase().includes(q);
        const matchTrx = String(order.trxId || '').toLowerCase().includes(q);
        return matchId || matchName || matchPhone || matchAddress || matchTrx;
      }

      return true;
    });
  }, [orders, selectedStatusTab, selectedPaymentFilter, searchQuery]);

  // Open Drawer and populate fields
  const handleOpenOrderDetails = (order: Order) => {
    setActiveOrder(order);
    setNewStatus(order.orderStatus === 'placed' || order.orderStatus === 'pending' ? 'confirmed' : order.orderStatus);
    setStatusChangeNote('');
    setSelectedCourier(order.courierName || 'steadfast');
    setTrackingCode(order.trackingCode || order.courierTrackingCode || '');
    setAdminInternalNote(order.adminNotes || '');
    setRefundAmount(order.total);
  };

  // Quick 1-Click Approve Order
  const handleQuickApprove = (order: Order, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onUpdateOrderStatus) {
      onUpdateOrderStatus(order.id, 'confirmed', order.paymentStatus, order.trackingCode, order.courierName);
    }
    if (activeOrder && activeOrder.id === order.id) {
      setActiveOrder(prev => prev ? { ...prev, orderStatus: 'confirmed' } : null);
      setNewStatus('confirmed');
    }
  };

  // Direct quick status change helper
  const handleDirectSetStatus = (status: OrderStatus) => {
    if (!activeOrder) return;
    const isCOD = !activeOrder.paymentMethod || activeOrder.paymentMethod === 'cod';
    const nextPaymentStatus = (status === 'delivered' && isCOD) ? 'paid' : activeOrder.paymentStatus;
    if (onUpdateOrderStatus) {
      onUpdateOrderStatus(activeOrder.id, status, nextPaymentStatus, activeOrder.trackingCode, activeOrder.courierName);
    }
    setActiveOrder(prev => prev ? { ...prev, orderStatus: status, paymentStatus: nextPaymentStatus } : null);
    setNewStatus(status);
  };

  const handleApplyStatusChange = () => {
    if (!activeOrder) return;
    const isCOD = !activeOrder.paymentMethod || activeOrder.paymentMethod === 'cod';
    const nextPaymentStatus = (newStatus === 'delivered' && isCOD) ? 'paid' : activeOrder.paymentStatus;
    if (onUpdateOrderStatus) {
      onUpdateOrderStatus(activeOrder.id, newStatus, nextPaymentStatus, activeOrder.trackingCode, activeOrder.courierName);
    }
    setActiveOrder(prev => prev ? { ...prev, orderStatus: newStatus, paymentStatus: nextPaymentStatus } : null);
    setStatusChangeNote('');
  };

  const handleSaveCourier = () => {
    if (!activeOrder) return;
    if (onUpdateCourierTracking) {
      onUpdateCourierTracking(activeOrder.id, selectedCourier, trackingCode);
    }
    if (onUpdateOrderStatus) {
      onUpdateOrderStatus(activeOrder.id, activeOrder.orderStatus, activeOrder.paymentStatus, trackingCode, selectedCourier);
    }
    setActiveOrder(prev => prev ? { ...prev, courierName: selectedCourier, trackingCode } : null);
  };

  const handleSaveNote = () => {
    if (!activeOrder) return;
    if (onSaveOrderNote) {
      onSaveOrderNote(activeOrder.id, adminInternalNote);
    }
    setActiveOrder(prev => prev ? { ...prev, adminNotes: adminInternalNote } : null);
  };

  const handleConfirmCancel = () => {
    if (!activeOrder) return;
    if (onCancelOrder) {
      onCancelOrder(activeOrder.id, cancelReason);
    } else if (onUpdateOrderStatus) {
      onUpdateOrderStatus(activeOrder.id, 'cancelled');
    }
    setActiveOrder(prev => prev ? { ...prev, orderStatus: 'cancelled' } : null);
    setIsCancelModalOpen(false);
  };

  const handleConfirmRefund = () => {
    if (!activeOrder) return;
    if (onProcessRefund) {
      onProcessRefund(activeOrder.id, refundAmount, refundMethod, refundNote);
    } else if (onUpdateOrderStatus) {
      onUpdateOrderStatus(activeOrder.id, 'refunded', 'refunded');
    }
    setActiveOrder(prev => prev ? { ...prev, orderStatus: 'refunded', paymentStatus: 'refunded' } : null);
    setIsRefundModalOpen(false);
  };

  // Bulk Selection Handlers
  const handleToggleSelectAll = () => {
    if (selectedOrderIds.length === filteredOrders.length) {
      setSelectedOrderIds([]);
    } else {
      setSelectedOrderIds(filteredOrders.map(o => o.id));
    }
  };

  const handleToggleSelectOrder = (orderId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedOrderIds(prev => 
      prev.includes(orderId) ? prev.filter(id => id !== orderId) : [...prev, orderId]
    );
  };

  const handleBatchApprove = () => {
    if (selectedOrderIds.length === 0) return;
    if (onBulkUpdateStatus) {
      onBulkUpdateStatus(selectedOrderIds, 'confirmed');
    } else if (onUpdateOrderStatus) {
      selectedOrderIds.forEach(id => onUpdateOrderStatus(id, 'confirmed'));
    }
    setSelectedOrderIds([]);
  };

  const handleBatchStatus = (status: OrderStatus) => {
    if (selectedOrderIds.length === 0) return;
    if (onBulkUpdateStatus) {
      onBulkUpdateStatus(selectedOrderIds, status);
    } else if (onUpdateOrderStatus) {
      selectedOrderIds.forEach(id => {
        const order = orders.find(o => o.id === id);
        const isCOD = !order?.paymentMethod || order.paymentMethod === 'cod';
        const payment = (status === 'delivered' && isCOD) ? 'paid' : order?.paymentStatus;
        onUpdateOrderStatus(id, status, payment);
      });
    }
    setSelectedOrderIds([]);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'অর্ডার ম্যানেজমেন্ট' : 'Order Fulfillment Hub'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? `মোট ${toBengaliNumber(orders.length)} টি অর্ডার সিস্টেমে আছে। দ্রুত 'অ্যাপ্রুভ' বাটনে ক্লিক করে পেন্ডিং অর্ডার নিশ্চিত করুন।` 
              : `Total ${orders.length} orders recorded. Click 'Approve' to quickly confirm pending orders.`}
          </p>
        </div>

        {/* Quick Stats Pill */}
        <div className="flex items-center flex-wrap gap-2.5">
          <div className="px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs font-bold text-amber-300 flex items-center gap-1.5 shadow-xs">
            <Package className="w-4 h-4 text-amber-400" />
            <span>
              {language === 'bn' ? 'বিক্রিত পণ্য: ' : 'Sold Units: '}
              <strong className="text-white">
                {toBengaliNumber(
                  orders
                    .filter(o => o.orderStatus !== 'cancelled')
                    .reduce((sum, o) => sum + (o.items?.reduce((s, i) => s + (i.quantity || 1), 0) || 0), 0)
                )}
              </strong>
            </span>
          </div>
          <div className="px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs font-bold text-emerald-400 flex items-center gap-1.5 shadow-xs">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <span>
              {language === 'bn' ? 'মোট আয়: ' : 'Total Income: '}
              <strong className="text-white">
                {formatPrice(
                  orders
                    .filter(o => o.orderStatus !== 'cancelled')
                    .reduce((sum, o) => sum + (Number(o.total) || 0), 0),
                  language
                )}
              </strong>
            </span>
          </div>
          <div className="px-3.5 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs font-bold text-blue-400 flex items-center gap-1.5 shadow-xs">
            <CheckCircle2 className="w-4 h-4 text-blue-400" />
            <span>{toBengaliNumber(orders.filter(o => o.orderStatus === 'delivered' || o.orderStatus === 'confirmed').length)} {language === 'bn' ? 'অ্যাক্টিভ' : 'Active'}</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs and Search Bar */}
      <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-3xl space-y-3">
        {/* Status Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 custom-scrollbar">
          {[
            { id: 'all', labelBn: 'সকল অর্ডার', labelEn: 'All Orders', count: orders.length },
            { id: 'pending', labelBn: 'পেন্ডিং / অ্যাপ্রুভাল চাই', labelEn: 'Pending Approval', count: orders.filter(o => o.orderStatus === 'placed' || o.orderStatus === 'pending').length },
            { id: 'processing', labelBn: 'প্রসেসিং ও কনফার্মড', labelEn: 'Confirmed & Processing', count: orders.filter(o => o.orderStatus === 'confirmed' || o.orderStatus === 'processing' || o.orderStatus === 'packed').length },
            { id: 'shipped', labelBn: 'কুরিয়ারে পাঠানো', labelEn: 'Shipped', count: orders.filter(o => o.orderStatus === 'shipped' || o.orderStatus === 'out_for_delivery').length },
            { id: 'delivered', labelBn: 'ডেলিভার্ড', labelEn: 'Delivered', count: orders.filter(o => o.orderStatus === 'delivered').length },
            { id: 'cancelled_returned', labelBn: 'বাতিল / রিটার্ন', labelEn: 'Cancelled & Returned', count: orders.filter(o => o.orderStatus === 'cancelled' || o.orderStatus === 'returned' || o.orderStatus === 'refunded').length },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedStatusTab(tab.id)}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition cursor-pointer ${
                selectedStatusTab === tab.id
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-950/40'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
              }`}
            >
              <span>{language === 'bn' ? tab.labelBn : tab.labelEn}</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                selectedStatusTab === tab.id ? 'bg-white/20 text-white' : 'bg-neutral-800 text-neutral-400'
              }`}>
                {language === 'bn' ? toBengaliNumber(tab.count) : tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Search & Extra Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={language === 'bn' ? 'অর্ডার আইডি, গ্রাহকের নাম, ফোন বা ট্রানজ্যাকশন আইডি দিয়ে খুঁজুন...' : 'Search by Order ID, Customer Name, Phone or TrxID...'}
              className="w-full pl-9.5 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 placeholder-neutral-500 focus:border-rose-500 outline-none"
            />
          </div>

          <select
            value={selectedPaymentFilter}
            onChange={(e) => setSelectedPaymentFilter(e.target.value)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 focus:border-rose-500 outline-none cursor-pointer"
          >
            <option value="all">{language === 'bn' ? 'সকল পেমেন্ট মেথড' : 'All Payment Methods'}</option>
            <option value="cod">Cash on Delivery (COD)</option>
            <option value="bkash">bKash MFS</option>
            <option value="nagad">Nagad MFS</option>
            <option value="card">Credit / Debit Card</option>
            <option value="paid">{language === 'bn' ? 'পেইড পেমেন্ট' : 'Paid Orders Only'}</option>
            <option value="unpaid">{language === 'bn' ? 'আনপেইড' : 'Unpaid Only'}</option>
          </select>
        </div>
      </div>

      {/* Bulk Action Banner when items selected */}
      {selectedOrderIds.length > 0 && (
        <div className="bg-gradient-to-r from-neutral-900 to-neutral-950 border border-rose-500/40 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl animate-fadeIn">
          <div className="flex items-center gap-2 text-xs text-neutral-200">
            <CheckSquare className="w-4 h-4 text-rose-400" />
            <span>
              {language === 'bn' 
                ? `${toBengaliNumber(selectedOrderIds.length)} টি অর্ডার নির্বাচিত হয়েছে` 
                : `${selectedOrderIds.length} orders selected`}
            </span>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            <button
              onClick={handleBatchApprove}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'সবগুলো অ্যাপ্রুভ করুন' : 'Approve All Selected'}</span>
            </button>
            <button
              onClick={() => handleBatchStatus('shipped')}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <Truck className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'কুরিয়ারে পাঠান' : 'Mark as Shipped'}</span>
            </button>
            <button
              onClick={() => handleBatchStatus('cancelled')}
              className="px-3 py-1.5 rounded-xl bg-red-600/80 hover:bg-red-600 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'বাতিল' : 'Cancel'}</span>
            </button>
            <button
              onClick={() => {
                if (onBulkDeleteOrders) {
                  onBulkDeleteOrders(selectedOrderIds);
                } else if (onDeleteOrder) {
                  selectedOrderIds.forEach(id => onDeleteOrder(id));
                }
                setSelectedOrderIds([]);
              }}
              className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'নির্বাচিতগুলো মুছে ফেলুন' : 'Delete Selected'}</span>
            </button>
            <button
              onClick={() => setSelectedOrderIds([])}
              className="px-2.5 py-1.5 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white text-xs transition cursor-pointer"
            >
              {language === 'bn' ? 'ক্লিয়ার' : 'Clear'}
            </button>
          </div>
        </div>
      )}

      {/* Orders Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
              <tr>
                <th className="py-3.5 px-3 text-center w-10">
                  <button 
                    onClick={handleToggleSelectAll}
                    className="text-neutral-400 hover:text-white cursor-pointer"
                    title="Select All"
                  >
                    {selectedOrderIds.length > 0 && selectedOrderIds.length === filteredOrders.length ? (
                      <CheckSquare className="w-4 h-4 text-rose-500" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3.5 px-3">Order ID</th>
                <th className="py-3.5 px-3">{language === 'bn' ? 'তারিখ' : 'Date'}</th>
                <th className="py-3.5 px-3">{language === 'bn' ? 'গ্রাহক' : 'Customer'}</th>
                <th className="py-3.5 px-3">{language === 'bn' ? 'আইটেম' : 'Items'}</th>
                <th className="py-3.5 px-3">{language === 'bn' ? 'মোট মূল্য' : 'Total'}</th>
                <th className="py-3.5 px-3">{language === 'bn' ? 'পেমেন্ট' : 'Payment'}</th>
                <th className="py-3.5 px-3">{language === 'bn' ? 'কুরিয়ার ও ট্র্যাকিং' : 'Courier'}</th>
                <th className="py-3.5 px-3">{language === 'bn' ? 'অর্ডার স্ট্যাটাস' : 'Status'}</th>
                <th className="py-3.5 px-3 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-neutral-500">
                    <ShoppingBag className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                    <p>{language === 'bn' ? 'কোনো অর্ডার খুঁজে পাওয়া যায়নি।' : 'No orders found matching filters.'}</p>
                  </td>
                </tr>
              ) : (
                filteredOrders.map(order => {
                  const statusInfo = ORDER_STATUS_DETAILS[order.orderStatus] || ORDER_STATUS_DETAILS.pending;
                  const StatusIcon = statusInfo.icon;
                  const totalItemsQty = (order.items || []).reduce((sum, item) => sum + item.quantity, 0);
                  const isPending = order.orderStatus === 'placed' || order.orderStatus === 'pending';
                  const isConfirmedOrProcessing = order.orderStatus === 'confirmed' || order.orderStatus === 'processing' || order.orderStatus === 'packed';
                  const isShipped = order.orderStatus === 'shipped' || order.orderStatus === 'out_for_delivery';
                  const isSelected = selectedOrderIds.includes(order.id);

                  return (
                    <tr 
                      key={order.id} 
                      className={`hover:bg-neutral-800/40 transition cursor-pointer ${
                        isSelected ? 'bg-rose-950/20' : ''
                      }`}
                      onClick={() => handleOpenOrderDetails(order)}
                    >
                      <td className="py-3 px-3 text-center" onClick={(e) => handleToggleSelectOrder(order.id, e)}>
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-rose-500 mx-auto" />
                        ) : (
                          <Square className="w-4 h-4 text-neutral-600 hover:text-neutral-400 mx-auto" />
                        )}
                      </td>
                      <td className="py-3 px-3 font-mono font-black text-rose-400">
                        {order.id}
                      </td>
                      <td className="py-3 px-3 text-neutral-400 text-[11px] whitespace-nowrap">
                        {safeDateToLocaleString(order.date, language === 'bn' ? 'bn-BD' : 'en-US', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-neutral-100">
                          {order.customerName || (order as any).name || (order as any).userName || (order as any).shippingAddress?.fullName || (language === 'bn' ? 'সম্মানিত ক্রেতা' : 'Customer')}
                        </div>
                        <div className="text-[10px] text-neutral-400 flex items-center gap-1">
                          <Phone className="w-3 h-3 text-neutral-500" />
                          <span>{order.phone || (order as any).userPhone || (order as any).shippingAddress?.phone || '-'}</span>
                        </div>
                        {order.address && (
                          <div className="text-[10px] text-neutral-400 truncate max-w-[160px]" title={order.address}>
                            {order.address}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-neutral-300">
                        <span className="font-bold text-white">{totalItemsQty}</span> {language === 'bn' ? 'টি পণ্য' : 'pcs'}
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-black text-sm text-white">
                          {formatPrice(order.total, language)}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <div className="uppercase font-bold text-[11px] text-neutral-200">
                          {order.paymentMethod}
                        </div>
                        <span className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-bold mt-0.5 ${
                          order.paymentStatus === 'paid' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                          order.paymentStatus === 'refunded' ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30' :
                          'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}>
                          {order.paymentStatus || 'pending'}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        {order.courierName ? (
                          <div>
                            <span className="text-[11px] font-bold text-neutral-200 capitalize">
                              {order.courierName}
                            </span>
                            {(order.trackingCode || order.courierTrackingCode) && (
                              <p className="text-[10px] font-mono text-neutral-400 truncate max-w-[100px]">
                                #{order.trackingCode || order.courierTrackingCode}
                              </p>
                            )}
                          </div>
                        ) : (
                          <span className="text-[10px] text-neutral-500 italic">Not assigned</span>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] font-bold border ${statusInfo.color}`}>
                          <StatusIcon className="w-3 h-3" />
                          <span>{language === 'bn' ? statusInfo.labelBn : statusInfo.labelEn}</span>
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          {/* DIRECT 1-CLICK APPROVE BUTTON FOR PENDING ORDERS */}
                          {isPending && (
                            <button
                              onClick={(e) => handleQuickApprove(order, e)}
                              className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[11px] flex items-center gap-1 shadow-md shadow-emerald-950/40 transition cursor-pointer shrink-0"
                              title={language === 'bn' ? 'অর্ডারটি অ্যাপ্রুভ / কনফার্ম করুন' : 'Approve & Confirm Order'}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'অ্যাপ্রুভ' : 'Approve'}</span>
                            </button>
                          )}

                          {/* Quick Shipped action */}
                          {isConfirmedOrProcessing && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (onUpdateOrderStatus) onUpdateOrderStatus(order.id, 'shipped');
                              }}
                              className="px-2 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/40 font-bold text-[10px] flex items-center gap-1 transition cursor-pointer shrink-0"
                              title="Mark as Shipped"
                            >
                              <Truck className="w-3 h-3" />
                              <span>{language === 'bn' ? 'কুরিয়ার' : 'Ship'}</span>
                            </button>
                          )}

                          {/* Quick Delivered action */}
                          {isShipped && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const isCOD = !order.paymentMethod || order.paymentMethod === 'cod';
                                const payment = isCOD ? 'paid' : order.paymentStatus;
                                if (onUpdateOrderStatus) onUpdateOrderStatus(order.id, 'delivered', payment);
                              }}
                              className="px-2 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 font-bold text-[10px] flex items-center gap-1 transition cursor-pointer shrink-0"
                              title={language === 'bn' ? 'ডেলিভারি সম্পন্ন করুন (COD পেমেন্ট সাথে সাথে Paid হবে)' : 'Mark as Delivered (COD auto-paid)'}
                            >
                              <Check className="w-3 h-3" />
                              <span>{language === 'bn' ? 'ডেলিভার্ড' : 'Delivered'}</span>
                            </button>
                          )}

                          {/* Invoice print */}
                          {onPrintInvoice && (
                            <button
                              onClick={() => onPrintInvoice(order)}
                              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition cursor-pointer"
                              title="Print Invoice / Voucher"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* View | Delete Actions */}
                          <div className="flex items-center gap-1 bg-neutral-950/60 p-1 rounded-xl border border-neutral-800">
                            {/* View Order Full Drawer */}
                            <button
                              onClick={() => handleOpenOrderDetails(order)}
                              className="px-2 py-1 rounded-lg bg-rose-600/15 hover:bg-rose-600/30 text-rose-400 border border-rose-500/20 font-bold text-[11px] flex items-center gap-1 transition cursor-pointer"
                              title={language === 'bn' ? 'অর্ডার বিস্তারিত দেখুন' : 'View Order Details'}
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'ভিউ' : 'View'}</span>
                            </button>

                            <span className="text-neutral-600 text-xs select-none">|</span>

                            {/* Delete Order with Confirmation */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setOrderToDelete(order);
                              }}
                              className="px-2 py-1 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400 hover:text-red-300 border border-red-800/30 font-bold text-[11px] flex items-center gap-1 transition cursor-pointer"
                              title={language === 'bn' ? 'অর্ডারটি ডিলিট করুন' : 'Delete Order'}
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-400" />
                              <span>{language === 'bn' ? 'ডিলিট' : 'Delete'}</span>
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Comprehensive Order Details Slide-Over Drawer / Modal */}
      {activeOrder && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-neutral-900 border border-neutral-800 w-full max-w-3xl rounded-3xl p-5 sm:p-7 space-y-6 my-6 shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center font-mono font-black text-sm">
                  #{activeOrder.id.slice(-4)}
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>Order #{activeOrder.id}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${ORDER_STATUS_DETAILS[activeOrder.orderStatus]?.color || ''}`}>
                      {ORDER_STATUS_DETAILS[activeOrder.orderStatus]?.labelBn || activeOrder.orderStatus}
                    </span>
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Placed on: {safeDateToDateTimeString(activeOrder.date)}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {onPrintInvoice && (
                  <button
                    onClick={() => onPrintInvoice(activeOrder)}
                    className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold flex items-center gap-1.5 border border-neutral-700 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Invoice</span>
                  </button>
                )}

                <button
                  onClick={() => setOrderToDelete(activeOrder)}
                  className="px-3 py-1.5 rounded-xl bg-red-950/50 hover:bg-red-900/70 text-red-400 hover:text-red-300 text-xs font-bold flex items-center gap-1.5 border border-red-800/40 cursor-pointer"
                  title={language === 'bn' ? 'অর্ডারটি ডিলিট করুন' : 'Delete Order'}
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                  <span>{language === 'bn' ? 'ডিলিট' : 'Delete'}</span>
                </button>

                <button
                  onClick={() => setActiveOrder(null)}
                  className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-800 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Action Top Bar for fast workflow */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-neutral-950 via-neutral-900 to-neutral-950 border border-neutral-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-rose-400" />
                  <span>{language === 'bn' ? 'কুইক স্ট্যাটাস একশন' : 'Quick Order Actions'}</span>
                </span>
                <span className="text-[11px] text-neutral-400 font-bold">
                  Current: <span className="text-white capitalize">{activeOrder.orderStatus}</span>
                </span>
              </div>

              <div className="flex items-center flex-wrap gap-2 pt-1">
                {/* 1-Click Approve button */}
                <button
                  onClick={() => handleDirectSetStatus('confirmed')}
                  className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 transition cursor-pointer ${
                    activeOrder.orderStatus === 'confirmed'
                      ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-950/40 ring-2 ring-emerald-400'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{language === 'bn' ? '✓ অর্ডার অ্যাপ্রুভ / কনফার্ম করুন' : '✓ Approve & Confirm Order'}</span>
                </button>

                <button
                  onClick={() => handleDirectSetStatus('processing')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                    activeOrder.orderStatus === 'processing'
                      ? 'bg-blue-500 text-white ring-2 ring-blue-400'
                      : 'bg-neutral-800 hover:bg-blue-600/30 text-neutral-200 border border-neutral-700'
                  }`}
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'প্রসেসিং হচ্ছে' : 'Processing'}</span>
                </button>

                <button
                  onClick={() => handleDirectSetStatus('shipped')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                    activeOrder.orderStatus === 'shipped'
                      ? 'bg-indigo-500 text-white ring-2 ring-indigo-400'
                      : 'bg-neutral-800 hover:bg-indigo-600/30 text-neutral-200 border border-neutral-700'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'কুরিয়ারে হস্তান্তর' : 'Dispatched / Shipped'}</span>
                </button>

                <button
                  onClick={() => handleDirectSetStatus('delivered')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                    activeOrder.orderStatus === 'delivered'
                      ? 'bg-emerald-500 text-white ring-2 ring-emerald-400'
                      : 'bg-neutral-800 hover:bg-emerald-600/30 text-neutral-200 border border-neutral-700'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'ডেলিভার্ড' : 'Delivered'}</span>
                </button>
              </div>
            </div>

            {/* Modal Body (Scrollable) */}
            <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-1 custom-scrollbar">
              {/* Customer and Delivery Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Customer Box */}
                <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                  <h4 className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-rose-400" />
                    <span>Customer Details</span>
                  </h4>
                  <div className="space-y-1 text-xs">
                    <p className="font-bold text-white text-sm">
                      {activeOrder.customerName || (activeOrder as any).name || (activeOrder as any).userName || (activeOrder as any).shippingAddress?.fullName || 'Customer'}
                    </p>
                    <p className="text-neutral-300 flex items-center gap-1.5 font-medium">
                      <Phone className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      <span>{activeOrder.phone || (activeOrder as any).userPhone || (activeOrder as any).shippingAddress?.phone || '-'}</span>
                    </p>
                    {activeOrder.email && (
                      <p className="text-neutral-400 text-[11px]">{activeOrder.email}</p>
                    )}
                    <p className="text-neutral-300 flex items-start gap-1.5 pt-1">
                      <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">
                        {activeOrder.address || (activeOrder as any).shippingAddress?.fullAddress || 'ঠিকানা দেওয়া হয়নি'}
                      </span>
                    </p>
                    {(activeOrder.thanaId || activeOrder.districtId || activeOrder.divisionId) && (
                      <p className="text-[11px] text-neutral-400 pl-5 capitalize">
                        {[activeOrder.thanaId, activeOrder.districtId, activeOrder.divisionId].filter(Boolean).join(', ')}
                      </p>
                    )}
                  </div>
                </div>

                {/* Payment & Summary Box */}
                <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                  <h4 className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                    <CreditCard className="w-3.5 h-3.5 text-rose-400" />
                    <span>Payment & Totals</span>
                  </h4>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Payment Method:</span>
                      <span className="font-bold text-white uppercase">{activeOrder.paymentMethod}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-neutral-400">Payment Status:</span>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-emerald-400 capitalize">{activeOrder.paymentStatus || 'Pending'}</span>
                        {((activeOrder.paymentMethod === 'cod' || !activeOrder.paymentMethod) && activeOrder.orderStatus === 'delivered') && (
                          <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                            {language === 'bn' ? 'COD ডেলিভারিতে পরিশোধিত' : 'COD Paid'}
                          </span>
                        )}
                      </div>
                    </div>
                    {activeOrder.trxId && (
                      <div className="flex justify-between font-mono text-[11px]">
                        <span className="text-neutral-400">TrxID:</span>
                        <span className="font-bold text-rose-400">{activeOrder.trxId}</span>
                      </div>
                    )}
                    <div className="pt-2 border-t border-neutral-800 flex justify-between font-black text-sm">
                      <span className="text-neutral-300">Grand Total:</span>
                      <span className="text-emerald-400">{formatPrice(activeOrder.total, language)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Ordered Items List */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <h4 className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                  <Package className="w-3.5 h-3.5 text-rose-400" />
                  <span>Ordered Items ({(activeOrder.items || []).length})</span>
                </h4>
                <div className="divide-y divide-neutral-800/80">
                  {(activeOrder.items || []).map((item, idx) => (
                    <div key={idx} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-3">
                        <img src={item.product.image} alt="" className="w-10 h-10 rounded-xl object-cover bg-neutral-800 shrink-0" />
                        <div>
                          <p className="font-bold text-neutral-100">
                            {language === 'bn' ? item.product.titleBn : item.product.titleEn}
                          </p>
                          {(item.selectedSize || item.selectedColor) && (
                            <p className="text-[10px] text-amber-300 font-semibold mt-0.5">
                              {[
                                item.selectedSize ? `Size: ${item.selectedSize}` : '',
                                item.selectedColor ? `Color: ${item.selectedColor}` : '',
                              ].filter(Boolean).join(' • ')}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-white">
                          {item.quantity} × {formatPrice(item.product.price, language)}
                        </p>
                        <p className="text-xs font-black text-emerald-400">
                          {formatPrice(item.quantity * item.product.price, language)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Detailed Status Dropdown & Notes Control */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <h4 className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 text-rose-400" />
                  <span>{language === 'bn' ? 'স্ট্যাটাস পরিবর্তন ও নোট যুক্ত করুন' : 'Update Order Status Workflow'}</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1 sm:col-span-1">
                    <label className="text-[11px] text-neutral-400">{language === 'bn' ? 'স্ট্যাটাস নির্ধারণ করুন:' : 'Choose Status:'}</label>
                    <select
                      value={newStatus}
                      onChange={(e) => setNewStatus(e.target.value as OrderStatus)}
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:border-rose-500 outline-none cursor-pointer"
                    >
                      {Object.keys(ORDER_STATUS_DETAILS).map(s => (
                        <option key={s} value={s}>
                          {language === 'bn' 
                            ? ORDER_STATUS_DETAILS[s as OrderStatus].labelBn 
                            : ORDER_STATUS_DETAILS[s as OrderStatus].labelEn}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1 sm:col-span-2">
                    <label className="text-[11px] text-neutral-400">{language === 'bn' ? 'এডমিন নোট (অপশনাল):' : 'Status Change Note (Optional):'}</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={statusChangeNote}
                        onChange={(e) => setStatusChangeNote(e.target.value)}
                        placeholder={language === 'bn' ? 'যেমন: ফোনে গ্রাহক কনফার্ম করেছেন।' : 'e.g. Phone confirmed with customer, parcel packed.'}
                        className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-neutral-200 outline-none"
                      />
                      <button
                        onClick={handleApplyStatusChange}
                        className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition cursor-pointer shrink-0"
                      >
                        {language === 'bn' ? 'আপডেট' : 'Update'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Courier & Tracking Code Assignment */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <h4 className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                  <Truck className="w-3.5 h-3.5 text-rose-400" />
                  <span>{language === 'bn' ? 'কুরিয়ার সার্ভিস ও ট্র্যাকিং কোড' : 'Courier & Shipment Tracking'}</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] text-neutral-400">{language === 'bn' ? 'কুরিয়ার পার্টনার:' : 'Courier Service:'}</label>
                    <select
                      value={selectedCourier}
                      onChange={(e) => setSelectedCourier(e.target.value as CourierName)}
                      className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white focus:border-rose-500 outline-none cursor-pointer"
                    >
                      {SUPPORTED_COURIERS.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1 sm:col-span-2">
                    <label className="text-[11px] text-neutral-400">{language === 'bn' ? 'কনসাইনমেন্ট / ট্র্যাকিং নম্বর:' : 'Consignment / Tracking Number:'}</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={trackingCode}
                        onChange={(e) => setTrackingCode(e.target.value)}
                        placeholder="e.g. STDF-894210"
                        className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-neutral-200 font-mono outline-none"
                      />
                      <button
                        onClick={handleSaveCourier}
                        className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition cursor-pointer shrink-0"
                      >
                        {language === 'bn' ? 'সংরক্ষণ' : 'Save Courier'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Admin Internal Notes */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <h4 className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-rose-400" />
                  <span>{language === 'bn' ? 'এডমিন ইন্টারনাল নোট' : 'Admin Internal Notes'}</span>
                </h4>
                <div className="flex gap-2">
                  <textarea
                    rows={2}
                    value={adminInternalNote}
                    onChange={(e) => setAdminInternalNote(e.target.value)}
                    placeholder={language === 'bn' ? 'শুধুমাত্র এডমিনদের দেখার জন্য অভ্যন্তরীণ নোট...' : 'Notes visible only to admin team...'}
                    className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-neutral-200 outline-none"
                  />
                  <button
                    onClick={handleSaveNote}
                    className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold h-fit self-end transition cursor-pointer"
                  >
                    {language === 'bn' ? 'নোট সেভ করুন' : 'Save Note'}
                  </button>
                </div>
              </div>

              {/* Status History Timeline */}
              {activeOrder.statusHistory && activeOrder.statusHistory.length > 0 && (
                <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                  <h4 className="text-xs font-black text-neutral-300 uppercase tracking-wider flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-rose-400" />
                    <span>Order Status Timeline Log</span>
                  </h4>
                  <div className="space-y-2">
                    {activeOrder.statusHistory.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-neutral-400 border-l-2 border-neutral-800 pl-3">
                        <div className="w-2 h-2 rounded-full bg-rose-500 -ml-4 mt-1" />
                        <div>
                          <p className="font-bold text-neutral-200 capitalize">{item.status}</p>
                          <p className="text-[10px] text-neutral-500">
                            {item.timestamp || (item.date ? safeDateToDateTimeString(item.date) : '')} {item.note ? `• ${item.note}` : ''}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer (Cancel & Refund actions) */}
            <div className="flex items-center justify-between pt-4 border-t border-neutral-800">
              <div className="flex items-center gap-2">
                {activeOrder.orderStatus !== 'cancelled' && (
                  <button
                    onClick={() => setIsCancelModalOpen(true)}
                    className="px-3 py-2 rounded-xl text-xs font-bold text-red-400 hover:bg-red-950/40 border border-red-500/30 transition cursor-pointer"
                  >
                    {language === 'bn' ? 'অর্ডার বাতিল করুন' : 'Cancel Order'}
                  </button>
                )}

                {activeOrder.orderStatus !== 'refunded' && (
                  <button
                    onClick={() => setIsRefundModalOpen(true)}
                    className="px-3 py-2 rounded-xl text-xs font-bold text-pink-400 hover:bg-pink-950/40 border border-pink-500/30 transition cursor-pointer"
                  >
                    {language === 'bn' ? 'রিফান্ড প্রসেস' : 'Process Refund'}
                  </button>
                )}
              </div>

              <button
                onClick={() => setActiveOrder(null)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-neutral-800 hover:bg-neutral-700 text-white transition cursor-pointer"
              >
                {language === 'bn' ? 'বন্ধ করুন' : 'Close Drawer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Confirmation Modal */}
      {isCancelModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 max-w-sm w-full rounded-3xl p-6 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-neutral-900 flex items-center gap-2">
              <XCircle className="w-5 h-5 text-red-600" />
              <span>Cancel Order Confirmation</span>
            </h4>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-neutral-700">Cancellation Reason:</label>
              <input
                type="text"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Reason for cancellation..."
                className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs text-neutral-900 outline-none focus:border-red-500 shadow-2xs"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCancelModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 cursor-pointer transition"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-500 cursor-pointer shadow-md shadow-red-600/20 transition"
              >
                Confirm Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Process Refund Modal */}
      {isRefundModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 max-w-sm w-full rounded-3xl p-6 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-neutral-900 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-pink-600" />
              <span>Process Customer Refund</span>
            </h4>
            <div className="space-y-2 text-xs">
              <div>
                <label className="text-neutral-700 font-semibold">Refund Amount (৳):</label>
                <input
                  type="number"
                  value={refundAmount}
                  onChange={(e) => setRefundAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl font-bold text-neutral-900 outline-none mt-1 shadow-2xs focus:border-pink-500"
                />
              </div>
              <div>
                <label className="text-neutral-700 font-semibold">Refund Channel:</label>
                <select
                  value={refundMethod}
                  onChange={(e) => setRefundMethod(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none mt-1 cursor-pointer shadow-2xs"
                >
                  <option value="bKash">bKash Personal / Merchant</option>
                  <option value="Nagad">Nagad</option>
                  <option value="Bank Transfer">Bank Transfer / Card</option>
                  <option value="Store Credit">Store Credit Voucher</option>
                </select>
              </div>
              <div>
                <label className="text-neutral-700 font-semibold">Refund Note:</label>
                <input
                  type="text"
                  value={refundNote}
                  onChange={(e) => setRefundNote(e.target.value)}
                  placeholder="Txn ID / Reason..."
                  className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none mt-1 shadow-2xs"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsRefundModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 cursor-pointer transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRefund}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-pink-600 hover:bg-pink-500 cursor-pointer shadow-md shadow-pink-600/20 transition"
              >
                Execute Refund
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Order Delete Confirmation Modal */}
      {orderToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-[70] flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-red-50 border border-red-200 text-red-600 flex items-center justify-center shrink-0 shadow-2xs">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-black text-neutral-900">
                  {language === 'bn' ? 'অর্ডার ডিলিট নিশ্চিত করুন' : 'Confirm Order Deletion'}
                </h3>
                <p className="text-xs text-neutral-500 font-mono">
                  ID: #{orderToDelete.id}
                </p>
              </div>
            </div>

            <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-4 space-y-2 text-xs">
              <p className="text-sm font-semibold text-neutral-900">
                Are you sure you want to delete this order?
              </p>
              <p className="text-neutral-600 text-xs leading-relaxed">
                {language === 'bn' 
                  ? 'আপনি কি নিশ্চিত যে আপনি এই অর্ডারটি ডাটাবেজ থেকে স্থায়ীভাবে ডিলিট করতে চান? কনফার্ম করলে ডাটাবেজ থেকে চিরতরে মুছে যাবে।'
                  : 'Are you sure you want to permanently delete this order from the database? This action cannot be undone.'}
              </p>
              <div className="pt-2 border-t border-neutral-200 text-neutral-700 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-neutral-500">{language === 'bn' ? 'গ্রাহকের নাম:' : 'Customer:'}</span>
                  <span className="font-bold text-neutral-900">{orderToDelete.customerName || 'গ্রাহক'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">{language === 'bn' ? 'মোবাইল নম্বর:' : 'Phone:'}</span>
                  <span className="font-mono text-neutral-800">{orderToDelete.phone || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">{language === 'bn' ? 'মোট মূল্য:' : 'Total Amount:'}</span>
                  <span className="font-black text-rose-600">{formatPrice(orderToDelete.total, language)}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-1">
              <button
                type="button"
                onClick={() => setOrderToDelete(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-bold text-neutral-600 bg-neutral-100 hover:bg-neutral-200 transition cursor-pointer"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={() => {
                  const id = orderToDelete.id;
                  if (activeOrder?.id === id) {
                    setActiveOrder(null);
                  }
                  setOrderToDelete(null);
                  if (onDeleteOrder) {
                    onDeleteOrder(id);
                  }
                }}
                className="px-5 py-2.5 rounded-xl text-xs font-black text-white bg-red-600 hover:bg-red-500 shadow-md shadow-red-600/20 transition cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>{language === 'bn' ? 'হ্যাঁ, ডিলিট করুন' : 'Confirm Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
