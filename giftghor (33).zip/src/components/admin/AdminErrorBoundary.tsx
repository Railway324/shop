import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, ArrowLeft } from 'lucide-react';
import { Language } from '../../types';

interface Props {
  children: ReactNode;
  language?: Language;
  onReset?: () => void;
  onBackToShop?: () => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class AdminErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Admin Panel Uncaught Error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleReload = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  public render() {
    if (this.state.hasError) {
      const isBn = this.props.language === 'bn';

      return (
        <div className="p-6 sm:p-10 max-w-3xl mx-auto my-8 bg-white border border-red-200 rounded-3xl shadow-sm text-neutral-900 space-y-5 animate-fadeIn">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-200 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-neutral-900">
                {isBn ? 'অ্যাডমিন প্যানেল লোড হতে সাময়িক সমস্যা হয়েছে' : 'Admin View Encountered an Error'}
              </h2>
              <p className="text-xs text-neutral-600 mt-0.5">
                {isBn 
                  ? 'একটি অর্ডারের ডেটা প্রক্রিয়াকরণে অপ্রত্যাশিত সমস্যা ঘটেছে। নিচের বাটনে ক্লিক করে পুনরায় লোড করুন।' 
                  : 'An unexpected issue occurred while rendering this admin view. You can reload safely.'}
              </p>
            </div>
          </div>

          {this.state.error && (
            <div className="p-3.5 bg-neutral-50 rounded-xl border border-neutral-200 font-mono text-xs text-red-600 overflow-x-auto">
              {this.state.error.message || String(this.state.error)}
            </div>
          )}

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={this.handleReload}
              className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-xs transition cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>{isBn ? 'পুনরায় চেষ্টা করুন' : 'Try Again / Reload View'}</span>
            </button>

            {this.props.onBackToShop && (
              <button
                type="button"
                onClick={this.props.onBackToShop}
                className="px-4 py-2.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold rounded-xl flex items-center gap-2 border border-neutral-200 transition cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{isBn ? 'স্টোরফ্রন্টে ফিরে যান' : 'Back to Storefront'}</span>
              </button>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
