import React, { useState, useMemo } from 'react';
import { 
  History, 
  Search, 
  Filter, 
  User, 
  Calendar, 
  ShieldCheck, 
  Trash2, 
  Download,
  Activity
} from 'lucide-react';
import { ActivityLogItem, Language } from '../../types';

interface AdminActivityLogViewProps {
  activityLogs?: ActivityLogItem[];
  language: Language;
  onClearLogs?: () => void;
}

export const AdminActivityLogView: React.FC<AdminActivityLogViewProps> = ({
  activityLogs = [],
  language,
  onClearLogs,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const filteredLogs = useMemo(() => {
    return activityLogs.filter(log => {
      if (categoryFilter !== 'all' && log.category !== categoryFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchAdmin = log.adminName.toLowerCase().includes(q);
        const matchAction = log.action.toLowerCase().includes(q);
        const matchDetails = log.details.toLowerCase().includes(q);
        return matchAdmin || matchAction || matchDetails;
      }
      return true;
    });
  }, [activityLogs, categoryFilter, searchQuery]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <History className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'এডমিন অ্যাক্টিভিটি ও অডিট লগ' : 'Admin Operations Audit Trail'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'স্টোর স্টাফদের প্রতিটি পরিবর্তন, প্রোডাক্ট এডিট, অর্ডার স্ট্যাটাস আপডেট ও সিস্টেম অ্যাকশন রেকর্ড।' 
              : 'Immutable record of staff actions, order status changes, and catalog updates.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onClearLogs && (
            <button
              onClick={onClearLogs}
              className="px-3.5 py-2 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-neutral-300 transition cursor-pointer"
            >
              Clear Logs
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-3xl space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search audit logs by admin name, action, or target ID..."
              className="w-full pl-9.5 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 placeholder-neutral-500 outline-none focus:border-rose-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 outline-none cursor-pointer"
          >
            <option value="all">All Action Categories</option>
            <option value="order">Orders & Shipments</option>
            <option value="product">Products & Catalog</option>
            <option value="inventory">Inventory Adjustments</option>
            <option value="coupon">Coupons & Promos</option>
            <option value="settings">Settings & System</option>
            <option value="user">Staff & Accounts</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
              <tr>
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">Staff Admin</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Action Performed</th>
                <th className="py-3.5 px-4">Details & Target</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono text-[11px]">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-neutral-500 font-sans text-xs">
                    <Activity className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                    <p>No activity records found matching filters.</p>
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-neutral-800/40 transition">
                    <td className="py-3 px-4 text-neutral-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 font-sans font-bold text-neutral-200">
                      {log.adminName}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-lg text-[9px] font-bold uppercase bg-neutral-800 text-neutral-300 border border-neutral-700">
                        {log.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-sans font-bold text-white">
                      {log.action}
                    </td>
                    <td className="py-3 px-4 font-sans text-neutral-300">
                      {log.details}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
