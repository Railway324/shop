import React, { useState, useMemo } from 'react';
import { 
  Boxes, 
  AlertTriangle, 
  Plus, 
  Minus, 
  History, 
  Search, 
  Filter, 
  ArrowUpDown, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  PackageCheck, 
  Sliders, 
  X,
  FileText,
  User,
  SlidersHorizontal
} from 'lucide-react';
import { Product, StockLog, Language } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';

interface AdminInventoryViewProps {
  products?: Product[];
  stockLogs?: StockLog[];
  language: Language;
  onAdjustStock?: (
    productId: string, 
    newStockOrDelta: number, 
    typeOrReason?: any, 
    quantity?: number, 
    reason?: string
  ) => void;
  lowStockThreshold?: number;
  onUpdateThreshold?: (threshold: number) => void;
}

export const AdminInventoryView: React.FC<AdminInventoryViewProps> = ({
  products = [],
  stockLogs = [],
  language,
  onAdjustStock,
  lowStockThreshold = 5,
  onUpdateThreshold,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'low_stock' | 'out_of_stock' | 'history'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Stock Adjustment Modal
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [adjustmentType, setAdjustmentType] = useState<'stock_in' | 'stock_out' | 'adjustment'>('stock_in');
  const [adjustmentAmount, setAdjustmentAmount] = useState<number>(10);
  const [adjustmentReason, setAdjustmentReason] = useState<string>('New Warehouse Shipment Received');

  // Quick Threshold Setting
  const [isEditingThreshold, setIsEditingThreshold] = useState(false);
  const [thresholdVal, setThresholdVal] = useState(lowStockThreshold);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      if (activeSubTab === 'low_stock' && (p.stock === 0 || p.stock > lowStockThreshold)) return false;
      if (activeSubTab === 'out_of_stock' && p.stock !== 0) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = p.titleBn.toLowerCase().includes(q) || p.titleEn.toLowerCase().includes(q);
        const matchSku = p.sku?.toLowerCase().includes(q);
        return matchTitle || matchSku;
      }
      return true;
    });
  }, [products, activeSubTab, lowStockThreshold, searchQuery]);

  // Inventory Totals
  const totalItemsInStock = useMemo(() => products.reduce((sum, p) => sum + p.stock, 0), [products]);
  const lowStockCount = useMemo(() => products.filter(p => p.stock > 0 && p.stock <= lowStockThreshold).length, [products, lowStockThreshold]);
  const outOfStockCount = useMemo(() => products.filter(p => p.stock === 0).length, [products]);

  const handleOpenAdjust = (p: Product, type: 'stock_in' | 'stock_out' | 'adjustment' = 'stock_in') => {
    setAdjustingProduct(p);
    setAdjustmentType(type);
    setAdjustmentAmount(type === 'adjustment' ? p.stock : 10);
    setAdjustmentReason(
      type === 'stock_in' ? 'Factory Batch Restock' :
      type === 'stock_out' ? 'Damaged / Sample Dispatch' :
      'Manual Physical Inventory Audit'
    );
  };

  const handleConfirmAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;

    let newStock = adjustingProduct.stock;
    let qty = Number(adjustmentAmount) || 0;

    if (adjustmentType === 'stock_in') {
      newStock += qty;
    } else if (adjustmentType === 'stock_out') {
      newStock = Math.max(0, newStock - qty);
    } else {
      newStock = Math.max(0, qty);
      qty = newStock - adjustingProduct.stock;
    }

    let delta = adjustmentType === 'stock_in' ? qty : adjustmentType === 'stock_out' ? -qty : (qty - adjustingProduct.stock);

    if (onAdjustStock) {
      // Handles both (id, delta, reason) and (id, newStock, type, qty, reason)
      onAdjustStock(adjustingProduct.id, delta, adjustmentReason, qty, adjustmentReason);
    }
    setAdjustingProduct(null);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Inventory Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Boxes className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'ইনভেন্টরি ও স্টক ব্যবস্থাপনা' : 'Inventory & Stock Management'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? `মোট ${toBengaliNumber(totalItemsInStock)} টি আইটেম স্টকে রয়েছে। স্টক-ইন, স্টক-আউট ও পরিবর্তন হিস্ট্রি নিরীক্ষণ করুন।` 
              : `Total ${totalItemsInStock} units in warehouse. Track stock levels and adjustment history.`}
          </p>
        </div>

        {/* Low Stock Threshold Setting */}
        <div className="flex items-center gap-2 bg-neutral-950 p-2 rounded-2xl border border-neutral-800">
          <span className="text-xs text-neutral-400 pl-2">
            {language === 'bn' ? 'সতর্কবার্তা সীমা:' : 'Alert Threshold:'}
          </span>
          {isEditingThreshold ? (
            <div className="flex items-center gap-1.5">
              <input
                type="number"
                value={thresholdVal}
                onChange={(e) => setThresholdVal(Number(e.target.value))}
                className="w-14 px-2 py-1 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white"
              />
              <button
                onClick={() => {
                  if (onUpdateThreshold) onUpdateThreshold(thresholdVal);
                  setIsEditingThreshold(false);
                }}
                className="p-1 rounded bg-rose-600 text-white text-xs"
              >
                Save
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsEditingThreshold(true)}
              className="px-2.5 py-1 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-xs font-black text-amber-400 border border-neutral-700 cursor-pointer"
            >
              ≤ {lowStockThreshold} units
            </button>
          )}
        </div>
      </div>

      {/* Overview Stat Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div 
          onClick={() => setActiveSubTab('all')}
          className={`p-4 rounded-3xl border transition cursor-pointer ${
            activeSubTab === 'all' ? 'bg-neutral-900 border-rose-500/50 shadow-lg shadow-rose-950/30' : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400">{language === 'bn' ? 'মোট মজুত একক' : 'Total Stocked Units'}</span>
            <PackageCheck className="w-5 h-5 text-emerald-400" />
          </div>
          <h3 className="text-2xl font-black text-white mt-2">
            {language === 'bn' ? toBengaliNumber(totalItemsInStock) : totalItemsInStock}
          </h3>
          <p className="text-[10px] text-neutral-500 mt-1">{products.length} catalog items</p>
        </div>

        <div 
          onClick={() => setActiveSubTab('low_stock')}
          className={`p-4 rounded-3xl border transition cursor-pointer ${
            activeSubTab === 'low_stock' ? 'bg-neutral-900 border-amber-500/50 shadow-lg shadow-amber-950/30' : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-400">{language === 'bn' ? 'কম স্টক প্রোডাক্ট' : 'Low Stock Items'}</span>
            <AlertTriangle className="w-5 h-5 text-amber-400" />
          </div>
          <h3 className="text-2xl font-black text-white mt-2">
            {language === 'bn' ? toBengaliNumber(lowStockCount) : lowStockCount}
          </h3>
          <p className="text-[10px] text-amber-400/80 mt-1">Requires factory re-order</p>
        </div>

        <div 
          onClick={() => setActiveSubTab('out_of_stock')}
          className={`p-4 rounded-3xl border transition cursor-pointer ${
            activeSubTab === 'out_of_stock' ? 'bg-neutral-900 border-red-500/50 shadow-lg shadow-red-950/30' : 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-400">{language === 'bn' ? 'স্টক শেষ (০)' : 'Out of Stock (0)'}</span>
            <XCircle className="w-5 h-5 text-red-400" />
          </div>
          <h3 className="text-2xl font-black text-white mt-2">
            {language === 'bn' ? toBengaliNumber(outOfStockCount) : outOfStockCount}
          </h3>
          <p className="text-[10px] text-red-400/80 mt-1">Unavailable for customer purchase</p>
        </div>
      </div>

      {/* Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 p-3 rounded-2xl">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'all', labelBn: 'সকল প্রোডাক্ট', labelEn: 'All Products' },
            { id: 'low_stock', labelBn: 'কম স্টক', labelEn: 'Low Stock' },
            { id: 'out_of_stock', labelBn: 'স্টক শেষ', labelEn: 'Out of Stock' },
            { id: 'history', labelBn: 'স্টক হিস্ট্রি লগ', labelEn: 'Adjustment Logs' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                activeSubTab === tab.id 
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-950/40' 
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
              }`}
            >
              {language === 'bn' ? tab.labelBn : tab.labelEn}
            </button>
          ))}
        </div>

        {activeSubTab !== 'history' && (
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={language === 'bn' ? 'নাম বা SKU দিয়ে খুঁজুন...' : 'Search stock...'}
              className="pl-8.5 pr-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 focus:border-rose-500 outline-none w-full sm:w-56"
            />
          </div>
        )}
      </div>

      {/* Content View: Products Stock Table OR Stock History Logs */}
      {activeSubTab !== 'history' ? (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-300">
              <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
                <tr>
                  <th className="py-3.5 px-4">{language === 'bn' ? 'পণ্য' : 'Product'}</th>
                  <th className="py-3.5 px-4">{language === 'bn' ? 'ক্যাটাগরি' : 'Category'}</th>
                  <th className="py-3.5 px-4">{language === 'bn' ? 'বর্তমান স্টক' : 'Current Stock'}</th>
                  <th className="py-3.5 px-4">{language === 'bn' ? 'স্টক অবস্থা' : 'Stock Status'}</th>
                  <th className="py-3.5 px-4 text-right">{language === 'bn' ? 'স্টক অ্যাডজাস্টমেন্ট' : 'Quick Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredProducts.map(product => {
                  const isLow = product.stock > 0 && product.stock <= lowStockThreshold;
                  const isOut = product.stock === 0;

                  return (
                    <tr key={product.id} className="hover:bg-neutral-800/40 transition">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img src={product.image} alt="" className="w-10 h-10 rounded-xl object-cover bg-neutral-800 shrink-0" />
                          <div className="overflow-hidden max-w-xs">
                            <p className="font-bold text-neutral-100 truncate">
                              {language === 'bn' ? product.titleBn : product.titleEn}
                            </p>
                            <p className="text-[10px] text-neutral-500 font-mono">
                              SKU: {product.sku || product.id}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 capitalize font-semibold text-neutral-400">
                        {product.category}
                      </td>
                      <td className="py-3 px-4 font-black text-sm text-white">
                        {language === 'bn' ? toBengaliNumber(product.stock) : product.stock} <span className="text-xs text-neutral-500 font-normal">units</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-1 rounded-xl text-[10px] font-bold ${
                          isOut ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                          isLow ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                          'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                        }`}>
                          {isOut ? (language === 'bn' ? 'স্টক শেষ' : 'Out of Stock') :
                           isLow ? (language === 'bn' ? 'রিফিল প্রয়োজন' : 'Low Stock Alert') :
                           (language === 'bn' ? 'পর্যাপ্ত মজুদ' : 'Optimal')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Stock In (+) */}
                          <button
                            onClick={() => handleOpenAdjust(product, 'stock_in')}
                            className="px-2.5 py-1 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                            title="Stock In (+)"
                          >
                            <Plus className="w-3 h-3" />
                            <span>Stock In</span>
                          </button>

                          {/* Stock Out (-) */}
                          <button
                            onClick={() => handleOpenAdjust(product, 'stock_out')}
                            className="px-2.5 py-1 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                            title="Stock Out (-)"
                          >
                            <Minus className="w-3 h-3" />
                            <span>Stock Out</span>
                          </button>

                          {/* Adjust exact */}
                          <button
                            onClick={() => handleOpenAdjust(product, 'adjustment')}
                            className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition cursor-pointer"
                            title="Set Exact Value"
                          >
                            <SlidersHorizontal className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Stock History Log View */
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
          <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <History className="w-4 h-4 text-rose-400" />
              <span>{language === 'bn' ? 'সর্বশেষ স্টক অডিট ও মুভমেন্ট লগ' : 'Stock Movement & Audit Logs'}</span>
            </h3>
            <span className="text-xs text-neutral-500">{stockLogs.length} entries recorded</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-300">
              <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-4">{language === 'bn' ? 'তারিখ ও সময়' : 'Timestamp'}</th>
                  <th className="py-3 px-4">{language === 'bn' ? 'পণ্য' : 'Product'}</th>
                  <th className="py-3 px-4">{language === 'bn' ? 'টাইপ' : 'Type'}</th>
                  <th className="py-3 px-4">{language === 'bn' ? 'পরিবর্তন' : 'Qty'}</th>
                  <th className="py-3 px-4">{language === 'bn' ? 'পূর্বের > বর্তমান' : 'Prev > New'}</th>
                  <th className="py-3 px-4">{language === 'bn' ? 'কারণ ও বিবরণ' : 'Reason / Note'}</th>
                  <th className="py-3 px-4">{language === 'bn' ? 'অপারেটর' : 'Admin'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {stockLogs.map(log => (
                  <tr key={log.id} className="hover:bg-neutral-800/40 transition">
                    <td className="py-3 px-4 text-neutral-400 font-mono text-[11px]">
                      {log.date}
                    </td>
                    <td className="py-3 px-4 font-bold text-neutral-100 max-w-xs truncate">
                      {log.productName}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase ${
                        log.type === 'stock_in' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        log.type === 'stock_out' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                        log.type === 'order' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                        'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                      }`}>
                        {log.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-bold">
                      <span className={log.quantity > 0 ? 'text-emerald-400' : 'text-red-400'}>
                        {log.quantity > 0 ? `+${log.quantity}` : log.quantity}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-neutral-400 font-mono">
                      {log.previousStock} → <span className="text-white font-bold">{log.newStock}</span>
                    </td>
                    <td className="py-3 px-4 text-neutral-300">
                      {log.reason}
                    </td>
                    <td className="py-3 px-4 text-[11px] text-neutral-400">
                      {log.adminName}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {adjustingProduct && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 w-full max-w-md rounded-3xl p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h3 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                <Boxes className="w-5 h-5 text-rose-600" />
                <span>{language === 'bn' ? 'স্টক সমন্বয় করুন' : 'Adjust Stock'}</span>
              </h3>
              <button 
                type="button"
                onClick={() => setAdjustingProduct(null)} 
                className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-neutral-50 rounded-2xl border border-neutral-200 flex items-center gap-3">
              <img src={adjustingProduct.image} alt="" className="w-12 h-12 rounded-xl object-cover border border-neutral-200 shadow-2xs" />
              <div>
                <p className="text-xs font-bold text-neutral-900 line-clamp-1">{adjustingProduct.titleBn}</p>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  {language === 'bn' ? 'বর্তমান মজুদ:' : 'Current Stock:'} <span className="font-bold text-rose-600">{adjustingProduct.stock}</span>
                </p>
              </div>
            </div>

            <form onSubmit={handleConfirmAdjustment} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {language === 'bn' ? 'অ্যাকশন নির্বাচন:' : 'Adjustment Type:'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustmentType('stock_in')}
                    className={`py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      adjustmentType === 'stock_in' ? 'bg-emerald-600 text-white border-emerald-500 shadow-xs' : 'bg-neutral-50 text-neutral-600 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    + Stock In
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustmentType('stock_out')}
                    className={`py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      adjustmentType === 'stock_out' ? 'bg-amber-600 text-white border-amber-500 shadow-xs' : 'bg-neutral-50 text-neutral-600 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    - Stock Out
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustmentType('adjustment')}
                    className={`py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      adjustmentType === 'adjustment' ? 'bg-purple-600 text-white border-purple-500 shadow-xs' : 'bg-neutral-50 text-neutral-600 border-neutral-200 hover:bg-neutral-100'
                    }`}
                  >
                    Set Exact
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {adjustmentType === 'adjustment' 
                    ? (language === 'bn' ? 'নতুন মোট স্টক সংখ্যা' : 'New Exact Stock Level')
                    : (language === 'bn' ? 'যোগ বা বিয়োগের পরিমাণ' : 'Quantity to Add/Deduct')}
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  value={adjustmentAmount}
                  onChange={(e) => setAdjustmentAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-2xl text-sm font-black text-neutral-900 focus:border-rose-500 outline-none shadow-2xs"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-800">
                  {language === 'bn' ? 'সমন্বয়ের কারণ / নোট:' : 'Reason / Note:'}
                </label>
                <input
                  type="text"
                  required
                  value={adjustmentReason}
                  onChange={(e) => setAdjustmentReason(e.target.value)}
                  placeholder="e.g. Factory consignment arrived"
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-2xl text-xs text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 outline-none shadow-2xs"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setAdjustingProduct(null)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-neutral-600 hover:text-neutral-900 bg-neutral-100 hover:bg-neutral-200 transition cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl text-xs font-black text-white bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 shadow-md shadow-rose-600/20 cursor-pointer transition"
                >
                  {language === 'bn' ? 'স্টক আপডেট করুন' : 'Confirm Stock'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
