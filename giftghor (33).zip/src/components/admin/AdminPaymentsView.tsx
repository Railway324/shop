import React, { useState, useMemo } from 'react';
import { 
  CreditCard, 
  Search, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  AlertCircle, 
  DollarSign, 
  ShieldCheck, 
  Smartphone, 
  Banknote, 
  Copy, 
  Check, 
  ExternalLink,
  Lock
} from 'lucide-react';
import { Order, Language, PaymentStatus } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';
import { safeDateToLocaleString } from '../../utils/dateUtils';

interface AdminPaymentsViewProps {
  orders?: Order[];
  language: Language;
  onUpdatePaymentStatus?: (orderId: string, status: PaymentStatus, trxId?: string) => void;
}

export const AdminPaymentsView: React.FC<AdminPaymentsViewProps> = ({
  orders = [],
  language,
  onUpdatePaymentStatus,
}) => {
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'bkash' | 'nagad' | 'cod' | 'card'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'unpaid' | 'refunded'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedTrx, setCopiedTrx] = useState<string | null>(null);

  // Filtered Orders / Transactions
  const transactions = useMemo(() => {
    return orders.filter(o => {
      if (paymentFilter !== 'all' && o.paymentMethod !== paymentFilter) return false;
      if (statusFilter === 'paid' && o.paymentStatus !== 'paid') return false;
      if (statusFilter === 'unpaid' && (o.paymentStatus === 'paid' || o.paymentStatus === 'refunded')) return false;
      if (statusFilter === 'refunded' && o.paymentStatus !== 'refunded') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTrx = String(o.trxId || '').toLowerCase().includes(q);
        const matchId = String(o.id || '').toLowerCase().includes(q);
        const matchCustomer = String(o.customerName || '').toLowerCase().includes(q);
        const matchPhone = String(o.phone || '').toLowerCase().includes(q);
        return matchTrx || matchId || matchCustomer || matchPhone;
      }
      return true;
    });
  }, [orders, paymentFilter, statusFilter, searchQuery]);

  // Method Volume Calculations
  const codTotal = orders.filter(o => o.paymentMethod === 'cod' && o.orderStatus !== 'cancelled').reduce((s, o) => s + (Number(o.total) || 0), 0);
  const bkashTotal = orders.filter(o => o.paymentMethod === 'bkash' && o.orderStatus !== 'cancelled').reduce((s, o) => s + (Number(o.total) || 0), 0);
  const nagadTotal = orders.filter(o => o.paymentMethod === 'nagad' && o.orderStatus !== 'cancelled').reduce((s, o) => s + (Number(o.total) || 0), 0);
  const cardTotal = orders.filter(o => o.paymentMethod === 'card' && o.orderStatus !== 'cancelled').reduce((s, o) => s + (Number(o.total) || 0), 0);

  const handleCopyTrx = (trx: string) => {
    navigator.clipboard.writeText(trx);
    setCopiedTrx(trx);
    setTimeout(() => setCopiedTrx(null), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'পেমেন্ট ও ট্রানজ্যাকশন ভেরিফিকেশন' : 'Payment Reconciliation & MFS'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'bKash, Nagad, Card এবং ক্যাশ অন ডেলিভারি পেমেন্টের হিসাব ও TrxID যাচাই করুন।' 
              : 'Audit MFS transaction IDs, verify manual payments and track payment channels.'}
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs font-bold text-emerald-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Payment Security Guard Active</span>
        </div>
      </div>

      {/* Channel Volume Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* bKash */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-pink-400">bKash MFS</span>
            <Smartphone className="w-4 h-4 text-pink-400" />
          </div>
          <h3 className="text-lg sm:text-xl font-black text-white mt-2">
            {formatPrice(bkashTotal, language)}
          </h3>
          <p className="text-[10px] text-neutral-500 mt-0.5">
            {orders.filter(o => o.paymentMethod === 'bkash').length} transactions
          </p>
        </div>

        {/* Nagad */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-orange-400">Nagad MFS</span>
            <Smartphone className="w-4 h-4 text-orange-400" />
          </div>
          <h3 className="text-lg sm:text-xl font-black text-white mt-2">
            {formatPrice(nagadTotal, language)}
          </h3>
          <p className="text-[10px] text-neutral-500 mt-0.5">
            {orders.filter(o => o.paymentMethod === 'nagad').length} transactions
          </p>
        </div>

        {/* COD */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400">Cash on Delivery</span>
            <Banknote className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-lg sm:text-xl font-black text-white mt-2">
            {formatPrice(codTotal, language)}
          </h3>
          <p className="text-[10px] text-neutral-500 mt-0.5">
            {orders.filter(o => o.paymentMethod === 'cod').length} shipments
          </p>
        </div>

        {/* Card */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-blue-400">Debit / Credit Card</span>
            <CreditCard className="w-4 h-4 text-blue-400" />
          </div>
          <h3 className="text-lg sm:text-xl font-black text-white mt-2">
            {formatPrice(cardTotal, language)}
          </h3>
          <p className="text-[10px] text-neutral-500 mt-0.5">
            {orders.filter(o => o.paymentMethod === 'card').length} payments
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-3xl space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative sm:col-span-1">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search TrxID, order #, or phone..."
              className="w-full pl-9.5 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 placeholder-neutral-500 focus:border-rose-500 outline-none"
            />
          </div>

          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value as any)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 outline-none cursor-pointer"
          >
            <option value="all">All Channels (bKash, Nagad, COD, Card)</option>
            <option value="bkash">bKash Only</option>
            <option value="nagad">Nagad Only</option>
            <option value="cod">Cash on Delivery (COD)</option>
            <option value="card">Cards</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 outline-none cursor-pointer"
          >
            <option value="all">All Verification Statuses</option>
            <option value="paid">Verified Paid Only</option>
            <option value="unpaid">Unverified / Pending</option>
            <option value="refunded">Refunded Only</option>
          </select>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
              <tr>
                <th className="py-3.5 px-4">Order & Date</th>
                <th className="py-3.5 px-4">Customer & Phone</th>
                <th className="py-3.5 px-4">Method & Channel</th>
                <th className="py-3.5 px-4">Transaction ID (TrxID)</th>
                <th className="py-3.5 px-4">Amount</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Verification Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-neutral-500">
                    <CreditCard className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                    <p>No payment records match the current filters.</p>
                  </td>
                </tr>
              ) : (
                transactions.map(order => (
                  <tr key={order.id} className="hover:bg-neutral-800/40 transition">
                    <td className="py-3 px-4">
                      <p className="font-mono font-bold text-rose-400">#{order.id}</p>
                      <p className="text-[10px] text-neutral-500">
                        {safeDateToLocaleString(order.date)}
                      </p>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-neutral-100">{order.customerName}</p>
                      <p className="text-[10px] text-neutral-400">{order.phone}</p>
                    </td>
                    <td className="py-3 px-4">
                      <span className="uppercase font-bold text-xs text-white">
                        {order.paymentMethod}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {order.trxId ? (
                        <div className="flex items-center gap-1.5 font-mono text-[11px] text-emerald-400 font-bold">
                          <span>{order.trxId}</span>
                          <button
                            onClick={() => handleCopyTrx(order.trxId!)}
                            className="p-1 hover:text-white transition"
                            title="Copy TrxID"
                          >
                            {copiedTrx === order.trxId ? <Check className="w-3 h-3 text-white" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-neutral-500 italic">COD / Cash on Arrival</span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-black text-sm text-white">
                      {formatPrice(order.total, language)}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold capitalize ${
                        order.paymentStatus === 'paid' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        order.paymentStatus === 'refunded' ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30' :
                        'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}>
                        {order.paymentStatus || 'Pending'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {order.paymentStatus !== 'paid' && (
                          <button
                            onClick={() => onUpdatePaymentStatus(order.id, 'paid', order.trxId)}
                            className="px-2.5 py-1 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition cursor-pointer"
                          >
                            Mark Paid
                          </button>
                        )}
                        {order.paymentStatus === 'paid' && (
                          <button
                            onClick={() => onUpdatePaymentStatus(order.id, 'pending')}
                            className="px-2.5 py-1 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border border-amber-500/30 text-xs font-bold transition cursor-pointer"
                          >
                            Mark Unpaid
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
