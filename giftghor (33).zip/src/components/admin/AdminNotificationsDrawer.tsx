import React from 'react';
import { 
  Bell, 
  X, 
  ShoppingBag, 
  AlertTriangle, 
  CheckCircle2, 
  CreditCard, 
  Trash2,
  Check
} from 'lucide-react';
import { AdminNotification, Language } from '../../types';

interface AdminNotificationsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications?: AdminNotification[];
  language: Language;
  onMarkAsRead?: (id: string) => void;
  onClearAll?: () => void;
  onSelectNotification?: (notification: AdminNotification) => void;
}

export const AdminNotificationsDrawer: React.FC<AdminNotificationsDrawerProps> = ({
  isOpen,
  onClose,
  notifications = [],
  language,
  onMarkAsRead,
  onClearAll,
  onSelectNotification,
}) => {
  if (!isOpen) return null;

  const notifList = Array.isArray(notifications) ? notifications : [];
  const unreadCount = notifList.filter(n => !n.isRead && !n.read).length;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-xs transition-opacity" 
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-sm bg-neutral-900 border-l border-neutral-800 shadow-2xl flex flex-col">
          {/* Top Bar */}
          <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">System Notifications</h3>
                <p className="text-[10px] text-neutral-400">
                  {unreadCount} unread alerts
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              {notifList.length > 0 && (
                <button
                  onClick={onClearAll}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition text-xs"
                  title="Clear all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* List Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {notifications.length === 0 ? (
              <div className="py-16 text-center text-neutral-500 space-y-2">
                <Bell className="w-10 h-10 mx-auto text-neutral-700 opacity-40" />
                <p className="text-xs">No notifications right now.</p>
              </div>
            ) : (
              notifications.map(item => {
                const getIcon = () => {
                  switch (item.type) {
                    case 'order':
                      return <ShoppingBag className="w-4 h-4 text-rose-400" />;
                    case 'low_stock':
                      return <AlertTriangle className="w-4 h-4 text-amber-400" />;
                    case 'payment':
                      return <CreditCard className="w-4 h-4 text-emerald-400" />;
                    default:
                      return <Bell className="w-4 h-4 text-blue-400" />;
                  }
                };

                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      onMarkAsRead(item.id);
                      if (onSelectNotification) onSelectNotification(item);
                    }}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer space-y-1.5 relative ${
                      item.isRead 
                        ? 'bg-neutral-950/40 border-neutral-800/60 opacity-75' 
                        : 'bg-neutral-950 border-neutral-700/80 shadow-md'
                    }`}
                  >
                    {!item.isRead && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 absolute top-3 right-3 animate-ping" />
                    )}

                    <div className="flex items-center gap-2">
                      {getIcon()}
                      <h4 className="text-xs font-bold text-white pr-4">{item.title}</h4>
                    </div>

                    <p className="text-[11px] text-neutral-300 leading-relaxed">
                      {item.message}
                    </p>

                    <p className="text-[9px] text-neutral-500 pt-1 font-mono">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(item.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
