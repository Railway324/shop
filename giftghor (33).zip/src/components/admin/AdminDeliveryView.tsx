import React, { useState } from 'react';
import { 
  Truck, 
  MapPin, 
  DollarSign, 
  Save, 
  Check, 
  AlertCircle, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { DeliverySettings, Language } from '../../types';
import { formatPrice } from '../../utils/translations';

interface AdminDeliveryViewProps {
  deliverySettings: DeliverySettings;
  language: Language;
  onSaveSettings: (settings: DeliverySettings) => void;
}

export const AdminDeliveryView: React.FC<AdminDeliveryViewProps> = ({
  deliverySettings,
  language,
  onSaveSettings,
}) => {
  const [insideDhakaFee, setInsideDhakaFee] = useState(String(deliverySettings.insideDhakaFee));
  const [outsideDhakaFee, setOutsideDhakaFee] = useState(String(deliverySettings.outsideDhakaFee));
  const [freeShippingThreshold, setFreeShippingThreshold] = useState(
    deliverySettings.freeShippingThreshold ? String(deliverySettings.freeShippingThreshold) : '1500'
  );
  const [estimatedInside, setEstimatedInside] = useState(deliverySettings.estimatedDaysInside || '24-48 Hours');
  const [estimatedOutside, setEstimatedOutside] = useState(deliverySettings.estimatedDaysOutside || '3-5 Days');
  const [couriers, setCouriers] = useState(deliverySettings.couriers);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleToggleCourier = (id: string) => {
    setCouriers(prev => 
      prev.map(c => c.id === id ? { ...c, enabled: !c.enabled } : c)
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: DeliverySettings = {
      insideDhakaFee: Number(insideDhakaFee) || 65,
      outsideDhakaFee: Number(outsideDhakaFee) || 120,
      freeShippingThreshold: freeShippingThreshold ? Number(freeShippingThreshold) : undefined,
      estimatedDaysInside: estimatedInside.trim(),
      estimatedDaysOutside: estimatedOutside.trim(),
      couriers: couriers
    };
    onSaveSettings(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Truck className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'ডেলিভারি চার্জ ও কুরিয়ার সেটিংস' : 'Delivery Charges & Courier Configuration'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'ঢাকা সিটি ও ঢাকার বাইরের ডেলিভারি ফি, ফ্রি শিপিং থ্রেশহোল্ড এবং সমর্থিত কুরিয়ার পার্টনার্স।' 
              : 'Configure regional delivery rates, free shipping rules and courier integration parameters.'}
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold animate-fadeIn">
            <Check className="w-4 h-4" />
            <span>Saved Successfully!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Regional Shipping Rates */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <MapPin className="w-4 h-4 text-rose-400" />
            <span>Regional Shipping Fee Rules</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
              <label className="text-xs font-bold text-neutral-300">
                Inside Dhaka Charge (৳): *
              </label>
              <input
                type="number"
                required
                value={insideDhakaFee}
                onChange={(e) => setInsideDhakaFee(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white font-bold text-sm focus:border-rose-500 outline-none"
              />
              <p className="text-[10px] text-neutral-500">Standard charge for Dhaka metro addresses.</p>
            </div>

            <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
              <label className="text-xs font-bold text-neutral-300">
                Outside Dhaka Charge (৳): *
              </label>
              <input
                type="number"
                required
                value={outsideDhakaFee}
                onChange={(e) => setOutsideDhakaFee(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white font-bold text-sm focus:border-rose-500 outline-none"
              />
              <p className="text-[10px] text-neutral-500">All districts outside Dhaka.</p>
            </div>

            <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2 sm:col-span-2 lg:col-span-1">
              <label className="text-xs font-bold text-neutral-300">
                Free Delivery Threshold (৳):
              </label>
              <input
                type="number"
                value={freeShippingThreshold}
                onChange={(e) => setFreeShippingThreshold(e.target.value)}
                className="w-full px-3.5 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white font-bold text-sm focus:border-rose-500 outline-none"
              />
              <p className="text-[10px] text-neutral-500">Orders above this amount get free delivery.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="space-y-1 text-xs">
              <label className="text-neutral-400 font-medium">Estimated Delivery (Inside Dhaka):</label>
              <input
                type="text"
                value={estimatedInside}
                onChange={(e) => setEstimatedInside(e.target.value)}
                placeholder="24-48 Hours"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none"
              />
            </div>

            <div className="space-y-1 text-xs">
              <label className="text-neutral-400 font-medium">Estimated Delivery (Outside Dhaka):</label>
              <input
                type="text"
                value={estimatedOutside}
                onChange={(e) => setEstimatedOutside(e.target.value)}
                placeholder="3-5 Business Days"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none"
              />
            </div>
          </div>
        </div>

        {/* Courier Services Matrix */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Truck className="w-4 h-4 text-rose-400" />
            <span>Supported Courier Partners & Tracking</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {couriers.map(courier => (
              <div 
                key={courier.id}
                className="p-3.5 bg-neutral-950 rounded-2xl border border-neutral-800 flex items-center justify-between gap-3"
              >
                <div>
                  <p className="font-bold text-xs text-white">{courier.name}</p>
                  <p className="text-[10px] text-neutral-500 font-mono truncate max-w-xs">{courier.trackingUrlPrefix || 'Manual tracking'}</p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={courier.enabled}
                    onChange={() => handleToggleCourier(courier.id)}
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-600"></div>
                </label>
              </div>
            ))}
          </div>
        </div>

        {/* Submit */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Delivery Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};
