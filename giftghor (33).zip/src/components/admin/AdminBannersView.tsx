import React, { useState, useEffect } from 'react';
import { 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  Edit3, 
  Flame, 
  Clock, 
  Save, 
  Check, 
  ExternalLink,
  Sparkles,
  X,
  Layers,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { Banner, Language, WebsiteCustomizerSettings } from '../../types';
import { ImageUploadField } from '../common/ImageUploadField';
import { initialWebsiteCustomizerSettings, saveCustomizerSettingsToStorage, saveSettingsToServer } from '../../utils/storage';

interface AdminBannersViewProps {
  language: Language;
  customizerSettings?: WebsiteCustomizerSettings;
  onSaveCustomizerSettings?: (settings: WebsiteCustomizerSettings) => void;
}

export const AdminBannersView: React.FC<AdminBannersViewProps> = ({
  language,
  customizerSettings: propSettings,
  onSaveCustomizerSettings,
}) => {
  const [settings, setSettings] = useState<WebsiteCustomizerSettings>(() => {
    return propSettings || initialWebsiteCustomizerSettings;
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBannerIndex, setEditingBannerIndex] = useState<number | null>(null);
  
  const [bannerForm, setBannerForm] = useState<Banner>({
    id: `banner-${Date.now()}`,
    titleBn: '',
    titleEn: '',
    subtitleBn: '',
    subtitleEn: '',
    badgeBn: 'নতুন অফার',
    badgeEn: 'Special Offer',
    buttonTextBn: 'এখনই কিনুন',
    buttonTextEn: 'Order Now',
    imageUrl: '',
    bgGradient: 'from-rose-700 via-rose-800 to-neutral-950',
    linkCategory: 'all',
    linkUrl: ''
  });

  const heroBanners = settings.heroBanners || [];

  const handleOpenAdd = () => {
    setEditingBannerIndex(null);
    setBannerForm({
      id: `banner-${Date.now()}`,
      titleBn: 'নতুন আকর্ষণীয় কালেকশন',
      titleEn: 'New Seasonal Collection',
      subtitleBn: '১০০% প্রিমিয়াম সুতি ফেব্রিক ও ক্যাশ অন ডেলিভারি',
      subtitleEn: 'High density combed cotton with cash on delivery across Bangladesh',
      badgeBn: 'হট অফার',
      badgeEn: 'Flash Drop',
      buttonTextBn: 'এখনই অর্ডার করুন',
      buttonTextEn: 'Order Now',
      imageUrl: '/products/1719939868_L_3.jpg',
      bgGradient: 'from-rose-700 via-rose-800 to-neutral-950',
      linkCategory: 'all',
      linkUrl: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (index: number) => {
    setEditingBannerIndex(index);
    setBannerForm({ ...heroBanners[index] });
    setIsModalOpen(true);
  };

  const handleSaveBanner = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedList = [...heroBanners];
    if (editingBannerIndex !== null) {
      updatedList[editingBannerIndex] = bannerForm;
    } else {
      updatedList.push(bannerForm);
    }

    const updatedSettings: WebsiteCustomizerSettings = {
      ...settings,
      heroBanners: updatedList
    };

    setSettings(updatedSettings);
    onSaveCustomizerSettings?.(updatedSettings);
    saveCustomizerSettingsToStorage(updatedSettings);
    saveSettingsToServer(updatedSettings).catch(err => console.warn('Failed to sync settings to server:', err));
    setIsModalOpen(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleDeleteBanner = (index: number) => {
    const updatedList = heroBanners.filter((_, i) => i !== index);
    const updatedSettings: WebsiteCustomizerSettings = {
      ...settings,
      heroBanners: updatedList
    };

    setSettings(updatedSettings);
    onSaveCustomizerSettings?.(updatedSettings);
    saveCustomizerSettingsToStorage(updatedSettings);
    saveSettingsToServer(updatedSettings).catch(err => console.warn('Failed to sync settings to server:', err));
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleSaveFlashSale = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    onSaveCustomizerSettings?.(settings);
    saveCustomizerSettingsToStorage(settings);
    saveSettingsToServer(settings).catch(err => console.warn('Failed to sync settings to server:', err));
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Toast */}
      {savedSuccess && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white text-xs font-bold px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 animate-bounce border border-emerald-500">
          <CheckCircle2 className="w-4 h-4 text-white" />
          <span>{language === 'bn' ? 'ব্যানার ও সেটিংস সফলভাবে সেভ হয়েছে!' : 'Banners updated & saved successfully!'}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <ImageIcon className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'হোমপেজ হিরো ব্যানার ও স্লাইডার' : 'Homepage Hero Banners & Slider'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'হোমপেজের প্রধান স্লাইডার ব্যানার তৈরি, এডিট বা ডিলিট করুন এবং যেকোনো অফার পরিচালনা করুন।' 
              : 'Add custom hero carousel slides, upload photos from device, or delete existing banners.'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'bn' ? 'নতুন ব্যানার স্লাইড যোগ করুন' : 'Add Hero Slide'}</span>
        </button>
      </div>

      {/* Flash Sale Banner Configuration Card */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-rose-950/40 border border-rose-900/40 p-5 sm:p-6 rounded-3xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
              <Flame className="w-5 h-5 text-rose-400 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {language === 'bn' ? 'ফ্ল্যাশ সেল কাউন্টডাউন সেকশন' : 'Flash Sale Live Campaign'}
              </h3>
              <p className="text-xs text-neutral-400">
                {language === 'bn' ? 'হোমপেজে কাউন্টডাউন টাইমার ও বিশেষ ছাড় ব্যানার সক্রিয় করুন' : 'Homepage countdown timer and limited-time offer badges'}
              </p>
            </div>
          </div>

          <label className="flex items-center gap-2 cursor-pointer bg-neutral-950 px-3 py-1.5 rounded-xl border border-neutral-800">
            <input
              type="checkbox"
              checked={settings.flashSaleEnabled}
              onChange={(e) => {
                const updated = { ...settings, flashSaleEnabled: e.target.checked };
                setSettings(updated);
                onSaveCustomizerSettings?.(updated);
                saveCustomizerSettingsToStorage(updated);
              }}
              className="w-4 h-4 text-rose-600 rounded bg-neutral-900 border-neutral-700"
            />
            <span className="text-xs font-bold text-white">
              {settings.flashSaleEnabled ? (language === 'bn' ? 'চালু আছে' : 'Active') : (language === 'bn' ? 'বন্ধ' : 'Disabled')}
            </span>
          </label>
        </div>

        {settings.flashSaleEnabled && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-neutral-800 animate-fadeIn text-xs">
            <div>
              <label className="text-neutral-300 font-semibold block mb-1">
                {language === 'bn' ? 'ক্যাম্পেইন টাইটেল (বাংলা):' : 'Campaign Title (Bangla):'}
              </label>
              <input
                type="text"
                value={settings.flashSaleTitleBn || ''}
                onChange={(e) => setSettings(prev => ({ ...prev, flashSaleTitleBn: e.target.value }))}
                onBlur={handleSaveFlashSale}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="text-neutral-300 font-semibold block mb-1">
                {language === 'bn' ? 'ক্যাম্পেইন টাইটেল (English):' : 'Campaign Title (English):'}
              </label>
              <input
                type="text"
                value={settings.flashSaleTitleEn || ''}
                onChange={(e) => setSettings(prev => ({ ...prev, flashSaleTitleEn: e.target.value }))}
                onBlur={handleSaveFlashSale}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="text-neutral-300 font-semibold block mb-1">
                {language === 'bn' ? 'সাবটাইটেল (বাংলা):' : 'Subtitle (Bangla):'}
              </label>
              <input
                type="text"
                value={settings.flashSaleSubtitleBn || ''}
                onChange={(e) => setSettings(prev => ({ ...prev, flashSaleSubtitleBn: e.target.value }))}
                onBlur={handleSaveFlashSale}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="text-neutral-300 font-semibold block mb-1">
                {language === 'bn' ? 'সাবটাইটেল (English):' : 'Subtitle (English):'}
              </label>
              <input
                type="text"
                value={settings.flashSaleSubtitleEn || ''}
                onChange={(e) => setSettings(prev => ({ ...prev, flashSaleSubtitleEn: e.target.value }))}
                onBlur={handleSaveFlashSale}
                className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white outline-none focus:border-rose-500"
              />
            </div>
          </div>
        )}
      </div>

      {/* Hero Banners Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-black text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-rose-400" />
            <span>{language === 'bn' ? `বর্তমান ব্যানারসমূহ (${heroBanners.length} টি)` : `Active Banners (${heroBanners.length})`}</span>
          </h3>

          <label className="flex items-center gap-2 cursor-pointer bg-neutral-900 px-3 py-1.5 rounded-xl border border-neutral-800 text-xs text-neutral-300">
            <input
              type="checkbox"
              checked={settings.useCustomBannersOnly}
              onChange={(e) => {
                const updated = { ...settings, useCustomBannersOnly: e.target.checked };
                setSettings(updated);
                onSaveCustomizerSettings?.(updated);
                saveCustomizerSettingsToStorage(updated);
                saveSettingsToServer(updated).catch(err => console.warn('Failed to sync settings to server:', err));
              }}
              className="w-4 h-4 text-rose-600 rounded bg-neutral-900 border-neutral-700"
            />
            <span>{language === 'bn' ? 'শুধুমাত্র কাস্টম ব্যানার দেখান' : 'Custom Banners Exclusively'}</span>
          </label>
        </div>

        {heroBanners.length === 0 ? (
          <div className="p-10 rounded-3xl bg-neutral-900 border border-dashed border-neutral-800 text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-neutral-950 text-neutral-500 flex items-center justify-center mx-auto">
              <ImageIcon className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-neutral-300">
                {language === 'bn' ? 'কোনো ব্যানার নেই' : 'No hero banners configured'}
              </h4>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                {language === 'bn' 
                  ? 'আপনার স্টোরের জন্য নতুন ব্যানার যোগ করতে উপরের "নতুন ব্যানার স্লাইড যোগ করুন" বাটনে চাপুন।' 
                  : 'Click the button above to upload artwork and create your first banner slide.'}
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {heroBanners.map((banner, index) => (
              <div 
                key={banner.id || index}
                className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden group hover:border-neutral-700 transition space-y-4 p-5 flex flex-col justify-between shadow-lg"
              >
                <div className="relative h-44 rounded-2xl overflow-hidden bg-neutral-950">
                  <img 
                    src={banner.imageUrl || '/logo.png'} 
                    alt="" 
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex flex-col justify-end p-4">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-600 text-white w-fit mb-1 uppercase tracking-wider">
                      {banner.badgeBn || banner.badgeEn || 'PROMO'}
                    </span>
                    <h4 className="text-white font-black text-sm line-clamp-1">
                      {language === 'bn' ? banner.titleBn : banner.titleEn}
                    </h4>
                    <p className="text-[11px] text-neutral-300 line-clamp-1">
                      {language === 'bn' ? banner.subtitleBn : banner.subtitleEn}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-neutral-800/80">
                  <span className="text-[11px] text-neutral-400 font-mono">
                    #{index + 1} • {banner.buttonTextEn || 'Order Now'}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(index)}
                      className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-neutral-400" />
                      <span>{language === 'bn' ? 'এডিট' : 'Edit'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteBanner(index)}
                      className="px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 hover:text-red-300 border border-red-500/30 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                      title="Delete Banner"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'মুছুন' : 'Delete'}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Banner Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 w-full max-w-lg rounded-3xl p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h3 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-rose-600" />
                <span>{editingBannerIndex !== null ? (language === 'bn' ? 'ব্যানার এডিট করুন' : 'Edit Hero Banner') : (language === 'bn' ? 'নতুন হিরো ব্যানার' : 'Add Hero Banner')}</span>
              </h3>
              <button 
                type="button"
                onClick={() => setIsModalOpen(false)} 
                className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 cursor-pointer transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBanner} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-800 font-bold block mb-1">
                    {language === 'bn' ? 'হেডলাইন (বাংলা) *' : 'Headline (Bangla) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={bannerForm.titleBn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, titleBn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none focus:border-rose-500 shadow-2xs"
                  />
                </div>

                <div>
                  <label className="text-neutral-800 font-bold block mb-1">
                    {language === 'bn' ? 'হেডলাইন (English) *' : 'Headline (English) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={bannerForm.titleEn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, titleEn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none focus:border-rose-500 shadow-2xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-700 block mb-1">
                    {language === 'bn' ? 'সাবটাইটেল (বাংলা)' : 'Subtitle (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={bannerForm.subtitleBn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, subtitleBn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none focus:border-rose-500 shadow-2xs"
                  />
                </div>

                <div>
                  <label className="text-neutral-700 block mb-1">
                    {language === 'bn' ? 'সাবটাইটেল (English)' : 'Subtitle (English)'}
                  </label>
                  <input
                    type="text"
                    value={bannerForm.subtitleEn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, subtitleEn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none focus:border-rose-500 shadow-2xs"
                  />
                </div>
              </div>

              {/* Direct Phone Photo Upload */}
              <div>
                <ImageUploadField
                  label={language === 'bn' ? 'ব্যানার ছবি আপলোড (ফোন থেকে সরাসরি সিলেক্ট করুন)' : 'Banner Image (Upload from Phone)'}
                  sublabel={language === 'bn' ? 'গ্যালারি / ক্যামেরা' : 'Gallery / Camera'}
                  value={bannerForm.imageUrl}
                  onChange={(img) => setBannerForm(prev => ({ ...prev, imageUrl: img }))}
                  aspectRatio="banner"
                  language={language}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-700 block mb-1">
                    {language === 'bn' ? 'ব্যাজ ট্যাগ (বাংলা)' : 'Badge Tag (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={bannerForm.badgeBn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, badgeBn: e.target.value }))}
                    placeholder="হট ড্রপ / স্পেশাল অফার"
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none focus:border-rose-500 shadow-2xs"
                  />
                </div>
                <div>
                  <label className="text-neutral-700 block mb-1">
                    {language === 'bn' ? 'ব্যাজ ট্যাগ (English)' : 'Badge Tag (English)'}
                  </label>
                  <input
                    type="text"
                    value={bannerForm.badgeEn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, badgeEn: e.target.value }))}
                    placeholder="Hot Drop / Exclusive"
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 outline-none focus:border-rose-500 shadow-2xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-bold cursor-pointer transition"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black shadow-md shadow-rose-600/20 cursor-pointer transition"
                >
                  {language === 'bn' ? 'ব্যানার সংরক্ষণ করুন' : 'Save Slide'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
