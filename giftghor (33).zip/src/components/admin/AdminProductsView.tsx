import React, { useState, useMemo, useRef } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  Copy, 
  Check, 
  X, 
  Image as ImageIcon, 
  Sparkles, 
  Flame, 
  Layers, 
  AlertCircle, 
  ArrowUpDown, 
  CheckSquare, 
  Square, 
  MoreVertical,
  SlidersHorizontal,
  Upload,
  Globe,
  Tag,
  Package,
  FolderOpen,
  Eye,
  RefreshCw,
  PlusCircle,
  MinusCircle,
  HelpCircle,
  CheckCircle2,
  Download,
  CloudLightning,
  Pin,
  Sliders,
  Camera,
  Truck,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Product, Language, CategoryId, ProductVariant, Category } from '../../types';
import { initialCategories } from '../../data/initialData';
import { formatPrice, toBengaliNumber } from '../../utils/translations';
import { syncProductsToServer } from '../../utils/storage';
import { ImageUploadField, MultiImageUpload } from '../common/ImageUploadField';
import { detectProductCategoryFromTitle, generateAutoSeo, normalizeCategoryId } from '../../utils/categoryUtils';

interface AdminProductsViewProps {
  products?: Product[];
  categories?: Category[];
  language: Language;
  onAddProduct?: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  onUpdateProduct?: (product: Product) => void;
  onDeleteProduct?: (productId: string) => void;
  onDuplicateProduct?: (product: Product) => void;
  onReorderProduct?: (productId: string, newOrder: number) => void;
  onBulkDelete?: (productIds: string[]) => void;
  onBulkStatusUpdate?: (productIds: string[], status: 'active' | 'inactive') => void;
  onBulkStockUpdate?: (productIds: string[], stock: number) => void;
  onBulkCategoryUpdate?: (productIds: string[], category: CategoryId) => void;
  onNavigateToOrdering?: () => void;
}

// Preset quick demo images for convenience
const PRESET_SAMPLE_IMAGES = [
  { label: 'Oversized T-Shirt', url: '/products/1719939868_L_3.jpg', category: 'fashion' },
  { label: 'Hoodie / Sweatshirt', url: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&q=80', category: 'fashion' },
  { label: 'Men Cotton Panjabi', url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800&q=80', category: 'panjabi' },
  { label: 'Women Floral Kurti', url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&q=80', category: 'three_piece' },
  { label: 'Casual Denim Shirt', url: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&q=80', category: 'shirt' },
  { label: 'Sports Sneakers', url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80', category: 'shoes' },
  { label: 'Luxury Chrono Watch', url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&q=80', category: 'watch' },
  { label: 'Leather Wallet', url: 'https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&q=80', category: 'leather' },
];

export const AdminProductsView: React.FC<AdminProductsViewProps> = ({
  products = [],
  categories = [],
  language,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onDuplicateProduct,
  onReorderProduct,
  onBulkDelete,
  onBulkStatusUpdate,
  onBulkStockUpdate,
  onBulkCategoryUpdate,
  onNavigateToOrdering,
}) => {
  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [stockFilter, setStockFilter] = useState<'all' | 'in_stock' | 'low_stock' | 'out_of_stock'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [featuredFilter, setFeaturedFilter] = useState<'all' | 'featured' | 'flash_sale'>('all');
  const [sortBy, setSortBy] = useState<'display_order' | 'newest' | 'price_asc' | 'price_desc' | 'stock_asc' | 'stock_desc' | 'name'>('display_order');
  const [positionInputs, setPositionInputs] = useState<Record<string, string>>({});
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(20);

  // Selected for Bulk Actions
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [bulkActionType, setBulkActionType] = useState<string>('');
  const [bulkStockVal, setBulkStockVal] = useState<number>(20);
  const [bulkCategoryVal, setBulkCategoryVal] = useState<CategoryId>('clothes');

  // Product Add / Edit Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const availableCategories = useMemo(() => {
    return categories && categories.length > 0 ? categories : initialCategories;
  }, [categories]);

  // Form Fields
  const [formTitleBn, setFormTitleBn] = useState('');
  const [formTitleEn, setFormTitleEn] = useState('');
  const [formCategory, setFormCategory] = useState<CategoryId>('clothes');
  const [formSubcategory, setFormSubcategory] = useState('');
  const [formPrice, setFormPrice] = useState('450');
  const [formOriginalPrice, setFormOriginalPrice] = useState('650');
  const [formFreeDelivery, setFormFreeDelivery] = useState(false);
  const [formSku, setFormSku] = useState('');
  const [formStock, setFormStock] = useState('30');
  const [formBrand, setFormBrand] = useState('Shopping Mall Signature');
  const [formTags, setFormTags] = useState('cotton, oversize, streetwear, premium');
  
  // Image Upload States
  const [imageUploadMode, setImageUploadMode] = useState<'gallery' | 'url'>('gallery');
  const [formImage, setFormImage] = useState('');
  const [galleryImagesList, setGalleryImagesList] = useState<string[]>([]);
  const [isDraggingMain, setIsDraggingMain] = useState(false);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // Description & Details
  const [formDescBn, setFormDescBn] = useState('');
  const [formDescEn, setFormDescEn] = useState('');
  const [formSize, setFormSize] = useState('');
  const [formColor, setFormColor] = useState('');
  const [formWeight, setFormWeight] = useState('');
  const [formStatus, setFormStatus] = useState<'active' | 'inactive'>('active');
  const [formIsFeatured, setFormIsFeatured] = useState(true);
  const [formIsFlashSale, setFormIsFlashSale] = useState(false);
  const [formIsPinnedToTop, setFormIsPinnedToTop] = useState(false);
  const [formDisplayOrder, setFormDisplayOrder] = useState<string>('');
  const [formSeoTitle, setFormSeoTitle] = useState('');
  const [formSeoDescription, setFormSeoDescription] = useState('');
  const [autoDetectedCategoryBadge, setAutoDetectedCategoryBadge] = useState<string>('');
  const [showAdvancedSettings, setShowAdvancedSettings] = useState<boolean>(false);

  // Title change handlers (manual category remains preserved without AI auto-overrides)
  const handleTitleBnChange = (val: string) => {
    setFormTitleBn(val);
    if (!val.trim()) return;

    const autoSeo = generateAutoSeo(val, formDescBn || formDescEn);
    setFormSeoTitle(autoSeo.seoTitle);
    setFormSeoDescription(autoSeo.seoDescription);
  };

  const handleTitleEnChange = (val: string) => {
    setFormTitleEn(val);
    if (!val.trim()) return;

    const autoSeo = generateAutoSeo(formTitleBn || val, formDescBn || formDescEn);
    setFormSeoTitle(autoSeo.seoTitle);
    setFormSeoDescription(autoSeo.seoDescription);
  };

  const handleDescBnChange = (val: string) => {
    setFormDescBn(val);
    const title = formTitleBn || formTitleEn;
    if (title) {
      const autoSeo = generateAutoSeo(title, val);
      setFormSeoDescription(autoSeo.seoDescription);
    }
  };

  const handleDescEnChange = (val: string) => {
    setFormDescEn(val);
    const title = formTitleBn || formTitleEn;
    if (title && !formDescBn) {
      const autoSeo = generateAutoSeo(title, val);
      setFormSeoDescription(autoSeo.seoDescription);
    }
  };

  // Delete Confirmation Modal
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // File Input References
  const mainFileInputRef = useRef<HTMLInputElement>(null);
  const multiFileInputRef = useRef<HTMLInputElement>(null);

  // Server & Publish Sync States
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  const handleManualSync = async () => {
    setIsSyncing(true);
    setSyncFeedback(null);
    try {
      const ok = await syncProductsToServer(products);
      if (ok) {
        setSyncFeedback(
          language === 'bn' 
            ? 'সকল পণ্য সার্ভার ফাইলে সেভ হয়েছে! গুগল এআই স্টুডিওতে পাবলিশ করলে সাইটে প্রদর্শিত হবে।' 
            : 'All products saved to server file! Ready for AI Studio publish.'
        );
      } else {
        setSyncFeedback(language === 'bn' ? 'সিঙ্ক সম্পন্ন হয়নি' : 'Sync failed');
      }
    } catch (e) {
      setSyncFeedback(language === 'bn' ? 'সিঙ্ক করতে ত্রুটি হয়েছে' : 'Sync error');
    } finally {
      setIsSyncing(false);
      setTimeout(() => setSyncFeedback(null), 5000);
    }
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(products, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `gift_ghor_products_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    const list = products.filter(p => {
      if (selectedCategory !== 'all') {
        if (normalizeCategoryId(p.category) !== normalizeCategoryId(selectedCategory)) return false;
      }
      if (statusFilter === 'active' && p.status === 'inactive') return false;
      if (statusFilter === 'inactive' && p.status !== 'inactive') return false;

      if (stockFilter === 'in_stock' && p.stock <= 5) return false;
      if (stockFilter === 'low_stock' && (p.stock === 0 || p.stock > 5)) return false;
      if (stockFilter === 'out_of_stock' && p.stock !== 0) return false;

      if (featuredFilter === 'featured' && !p.isFeatured) return false;
      if (featuredFilter === 'flash_sale' && !p.isFlashSale) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = (p.titleBn || '').toLowerCase().includes(q) || (p.titleEn || '').toLowerCase().includes(q);
        const matchSku = (p.sku || p.id || '').toLowerCase().includes(q);
        const matchBrand = (p.brand || '').toLowerCase().includes(q);
        const matchCategory = (p.category || '').toLowerCase().includes(q);
        const matchTags = (p.tags || []).some(t => t.toLowerCase().includes(q));
        return matchTitle || matchSku || matchBrand || matchCategory || matchTags;
      }

      return true;
    });

    // Sorting
    return list.sort((a, b) => {
      if (sortBy === 'price_asc') return a.price - b.price;
      if (sortBy === 'price_desc') return b.price - a.price;
      if (sortBy === 'stock_asc') return a.stock - b.stock;
      if (sortBy === 'stock_desc') return b.stock - a.stock;
      if (sortBy === 'name') return (a.titleEn || a.titleBn).localeCompare(b.titleEn || b.titleBn);
      if (sortBy === 'newest') return (b.createdAt || '').localeCompare(a.createdAt || '');

      // Default: 'display_order' (Pin to top first, then 1, 2, 3...)
      if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
      if (!a.isPinnedToTop && b.isPinnedToTop) return 1;

      const ordA = typeof a.displayOrder === 'number' && a.displayOrder > 0 ? a.displayOrder : 99999;
      const ordB = typeof b.displayOrder === 'number' && b.displayOrder > 0 ? b.displayOrder : 99999;
      if (ordA !== ordB) return ordA - ordB;
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    });
  }, [products, selectedCategory, statusFilter, stockFilter, featuredFilter, searchQuery, sortBy]);

  // Reset page when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, selectedCategory, statusFilter, stockFilter, featuredFilter, sortBy, pageSize]);

  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / pageSize));
  const paginatedProducts = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredProducts.slice(start, start + pageSize);
  }, [filteredProducts, currentPage, pageSize]);

  // Quick inline position / serial reorder
  const handleQuickSetPosition = (productId: string, orderNum: number, e?: React.MouseEvent | React.FormEvent) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    if (isNaN(orderNum) || orderNum < 1) return;
    if (onReorderProduct) {
      onReorderProduct(productId, orderNum);
    } else if (onUpdateProduct) {
      const p = products.find(prod => prod.id === productId);
      if (p) onUpdateProduct({ ...p, displayOrder: orderNum });
    }
    // Clear input
    setPositionInputs(prev => {
      const next = { ...prev };
      delete next[productId];
      return next;
    });
  };

  // Open Modal for Add
  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setFormTitleBn('');
    setFormTitleEn('');
    setFormCategory('clothes');
    setFormSubcategory('');
    setFormPrice('750');
    setFormOriginalPrice('');
    setFormFreeDelivery(false);
    setFormSku(`SM-${Math.floor(1000 + Math.random() * 9000)}`);
    setFormStock('50');
    setFormBrand('Happy Shopping');
    setFormTags('');
    setFormImage('/products/1719939868_L_3.jpg');
    setGalleryImagesList([]);
    setImageUploadMode('gallery');
    setFormDescBn('');
    setFormDescEn('');
    setFormSize('');
    setFormColor('');
    setFormWeight('');
    setFormStatus('active');
    setFormIsFeatured(true);
    setFormIsFlashSale(false);
    setFormIsPinnedToTop(false);
    setFormDisplayOrder('');
    setFormSeoTitle('');
    setFormSeoDescription('');
    setAutoDetectedCategoryBadge('');
    setShowAdvancedSettings(false);
    setIsModalOpen(true);
  };

  // Open Modal for Edit
  const handleOpenEditModal = (p: Product) => {
    setEditingProduct(p);
    setFormTitleBn(p.titleBn || p.titleEn || '');
    setFormTitleEn(p.titleEn || p.titleBn || '');
    setFormCategory(p.category || 'others');
    setFormSubcategory(p.subcategory || '');
    setFormPrice(p.price !== undefined ? String(p.price) : '450');
    setFormOriginalPrice(p.originalPrice ? String(p.originalPrice) : '');
    setFormFreeDelivery(!!p.freeDelivery);
    setFormSku(p.sku || `SM-${p.id.slice(-4)}`);
    setFormStock(p.stock !== undefined ? String(p.stock) : '50');
    setFormBrand(p.brand || 'Happy Shopping');
    setFormTags(p.tags?.join(', ') || '');
    setFormImage(p.image || '/products/1719939868_L_3.jpg');
    setGalleryImagesList(p.additionalImages || []);
    setImageUploadMode((p.image || '').startsWith('data:') ? 'gallery' : 'url');
    setFormDescBn(p.descriptionBn || p.descriptionEn || `${p.titleBn || p.titleEn || 'পণ্য'} - প্রিমিয়াম কোয়ালিটি ও ১০০% ক্যাশ অন ডেলিভারি সুবিধা।`);
    setFormDescEn(p.descriptionEn || p.descriptionBn || '');
    setFormSize(p.size || '');
    setFormColor(p.color || '');
    setFormWeight(p.weight || '');
    setFormStatus(p.status || 'active');
    setFormIsFeatured(p.isFeatured ?? true);
    setFormIsFlashSale(p.isFlashSale ?? false);
    setFormIsPinnedToTop(p.isPinnedToTop ?? false);
    setFormDisplayOrder(p.displayOrder !== undefined ? String(p.displayOrder) : '');
    setFormSeoTitle(p.seoTitle || '');
    setFormSeoDescription(p.seoDescription || '');
    const detected = detectProductCategoryFromTitle(p.titleBn || p.titleEn);
    setAutoDetectedCategoryBadge(`${detected.badge} (${language === 'bn' ? detected.nameBn : detected.nameEn})`);
    setShowAdvancedSettings(false);
    setIsModalOpen(true);
  };

  // Process File to Base64 (Compressed preview)
  const processImageFile = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          resolve(event.target.result as string);
        } else {
          reject(new Error('Failed to read image'));
        }
      };
      reader.onerror = () => reject(new Error('Error reading image file'));
      reader.readAsDataURL(file);
    });
  };

  // Main Image Local Gallery Handler
  const handleMainFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploadingImage(true);
      const base64Url = await processImageFile(file);
      setFormImage(base64Url);
    } catch (err) {
      console.error('Image load failed:', err);
    } finally {
      setIsUploadingImage(false);
      if (mainFileInputRef.current) {
        mainFileInputRef.current.value = '';
      }
    }
  };

  // Main Image Drag and Drop
  const handleMainDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingMain(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    try {
      setIsUploadingImage(true);
      const base64Url = await processImageFile(file);
      setFormImage(base64Url);
    } catch (err) {
      console.error('Image drop failed:', err);
    } finally {
      setIsUploadingImage(false);
    }
  };

  // Multi-Images Gallery Picker Handler
  const handleMultiFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = e.target.files ? Array.from(e.target.files) : [];
    if (files.length === 0) return;

    try {
      setIsUploadingImage(true);
      const promises = files.map((f: File) => processImageFile(f));
      const urls = await Promise.all(promises);
      setGalleryImagesList(prev => [...prev, ...urls]);
    } catch (err) {
      console.error('Multi image upload error:', err);
    } finally {
      setIsUploadingImage(false);
    }
  };

  // Remove an extra gallery image
  const handleRemoveGalleryImage = (indexToRemove: number) => {
    setGalleryImagesList(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  // Handle Save
  const handleSaveProduct = (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    const priceNum = Math.max(1, Number(formPrice) || (editingProduct ? editingProduct.price : 450));
    const cleanTitleBn = (formTitleBn || formTitleEn || (editingProduct ? (editingProduct.titleBn || editingProduct.titleEn) : '') || 'নতুন পণ্য').trim();
    const cleanTitleEn = (formTitleEn || formTitleBn || cleanTitleBn).trim();
    const cleanDescBn = (formDescBn || formDescEn || (editingProduct ? (editingProduct.descriptionBn || editingProduct.descriptionEn) : '') || `${cleanTitleBn} - প্রিমিয়াম কোয়ালিটি ও ১০০% ক্যাশ অন ডেলিভারি সুবিধা।`).trim();
    const cleanDescEn = (formDescEn || formDescBn || cleanDescBn).trim();
    const cleanImage = (formImage || (editingProduct ? editingProduct.image : '') || '/products/1719939868_L_3.jpg').trim();
    const autoSeo = generateAutoSeo(cleanTitleBn, cleanDescBn);

    const cleanSize = formSize.trim();
    const cleanColor = formColor.trim();

    if (editingProduct) {
      const updated: Product = {
        ...editingProduct,
        titleBn: cleanTitleBn,
        titleEn: cleanTitleEn,
        category: formCategory,
        price: priceNum,
        image: cleanImage,
        descriptionBn: cleanDescBn,
        descriptionEn: cleanDescEn,
        size: cleanSize || undefined,
        color: cleanColor || undefined,
        sku: editingProduct.sku || `SM-${Date.now().toString().slice(-4)}`,
        stock: editingProduct.stock ?? 50,
        status: editingProduct.status || 'active',
        isFeatured: editingProduct.isFeatured ?? false,
        isFlashSale: editingProduct.isFlashSale ?? false,
        freeDelivery: formFreeDelivery,
        isPinnedToTop: editingProduct.isPinnedToTop ?? false,
        displayOrder: editingProduct.displayOrder,
        seoTitle: editingProduct.seoTitle || autoSeo.seoTitle,
        seoDescription: editingProduct.seoDescription || autoSeo.seoDescription,
        updatedAt: new Date().toISOString()
      };
      if (onUpdateProduct) onUpdateProduct(updated);
    } else {
      const newProd: Omit<Product, 'id' | 'createdAt'> = {
        titleBn: cleanTitleBn,
        titleEn: cleanTitleEn,
        category: formCategory,
        price: priceNum,
        image: cleanImage,
        descriptionBn: cleanDescBn,
        descriptionEn: cleanDescEn,
        ...(cleanSize ? { size: cleanSize } : {}),
        ...(cleanColor ? { color: cleanColor } : {}),
        sku: `SM-${Date.now().toString().slice(-4)}`,
        stock: 50,
        brand: 'Happy Shopping',
        rating: 5.0,
        reviewsCount: 1,
        status: 'active',
        isFeatured: false,
        isFlashSale: false,
        freeDelivery: formFreeDelivery,
        isPinnedToTop: false,
        seoTitle: autoSeo.seoTitle,
        seoDescription: autoSeo.seoDescription,
      };
      if (onAddProduct) onAddProduct(newProd);
    }

    setEditingProduct(null);
    setIsModalOpen(false);
  };

  // Quick Inline Stock Adjust
  const handleQuickStockAdjust = (product: Product, delta: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const newStock = Math.max(0, (product.stock || 0) + delta);
    if (onUpdateProduct) {
      onUpdateProduct({ ...product, stock: newStock });
    }
  };

  // Quick Status Toggle
  const handleQuickStatusToggle = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    const newStatus = product.status === 'inactive' ? 'active' : 'inactive';
    if (onUpdateProduct) {
      onUpdateProduct({ ...product, status: newStatus });
    }
  };

  // Quick Featured Toggle
  const handleQuickFeaturedToggle = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onUpdateProduct) {
      onUpdateProduct({ ...product, isFeatured: !product.isFeatured });
    }
  };

  // Quick Flash Sale Toggle
  const handleQuickFlashToggle = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onUpdateProduct) {
      onUpdateProduct({ ...product, isFlashSale: !product.isFlashSale });
    }
  };

  // Duplicate Action
  const handleDuplicate = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onDuplicateProduct) {
      onDuplicateProduct(product);
    } else if (onAddProduct) {
      const copy: Omit<Product, 'id' | 'createdAt'> = {
        ...product,
        titleBn: `${product.titleBn} (কপি)`,
        titleEn: `${product.titleEn} (Copy)`,
        sku: `${product.sku || 'SM'}-COPY-${Date.now().toString().slice(-4)}`
      };
      onAddProduct(copy);
    }
  };

  // Bulk Selection Handlers
  const handleToggleSelectAll = () => {
    if (selectedProductIds.length === filteredProducts.length) {
      setSelectedProductIds([]);
    } else {
      setSelectedProductIds(filteredProducts.map(p => p.id));
    }
  };

  const handleToggleSelectOne = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedProductIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleExecuteBulkAction = () => {
    if (selectedProductIds.length === 0) return;

    if (bulkActionType === 'delete') {
      if (onBulkDelete) {
        onBulkDelete(selectedProductIds);
      } else if (onDeleteProduct) {
        selectedProductIds.forEach(id => onDeleteProduct(id));
      }
      setSelectedProductIds([]);
    } else if (bulkActionType === 'activate') {
      if (onBulkStatusUpdate) {
        onBulkStatusUpdate(selectedProductIds, 'active');
      } else if (onUpdateProduct) {
        selectedProductIds.forEach(id => {
          const p = products.find(prod => prod.id === id);
          if (p) onUpdateProduct({ ...p, status: 'active' });
        });
      }
      setSelectedProductIds([]);
    } else if (bulkActionType === 'deactivate') {
      if (onBulkStatusUpdate) {
        onBulkStatusUpdate(selectedProductIds, 'inactive');
      } else if (onUpdateProduct) {
        selectedProductIds.forEach(id => {
          const p = products.find(prod => prod.id === id);
          if (p) onUpdateProduct({ ...p, status: 'inactive' });
        });
      }
      setSelectedProductIds([]);
    } else if (bulkActionType === 'stock') {
      if (onBulkStockUpdate) {
        onBulkStockUpdate(selectedProductIds, bulkStockVal);
      } else if (onUpdateProduct) {
        selectedProductIds.forEach(id => {
          const p = products.find(prod => prod.id === id);
          if (p) onUpdateProduct({ ...p, stock: bulkStockVal });
        });
      }
      setSelectedProductIds([]);
    } else if (bulkActionType === 'category') {
      if (onBulkCategoryUpdate) {
        onBulkCategoryUpdate(selectedProductIds, bulkCategoryVal);
      } else if (onUpdateProduct) {
        selectedProductIds.forEach(id => {
          const p = products.find(prod => prod.id === id);
          if (p) onUpdateProduct({ ...p, category: bulkCategoryVal });
        });
      }
      setSelectedProductIds([]);
    }
    setBulkActionType('');
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header & Add Button */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Package className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'পণ্য পরিচালনা ও ক্যাটালগ' : 'Product Catalog Management'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? `মোট ${toBengaliNumber(products.length)} টি পণ্য রেজিস্টার্ড রয়েছে। পণ্য যুক্ত করার সাথে সাথে তা সার্ভারে সংরক্ষিত হবে এবং পাবলিশ করলে দেখা যাবে।` 
              : `Total ${products.length} products registered. Products are permanently stored on the server.`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {/* Manual Server Sync Button */}
          <button
            onClick={handleManualSync}
            disabled={isSyncing}
            title={language === 'bn' ? 'সকল পণ্য সার্ভারে সেভ করুন যাতে পাবলিশের পর সবাই দেখতে পায়' : 'Sync all products to server'}
            className="px-3.5 py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-amber-300 hover:text-amber-200 border border-amber-500/30 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-400' : ''}`} />
            <span>{isSyncing ? (language === 'bn' ? 'সেভ হচ্ছে...' : 'Saving...') : (language === 'bn' ? 'সার্ভারে সিঙ্ক করুন' : 'Sync Server')}</span>
          </button>

          {/* Export JSON Backup */}
          <button
            onClick={handleExportJson}
            title={language === 'bn' ? 'পণ্যের তালিকা JSON হিসেবে ডাউনলোড করুন' : 'Export products as JSON'}
            className="px-3.5 py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold flex items-center justify-center gap-1.5 border border-neutral-700 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-neutral-400" />
            <span>JSON</span>
          </button>

          {/* Quick Category & Product Ordering Shortcut */}
          {onNavigateToOrdering && (
            <button
              type="button"
              onClick={onNavigateToOrdering}
              title={language === 'bn' ? 'হোমপেজে কোন ক্যাটাগরি এবং কোন পণ্য আগে/পরে থাকবে তা ঠিক করুন' : 'Customize category and product display order'}
              className="px-4 py-2.5 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 hover:text-amber-200 border border-amber-500/30 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'bn' ? 'ক্যাটাগরি ও পণ্যের ক্রম সাজান' : 'Sort & Order Categories'}</span>
            </button>
          )}

          {/* Add Product Button */}
          <button
            onClick={handleOpenAddModal}
            className="px-5 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-rose-900/40 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'bn' ? '+ নতুন পণ্য যুক্ত করুন' : '+ Add New Product'}</span>
          </button>
        </div>
      </div>

      {/* Sync Feedback Toast Banner */}
      {syncFeedback && (
        <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/40 rounded-2xl flex items-center gap-3 text-emerald-300 text-xs font-medium animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{syncFeedback}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-3xl space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={language === 'bn' ? 'পণ্যের নাম, SKU, ক্যাটাগরি বা ব্র্যান্ড...' : 'Search by name, SKU, brand...'}
              className="w-full pl-9.5 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 placeholder-neutral-500 focus:border-rose-500 outline-none"
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 focus:border-rose-500 outline-none cursor-pointer"
          >
            <option value="all">{language === 'bn' ? 'সকল ক্যাটাগরি' : 'All Categories'}</option>
            {availableCategories.map(cat => (
              <option key={cat.id} value={cat.id}>
                {language === 'bn' ? cat.nameBn : cat.nameEn}
              </option>
            ))}
          </select>

          {/* Stock Filter */}
          <select
            value={stockFilter}
            onChange={(e) => setStockFilter(e.target.value as any)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 focus:border-rose-500 outline-none cursor-pointer"
          >
            <option value="all">{language === 'bn' ? 'সকল স্টক অবস্থা' : 'All Stock Status'}</option>
            <option value="in_stock">{language === 'bn' ? 'পর্যাপ্ত স্টক (>৫)' : 'In Stock (>5)'}</option>
            <option value="low_stock">{language === 'bn' ? 'কম স্টক (১-৫)' : 'Low Stock (1-5)'}</option>
            <option value="out_of_stock">{language === 'bn' ? 'স্টক শেষ (০)' : 'Out of Stock (0)'}</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 focus:border-rose-500 outline-none cursor-pointer"
          >
            <option value="all">{language === 'bn' ? 'সকল স্ট্যাটাস' : 'All Status'}</option>
            <option value="active">{language === 'bn' ? 'অ্যাক্টিভ পণ্য' : 'Active Only'}</option>
            <option value="inactive">{language === 'bn' ? 'ইনঅ্যাক্টিভ' : 'Inactive Only'}</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 focus:border-rose-500 outline-none cursor-pointer"
          >
            <option value="display_order">{language === 'bn' ? '🔢 সাজানো ক্রম (১, ২, ৩...)' : 'Display Order (#1, #2...)'}</option>
            <option value="newest">{language === 'bn' ? 'সর্বশেষ যোগকৃত' : 'Newest First'}</option>
            <option value="price_asc">{language === 'bn' ? 'দাম: কম থেকে বেশি' : 'Price: Low to High'}</option>
            <option value="price_desc">{language === 'bn' ? 'দাম: বেশি থেকে কম' : 'Price: High to Low'}</option>
            <option value="stock_asc">{language === 'bn' ? 'স্টক: কম থেকে বেশি' : 'Stock: Low to High'}</option>
            <option value="stock_desc">{language === 'bn' ? 'স্টক: বেশি থেকে কম' : 'Stock: High to Low'}</option>
            <option value="name">{language === 'bn' ? 'নাম অনুসারে (A-Z)' : 'Name (A-Z)'}</option>
          </select>
        </div>

        {/* Bulk Action Controls if Selected */}
        {selectedProductIds.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-neutral-950 rounded-2xl border border-rose-900/40 animate-fadeIn shadow-lg">
            <div className="flex items-center gap-2 text-xs font-bold text-rose-300">
              <CheckSquare className="w-4 h-4 text-rose-400" />
              <span>
                {language === 'bn' 
                  ? `${toBengaliNumber(selectedProductIds.length)} টি পণ্য নির্বাচিত` 
                  : `${selectedProductIds.length} items selected`}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={bulkActionType}
                onChange={(e) => setBulkActionType(e.target.value)}
                className="px-3 py-1.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-200 outline-none"
              >
                <option value="">{language === 'bn' ? '-- বাল্ক অ্যাকশন বেছে নিন --' : '-- Choose Bulk Action --'}</option>
                <option value="activate">{language === 'bn' ? 'সরাসরি অ্যাক্টিভ করুন' : 'Make Active'}</option>
                <option value="deactivate">{language === 'bn' ? 'ইনঅ্যাক্টিভ করুন' : 'Make Inactive'}</option>
                <option value="stock">{language === 'bn' ? 'স্টক পরিমাণ আপডেট করুন' : 'Update Stock Quantity'}</option>
                <option value="category">{language === 'bn' ? 'ক্যাটাগরি পরিবর্তন করুন' : 'Change Category'}</option>
                <option value="delete">{language === 'bn' ? 'একসাথে ডিলিট করুন' : 'Delete Selected'}</option>
              </select>

              {bulkActionType === 'stock' && (
                <input
                  type="number"
                  value={bulkStockVal}
                  onChange={(e) => setBulkStockVal(Number(e.target.value))}
                  placeholder="New stock"
                  className="w-20 px-2 py-1.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                />
              )}

              {bulkActionType === 'category' && (
                <select
                  value={bulkCategoryVal}
                  onChange={(e) => setBulkCategoryVal(e.target.value as CategoryId)}
                  className="px-2 py-1.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-neutral-100"
                >
                  {availableCategories.filter(c => c.id !== 'all').map(c => (
                    <option key={c.id} value={c.id}>{language === 'bn' ? c.nameBn : c.nameEn}</option>
                  ))}
                </select>
              )}

              <button
                onClick={handleExecuteBulkAction}
                disabled={!bulkActionType}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-bold transition cursor-pointer"
              >
                {language === 'bn' ? 'প্রয়োগ করুন' : 'Apply'}
              </button>

              <button
                onClick={() => setSelectedProductIds([])}
                className="px-2 py-1.5 rounded-xl text-xs text-neutral-400 hover:text-white"
              >
                {language === 'bn' ? 'ক্লিয়ার' : 'Clear'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Products Table & Mobile Cards Card */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
        {/* 1. Mobile Cards View (Visible on phones) */}
        <div className="block sm:hidden divide-y divide-neutral-800/80">
          {paginatedProducts.length === 0 ? (
            <div className="py-12 text-center text-neutral-500">
              <Package className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
              <p>{language === 'bn' ? 'কোনো পণ্য খুঁজে পাওয়া যায়নি।' : 'No products found.'}</p>
            </div>
          ) : (
            paginatedProducts.map(product => {
              const isSelected = selectedProductIds.includes(product.id);
              const isOut = product.stock === 0;

              return (
                <div 
                  key={product.id}
                  className={`p-3.5 space-y-3 transition ${isSelected ? 'bg-rose-950/20' : 'hover:bg-neutral-850/50'}`}
                >
                  <div className="flex items-center gap-3">
                    <button 
                      type="button"
                      onClick={(e) => handleToggleSelectOne(product.id, e)}
                      className="p-1 text-neutral-500 hover:text-white"
                    >
                      {isSelected ? <CheckSquare className="w-5 h-5 text-rose-500" /> : <Square className="w-5 h-5" />}
                    </button>

                    <div className="w-14 h-14 rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-800 shrink-0 relative">
                      <img src={product.image || '/products/1719939868_L_3.jpg'} alt="" className="w-full h-full object-cover" />
                      {typeof product.displayOrder === 'number' && (
                        <span className="absolute bottom-0 left-0 bg-neutral-900/90 text-amber-300 font-mono text-[9px] font-black px-1 rounded-tr">
                          #{product.displayOrder}
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-white text-xs truncate">
                        {language === 'bn' ? product.titleBn : product.titleEn}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs font-black text-rose-400">
                          {formatPrice(product.price, language)}
                        </span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                          isOut ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                        }`}>
                          {isOut ? '০ স্টক' : `${product.stock} pcs`}
                        </span>
                        <span className="text-[10px] text-neutral-400 truncate">
                          {product.category}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Mobile Quick Action Buttons */}
                  <div className="flex items-center justify-between pt-1 border-t border-neutral-800/60 gap-2">
                    <button
                      type="button"
                      onClick={(e) => handleQuickStatusToggle(product, e)}
                      className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 ${
                        product.status === 'inactive' ? 'bg-neutral-800 text-neutral-400' : 'bg-emerald-500/20 text-emerald-300'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${product.status === 'inactive' ? 'bg-neutral-500' : 'bg-emerald-400'}`} />
                      <span>{product.status === 'inactive' ? 'Inactive' : 'Active'}</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={(e) => handleDuplicate(product, e)}
                        className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
                        title="Copy"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenEditModal(product);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/30 text-xs font-bold flex items-center gap-1"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>{language === 'bn' ? 'এডিট' : 'Edit'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteConfirmId(product.id);
                        }}
                        className="p-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* 2. Desktop Table View (Visible on tablets & computers) */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
              <tr>
                <th className="py-3.5 px-4 w-10 text-center">
                  <button onClick={handleToggleSelectAll} className="text-neutral-400 hover:text-white cursor-pointer">
                    {selectedProductIds.length > 0 && selectedProductIds.length === filteredProducts.length ? (
                      <CheckSquare className="w-4 h-4 text-rose-500" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'পণ্য ও ছবি' : 'Product & Image'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'ক্যাটাগরি' : 'Category'}</th>
                <th className="py-3.5 px-3 text-center">{language === 'bn' ? 'পজিশন / ক্রমিক (#)' : 'Position (#)'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'বিক্রয় মূল্য' : 'Price'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'স্টক পরিমাণ' : 'Stock Quantity'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'অবস্থা' : 'Status'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'ব্যাজ ও ফিচার' : 'Badges'}</th>
                <th className="py-3.5 px-4 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {paginatedProducts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-neutral-500">
                    <Package className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                    <p>{language === 'bn' ? 'কোনো পণ্য খুঁজে পাওয়া যায়নি।' : 'No products found.'}</p>
                  </td>
                </tr>
              ) : (
                paginatedProducts.map(product => {
                  const isSelected = selectedProductIds.includes(product.id);
                  const isLow = product.stock > 0 && product.stock <= 5;
                  const isOut = product.stock === 0;

                  return (
                    <tr 
                      key={product.id} 
                      className={`hover:bg-neutral-800/40 transition cursor-pointer ${isSelected ? 'bg-rose-950/20' : ''}`}
                      onClick={() => handleOpenEditModal(product)}
                    >
                      <td className="py-3 px-4 text-center" onClick={(e) => handleToggleSelectOne(product.id, e)}>
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-rose-500 mx-auto" />
                        ) : (
                          <Square className="w-4 h-4 text-neutral-600 hover:text-neutral-400 mx-auto" />
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="relative w-12 h-12 rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-800 shrink-0">
                            <img 
                              src={product.image || '/products/1719939868_L_3.jpg'} 
                              alt="" 
                              className="w-full h-full object-cover" 
                            />
                            {product.additionalImages && product.additionalImages.length > 0 && (
                              <span className="absolute bottom-0 right-0 bg-black/80 text-[8px] font-bold text-white px-1 rounded-tl">
                                +{product.additionalImages.length}
                              </span>
                            )}
                          </div>
                          <div className="overflow-hidden max-w-xs">
                            <p className="font-bold text-neutral-100 truncate text-xs flex items-center gap-2">
                              <span>{language === 'bn' ? product.titleBn : product.titleEn}</span>
                              {product.isPinnedToTop && (
                                <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5 shrink-0">
                                  <Pin className="w-2.5 h-2.5 fill-amber-400" />
                                  <span>{language === 'bn' ? 'শীর্ষে পিন' : 'Pinned'}</span>
                                </span>
                              )}
                              {typeof product.displayOrder === 'number' && (
                                <span className="bg-neutral-800 text-neutral-300 border border-neutral-700 text-[9px] font-mono font-bold px-1.5 py-0.5 rounded shrink-0">
                                  #{product.displayOrder}
                                </span>
                              )}
                            </p>
                            <p className="text-[10px] text-neutral-400 font-mono flex items-center gap-1.5 mt-0.5">
                              <span className="text-rose-400">SKU: {product.sku || product.id}</span>
                              {product.brand && <span className="text-neutral-500">• {product.brand}</span>}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 font-semibold text-neutral-300" onClick={(e) => e.stopPropagation()}>
                        <select
                          value={product.category}
                          onChange={(e) => {
                            if (onUpdateProduct) {
                              onUpdateProduct({ ...product, category: e.target.value as CategoryId, updatedAt: new Date().toISOString() });
                            }
                          }}
                          className="bg-neutral-900 border border-neutral-750 text-neutral-200 text-xs rounded-xl px-2.5 py-1 outline-none focus:border-rose-500 cursor-pointer font-medium hover:border-neutral-600 transition"
                          title={language === 'bn' ? 'সরাসরি ক্যাটাগরি পরিবর্তন করুন' : 'Quick Category Switch'}
                        >
                          <option value="clothes">{language === 'bn' ? 'পোশাক ও ড্রেস (Clothes & Dresses)' : 'Clothes & Dresses'}</option>
                          <option value="bags">{language === 'bn' ? 'ব্যাগ ও ব্যাকপ্যাক (Bags & Backpacks)' : 'Bags & Backpacks'}</option>
                          <option value="watch">{language === 'bn' ? 'ঘড়ি (WATCH)' : 'WATCH'}</option>
                          <option value="gadgets-electronics">{language === 'bn' ? 'গ্যাজেটস ও ইলেকট্রনিক্স' : 'Gadgets & Tech'}</option>
                          <option value="home-lifestyle">{language === 'bn' ? 'হোম ও লাইফস্টাইল' : 'Home & Lifestyle'}</option>
                          <option value="kids-zone">{language === 'bn' ? 'কিডস জোন' : 'Kids Zone'}</option>
                          <option value="bike-accessories">{language === 'bn' ? 'বাইক এক্সেসরিজ' : 'Bike Accessories'}</option>
                          <option value="combo-product">{language === 'bn' ? 'কম্বো প্রোডাক্ট' : 'Combo'}</option>
                          <option value="beauty-skincare">{language === 'bn' ? 'বিউটি ও স্কিনকেয়ার' : 'Beauty & Skincare'}</option>
                          <option value="others">{language === 'bn' ? 'অন্যান্য' : 'Others'}</option>
                        </select>
                      </td>
                      <td className="py-3 px-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <div className="flex flex-col items-center justify-center gap-1">
                          <div className="flex items-center gap-1">
                            <span className={`px-2 py-0.5 rounded-lg text-xs font-mono font-black ${
                              product.displayOrder === 1 
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm' 
                                : typeof product.displayOrder === 'number'
                                  ? 'bg-neutral-800 text-neutral-200 border border-neutral-700'
                                  : 'bg-neutral-900 text-neutral-500 border border-neutral-800'
                            }`}>
                              #{product.displayOrder || '-'}
                            </span>
                            {product.displayOrder !== 1 && (
                              <button
                                onClick={(e) => handleQuickSetPosition(product.id, 1, e)}
                                className="px-1.5 py-0.5 rounded bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 text-[9px] font-bold transition cursor-pointer"
                                title={language === 'bn' ? '১ নম্বরে তুলুন (শীর্ষে)' : 'Set as #1'}
                              >
                                {language === 'bn' ? '১ নম্বরে' : '#1'}
                              </button>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-1 mt-0.5">
                            <input
                              type="number"
                              min="1"
                              max="999"
                              value={positionInputs[product.id] ?? ''}
                              onChange={(e) => setPositionInputs(prev => ({ ...prev, [product.id]: e.target.value }))}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  const val = parseInt(positionInputs[product.id] || '', 10);
                                  if (!isNaN(val) && val >= 1) {
                                    handleQuickSetPosition(product.id, val, e);
                                  }
                                }
                              }}
                              placeholder="ক্রম..."
                              className="w-12 px-1.5 py-0.5 text-[11px] text-center font-bold bg-neutral-950 border border-neutral-700 rounded-md text-white outline-none focus:border-rose-500"
                            />
                            <button
                              onClick={(e) => {
                                const val = parseInt(positionInputs[product.id] || '', 10);
                                if (!isNaN(val) && val >= 1) {
                                  handleQuickSetPosition(product.id, val, e);
                                }
                              }}
                              disabled={!positionInputs[product.id]}
                              className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 disabled:opacity-30 text-neutral-300 hover:text-white transition cursor-pointer"
                              title={language === 'bn' ? 'পজিশন সেট করুন' : 'Apply Position'}
                            >
                              <Check className="w-3 h-3 text-emerald-400" />
                            </button>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-black text-white text-sm">
                          {formatPrice(product.price, language)}
                        </div>
                        {product.originalPrice && product.originalPrice > product.price && (
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] text-neutral-500 line-through">
                              {formatPrice(product.originalPrice, language)}
                            </span>
                            <span className="text-[9px] font-bold text-emerald-400">
                              -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={(e) => handleQuickStockAdjust(product, -1, e)}
                            className="p-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition cursor-pointer"
                            title="Decrease stock by 1"
                          >
                            <MinusCircle className="w-3.5 h-3.5" />
                          </button>
                          
                          <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black min-w-[55px] text-center ${
                            isOut ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                            isLow ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                            'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                          }`}>
                            {isOut ? (language === 'bn' ? '০ স্টক' : 'Out') : 
                             `${language === 'bn' ? toBengaliNumber(product.stock) : product.stock} pcs`}
                          </span>

                          <button
                            onClick={(e) => handleQuickStockAdjust(product, 1, e)}
                            className="p-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition cursor-pointer"
                            title="Increase stock by 1"
                          >
                            <PlusCircle className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className="py-3 px-4" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={(e) => handleQuickStatusToggle(product, e)}
                          className={`px-2.5 py-1 rounded-xl text-[10px] font-black transition cursor-pointer flex items-center gap-1 ${
                            product.status === 'inactive' 
                              ? 'bg-neutral-800 text-neutral-400 hover:text-neutral-200 border border-neutral-700' 
                              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-sm'
                          }`}
                          title="Click to toggle Active / Inactive"
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${product.status === 'inactive' ? 'bg-neutral-500' : 'bg-emerald-400'}`} />
                          <span>{product.status === 'inactive' ? 'Inactive' : 'Active'}</span>
                        </button>
                      </td>
                      <td className="py-3 px-4" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={(e) => handleQuickFeaturedToggle(product, e)}
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold transition cursor-pointer ${
                              product.isFeatured 
                                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' 
                                : 'bg-neutral-800/60 text-neutral-500 hover:text-neutral-300'
                            }`}
                            title="Toggle Featured"
                          >
                            Featured
                          </button>
                          <button
                            onClick={(e) => handleQuickFlashToggle(product, e)}
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold transition cursor-pointer ${
                              product.isFlashSale 
                                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' 
                                : 'bg-neutral-800/60 text-neutral-500 hover:text-neutral-300'
                            }`}
                            title="Toggle Flash Sale"
                          >
                            Flash
                          </button>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Duplicate */}
                          <button
                            onClick={(e) => handleDuplicate(product, e)}
                            className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition cursor-pointer"
                            title={language === 'bn' ? 'পণ্য ডুপ্লিকেট / কপি করুন' : 'Duplicate Product'}
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenEditModal(product);
                            }}
                            className="p-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 transition cursor-pointer"
                            title={language === 'bn' ? 'পণ্য এডিট করুন' : 'Edit Product'}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteConfirmId(product.id);
                            }}
                            className="p-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 transition cursor-pointer"
                            title={language === 'bn' ? 'পণ্য ডিলিট করুন' : 'Delete Product'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* 3. Pagination & Count Bar */}
        {filteredProducts.length > 0 && (
          <div className="p-4 bg-neutral-950/80 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-neutral-400">
            <div className="flex items-center gap-2">
              <span>{language === 'bn' ? 'মোট' : 'Total'}</span>
              <span className="font-bold text-white">{filteredProducts.length}</span>
              <span>{language === 'bn' ? 'টি পণ্যের মধ্যে' : 'products • showing'}</span>
              <span className="font-bold text-rose-400">
                {(currentPage - 1) * pageSize + 1} - {Math.min(currentPage * pageSize, filteredProducts.length)}
              </span>
            </div>

            <div className="flex items-center gap-3">
              {/* Rows Per Page Selector */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-neutral-400">{language === 'bn' ? 'প্রতি পেজে:' : 'Per page:'}</span>
                <select
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                  className="bg-neutral-900 border border-neutral-700 text-white rounded-lg px-2 py-1 outline-none text-xs"
                >
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>

              {/* Prev / Next Pagination Controls */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 disabled:opacity-30 disabled:cursor-not-allowed text-white transition"
                  title="Previous Page"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <span className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 font-bold text-neutral-200">
                  {currentPage} / {totalPages}
                </span>

                <button
                  type="button"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 disabled:opacity-30 disabled:cursor-not-allowed text-white transition"
                  title="Next Page"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit Product Comprehensive Modal with Direct Gallery Upload */}
      {isModalOpen && (
        <div 
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fadeIn"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setEditingProduct(null);
              setIsModalOpen(false);
            }
          }}
        >
          <div 
            className="relative w-full max-w-2xl bg-white border border-neutral-200 text-neutral-900 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden my-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Sticky Modal Header */}
            <div className="px-5 sm:px-6 py-4 bg-neutral-50/90 border-b border-neutral-200 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center shadow-xs">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-neutral-900">
                    {editingProduct ? (language === 'bn' ? 'পণ্য সম্পাদনা ও আপডেট' : 'Edit Product Details') : (language === 'bn' ? 'নতুন পণ্য যুক্ত করুন' : 'Add New Product')}
                  </h3>
                  <p className="text-xs text-neutral-500">
                    {language === 'bn' ? 'পণ্যের ছবি, ক্যাটাগরি, নাম, বিবরণী ও মূল্য নির্ধারণ করুন' : 'Configure image, category, title, description & price'}
                  </p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => {
                  setEditingProduct(null);
                  setIsModalOpen(false);
                }} 
                className="p-2 rounded-xl text-neutral-400 hover:text-neutral-800 hover:bg-neutral-200/70 transition cursor-pointer"
                title={language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Modal Form Body */}
            <form onSubmit={handleSaveProduct} className="flex flex-col flex-1 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
                {/* 1. PRODUCT IMAGE UPLOAD */}
                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-rose-700 flex items-center gap-1.5">
                      <Camera className="w-4 h-4 text-rose-600" />
                      <span>{language === 'bn' ? '১. পণ্যের ছবি (Product Image)' : '1. Product Image'} *</span>
                    </label>
                    <span className="text-[11px] text-neutral-500 font-medium">ফোন বা কম্পিউটার থেকে সরাসরি আপলোড</span>
                  </div>

                  {/* Image Preview & Upload Controls */}
                  <div className="flex flex-col sm:flex-row gap-4 items-center">
                    <div className="w-28 h-28 shrink-0 rounded-2xl bg-white border-2 border-dashed border-neutral-300 flex items-center justify-center overflow-hidden relative group shadow-2xs">
                      {formImage ? (
                        <>
                          <img 
                            src={formImage} 
                            alt="Preview" 
                            className="w-full h-full object-cover" 
                          />
                          <button
                            type="button"
                            onClick={() => setFormImage('')}
                            className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-rose-300 font-bold text-xs"
                            title="Remove image"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </>
                      ) : (
                        <div className="text-center p-2">
                          <ImageIcon className="w-6 h-6 text-neutral-400 mx-auto mb-1" />
                          <span className="text-[10px] text-neutral-400 font-bold block">ছবি নেই</span>
                        </div>
                      )}
                    </div>

                    <div className="flex-1 w-full space-y-2.5">
                      <input
                        type="file"
                        ref={mainFileInputRef}
                        accept="image/*"
                        onChange={handleMainFileSelect}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => mainFileInputRef.current?.click()}
                        disabled={isUploadingImage}
                        className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
                      >
                        <Upload className="w-4 h-4" />
                        <span>{isUploadingImage ? (language === 'bn' ? 'ছবি লোড হচ্ছে...' : 'Uploading...') : (language === 'bn' ? 'ডিভাইসের গ্যালারি / ক্যামেরা থেকে আপলোড' : 'Upload from Device Gallery')}</span>
                      </button>

                      <div className="relative">
                        <input
                          type="text"
                          value={formImage}
                          onChange={(e) => setFormImage(e.target.value)}
                          placeholder="অথবা সরাসরি ইমেজ লিংক (Image URL) দিন..."
                          className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-xs text-neutral-900 placeholder:text-neutral-400 outline-none focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. PRODUCT CATEGORY SELECTION */}
                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-2">
                  <label className="text-xs font-bold text-neutral-800 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-rose-600" />
                    <span>{language === 'bn' ? '২. পণ্যের ক্যাটাগরি নির্ধারণ করুন (Product Category)' : '2. Select Product Category'} *</span>
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as CategoryId)}
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-bold text-neutral-900 outline-none focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 cursor-pointer shadow-2xs"
                  >
                    {availableCategories.filter(c => c.id !== 'all').map(c => (
                      <option key={c.id} value={c.id} className="text-neutral-900 py-1">
                        {language === 'bn' ? c.nameBn : c.nameEn}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 3. PRODUCT NAME / TITLE */}
                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-800">
                      {language === 'bn' ? '৩. পণ্যের নাম (বাংলা)' : '3. Product Name (Bengali)'} *
                    </label>
                    <input
                      type="text"
                      required
                      value={formTitleBn}
                      onChange={(e) => handleTitleBnChange(e.target.value)}
                      placeholder="যেমন: প্রিমিয়াম জামদানি সুতি শাড়ি, লেডিস হ্যান্ডব্যাগ, স্মার্ট ওয়াচ..."
                      className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-medium text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none shadow-2xs"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-600">
                      {language === 'bn' ? 'পণ্যের নাম (ইংরেজি - ঐচ্ছিক)' : 'Product Name (English - Optional)'}
                    </label>
                    <input
                      type="text"
                      value={formTitleEn}
                      onChange={(e) => handleTitleEnChange(e.target.value)}
                      placeholder="e.g. Premium Cotton Jamdani Saree / Smart Watch"
                      className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-medium text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none shadow-2xs"
                    />
                  </div>
                </div>

                {/* 4. PRODUCT DESCRIPTION */}
                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-800">
                      {language === 'bn' ? '৪. পণ্যের বিস্তারিত বিবরণ (Description - বাংলা)' : '4. Description (Bengali)'} *
                    </label>
                    <textarea
                      rows={3}
                      required
                      value={formDescBn}
                      onChange={(e) => handleDescBnChange(e.target.value)}
                      placeholder="পণ্যের উপাদান, বৈশিষ্ট্য, সাইজ বিবরণ ও বিস্তারিত বিবরণ লিখুন..."
                      className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-medium text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none shadow-2xs"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-600">
                      {language === 'bn' ? 'পণ্যের বিবরণ (ইংরেজি - ঐচ্ছিক)' : 'Description (English - Optional)'}
                    </label>
                    <textarea
                      rows={2}
                      value={formDescEn}
                      onChange={(e) => handleDescEnChange(e.target.value)}
                      placeholder="Product details & specifications..."
                      className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-medium text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none shadow-2xs"
                    />
                  </div>
                </div>

                {/* 4.5 OPTIONAL REAL VARIANTS (SIZE & COLOR) */}
                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-neutral-800">
                        {language === 'bn' ? 'সাইজ (ঐচ্ছিক - কমা দিয়ে লিখুন)' : 'Sizes (Optional - comma separated)'}
                      </label>
                      <input
                        type="text"
                        value={formSize}
                        onChange={(e) => setFormSize(e.target.value)}
                        placeholder={language === 'bn' ? 'সাইজ না থাকলে খালি রাখুন (উদা: M, L, XL, XXL)' : 'Leave blank if no size (e.g. M, L, XL)'}
                        className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-medium text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 outline-none shadow-2xs"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-neutral-800">
                        {language === 'bn' ? 'কালার (ঐচ্ছিক - কমা দিয়ে লিখুন)' : 'Colors (Optional - comma separated)'}
                      </label>
                      <input
                        type="text"
                        value={formColor}
                        onChange={(e) => setFormColor(e.target.value)}
                        placeholder={language === 'bn' ? 'কালার না থাকলে খালি রাখুন (উদা: Black, Maroon)' : 'Leave blank if no color (e.g. Black, Maroon)'}
                        className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs font-medium text-neutral-900 placeholder:text-neutral-400 focus:border-rose-500 outline-none shadow-2xs"
                      />
                    </div>
                  </div>
                </div>

                {/* 5. SELLING PRICE & FREE DELIVERY */}
                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3">
                  <div>
                    <label className="text-xs font-bold text-neutral-800">
                      {language === 'bn' ? '৫. বিক্রয় মূল্য (৳ BDT Price)' : '5. Selling Price (৳ BDT)'} *
                    </label>
                    <div className="relative w-full max-w-xs mt-1.5">
                      <span className="absolute left-3.5 top-2.5 text-xs font-black text-rose-600">৳</span>
                      <input
                        type="number"
                        required
                        min="1"
                        value={formPrice}
                        onChange={(e) => setFormPrice(e.target.value)}
                        placeholder="750"
                        className="w-full pl-8 pr-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-sm font-black text-rose-600 focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none font-mono shadow-2xs"
                      />
                    </div>
                  </div>

                  <div className="pt-2 border-t border-neutral-200">
                    <label className="flex items-center gap-2.5 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={formFreeDelivery}
                        onChange={(e) => setFormFreeDelivery(e.target.checked)}
                        className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 border-neutral-300 bg-white cursor-pointer"
                      />
                      <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-800">
                        <Truck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{language === 'bn' ? 'এই পণ্যের জন্য ডেলিভারি সম্পূর্ণ ফ্রি (Free Delivery)' : 'Free Delivery for this product'}</span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Sticky Modal Footer with Buttons */}
              <div className="px-5 sm:px-6 py-4 bg-neutral-50 border-t border-neutral-200 flex items-center justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setEditingProduct(null);
                    setIsModalOpen(false);
                  }}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-neutral-600 hover:text-neutral-900 bg-neutral-200/70 hover:bg-neutral-200 transition cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl text-xs font-black text-white bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 shadow-md shadow-rose-600/20 transition cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingProduct ? (language === 'bn' ? 'আপডেট সংরক্ষণ করুন' : 'Save Changes') : (language === 'bn' ? 'পণ্য প্রকাশ করুন' : 'Publish Product')}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 max-w-sm w-full rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 border border-red-200 flex items-center justify-center mx-auto shadow-2xs">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-neutral-900">
                {language === 'bn' ? 'পণ্যটি ডিলিট করতে চান?' : 'Delete Product?'}
              </h4>
              <p className="text-xs text-neutral-500 mt-1">
                {language === 'bn' ? 'এই পণ্যটি ক্যাটালগ থেকে স্থায়ীভাবে মুছে ফেলা হবে।' : 'This action will permanently delete this product.'}
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-neutral-100 hover:bg-neutral-200 text-neutral-700 cursor-pointer transition"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteProduct) onDeleteProduct(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="px-4 py-2.5 rounded-xl text-xs font-black bg-red-600 hover:bg-red-500 text-white cursor-pointer shadow-md shadow-red-600/20 transition"
              >
                {language === 'bn' ? 'হ্যাঁ, ডিলিট করুন' : 'Yes, Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
