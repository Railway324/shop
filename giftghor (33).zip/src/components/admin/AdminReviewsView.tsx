import React, { useState, useMemo } from 'react';
import { 
  MessageSquare, 
  Star, 
  Check, 
  X, 
  Trash2, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Filter, 
  ThumbsUp,
  ShieldCheck
} from 'lucide-react';
import { ProductReview, Language } from '../../types';
import { toBengaliNumber } from '../../utils/translations';

interface AdminReviewsViewProps {
  reviews?: ProductReview[];
  language: Language;
  onUpdateReviewStatus?: (reviewId: string, status: 'approved' | 'rejected' | 'pending') => void;
  onDeleteReview?: (reviewId: string) => void;
}

export const AdminReviewsView: React.FC<AdminReviewsViewProps> = ({
  reviews = [],
  language,
  onUpdateReviewStatus,
  onDeleteReview,
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [ratingFilter, setRatingFilter] = useState<'all' | '5' | '4' | '3' | '2' | '1'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredReviews = useMemo(() => {
    return reviews.filter(r => {
      if (statusFilter !== 'all' && r.status !== statusFilter) return false;
      if (ratingFilter !== 'all' && r.rating !== Number(ratingFilter)) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const reviewer = (r.customerName || r.userName || '').toLowerCase();
        const comment = (r.comment || '').toLowerCase();
        const product = (r.productName || r.productTitle || '').toLowerCase();
        return reviewer.includes(q) || comment.includes(q) || product.includes(q);
      }
      return true;
    });
  }, [reviews, statusFilter, ratingFilter, searchQuery]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <MessageSquare className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'গ্রাহক রিভিউ ও রেটিং মডারেশন' : 'Product Reviews & Feedback Moderation'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? `মোট ${toBengaliNumber(reviews.length)} টি রিভিউ। গ্রাহকদের কমেন্ট যাচাই করে স্টোরে পাবলিশ বা রিজেক্ট করুন।` 
              : `Total ${reviews.length} product reviews. Moderate and approve verified customer feedback.`}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs font-bold text-amber-400">
            {reviews.filter(r => r.status === 'pending').length} Pending Approval
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-3xl space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative sm:col-span-1">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search reviewer or product..."
              className="w-full pl-9.5 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 placeholder-neutral-500 outline-none focus:border-rose-500"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 outline-none cursor-pointer"
          >
            <option value="all">All Moderation Statuses</option>
            <option value="pending">Pending Only</option>
            <option value="approved">Approved & Public</option>
            <option value="rejected">Rejected / Hidden</option>
          </select>

          <select
            value={ratingFilter}
            onChange={(e) => setRatingFilter(e.target.value as any)}
            className="px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 outline-none cursor-pointer"
          >
            <option value="all">All Star Ratings</option>
            <option value="5">⭐⭐⭐⭐⭐ (5 Stars)</option>
            <option value="4">⭐⭐⭐⭐ (4 Stars)</option>
            <option value="3">⭐⭐⭐ (3 Stars)</option>
            <option value="2">⭐⭐ (2 Stars)</option>
            <option value="1">⭐ (1 Star)</option>
          </select>
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-3">
        {filteredReviews.length === 0 ? (
          <div className="py-12 text-center text-neutral-500 bg-neutral-900 border border-neutral-800 rounded-3xl">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
            <p>No customer reviews match your filters.</p>
          </div>
        ) : (
          filteredReviews.map(review => (
            <div 
              key={review.id}
              className="p-5 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-3 hover:border-neutral-700 transition"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-neutral-800 flex items-center justify-center font-bold text-white">
                    {(review.customerName || review.userName || 'U').charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-xs text-white">{review.customerName || review.userName || 'Anonymous'}</h4>
                      {review.verifiedPurchase && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" />
                          <span>Verified Purchase</span>
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-neutral-400 font-medium">
                      Product: <span className="text-neutral-200">{review.productName || review.productTitle || 'Catalog Product'}</span> • {new Date(review.date || review.createdAt || Date.now()).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star 
                      key={star} 
                      className={`w-3.5 h-3.5 ${star <= review.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-700'}`} 
                    />
                  ))}
                </div>
              </div>

              <p className="text-xs text-neutral-300 bg-neutral-950/80 p-3 rounded-2xl border border-neutral-800/80 leading-relaxed">
                "{review.comment}"
              </p>

              <div className="flex items-center justify-between pt-1">
                <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold capitalize ${
                  review.status === 'approved' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                  review.status === 'rejected' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                  'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                }`}>
                  Status: {review.status}
                </span>

                <div className="flex items-center gap-2">
                  {review.status !== 'approved' && (
                    <button
                      onClick={() => onUpdateReviewStatus(review.id, 'approved')}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                  )}

                  {review.status !== 'rejected' && (
                    <button
                      onClick={() => onUpdateReviewStatus(review.id, 'rejected')}
                      className="px-3 py-1.5 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  )}

                  <button
                    onClick={() => onDeleteReview(review.id)}
                    className="p-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 transition cursor-pointer"
                    title="Delete Review"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
