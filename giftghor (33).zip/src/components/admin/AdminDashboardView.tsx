import React, { useState, useMemo } from 'react';
import { 
  DollarSign, 
  ShoppingBag, 
  Package, 
  Users, 
  AlertTriangle, 
  TrendingUp, 
  Clock, 
  Truck, 
  CheckCircle2, 
  XCircle, 
  ArrowUpRight, 
  ArrowDownRight, 
  Calendar, 
  ChevronRight, 
  Filter, 
  Eye, 
  Sparkles,
  Boxes,
  RefreshCw,
  CreditCard,
  RotateCcw,
  Search,
  Check,
  Percent,
  ListOrdered,
  CloudUpload,
  Globe
} from 'lucide-react';
import { Product, Order, Language, Customer, OrderStatus } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';
import { safeParseDate, safeDateToISODate, safeDateToLocaleString } from '../../utils/dateUtils';

interface AdminDashboardViewProps {
  products?: Product[];
  orders?: Order[];
  customers?: Customer[];
  language: Language;
  onSelectOrder?: (order: Order) => void;
  onViewOrderDetails?: (order: Order) => void;
  onUpdateOrderStatus?: (orderId: string, status: OrderStatus) => void;
  onNavigateTab: (tab: any) => void;
  onOpenLivePublish?: () => void;
}

type DateFilterOption = 'today' | '7days' | '30days' | 'month' | 'year' | 'custom';
type DeliveryTrackerTab = 'delivered' | 'returned';

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  products = [],
  orders = [],
  customers = [],
  language,
  onSelectOrder,
  onViewOrderDetails,
  onUpdateOrderStatus,
  onNavigateTab,
  onOpenLivePublish,
}) => {
  const [dateFilter, setDateFilter] = useState<DateFilterOption>('30days');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  // Delivery & Return Tracker active tab and search
  const [trackerTab, setTrackerTab] = useState<DeliveryTrackerTab>('delivered');
  const [trackerSearch, setTrackerSearch] = useState('');

  const handleOrderClick = (order: Order) => {
    if (onSelectOrder) onSelectOrder(order);
    if (onViewOrderDetails) onViewOrderDetails(order);
  };

  // Filter orders by date range
  const filteredOrders = useMemo(() => {
    const now = new Date();
    return orders.filter(o => {
      const orderDate = safeParseDate(o.date);
      if (dateFilter === 'today') {
        return orderDate.toDateString() === now.toDateString();
      }
      if (dateFilter === '7days') {
        const past7 = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return orderDate >= past7;
      }
      if (dateFilter === '30days') {
        const past30 = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return orderDate >= past30;
      }
      if (dateFilter === 'month') {
        return orderDate.getMonth() === now.getMonth() && orderDate.getFullYear() === now.getFullYear();
      }
      if (dateFilter === 'year') {
        return orderDate.getFullYear() === now.getFullYear();
      }
      if (dateFilter === 'custom' && customStartDate && customEndDate) {
        const start = safeParseDate(customStartDate);
        const end = safeParseDate(customEndDate);
        end.setHours(23, 59, 59, 999);
        return orderDate >= start && orderDate <= end;
      }
      return true;
    });
  }, [orders, dateFilter, customStartDate, customEndDate]);

  // Key Revenue Metrics
  const totalRevenue = useMemo(() => {
    return filteredOrders
      .filter(o => o.orderStatus !== 'cancelled' && o.orderStatus !== 'returned')
      .reduce((acc, o) => acc + (Number(o.total) || 0), 0);
  }, [filteredOrders]);

  const todayRevenue = useMemo(() => {
    const todayStr = new Date().toDateString();
    return orders
      .filter(o => safeParseDate(o.date).toDateString() === todayStr && o.orderStatus !== 'cancelled')
      .reduce((acc, o) => acc + (Number(o.total) || 0), 0);
  }, [orders]);

  const monthlyRevenue = useMemo(() => {
    const now = new Date();
    return orders
      .filter(o => {
        const d = safeParseDate(o.date);
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear() && o.orderStatus !== 'cancelled';
      })
      .reduce((acc, o) => acc + (Number(o.total) || 0), 0);
  }, [orders]);

  // Order Counts
  const totalOrdersCount = filteredOrders.length;
  const pendingOrdersCount = filteredOrders.filter(o => o.orderStatus === 'placed' || o.orderStatus === 'pending').length;
  const processingOrdersCount = filteredOrders.filter(o => o.orderStatus === 'confirmed' || o.orderStatus === 'processing' || o.orderStatus === 'packed').length;
  const shippedOrdersCount = filteredOrders.filter(o => o.orderStatus === 'shipped' || o.orderStatus === 'out_for_delivery').length;
  const deliveredOrdersCount = filteredOrders.filter(o => o.orderStatus === 'delivered').length;
  const returnedOrdersCount = filteredOrders.filter(o => o.orderStatus === 'returned').length;
  const cancelledOrdersCount = filteredOrders.filter(o => o.orderStatus === 'cancelled').length;
  const totalReturnedOrCancelledCount = returnedOrdersCount + cancelledOrdersCount;

  // Inventory & Product Counts
  const totalProductsCount = products.length;
  const lowStockProducts = useMemo(() => products.filter(p => p.stock > 0 && p.stock <= 5), [products]);
  const outOfStockProducts = useMemo(() => products.filter(p => p.stock === 0), [products]);

  // Average Order Value
  const averageOrderValue = totalOrdersCount > 0 ? Math.round(totalRevenue / (totalOrdersCount - totalReturnedOrCancelledCount || 1)) : 0;

  // Delivery Rate %
  const deliverySuccessRate = totalOrdersCount > 0 
    ? Math.round((deliveredOrdersCount / totalOrdersCount) * 100) 
    : 100;

  // ==========================================
  // 1. DELIVERED PRODUCTS DETAILED EXTRACTION
  // ==========================================
  const deliveredProductsDetailedList = useMemo(() => {
    const list: {
      order: Order;
      product: Product;
      quantity: number;
      unitPrice: number;
      totalAmount: number;
      deliveredDate: string;
    }[] = [];

    filteredOrders.forEach(order => {
      if (order.orderStatus === 'delivered' && Array.isArray(order.items)) {
        order.items.forEach(item => {
          if (!item?.product) return;
          const unitPrice = typeof item.product.price === 'number' ? item.product.price : (Number(item.product.price) || 0);
          const qty = Number(item.quantity) || 1;
          list.push({
            order,
            product: item.product,
            quantity: qty,
            unitPrice,
            totalAmount: qty * unitPrice,
            deliveredDate: safeDateToISODate(order.date),
          });
        });
      }
    });

    return list;
  }, [filteredOrders]);

  const totalDeliveredUnits = useMemo(() => {
    return deliveredProductsDetailedList.reduce((sum, item) => sum + item.quantity, 0);
  }, [deliveredProductsDetailedList]);

  const totalDeliveredRevenue = useMemo(() => {
    return deliveredProductsDetailedList.reduce((sum, item) => sum + item.totalAmount, 0);
  }, [deliveredProductsDetailedList]);

  // ==========================================
  // 2. RETURNED & CANCELLED PRODUCTS EXTRACTION
  // ==========================================
  const returnedProductsDetailedList = useMemo(() => {
    const list: {
      order: Order;
      product: Product;
      quantity: number;
      unitPrice: number;
      totalAmount: number;
      status: OrderStatus;
      date: string;
    }[] = [];

    filteredOrders.forEach(order => {
      if ((order.orderStatus === 'returned' || order.orderStatus === 'cancelled') && Array.isArray(order.items)) {
        order.items.forEach(item => {
          if (!item?.product) return;
          const unitPrice = typeof item.product.price === 'number' ? item.product.price : (Number(item.product.price) || 0);
          const qty = Number(item.quantity) || 1;
          list.push({
            order,
            product: item.product,
            quantity: qty,
            unitPrice,
            totalAmount: qty * unitPrice,
            status: order.orderStatus,
            date: safeDateToISODate(order.date),
          });
        });
      }
    });

    return list;
  }, [filteredOrders]);

  const totalReturnedUnits = useMemo(() => {
    return returnedProductsDetailedList.reduce((sum, item) => sum + item.quantity, 0);
  }, [returnedProductsDetailedList]);

  const totalReturnedValue = useMemo(() => {
    return returnedProductsDetailedList.reduce((sum, item) => sum + item.totalAmount, 0);
  }, [returnedProductsDetailedList]);

  // Filtered tracker list based on search
  const filteredTrackerDelivered = useMemo(() => {
    if (!trackerSearch.trim()) return deliveredProductsDetailedList;
    const q = trackerSearch.toLowerCase();
    return deliveredProductsDetailedList.filter(item => 
      String(item.product?.titleBn || '').toLowerCase().includes(q) ||
      String(item.product?.titleEn || '').toLowerCase().includes(q) ||
      String(item.order?.customerName || '').toLowerCase().includes(q) ||
      String(item.order?.phone || '').includes(q) ||
      String(item.order?.id || '').toLowerCase().includes(q) ||
      String(item.product?.sku || '').toLowerCase().includes(q)
    );
  }, [deliveredProductsDetailedList, trackerSearch]);

  const filteredTrackerReturned = useMemo(() => {
    if (!trackerSearch.trim()) return returnedProductsDetailedList;
    const q = trackerSearch.toLowerCase();
    return returnedProductsDetailedList.filter(item => 
      String(item.product?.titleBn || '').toLowerCase().includes(q) ||
      String(item.product?.titleEn || '').toLowerCase().includes(q) ||
      String(item.order?.customerName || '').toLowerCase().includes(q) ||
      String(item.order?.phone || '').includes(q) ||
      String(item.order?.id || '').toLowerCase().includes(q) ||
      String(item.product?.sku || '').toLowerCase().includes(q)
    );
  }, [returnedProductsDetailedList, trackerSearch]);

  // Top Selling Products Calculation
  const topSellingProducts = useMemo(() => {
    const salesMap: Record<string, { product: Product; quantity: number; revenue: number }> = {};
    
    filteredOrders.forEach(order => {
      if (order.orderStatus === 'cancelled' || order.orderStatus === 'returned') return;
      if (!Array.isArray(order.items)) return;
      order.items.forEach(item => {
        if (!item?.product?.id) return;
        if (!salesMap[item.product.id]) {
          salesMap[item.product.id] = { product: item.product, quantity: 0, revenue: 0 };
        }
        const unitPrice = typeof item.product.price === 'number' ? item.product.price : (Number(item.product.price) || 0);
        const qty = Number(item.quantity) || 1;
        salesMap[item.product.id].quantity += qty;
        salesMap[item.product.id].revenue += qty * unitPrice;
      });
    });

    return Object.values(salesMap)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 5);
  }, [filteredOrders]);

  // Daily Trend Data (Last 7 days calculation for SVG Chart)
  const chartDays = useMemo(() => {
    const days: { label: string; date: string; revenue: number; orders: number }[] = [];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const dateStr = safeDateToISODate(d);
      const dayOrders = orders.filter(o => {
        const orderD = safeDateToISODate(o.date);
        return orderD === dateStr && o.orderStatus !== 'cancelled' && o.orderStatus !== 'returned';
      });
      const rev = dayOrders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
      days.push({
        label: d.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', { weekday: 'short' }),
        date: dateStr,
        revenue: rev,
        orders: dayOrders.length,
      });
    }
    return days;
  }, [orders, language]);

  const maxRevenue = Math.max(...chartDays.map(d => d.revenue), 1000);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner & Date Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-neutral-900/70 border border-neutral-800 p-4 sm:p-5 rounded-3xl backdrop-blur-sm">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <span>{language === 'bn' ? 'ওভারভিউ ড্যাশবোর্ড' : 'Executive Overview'}</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
              Live Real-Time
            </span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'দোকানের সেলস, ডেলিভারি সম্পন্ন ও রিটার্ন প্রোডাক্টের লাইভ অ্যানালিটিক্স।' 
              : 'Real-time sales performance, delivered vs returned products and inventory tracking.'}
          </p>
        </div>

        {/* Date Filter Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 bg-neutral-950 p-1.5 rounded-2xl border border-neutral-800">
          {[
            { id: 'today', labelBn: 'আজ', labelEn: 'Today' },
            { id: '7days', labelBn: '৭ দিন', labelEn: '7 Days' },
            { id: '30days', labelBn: '৩০ দিন', labelEn: '30 Days' },
            { id: 'month', labelBn: 'এই মাস', labelEn: 'This Month' },
            { id: 'year', labelBn: 'এই বছর', labelEn: 'This Year' },
            { id: 'custom', labelBn: 'কাস্টম', labelEn: 'Custom' },
          ].map(opt => (
            <button
              key={opt.id}
              onClick={() => setDateFilter(opt.id as DateFilterOption)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                dateFilter === opt.id 
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-900/40' 
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
              }`}
            >
              {language === 'bn' ? opt.labelBn : opt.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Custom Date Range Selectors */}
      {dateFilter === 'custom' && (
        <div className="flex flex-wrap items-center gap-3 p-4 bg-neutral-900 border border-neutral-800 rounded-2xl">
          <div className="flex items-center gap-2 text-xs text-neutral-300">
            <span>{language === 'bn' ? 'শুরু:' : 'From:'}</span>
            <input 
              type="date" 
              value={customStartDate} 
              onChange={(e) => setCustomStartDate(e.target.value)} 
              className="px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-xl text-xs text-white"
            />
          </div>
          <div className="flex items-center gap-2 text-xs text-neutral-300">
            <span>{language === 'bn' ? 'শেষ:' : 'To:'}</span>
            <input 
              type="date" 
              value={customEndDate} 
              onChange={(e) => setCustomEndDate(e.target.value)} 
              className="px-3 py-1.5 bg-neutral-950 border border-neutral-700 rounded-xl text-xs text-white"
            />
          </div>
        </div>
      )}

      {/* 1-Click Live Cloud Publish Action Card */}
      {onOpenLivePublish && (
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-rose-950/60 via-amber-950/40 to-neutral-900/80 border border-rose-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-rose-600 to-orange-500 flex items-center justify-center text-white shrink-0 shadow-md">
              <CloudUpload className="w-6 h-6 text-amber-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-sm sm:text-base font-black text-white">
                  {language === 'bn' ? '🚀 ১-ক্লিক অটোমেটিক লাইভ পাবলিশ' : '🚀 1-Click Automatic Live Publish'}
                </h4>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[9px] font-bold">
                  Live Cloud
                </span>
              </div>
              <p className="text-xs text-neutral-300 mt-0.5">
                {language === 'bn'
                  ? 'গুগল স্টুডিওতে আপনার যোগ করা নতুন পণ্য, ছবি ও ডিজাইন সরাসরি ডিপ্লয় করা ওয়েবসাইটে (https://gift-ghor.ai.studio) পাঠিয়ে দিন।'
                  : 'Instantly push all changes from Google Studio directly to your deployed live website.'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 self-end sm:self-center">
            <a
              href="https://gift-ghor.ai.studio"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold flex items-center gap-1.5 border border-neutral-700 transition"
            >
              <Globe className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">লাইভ লিংক</span>
            </a>
            <button
              onClick={onOpenLivePublish}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 via-rose-700 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition cursor-pointer shrink-0"
            >
              <CloudUpload className="w-4 h-4 text-amber-300" />
              <span>{language === 'bn' ? 'লাইভ সাইটে পাবলিশ করুন' : 'Publish Live Now'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Top 4 Key Performance Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Revenue */}
        <div className="bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800/90 p-5 rounded-3xl group hover:border-rose-500/40 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400">
              {language === 'bn' ? 'মোট বিক্রয় আয়' : 'Total Revenue'}
            </span>
            <div className="w-9 h-9 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-white">
              {formatPrice(totalRevenue, language)}
            </h3>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold mt-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+{language === 'bn' ? '১২.৪%' : '12.4%'} vs last period</span>
            </div>
          </div>
        </div>

        {/* Total Orders */}
        <div 
          onClick={() => onNavigateTab('orders')}
          className="bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800/90 p-5 rounded-3xl group hover:border-indigo-500/40 transition cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400">
              {language === 'bn' ? 'মোট অর্ডার' : 'Total Orders'}
            </span>
            <div className="w-9 h-9 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-white">
              {language === 'bn' ? toBengaliNumber(totalOrdersCount) : totalOrdersCount}
            </h3>
            <span className="text-xs text-neutral-400">
              {language === 'bn' ? 'কাস্টমার রিকোয়েস্ট' : 'Customer orders'}
            </span>
          </div>
        </div>

        {/* Delivered Orders */}
        <div className="bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800/90 p-5 rounded-3xl group hover:border-emerald-500/40 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400">
              {language === 'bn' ? 'ডেলিভারি সম্পন্ন' : 'Delivered Orders'}
            </span>
            <div className="w-9 h-9 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-white">
              {language === 'bn' ? toBengaliNumber(deliveredOrdersCount) : deliveredOrdersCount}
            </h3>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold mt-1">
              <span>{language === 'bn' ? `${toBengaliNumber(totalDeliveredUnits)} টি পণ্য বিতরণ` : `${totalDeliveredUnits} units delivered`}</span>
            </div>
          </div>
        </div>

        {/* Returned / Cancelled */}
        <div className="bg-gradient-to-br from-neutral-900 to-neutral-950 border border-neutral-800/90 p-5 rounded-3xl group hover:border-red-500/40 transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-400">
              {language === 'bn' ? 'রিটার্ন ও বাতিল' : 'Returned / Void'}
            </span>
            <div className="w-9 h-9 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center">
              <RotateCcw className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black text-white">
              {language === 'bn' ? toBengaliNumber(totalReturnedOrCancelledCount) : totalReturnedOrCancelledCount}
            </h3>
            <span className="text-xs text-red-400/80 font-bold">
              {language === 'bn' ? `${toBengaliNumber(totalReturnedUnits)} টি পণ্য ফেরত` : `${totalReturnedUnits} units returned`}
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 🚀 HIGHLIGHTED: DELIVERED VS RETURNED PRODUCTS LIVE TRACKER SECTION       */}
      {/* (Fulfilling user request: "ডেলিভারি সম্পূর্ণ হওয়া ও রিটার্ন হওয়া পণ্যের তালিকা") */}
      {/* ========================================================================= */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 sm:p-6 space-y-5 shadow-2xl">
        {/* Header & Mini Stats */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-neutral-800/80 pb-4">
          <div>
            <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              <ListOrdered className="w-5 h-5 text-rose-400" />
              <span>{language === 'bn' ? 'ডেলিভারি সম্পন্ন ও রিটার্ন প্রোডাক্ট ট্র্যাকার' : 'Delivered vs Returned Products Tracker'}</span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              {language === 'bn' 
                ? 'সফলভাবে ডেলিভারি হওয়া এবং রিটার্ন / বাতিল হওয়া প্রতিটি পণ্যের সংখ্যা ও বিস্তারিত তালিকা।' 
                : 'Complete live itemized list of all products delivered vs returned/cancelled.'}
            </p>
          </div>

          {/* 3 Quick Stat Badges */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <div className="px-3 py-1.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 flex items-center gap-2 text-xs font-bold">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>{language === 'bn' ? `ডেলিভারি: ${toBengaliNumber(totalDeliveredUnits)} টি পণ্য` : `Delivered: ${totalDeliveredUnits} units`}</span>
              <span className="font-mono text-white text-[11px]">({formatPrice(totalDeliveredRevenue, language)})</span>
            </div>

            <div className="px-3 py-1.5 rounded-2xl bg-red-950/40 border border-red-500/30 text-red-400 flex items-center gap-2 text-xs font-bold">
              <RotateCcw className="w-3.5 h-3.5 text-red-400" />
              <span>{language === 'bn' ? `রিটার্ন: ${toBengaliNumber(totalReturnedUnits)} টি পণ্য` : `Returned: ${totalReturnedUnits} units`}</span>
              <span className="font-mono text-white text-[11px]">({formatPrice(totalReturnedValue, language)})</span>
            </div>

            <div className="px-3 py-1.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 text-indigo-400 flex items-center gap-1.5 text-xs font-bold">
              <Percent className="w-3.5 h-3.5 text-indigo-400" />
              <span>{language === 'bn' ? `সাফল্য: ${toBengaliNumber(deliverySuccessRate)}%` : `Success: ${deliverySuccessRate}%`}</span>
            </div>
          </div>
        </div>

        {/* Tab Switcher & Search Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 bg-neutral-950 p-1.5 rounded-2xl border border-neutral-800">
            <button
              onClick={() => setTrackerTab('delivered')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                trackerTab === 'delivered' 
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/40' 
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{language === 'bn' ? `ডেলিভারি সম্পন্ন পণ্য (${toBengaliNumber(deliveredProductsDetailedList.length)})` : `Delivered Products (${deliveredProductsDetailedList.length})`}</span>
            </button>

            <button
              onClick={() => setTrackerTab('returned')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition cursor-pointer flex items-center gap-2 ${
                trackerTab === 'returned' 
                  ? 'bg-red-600 text-white shadow-lg shadow-red-900/40' 
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <XCircle className="w-4 h-4" />
              <span>{language === 'bn' ? `রিটার্ন ও বাতিল পণ্য (${toBengaliNumber(returnedProductsDetailedList.length)})` : `Returned Products (${returnedProductsDetailedList.length})`}</span>
            </button>
          </div>

          {/* Quick Search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={trackerSearch}
              onChange={(e) => setTrackerSearch(e.target.value)}
              placeholder={language === 'bn' ? 'পণ্য বা ক্রেতার নাম...' : 'Search items or customer...'}
              className="w-full pl-9 pr-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:border-rose-500 outline-none"
            />
          </div>
        </div>

        {/* Tab 1: Delivered Products Table */}
        {trackerTab === 'delivered' && (
          <div className="overflow-x-auto rounded-2xl border border-neutral-800/80 bg-neutral-950/60">
            <table className="w-full text-left text-xs text-neutral-300">
              <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'পণ্য ও বিবরণ' : 'Product & Specs'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'অর্ডার আইডি ও গ্রাহক' : 'Order ID & Customer'}</th>
                  <th className="py-3 px-3.5 text-center">{language === 'bn' ? 'ডেলিভারি পরিমাণ' : 'Delivered Qty'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'একক মূল্য' : 'Unit Price'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'মোট বিক্রয়' : 'Total Revenue'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'পেমেন্ট' : 'Payment'}</th>
                  <th className="py-3 px-3.5 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredTrackerDelivered.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-neutral-500">
                      <CheckCircle2 className="w-7 h-7 mx-auto mb-2 text-neutral-600" />
                      <p>{language === 'bn' ? 'নির্বাচিত ফিল্টারে কোনো ডেলিভারি সম্পন্ন পণ্য পাওয়া যায়নি।' : 'No delivered products found in this period.'}</p>
                    </td>
                  </tr>
                ) : (
                  filteredTrackerDelivered.map((item, idx) => (
                    <tr key={idx} className="hover:bg-neutral-800/40 transition">
                      <td className="py-3 px-3.5">
                        <div className="flex items-center gap-3">
                          <img 
                            src={item.product.image || '/products/1719939868_L_3.jpg'} 
                            alt="" 
                            className="w-10 h-10 rounded-xl object-cover bg-neutral-900 border border-neutral-800 shrink-0" 
                          />
                          <div className="overflow-hidden max-w-xs">
                            <p className="font-bold text-neutral-100 truncate text-xs">
                              {language === 'bn' ? item.product.titleBn : item.product.titleEn}
                            </p>
                            <p className="text-[10px] text-neutral-400 font-mono">
                              SKU: {item.product.sku || item.product.id} • {item.product.category}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3.5">
                        <div className="font-mono text-rose-400 font-bold text-[11px]">{item.order.id}</div>
                        <div className="text-neutral-200 font-medium text-xs">{item.order.customerName}</div>
                        <div className="text-[10px] text-neutral-500">{item.order.phone}</div>
                      </td>
                      <td className="py-3 px-3.5 text-center">
                        <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 font-black text-xs border border-emerald-500/30">
                          {language === 'bn' ? `${toBengaliNumber(item.quantity)} টি` : `${item.quantity} pcs`}
                        </span>
                      </td>
                      <td className="py-3 px-3.5 font-medium text-neutral-300">
                        {formatPrice(item.unitPrice, language)}
                      </td>
                      <td className="py-3 px-3.5 font-black text-emerald-400 text-xs">
                        {formatPrice(item.totalAmount, language)}
                      </td>
                      <td className="py-3 px-3.5">
                        <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-neutral-800 text-neutral-300 uppercase">
                          {item.order.paymentMethod}
                        </span>
                      </td>
                      <td className="py-3 px-3.5 text-right">
                        <button
                          onClick={() => handleOrderClick(item.order)}
                          className="px-2.5 py-1 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold transition flex items-center gap-1 ml-auto cursor-pointer"
                          title="View order details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'অর্ডার' : 'View'}</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 2: Returned & Cancelled Products Table */}
        {trackerTab === 'returned' && (
          <div className="overflow-x-auto rounded-2xl border border-neutral-800/80 bg-neutral-950/60">
            <table className="w-full text-left text-xs text-neutral-300">
              <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'পণ্য ও বিবরণ' : 'Product & Specs'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'অর্ডার আইডি ও গ্রাহক' : 'Order ID & Customer'}</th>
                  <th className="py-3 px-3.5 text-center">{language === 'bn' ? 'রিটার্ন পরিমাণ' : 'Returned Qty'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'মূল্য ক্ষতি' : 'Value Loss'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'স্ট্যাটাস' : 'Status'}</th>
                  <th className="py-3 px-3.5">{language === 'bn' ? 'তারিখ' : 'Date'}</th>
                  <th className="py-3 px-3.5 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredTrackerReturned.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-neutral-500">
                      <CheckCircle2 className="w-7 h-7 mx-auto mb-2 text-emerald-400" />
                      <p>{language === 'bn' ? 'অভিনন্দন! এই সময়সীমায় কোনো রিটার্ন বা বাতিল পণ্য নেই।' : 'Zero returned or cancelled products in this timeframe.'}</p>
                    </td>
                  </tr>
                ) : (
                  filteredTrackerReturned.map((item, idx) => (
                    <tr key={idx} className="hover:bg-neutral-800/40 transition">
                      <td className="py-3 px-3.5">
                        <div className="flex items-center gap-3">
                          <img 
                            src={item.product.image || '/products/1719939868_L_3.jpg'} 
                            alt="" 
                            className="w-10 h-10 rounded-xl object-cover bg-neutral-900 border border-neutral-800 shrink-0" 
                          />
                          <div className="overflow-hidden max-w-xs">
                            <p className="font-bold text-neutral-100 truncate text-xs">
                              {language === 'bn' ? item.product.titleBn : item.product.titleEn}
                            </p>
                            <p className="text-[10px] text-neutral-400 font-mono">
                              SKU: {item.product.sku || item.product.id} • {item.product.category}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3.5">
                        <div className="font-mono text-rose-400 font-bold text-[11px]">{item.order.id}</div>
                        <div className="text-neutral-200 font-medium text-xs">{item.order.customerName}</div>
                        <div className="text-[10px] text-neutral-500">{item.order.phone}</div>
                      </td>
                      <td className="py-3 px-3.5 text-center">
                        <span className="px-2.5 py-1 rounded-xl bg-red-500/20 text-red-400 font-black text-xs border border-red-500/30">
                          {language === 'bn' ? `${toBengaliNumber(item.quantity)} টি` : `${item.quantity} pcs`}
                        </span>
                      </td>
                      <td className="py-3 px-3.5 font-bold text-red-400 text-xs">
                        {formatPrice(item.totalAmount, language)}
                      </td>
                      <td className="py-3 px-3.5">
                        <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/30 uppercase">
                          {item.status}
                        </span>
                      </td>
                      <td className="py-3 px-3.5 text-[11px] text-neutral-400">
                        {safeDateToLocaleString(item.date)}
                      </td>
                      <td className="py-3 px-3.5 text-right">
                        <button
                          onClick={() => handleOrderClick(item.order)}
                          className="px-2.5 py-1 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold transition flex items-center gap-1 ml-auto cursor-pointer"
                          title="View order details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'অর্ডার' : 'View'}</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Interactive Sales Chart & Low Stock Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Trend (Last 7 Days Bar Chart) */}
        <div className="lg:col-span-2 bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-rose-400" />
                <span>{language === 'bn' ? 'দৈনিক সেলস ট্রেন্ড (গত ৭ দিন)' : 'Daily Sales Trend (Last 7 Days)'}</span>
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                {language === 'bn' ? 'দৈনিক মোট রাজস্ব ও আয়' : 'Revenue generated per day'}
              </p>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-xl">
              +14.8% Growth
            </span>
          </div>

          {/* SVG Bar Chart */}
          <div className="pt-6 pb-2">
            <div className="h-44 flex items-end justify-between gap-2 sm:gap-4 px-2">
              {chartDays.map((day, idx) => {
                const heightPercent = Math.max(Math.round((day.revenue / maxRevenue) * 100), 8);
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 group relative">
                    <div className="absolute -top-10 opacity-0 group-hover:opacity-100 transition-opacity bg-neutral-950 text-white text-[10px] font-bold px-2 py-1 rounded-lg border border-neutral-700 pointer-events-none whitespace-nowrap z-20 shadow-xl">
                      {formatPrice(day.revenue, language)} ({day.orders} ord)
                    </div>

                    <div className="w-full bg-neutral-800/80 rounded-2xl overflow-hidden h-36 flex items-end">
                      <div 
                        style={{ height: `${heightPercent}%` }}
                        className="w-full bg-gradient-to-t from-rose-600 to-red-500 rounded-t-xl group-hover:from-rose-500 group-hover:to-orange-400 transition-all duration-500"
                      />
                    </div>
                    <span className="text-[11px] font-bold text-neutral-400">
                      {day.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>{language === 'bn' ? 'স্টক সতর্কবার্তা' : 'Low Stock Alerts'}</span>
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                {lowStockProducts.length + outOfStockProducts.length} Items
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              {language === 'bn' ? 'যেসব পণ্যের স্টক দ্রুত শেষ হয়ে আসছে' : 'Products that require immediate restock.'}
            </p>

            <div className="mt-4 space-y-2.5 max-h-56 overflow-y-auto custom-scrollbar pr-1">
              {lowStockProducts.length === 0 && outOfStockProducts.length === 0 ? (
                <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800 text-center text-xs text-emerald-400">
                  {language === 'bn' ? 'সব পণ্যের পর্যাপ্ত স্টক রয়েছে!' : 'All products are well stocked!'}
                </div>
              ) : (
                [...outOfStockProducts, ...lowStockProducts].slice(0, 4).map(prod => (
                  <div key={prod.id} className="p-2.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <img src={prod.image} alt="" className="w-9 h-9 rounded-xl object-cover bg-neutral-800 shrink-0" />
                      <div className="overflow-hidden">
                        <p className="text-xs font-bold text-neutral-200 truncate">
                          {language === 'bn' ? prod.titleBn : prod.titleEn}
                        </p>
                        <p className="text-[10px] text-neutral-400">{formatPrice(prod.price, language)}</p>
                      </div>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg shrink-0 ${
                      prod.stock === 0 
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30' 
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}>
                      {prod.stock === 0 ? (language === 'bn' ? '০ স্টক' : 'Out') : `${language === 'bn' ? toBengaliNumber(prod.stock) : prod.stock} Left`}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('inventory')}
            className="w-full py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold flex items-center justify-center gap-2 border border-neutral-700 transition cursor-pointer"
          >
            <span>{language === 'bn' ? 'সম্পূর্ণ ইনভেন্টরি ম্যানেজ করুন' : 'Manage Full Inventory'}</span>
            <ChevronRight className="w-4 h-4 text-neutral-400" />
          </button>
        </div>
      </div>

      {/* Recent Orders & Top Selling Products */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-rose-400" />
                <span>{language === 'bn' ? 'সাম্প্রতিক অর্ডারসমূহ' : 'Recent Orders'}</span>
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                {language === 'bn' ? 'সর্বশেষ গ্রাহক ক্রয়ের তালিকা' : 'Latest customer transactions'}
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('orders')}
              className="text-xs font-bold text-rose-400 hover:text-rose-300 transition flex items-center gap-1 cursor-pointer"
            >
              <span>{language === 'bn' ? 'সব অর্ডার' : 'View All'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-300">
              <thead className="bg-neutral-950/60 text-neutral-400 uppercase text-[10px] font-bold border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-3">Order ID</th>
                  <th className="py-3 px-3">{language === 'bn' ? 'গ্রাহক' : 'Customer'}</th>
                  <th className="py-3 px-3">{language === 'bn' ? 'পেমেন্ট' : 'Payment'}</th>
                  <th className="py-3 px-3">{language === 'bn' ? 'মোট' : 'Total'}</th>
                  <th className="py-3 px-3">{language === 'bn' ? 'স্ট্যাটাস' : 'Status'}</th>
                  <th className="py-3 px-3 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredOrders.slice(0, 5).map(order => (
                  <tr key={order.id} className="hover:bg-neutral-800/40 transition">
                    <td className="py-3 px-3 font-mono font-bold text-rose-400">
                      {order.id}
                    </td>
                    <td className="py-3 px-3 font-semibold text-neutral-200">
                      <div>{order.customerName}</div>
                      <div className="text-[10px] text-neutral-500">{order.phone}</div>
                    </td>
                    <td className="py-3 px-3 uppercase text-[11px] font-bold text-neutral-300">
                      {order.paymentMethod}
                    </td>
                    <td className="py-3 px-3 font-bold text-white">
                      {formatPrice(order.total, language)}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold capitalize ${
                        order.orderStatus === 'delivered' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        order.orderStatus === 'shipped' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' :
                        order.orderStatus === 'cancelled' || order.orderStatus === 'returned' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                        'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}>
                        {order.orderStatus}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {(order.orderStatus === 'placed' || order.orderStatus === 'pending') && onUpdateOrderStatus && (
                          <button
                            onClick={() => onUpdateOrderStatus(order.id, 'confirmed')}
                            className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold flex items-center gap-1 transition shadow-sm cursor-pointer"
                            title={language === 'bn' ? 'অর্ডার অ্যাপ্রুভ / কনফার্ম করুন' : 'Approve & Confirm Order'}
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{language === 'bn' ? 'অ্যাপ্রুভ' : 'Approve'}</span>
                          </button>
                        )}
                        <button
                          onClick={() => handleOrderClick(order)}
                          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition cursor-pointer"
                          title="View Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Selling Products List */}
        <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-black text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{language === 'bn' ? 'টপ সেলিং পণ্য' : 'Top Selling'}</span>
            </h3>
            <button
              onClick={() => onNavigateTab('products')}
              className="text-xs font-bold text-rose-400 hover:text-rose-300"
            >
              {language === 'bn' ? 'সকল পণ্য' : 'All'}
            </button>
          </div>

          <div className="space-y-3">
            {topSellingProducts.length === 0 ? (
              <p className="text-xs text-neutral-500 text-center py-6">
                {language === 'bn' ? 'কোনো সেলস রেকর্ড পাওয়া যায়নি।' : 'No sales records yet.'}
              </p>
            ) : (
              topSellingProducts.map((item, idx) => (
                <div key={item.product.id} className="flex items-center justify-between gap-3 p-2.5 rounded-2xl bg-neutral-950 border border-neutral-800/80">
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <span className="w-5 h-5 rounded-lg bg-neutral-800 text-[10px] font-black text-neutral-300 flex items-center justify-center shrink-0">
                      #{idx + 1}
                    </span>
                    <img src={item.product.image} alt="" className="w-9 h-9 rounded-xl object-cover bg-neutral-800 shrink-0" />
                    <div className="overflow-hidden">
                      <p className="text-xs font-bold text-neutral-200 truncate">
                        {language === 'bn' ? item.product.titleBn : item.product.titleEn}
                      </p>
                      <p className="text-[10px] text-neutral-400">
                        {item.quantity} {language === 'bn' ? 'টি বিক্রিত' : 'sold'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs font-black text-emerald-400">{formatPrice(item.revenue, language)}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
