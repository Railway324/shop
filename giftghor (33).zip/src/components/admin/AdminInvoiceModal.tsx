import React from 'react';
import { Printer, X, ShoppingBag, Phone, MapPin, CheckCircle, ShieldCheck } from 'lucide-react';
import { Order, Language } from '../../types';
import { formatPrice } from '../../utils/translations';
import { safeDateToLocaleString } from '../../utils/dateUtils';

interface AdminInvoiceModalProps {
  order: Order | null;
  language: Language;
  onClose: () => void;
}

export const AdminInvoiceModal: React.FC<AdminInvoiceModalProps> = ({
  order,
  language,
  onClose,
}) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const totalItemsCount = order.items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto print:p-0 print:bg-white animate-fadeIn">
      {/* Container */}
      <div className="bg-neutral-900 border border-neutral-800 w-full max-w-2xl rounded-3xl p-6 sm:p-8 space-y-6 my-6 shadow-2xl print:border-none print:shadow-none print:bg-white print:text-black print:m-0 print:p-6 print:rounded-none">
        {/* Header Actions (hidden on print) */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-4 print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-rose-400" />
            <h3 className="text-base font-bold text-white">Invoice / Delivery Memo Voucher</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Invoice</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Area */}
        <div className="space-y-6 bg-white text-neutral-900 p-6 sm:p-8 rounded-2xl print:p-0">
          {/* Top Invoice Brand & Meta */}
          <div className="flex items-start justify-between border-b border-neutral-200 pb-6">
            <div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full overflow-hidden ring-1 ring-orange-400 bg-white flex items-center justify-center shrink-0">
                  <img src="/logo.png?v=20260924_2" alt="Happy Shopping" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div>
                  <h1 className="text-xl font-black text-neutral-900 tracking-tight">Happy Shopping</h1>
                  <p className="text-[10px] text-orange-600 font-bold">Better Product • Happier You</p>
                </div>
              </div>
              <div className="mt-3 text-xs text-neutral-600 space-y-0.5">
                <p>House #45, Dhanmondi 27, Dhaka-1209</p>
                <p>Helpline: support@happyshopping.com</p>
              </div>
            </div>

            <div className="text-right">
              <span className="inline-block px-2.5 py-1 rounded bg-neutral-100 text-neutral-800 font-black text-xs uppercase tracking-wider mb-2">
                INVOICE MEMO
              </span>
              <p className="text-xs font-mono font-bold text-neutral-900">
                Invoice #{order.id}
              </p>
              <p className="text-xs text-neutral-500">
                Date: {safeDateToLocaleString(order.date, 'en-GB')}
              </p>
              {order.courierName && (
                <p className="text-[11px] font-bold text-rose-600 mt-1 capitalize">
                  Courier: {order.courierName} {order.trackingCode ? `(#${order.trackingCode})` : ''}
                </p>
              )}
            </div>
          </div>

          {/* Customer Bill To & Ship To */}
          <div className="grid grid-cols-2 gap-6 text-xs border-b border-neutral-200 pb-6">
            <div>
              <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-wider mb-1">
                BILL TO / CUSTOMER:
              </h4>
              <p className="font-bold text-neutral-900 text-sm">{order.customerName}</p>
              <p className="text-neutral-700 font-medium">{order.phone}</p>
              {order.email && <p className="text-neutral-600 text-[11px]">{order.email}</p>}
            </div>

            <div>
              <h4 className="text-[10px] font-black uppercase text-neutral-400 tracking-wider mb-1">
                DELIVERY DESTINATION:
              </h4>
              <p className="text-neutral-800 leading-relaxed font-medium">
                {order.address}
              </p>
              <div className="mt-2 text-[11px] font-semibold text-neutral-600">
                Payment: <span className="uppercase font-bold text-neutral-900">{order.paymentMethod}</span> ({order.paymentStatus || 'Pending'})
              </div>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-800">
              <thead className="bg-neutral-100 text-neutral-700 uppercase text-[10px] font-black border-b border-neutral-200">
                <tr>
                  <th className="py-2.5 px-3">SL</th>
                  <th className="py-2.5 px-3">Item Description</th>
                  <th className="py-2.5 px-3">Variant</th>
                  <th className="py-2.5 px-3 text-center">Qty</th>
                  <th className="py-2.5 px-3 text-right">Unit Price</th>
                  <th className="py-2.5 px-3 text-right">Total (BDT)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 font-medium">
                {order.items.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-2.5 px-3 font-bold text-neutral-500">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-bold text-neutral-900">
                      {item.product.titleEn}
                    </td>
                    <td className="py-2.5 px-3 text-neutral-600">
                      {[
                        item.selectedSize ? `Size: ${item.selectedSize}` : '',
                        item.selectedColor ? `Color: ${item.selectedColor}` : '',
                      ].filter(Boolean).join(' • ') || '—'}
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold">
                      {item.quantity}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium">
                      ৳{item.product.price}
                    </td>
                    <td className="py-2.5 px-3 text-right font-black text-neutral-900">
                      ৳{item.quantity * item.product.price}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Calculation Breakdown & Signature */}
          <div className="grid grid-cols-2 gap-6 pt-2 border-t border-neutral-200">
            <div className="space-y-2 text-xs text-neutral-600">
              <p className="font-semibold text-neutral-900">Terms & Instructions:</p>
              <ul className="list-disc list-inside space-y-1 text-[11px]">
                <li>Please check the parcel in front of the delivery rider.</li>
                <li>7-day replacement warranty for manufacturing defects.</li>
                <li>Keep this invoice memo safe for any warranty claim.</li>
              </ul>
            </div>

            <div className="space-y-1.5 text-xs text-right">
              <div className="flex justify-between text-neutral-600">
                <span>Items Subtotal:</span>
                <span className="font-semibold">৳{order.items.reduce((s, i) => s + i.quantity * i.product.price, 0)}</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Delivery Charge:</span>
                <span className="font-semibold">৳60</span>
              </div>
              <div className="flex justify-between text-sm font-black text-neutral-900 pt-2 border-t border-neutral-300">
                <span>Amount Payable:</span>
                <span className="text-base text-rose-600 font-black">৳{order.total}</span>
              </div>
            </div>
          </div>

          {/* Signature Footer */}
          <div className="pt-10 flex items-center justify-between text-xs text-neutral-500 border-t border-neutral-200">
            <div className="text-center">
              <div className="w-36 border-b border-neutral-400 mb-1" />
              <p>Customer Signature</p>
            </div>

            <div className="text-center">
              <div className="w-36 border-b border-neutral-400 mb-1" />
              <p>Authorized Signature & Seal</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
