import React, { useState, useEffect } from 'react';
import { 
  Palette, 
  Type, 
  Image as ImageIcon, 
  Sparkles, 
  Zap, 
  Sliders, 
  Save, 
  RotateCcw, 
  Check, 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  Layout, 
  Phone, 
  Mail, 
  ShieldCheck, 
  Truck, 
  Clock, 
  RotateCw, 
  Share2, 
  ExternalLink,
  Upload,
  Download,
  CheckCircle2,
  X,
  Layers,
  HelpCircle,
  Smartphone,
  Globe
} from 'lucide-react';
import { 
  WebsiteCustomizerSettings, 
  Language, 
  ThemePreset, 
  Banner, 
  TrustFeature 
} from '../../types';
import { initialWebsiteCustomizerSettings, saveCustomizerSettingsToStorage, saveSettingsToServer } from '../../utils/storage';
import { ImageUploadField } from '../common/ImageUploadField';

interface AdminAppearanceViewProps {
  settings: WebsiteCustomizerSettings;
  language: Language;
  onSaveSettings: (settings: WebsiteCustomizerSettings) => void;
}

export const AdminAppearanceView: React.FC<AdminAppearanceViewProps> = ({
  settings,
  language,
  onSaveSettings,
}) => {
  const [form, setForm] = useState<WebsiteCustomizerSettings>(() => ({
    ...settings,
    features: Array.isArray(settings.features) ? settings.features : initialWebsiteCustomizerSettings.features,
    heroBanners: Array.isArray(settings.heroBanners) ? settings.heroBanners : []
  }));

  const [activeSubTab, setActiveSubTab] = useState<'theme' | 'branding' | 'banners' | 'offers' | 'sections' | 'features' | 'footer' | 'preview'>('theme');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [bannerModalOpen, setBannerModalOpen] = useState(false);
  const [editingBannerIndex, setEditingBannerIndex] = useState<number | null>(null);

  // Banner editing state
  const [bannerForm, setBannerForm] = useState<Banner>({
    id: `banner-${Date.now()}`,
    titleBn: '',
    titleEn: '',
    subtitleBn: '',
    subtitleEn: '',
    badgeBn: '',
    badgeEn: '',
    buttonTextBn: 'এখনই কিনুন',
    buttonTextEn: 'Order Now',
    imageUrl: '',
    bgGradient: 'from-rose-700 via-rose-800 to-neutral-950',
    linkCategory: 'all',
  });

  // Preset Color Palettes
  const THEME_PRESETS: { id: ThemePreset; nameBn: string; nameEn: string; primary: string; accent: string; previewClass: string }[] = [
    { id: 'maroon', nameBn: 'রয়্যাল মেরুন ও গোল্ড (ডিফল্ট)', nameEn: 'Royal Maroon & Gold (Default)', primary: '#800020', accent: '#D4AF37', previewClass: 'from-[#800020] to-[#D4AF37]' },
    { id: 'rose', nameBn: 'রোজ পিঙ্ক', nameEn: 'Rose Luxury', primary: '#E11D48', accent: '#F59E0B', previewClass: 'from-rose-600 to-amber-500' },
    { id: 'emerald', nameBn: 'এমারেল্ড গ্রিন', nameEn: 'Emerald Fresh', primary: '#059669', accent: '#10B981', previewClass: 'from-emerald-600 to-teal-500' },
    { id: 'indigo', nameBn: 'রয়্যাল ইন্ডিগো', nameEn: 'Royal Indigo', primary: '#4338CA', accent: '#6366F1', previewClass: 'from-indigo-600 to-blue-500' },
    { id: 'amber', nameBn: 'গোল্ডেন অ্যাম্বার', nameEn: 'Golden Amber', primary: '#D97706', accent: '#F59E0B', previewClass: 'from-amber-600 to-yellow-500' },
    { id: 'violet', nameBn: 'সাইবার ভায়োলেট', nameEn: 'Cyber Violet', primary: '#7C3AED', accent: '#A855F7', previewClass: 'from-violet-600 to-fuchsia-500' },
    { id: 'crimson', nameBn: 'ক্রিমসন রেড', nameEn: 'Crimson Bold', primary: '#DC2626', accent: '#EF4444', previewClass: 'from-red-600 to-rose-500' },
    { id: 'cyan', nameBn: 'ওশান সায়ান', nameEn: 'Ocean Cyan', primary: '#0891B2', accent: '#06B6D4', previewClass: 'from-cyan-600 to-blue-500' },
    { id: 'midnight', nameBn: 'মিডনাইট ব্ল্যাক', nameEn: 'Midnight Dark', primary: '#171717', accent: '#525252', previewClass: 'from-neutral-900 to-neutral-700' },
    { id: 'custom', nameBn: 'কাস্টম কালার হেক্স', nameEn: 'Custom Hex Colors', primary: form.primaryColorHex, accent: form.accentColorHex, previewClass: 'from-neutral-800 to-neutral-600' }
  ];

  const handleSelectPreset = (preset: typeof THEME_PRESETS[0]) => {
    setForm(prev => ({
      ...prev,
      themePreset: preset.id,
      primaryColorHex: preset.id === 'custom' ? prev.primaryColorHex : preset.primary,
      accentColorHex: preset.id === 'custom' ? prev.accentColorHex : preset.accent,
    }));
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    onSaveSettings(form);
    saveSettingsToServer(form);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetToDefault = () => {
    if (window.confirm(language === 'bn' ? 'আপনি কি নিশ্চিত যে সকল ডিজাইন এবং টেক্সট পূর্বাবস্থায় (Factory Defaults) ফিরিয়ে নিতে চান?' : 'Are you sure you want to reset all designs and texts to default?')) {
      setForm(initialWebsiteCustomizerSettings);
      onSaveSettings(initialWebsiteCustomizerSettings);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  // Export & Import JSON
  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(form, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `gift-ghor-design-backup-${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && typeof parsed === 'object') {
          const merged = { ...initialWebsiteCustomizerSettings, ...parsed };
          setForm(merged);
          onSaveSettings(merged);
          alert(language === 'bn' ? 'ডিজাইন ও কনফিগারেশন সফলভাবে ইমপোর্ট করা হয়েছে!' : 'Design settings imported successfully!');
        }
      } catch (err) {
        alert(language === 'bn' ? 'ভুল বা অকার্যকর JSON ফাইল!' : 'Invalid JSON file!');
      }
    };
    reader.readAsText(file);
  };

  // Banner Handlers
  const handleOpenAddBanner = () => {
    setEditingBannerIndex(null);
    setBannerForm({
      id: `banner-${Date.now()}`,
      titleBn: 'নতুন প্রিমিয়াম কালেকশন',
      titleEn: 'New Premium Collection',
      subtitleBn: '১০০% অরিজিনাল ও ক্যাশ অন ডেলিভারি সুবিধা',
      subtitleEn: '100% Authentic quality with Cash on Delivery across Bangladesh',
      badgeBn: 'নতুন ড্রপ',
      badgeEn: 'New Drop',
      buttonTextBn: 'এখনই কিনুন',
      buttonTextEn: 'Order Now',
      imageUrl: '/products/1719939868_L_3.jpg',
      bgGradient: 'from-rose-700 via-rose-800 to-neutral-950',
      linkCategory: 'all'
    });
    setBannerModalOpen(true);
  };

  const handleOpenEditBanner = (index: number) => {
    setEditingBannerIndex(index);
    setBannerForm({ ...form.heroBanners[index] });
    setBannerModalOpen(true);
  };

  const handleDeleteBanner = (index: number) => {
    const updatedHeroBanners = (form.heroBanners || []).filter((_, i) => i !== index);
    const updatedForm = {
      ...form,
      heroBanners: updatedHeroBanners
    };
    setForm(updatedForm);
    onSaveSettings(updatedForm);
    saveCustomizerSettingsToStorage(updatedForm);
    saveSettingsToServer(updatedForm).catch(err => console.warn('Failed to sync settings to server:', err));
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleSaveBanner = (e: React.FormEvent) => {
    e.preventDefault();
    const list = [...(form.heroBanners || [])];
    if (editingBannerIndex !== null) {
      list[editingBannerIndex] = bannerForm;
    } else {
      list.push(bannerForm);
    }
    const updatedForm = { ...form, heroBanners: list };
    setForm(updatedForm);
    onSaveSettings(updatedForm);
    saveCustomizerSettingsToStorage(updatedForm);
    saveSettingsToServer(updatedForm).catch(err => console.warn('Failed to sync settings to server:', err));
    setBannerModalOpen(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-800 border border-neutral-800 p-5 sm:p-6 rounded-3xl shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center font-black">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <span>{language === 'bn' ? 'ওয়েবসাইট ডিজাইন ও কন্টেন্ট স্টুডিও' : 'Website Design & Content Studio'}</span>
                <span className="bg-rose-500/20 text-rose-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-rose-500/30 uppercase">
                  Full Control
                </span>
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                {language === 'bn'
                  ? 'ওয়েবসাইটের সম্পূর্ণ ডিজাইন, কালার থিম, সকল টেক্সট, ব্যানার, অফার ও হেডার-ফুটার নিজের মতো পরিবর্তন ও নিয়ন্ত্রণ করুন।'
                  : 'Customize all website visuals, theme colors, section headings, banners, flash sale offers, and footer copy.'}
              </p>
            </div>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center flex-wrap gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-neutral-700 cursor-pointer"
            title="Reset to defaults"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'রিসেট' : 'Reset'}</span>
          </button>

          <button
            type="button"
            onClick={handleExportJson}
            className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-neutral-700 cursor-pointer"
            title="Backup settings as JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'ব্যাকআপ' : 'Export'}</span>
          </button>

          <label className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-neutral-700 cursor-pointer">
            <Upload className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'ইমপোর্ট' : 'Import'}</span>
            <input type="file" accept=".json" onChange={handleImportJson} className="hidden" />
          </label>

          <button
            type="button"
            onClick={() => handleSave()}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-black transition flex items-center gap-2 shadow-lg shadow-rose-950/50 cursor-pointer"
          >
            {savedSuccess ? <Check className="w-4 h-4 text-white" /> : <Save className="w-4 h-4 text-white" />}
            <span>{savedSuccess ? (language === 'bn' ? 'সফলভাবে সেভ হয়েছে!' : 'Changes Saved!') : (language === 'bn' ? 'সব সেভ করুন' : 'Save Changes')}</span>
          </button>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar bg-neutral-900/90 border border-neutral-800 p-1.5 rounded-2xl">
        {[
          { id: 'theme', labelBn: 'রং ও থিম', labelEn: 'Colors & Theme', icon: Palette },
          { id: 'branding', labelBn: 'ব্র্যান্ড ও হেডার', labelEn: 'Brand & Header', icon: Globe },
          { id: 'banners', labelBn: 'হিরো ব্যানার', labelEn: 'Hero Banners', icon: ImageIcon },
          { id: 'offers', labelBn: 'ফ্ল্যাশ সেল ও অফার', labelEn: 'Offers & Flash Sale', icon: Zap },
          { id: 'sections', labelBn: 'সেকশন টেক্সট', labelEn: 'Section Headings', icon: Type },
          { id: 'features', labelBn: 'ট্রাস্ট ফিচারসমূহ', labelEn: 'Trust Badges', icon: ShieldCheck },
          { id: 'footer', labelBn: 'ফুটার ও সোশ্যাল', labelEn: 'Footer & Links', icon: Layout },
          { id: 'preview', labelBn: 'লাইভ প্রিভিউ', labelEn: 'Live Preview', icon: Eye },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                isActive
                  ? 'bg-rose-600 text-white shadow-md'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? tab.labelBn : tab.labelEn}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* 1. THEME & COLORS TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'theme' && (
        <div className="space-y-6">
          {/* Preset Color Choices */}
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Palette className="w-4 h-4 text-rose-400" />
                <span>{language === 'bn' ? 'স্টোর কালার থিম প্যালেট (Color Scheme)' : 'Store Color Theme Palettes'}</span>
              </h3>
              <p className="text-xs text-neutral-400 mt-0.5">
                {language === 'bn'
                  ? 'যেকোনো থিম নির্বাচন করুন অথবা কাস্টম হেক্স কোড লিখে আপনার ব্র্যান্ডের নিজস্ব কালার সেট করুন।'
                  : 'Choose a designer-crafted color palette or enter custom HEX values for your brand.'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pt-2">
              {THEME_PRESETS.map((preset) => {
                const isSelected = form.themePreset === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className={`p-3.5 rounded-2xl border text-left transition cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-rose-500 bg-rose-500/10 ring-2 ring-rose-500/30'
                        : 'border-neutral-800 bg-neutral-950/60 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${preset.previewClass} shadow-xs shrink-0 flex items-center justify-center`}>
                        <div className="w-2.5 h-2.5 rounded-full bg-white/80" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white leading-tight">
                          {language === 'bn' ? preset.nameBn : preset.nameEn}
                        </p>
                        <p className="text-[10px] text-neutral-400 font-mono mt-0.5">
                          {preset.primary}
                        </p>
                      </div>
                    </div>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-rose-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Custom Hex Codes Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-neutral-800">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  {language === 'bn' ? 'প্রাইমারি কালার (Primary Hex)' : 'Primary Color Hex'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={form.primaryColorHex}
                    onChange={(e) => setForm(prev => ({ ...prev, primaryColorHex: e.target.value, themePreset: 'custom' }))}
                    className="w-10 h-10 rounded-xl bg-transparent border border-neutral-700 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={form.primaryColorHex}
                    onChange={(e) => setForm(prev => ({ ...prev, primaryColorHex: e.target.value, themePreset: 'custom' }))}
                    placeholder="#E11D48"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white font-mono text-xs focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  {language === 'bn' ? 'একসেন্ট / বাটন হাইলাইট কালার (Accent Hex)' : 'Accent Highlight Color Hex'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={form.accentColorHex}
                    onChange={(e) => setForm(prev => ({ ...prev, accentColorHex: e.target.value, themePreset: 'custom' }))}
                    className="w-10 h-10 rounded-xl bg-transparent border border-neutral-700 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={form.accentColorHex}
                    onChange={(e) => setForm(prev => ({ ...prev, accentColorHex: e.target.value, themePreset: 'custom' }))}
                    placeholder="#F59E0B"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white font-mono text-xs focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Typography & Corner Rounding */}
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Type className="w-4 h-4 text-rose-400" />
              <span>{language === 'bn' ? 'ফন্ট স্টাইল ও কর্নার শেপ' : 'Typography & Corner Rounding'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  {language === 'bn' ? 'ফন্ট ফ্যামিলি (Font Family)' : 'Font Family'}
                </label>
                <select
                  value={form.fontFamily}
                  onChange={(e) => setForm(prev => ({ ...prev, fontFamily: e.target.value as any }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold focus:outline-hidden focus:border-rose-500"
                >
                  <option value="hind">Hind Siliguri (বাংলা ও ইংরেজি উভয়ের জন্য সেরা)</option>
                  <option value="inter">Inter (Modern Clean)</option>
                  <option value="outfit">Outfit (Geometric & Bold)</option>
                  <option value="poppins">Poppins (Friendly Rounded)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1.5">
                  {language === 'bn' ? 'কার্ড ও বাটনের কর্নার স্টাইল (Border Radius)' : 'Border Radius Shape'}
                </label>
                <select
                  value={form.borderRadius}
                  onChange={(e) => setForm(prev => ({ ...prev, borderRadius: e.target.value as any }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold focus:outline-hidden focus:border-rose-500"
                >
                  <option value="rounded-xl">Compact Rounded (12px)</option>
                  <option value="rounded-2xl">Modern Soft Curves (16px - Recommended)</option>
                  <option value="rounded-3xl">Pill Smooth Curves (24px)</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BRANDING & HEADER TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'branding' && (
        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Globe className="w-4 h-4 text-rose-400" />
              <span>{language === 'bn' ? 'ব্র্যান্ডের নাম ও স্লোগান' : 'Brand Identity & Logo'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'দোকানের নাম (ইংরেজি)' : 'Store Name (English)'}
                </label>
                <input
                  type="text"
                  value={form.brandNameEn}
                  onChange={(e) => setForm(prev => ({ ...prev, brandNameEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'দোকানের নাম (বাংলা)' : 'Store Name (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.brandNameBn}
                  onChange={(e) => setForm(prev => ({ ...prev, brandNameBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'লোগো হাইলাইট শব্দ (যেমন: Ghor)' : 'Logo Accent Word (e.g. Ghor)'}
                </label>
                <input
                  type="text"
                  value={form.brandAccentWordEn || ''}
                  onChange={(e) => setForm(prev => ({ ...prev, brandAccentWordEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-amber-400 text-xs focus:outline-hidden focus:border-rose-500 font-bold"
                />
              </div>

              <div className="sm:col-span-2">
                <ImageUploadField
                  label={language === 'bn' ? 'স্টোর লোগো আপলোড (ফোন থেকে সরাসরি সিলেক্ট করুন)' : 'Store Logo (Upload from Phone)'}
                  sublabel={language === 'bn' ? 'ক্যামেরা / গ্যালারি' : 'Camera / Gallery'}
                  value={form.logoUrl}
                  onChange={(img) => setForm(prev => ({ ...prev, logoUrl: img }))}
                  aspectRatio="square"
                  language={language}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ট্যাগলাইন / স্লোগান (ইংরেজি)' : 'Tagline / Slogan (English)'}
                </label>
                <input
                  type="text"
                  value={form.taglineEn}
                  onChange={(e) => setForm(prev => ({ ...prev, taglineEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ট্যাগলাইন / স্লোগান (বাংলা)' : 'Tagline / Slogan (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.taglineBn}
                  onChange={(e) => setForm(prev => ({ ...prev, taglineBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                />
              </div>
            </div>
          </div>

          {/* Official Store Badge / Label Toggle & Option */}
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-rose-400" />
                  <span>{language === 'bn' ? 'Official Store (অফিশিয়াল স্টোর) সেটিংস' : 'Official Store Badge Settings'}</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {language === 'bn'
                    ? "ওয়েবসাইট ও ব্যানারে 'Official Store' / 'অফিশিয়াল স্টোর' লেখা প্রদর্শন অথবা সম্পূর্ণ সরিয়ে ফেলার অপশন।"
                    : "Toggle on/off or customize the 'Official Store' badge across the storefront and banners."}
                </p>
              </div>

              <label className="flex items-center gap-2 cursor-pointer bg-neutral-950 px-3.5 py-2 rounded-xl border border-neutral-800 shrink-0">
                <input
                  type="checkbox"
                  checked={form.showOfficialStoreBadge === true}
                  onChange={(e) => setForm(prev => ({ ...prev, showOfficialStoreBadge: e.target.checked }))}
                  className="w-4 h-4 text-rose-600 rounded bg-neutral-900 border-neutral-700 focus:ring-rose-500"
                />
                <span className="text-xs font-bold text-white">
                  {form.showOfficialStoreBadge 
                    ? (language === 'bn' ? 'চালু আছে (Enabled)' : 'Enabled') 
                    : (language === 'bn' ? 'বন্ধ (Hidden/Removed)' : 'Disabled / Hidden')}
                </span>
              </label>
            </div>

            {form.showOfficialStoreBadge && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-neutral-800">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'ব্যাজ টেক্সট (বাংলা)' : 'Badge Text (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={form.officialStoreBadgeBn || 'অফিশিয়াল স্টোর'}
                    onChange={(e) => setForm(prev => ({ ...prev, officialStoreBadgeBn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'ব্যাজ টেক্সট (ইংরেজি)' : 'Badge Text (English)'}
                  </label>
                  <input
                    type="text"
                    value={form.officialStoreBadgeEn || 'Official Store'}
                    onChange={(e) => setForm(prev => ({ ...prev, officialStoreBadgeEn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Top Marquee & Announcement Bar */}
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>{language === 'bn' ? 'টপ নোটিফিকেশন ও অফার বার (Top Announcement Bar)' : 'Top Announcement Marquee Bar'}</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {language === 'bn'
                    ? 'ওয়েবসাইটের একদম উপরে চলমান বিশেষ অফার বা ঘোষণা প্রদর্শন করুন।'
                    : 'Show an attention-grabbing offer marquee bar at the top of all pages.'}
                </p>
              </div>

              <label className="flex items-center gap-2 cursor-pointer bg-neutral-950 px-3 py-1.5 rounded-xl border border-neutral-800">
                <input
                  type="checkbox"
                  checked={form.showAnnouncementBar}
                  onChange={(e) => setForm(prev => ({ ...prev, showAnnouncementBar: e.target.checked }))}
                  className="w-4 h-4 text-rose-600 rounded bg-neutral-900 border-neutral-700"
                />
                <span className="text-xs font-bold text-white">
                  {form.showAnnouncementBar ? (language === 'bn' ? 'চালু আছে' : 'Active') : (language === 'bn' ? 'বন্ধ' : 'Hidden')}
                </span>
              </label>
            </div>

            {form.showAnnouncementBar && (
              <div className="space-y-4 pt-2 border-t border-neutral-800 animate-fadeIn">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">
                      {language === 'bn' ? 'অ্যানাউন্সমেন্ট টেক্সট (বাংলা)' : 'Announcement Text (Bangla)'}
                    </label>
                    <input
                      type="text"
                      value={form.announcementTextBn}
                      onChange={(e) => setForm(prev => ({ ...prev, announcementTextBn: e.target.value }))}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">
                      {language === 'bn' ? 'অ্যানাউন্সমেন্ট টেক্সট (ইংরেজি)' : 'Announcement Text (English)'}
                    </label>
                    <input
                      type="text"
                      value={form.announcementTextEn}
                      onChange={(e) => setForm(prev => ({ ...prev, announcementTextEn: e.target.value }))}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">
                      {language === 'bn' ? 'টপ বার ব্যাকগ্রাউন্ড কালার' : 'Top Bar Background Color'}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={form.announcementBgColor || '#881337'}
                        onChange={(e) => setForm(prev => ({ ...prev, announcementBgColor: e.target.value }))}
                        className="w-9 h-9 rounded-lg bg-transparent border border-neutral-700 cursor-pointer"
                      />
                      <input
                        type="text"
                        value={form.announcementBgColor || '#881337'}
                        onChange={(e) => setForm(prev => ({ ...prev, announcementBgColor: e.target.value }))}
                        className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 mb-1">
                      {language === 'bn' ? 'হেডার ব্যাজ টেক্সট (বাংলা)' : 'Header Badge Text (Bangla)'}
                    </label>
                    <input
                      type="text"
                      value={form.freeDeliveryBadgeBn}
                      onChange={(e) => setForm(prev => ({ ...prev, freeDeliveryBadgeBn: e.target.value }))}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. HERO BANNERS & SLIDER TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'banners' && (
        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-rose-400" />
                  <span>{language === 'bn' ? 'হোমপেজ হিরো ব্যানার স্লাইডার' : 'Homepage Hero Banner Slider'}</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {language === 'bn'
                    ? 'হোমপেজে প্রদর্শিত ব্যানারগুলো সরাসরি এডিট করুন, নতুন স্লাইড যোগ করুন অথবা ডিলিট করুন।'
                    : 'Manage promotional hero banners, upload artwork, and link directly to categories or sales.'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddBanner}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-md cursor-pointer self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>{language === 'bn' ? 'নতুন ব্যানার যোগ করুন' : 'Add New Banner'}</span>
              </button>
            </div>

            {/* Banner Toggle Switch */}
            <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-white">
                  {language === 'bn' ? 'শুধুমাত্র কাস্টম ব্যানার প্রদর্শন করুন' : 'Display Custom Banners Exclusively'}
                </p>
                <p className="text-[11px] text-neutral-400">
                  {language === 'bn' 
                    ? 'চালু থাকলে পণ্যের অটো-জেনারেটেড ব্যানারের বদলে শুধুমাত্র নিচের কাস্টম ব্যানারগুলো দেখাবে।' 
                    : 'When enabled, only these custom slides will display instead of auto product cards.'}
                </p>
              </div>
              <input
                type="checkbox"
                checked={form.useCustomBannersOnly}
                onChange={(e) => setForm(prev => ({ ...prev, useCustomBannersOnly: e.target.checked }))}
                className="w-5 h-5 text-rose-600 rounded bg-neutral-900 border-neutral-700 cursor-pointer"
              />
            </div>

            {/* Banner List */}
            {(!form.heroBanners || form.heroBanners.length === 0) ? (
              <div className="p-8 rounded-2xl bg-neutral-950 border border-dashed border-neutral-800 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-neutral-500 flex items-center justify-center mx-auto">
                  <ImageIcon className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-neutral-300">
                    {language === 'bn' ? 'বর্তমানে কোনো কাস্টম হিরো ব্যানার নেই' : 'No custom hero banners available'}
                  </p>
                  <p className="text-[11px] text-neutral-500">
                    {language === 'bn' ? 'নতুন ব্যানার স্লাইড তৈরি করতে উপরের বাটনে ক্লিক করুন।' : 'Click the button above to add your first banner slide.'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {form.heroBanners.map((b, index) => (
                  <div
                    key={b.id || index}
                    className="relative rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950 group shadow-lg flex flex-col justify-between"
                  >
                    <div className="relative h-44 bg-neutral-900 overflow-hidden">
                      <img
                        src={b.imageUrl || '/logo.png'}
                        alt={b.titleEn}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent p-4 flex flex-col justify-end">
                        <span className="bg-rose-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-md uppercase self-start mb-1">
                          {b.badgeBn || b.badgeEn || 'PROMO'}
                        </span>
                        <h4 className="text-sm font-black text-white line-clamp-1">
                          {language === 'bn' ? b.titleBn : b.titleEn}
                        </h4>
                        <p className="text-[11px] text-neutral-300 line-clamp-1">
                          {language === 'bn' ? b.subtitleBn : b.subtitleEn}
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-neutral-900/80 border-t border-neutral-800 flex items-center justify-between">
                      <span className="text-[11px] text-neutral-400 font-mono">
                        #{index + 1} • {b.buttonTextEn || 'Order Now'}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleOpenEditBanner(index)}
                          className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold transition cursor-pointer flex items-center gap-1"
                          title="Edit Banner"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'এডিট' : 'Edit'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteBanner(index)}
                          className="px-2.5 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 hover:text-red-300 border border-red-500/30 text-xs font-bold transition cursor-pointer flex items-center gap-1"
                          title="Delete Banner"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'মুছুন' : 'Delete'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. OFFERS & FLASH SALE TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'offers' && (
        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>{language === 'bn' ? 'ফ্ল্যাশ সেল কাউন্টডাউন সেকশন' : 'Flash Sale Countdown Section'}</span>
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {language === 'bn'
                    ? 'হোমপেজে কাউন্টডাউন টাইমার সহ আকর্ষণীয় ফ্ল্যাশ সেল প্রদর্শনের সেটিংস।'
                    : 'Configure the homepage flash deal countdown timer, title, and urgent offer badges.'}
                </p>
              </div>

              <label className="flex items-center gap-2 cursor-pointer bg-neutral-950 px-3 py-1.5 rounded-xl border border-neutral-800">
                <input
                  type="checkbox"
                  checked={form.flashSaleEnabled}
                  onChange={(e) => setForm(prev => ({ ...prev, flashSaleEnabled: e.target.checked }))}
                  className="w-4 h-4 text-rose-600 rounded bg-neutral-900 border-neutral-700"
                />
                <span className="text-xs font-bold text-white">
                  {form.flashSaleEnabled ? (language === 'bn' ? 'চালু' : 'Active') : (language === 'bn' ? 'বন্ধ' : 'Disabled')}
                </span>
              </label>
            </div>

            {form.flashSaleEnabled && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-neutral-800 animate-fadeIn">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'ফ্ল্যাশ সেল টাইটেল (বাংলা)' : 'Flash Sale Title (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={form.flashSaleTitleBn}
                    onChange={(e) => setForm(prev => ({ ...prev, flashSaleTitleBn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'ফ্ল্যাশ সেল টাইটেল (ইংরেজি)' : 'Flash Sale Title (English)'}
                  </label>
                  <input
                    type="text"
                    value={form.flashSaleTitleEn}
                    onChange={(e) => setForm(prev => ({ ...prev, flashSaleTitleEn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'সাবটাইটেল (বাংলা)' : 'Subtitle (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={form.flashSaleSubtitleBn}
                    onChange={(e) => setForm(prev => ({ ...prev, flashSaleSubtitleBn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'সাবটাইটেল (ইংরেজি)' : 'Subtitle (English)'}
                  </label>
                  <input
                    type="text"
                    value={form.flashSaleSubtitleEn}
                    onChange={(e) => setForm(prev => ({ ...prev, flashSaleSubtitleEn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs focus:outline-hidden focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'ফ্ল্যাশ সেল সমাপ্তির তারিখ ও সময়' : 'Flash Sale End Date & Time'}
                  </label>
                  <input
                    type="datetime-local"
                    value={form.flashSaleEndTime}
                    onChange={(e) => setForm(prev => ({ ...prev, flashSaleEndTime: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-mono focus:outline-hidden focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'ব্যাজ টেক্সট (যেমন: হট ডিল / HOT DEAL)' : 'Badge Text (e.g. HOT DEAL)'}
                  </label>
                  <input
                    type="text"
                    value={form.flashSaleBadgeTextBn}
                    onChange={(e) => setForm(prev => ({ ...prev, flashSaleBadgeTextBn: e.target.value }))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-rose-400 text-xs font-bold focus:outline-hidden focus:border-rose-500"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. SECTION HEADINGS TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'sections' && (
        <div className="space-y-6">
          {/* Categories Section */}
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-rose-400" />
              <span>{language === 'bn' ? 'ক্যাটাগরি সেকশন টেক্সট' : 'Category Section Headings'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ক্যাটাগরি টাইটেল (বাংলা)' : 'Category Title (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.categorySectionTitleBn}
                  onChange={(e) => setForm(prev => ({ ...prev, categorySectionTitleBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ক্যাটাগরি টাইটেল (ইংরেজি)' : 'Category Title (English)'}
                </label>
                <input
                  type="text"
                  value={form.categorySectionTitleEn}
                  onChange={(e) => setForm(prev => ({ ...prev, categorySectionTitleEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ক্যাটাগরি সাবটাইটেল (বাংলা)' : 'Category Subtitle (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.categorySectionSubtitleBn}
                  onChange={(e) => setForm(prev => ({ ...prev, categorySectionSubtitleBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ক্যাটাগরি সাবটাইটেল (ইংরেজি)' : 'Category Subtitle (English)'}
                </label>
                <input
                  type="text"
                  value={form.categorySectionSubtitleEn}
                  onChange={(e) => setForm(prev => ({ ...prev, categorySectionSubtitleEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>
            </div>
          </div>

          {/* Product Collection Section */}
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{language === 'bn' ? 'প্রোডাক্ট কালেকশন সেকশন টেক্সট' : 'Product Collection Section Headings'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'কালেকশন টাইটেল (বাংলা)' : 'Collection Title (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.catalogSectionTitleBn}
                  onChange={(e) => setForm(prev => ({ ...prev, catalogSectionTitleBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'কালেকশন টাইটেল (ইংরেজি)' : 'Collection Title (English)'}
                </label>
                <input
                  type="text"
                  value={form.catalogSectionTitleEn}
                  onChange={(e) => setForm(prev => ({ ...prev, catalogSectionTitleEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'কালেকশন সাবটাইটেল (বাংলা)' : 'Collection Subtitle (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.catalogSectionSubtitleBn}
                  onChange={(e) => setForm(prev => ({ ...prev, catalogSectionSubtitleBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'কালেকশন সাবটাইটেল (ইংরেজি)' : 'Collection Subtitle (English)'}
                </label>
                <input
                  type="text"
                  value={form.catalogSectionSubtitleEn}
                  onChange={(e) => setForm(prev => ({ ...prev, catalogSectionSubtitleEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>
            </div>
          </div>

          {/* Direct Hotline / Callout Banner */}
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Phone className="w-4 h-4 text-rose-400" />
              <span>{language === 'bn' ? 'সরাসরি অর্ডার ও হটলাইন কলআউট ব্যানার' : 'Direct Order Hotline Callout Banner'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ব্যানার টাইটেল (বাংলা)' : 'Banner Title (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.directOrderTitleBn}
                  onChange={(e) => setForm(prev => ({ ...prev, directOrderTitleBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'ব্যানার টাইটেল (ইংরেজি)' : 'Banner Title (English)'}
                </label>
                <input
                  type="text"
                  value={form.directOrderTitleEn}
                  onChange={(e) => setForm(prev => ({ ...prev, directOrderTitleEn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'হটলাইন ইমেইল' : 'Hotline Email'}
                </label>
                <input
                  type="text"
                  value={form.hotlineEmail}
                  onChange={(e) => setForm(prev => ({ ...prev, hotlineEmail: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'হটলাইন মোবাইল নম্বর' : 'Hotline Phone'}
                </label>
                <input
                  type="text"
                  value={form.hotlinePhone}
                  onChange={(e) => setForm(prev => ({ ...prev, hotlinePhone: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. TRUST FEATURES TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'features' && (
        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{language === 'bn' ? 'স্টোর ট্রাস্ট ও গ্যারান্টি ব্যাজসমূহ' : 'Store Trust & Value Features'}</span>
            </h3>
            <p className="text-xs text-neutral-400">
              {language === 'bn'
                ? 'ফুটারের উপরের ৪টি ট্রাস্ট ব্যাজের নাম এবং বিবরণ ইচ্ছামতো এডিট করুন।'
                : 'Edit the 4 value proposition assurance badges displayed across the website.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {form.features.map((feat, index) => (
                <div key={feat.id || index} className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-rose-400">
                      Feature #{index + 1}
                    </span>
                    <select
                      value={feat.icon}
                      onChange={(e) => {
                        const next = [...form.features];
                        next[index] = { ...feat, icon: e.target.value as any };
                        setForm(prev => ({ ...prev, features: next }));
                      }}
                      className="px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-700 text-neutral-300 text-[11px]"
                    >
                      <option value="truck">Truck (Delivery)</option>
                      <option value="shield">Shield (Authentic)</option>
                      <option value="refresh">Refresh (Return)</option>
                      <option value="clock">Clock (24/7 Support)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <input
                      type="text"
                      value={feat.titleBn}
                      onChange={(e) => {
                        const next = [...form.features];
                        next[index] = { ...feat, titleBn: e.target.value };
                        setForm(prev => ({ ...prev, features: next }));
                      }}
                      placeholder="Title (Bangla)"
                      className="w-full px-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-bold"
                    />
                    <input
                      type="text"
                      value={feat.descBn}
                      onChange={(e) => {
                        const next = [...form.features];
                        next[index] = { ...feat, descBn: e.target.value };
                        setForm(prev => ({ ...prev, features: next }));
                      }}
                      placeholder="Description (Bangla)"
                      className="w-full px-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-[11px]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. FOOTER & SOCIALS TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'footer' && (
        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 p-5 sm:p-6 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Layout className="w-4 h-4 text-rose-400" />
              <span>{language === 'bn' ? 'ফুটার তথ্য ও সোশ্যাল লিংক' : 'Footer Content & Social Media'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'দোকান সম্পর্কিত সংক্ষিপ্ত পরিচিতি (বাংলা)' : 'About Store (Bangla)'}
                </label>
                <textarea
                  rows={3}
                  value={form.footerAboutBn}
                  onChange={(e) => setForm(prev => ({ ...prev, footerAboutBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'অফিস ঠিকানা (বাংলা)' : 'Office Address (Bangla)'}
                </label>
                <input
                  type="text"
                  value={form.officeAddressBn}
                  onChange={(e) => setForm(prev => ({ ...prev, officeAddressBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'কপিরাইট নোটিশ (বাংলা)' : 'Copyright Text'}
                </label>
                <input
                  type="text"
                  value={form.copyrightTextBn}
                  onChange={(e) => setForm(prev => ({ ...prev, copyrightTextBn: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  Facebook Page URL
                </label>
                <input
                  type="text"
                  value={form.facebookUrl}
                  onChange={(e) => setForm(prev => ({ ...prev, facebookUrl: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">
                  WhatsApp Helpline URL (e.g. https://wa.me/8801700000000)
                </label>
                <input
                  type="text"
                  value={form.whatsappUrl}
                  onChange={(e) => setForm(prev => ({ ...prev, whatsappUrl: e.target.value }))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-mono"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. LIVE PREVIEW TAB */}
      {/* ========================================================================= */}
      {activeSubTab === 'preview' && (
        <div className="space-y-6">
          <div className="bg-neutral-900 border border-neutral-800 p-5 rounded-3xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>{language === 'bn' ? 'রিয়েলটাইম লাইভ প্রিভিউ' : 'Real-time Live Preview'}</span>
            </h3>

            {/* Preview Frame */}
            <div className="rounded-3xl overflow-hidden border-4 border-neutral-800 bg-white text-neutral-900 shadow-2xl">
              {/* Top Notification Bar */}
              {form.showAnnouncementBar && (
                <div 
                  style={{ backgroundColor: form.announcementBgColor, color: form.announcementTextColor }}
                  className="py-1.5 px-4 text-xs font-bold flex items-center justify-between"
                >
                  <span className="truncate">
                    {language === 'bn' ? form.announcementTextBn : form.announcementTextEn}
                  </span>
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-black/20 shrink-0">
                    {form.freeDeliveryBadgeBn}
                  </span>
                </div>
              )}

              {/* Header Preview */}
              <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-white">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full ring-2 ring-amber-400 overflow-hidden bg-neutral-950 flex items-center justify-center">
                    <img src={form.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <span className="text-lg font-black tracking-tight text-neutral-900">
                      {form.brandNameEn}
                    </span>
                    <p className="text-[9px] text-amber-600 font-bold">
                      {form.taglineEn}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span 
                    style={{ backgroundColor: form.primaryColorHex }} 
                    className="px-3 py-1.5 rounded-xl text-white text-xs font-bold shadow-sm"
                  >
                    Primary Button
                  </span>
                </div>
              </div>

              {/* Sample Banner Slide */}
              {form.heroBanners.length > 0 && (
                <div className="p-6 bg-gradient-to-r from-neutral-900 to-neutral-800 text-white flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="space-y-2">
                    <span className="bg-rose-600 text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase inline-block">
                      {form.heroBanners[0].badgeBn || 'SPECIAL'}
                    </span>
                    <h3 className="text-xl font-black">
                      {language === 'bn' ? form.heroBanners[0].titleBn : form.heroBanners[0].titleEn}
                    </h3>
                    <p className="text-xs text-neutral-300">
                      {language === 'bn' ? form.heroBanners[0].subtitleBn : form.heroBanners[0].subtitleEn}
                    </p>
                  </div>
                  <button 
                    style={{ backgroundColor: form.primaryColorHex }}
                    className="px-5 py-2 rounded-xl text-white text-xs font-black shadow-lg cursor-pointer"
                  >
                    {form.heroBanners[0].buttonTextBn || 'এখনই কিনুন'}
                  </button>
                </div>
              )}

              {/* Footer Preview */}
              <div className="p-4 bg-neutral-950 text-neutral-400 text-xs flex items-center justify-between">
                <span>{form.copyrightTextBn}</span>
                <span className="font-mono text-[11px] text-neutral-500">{form.hotlineEmail}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Banner Add/Edit Modal */}
      {bannerModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 w-full max-w-lg rounded-3xl p-6 space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-rose-400" />
                <span>{editingBannerIndex !== null ? (language === 'bn' ? 'ব্যানার এডিট করুন' : 'Edit Banner') : (language === 'bn' ? 'নতুন ব্যানার তৈরি করুন' : 'Create New Banner')}</span>
              </h3>
              <button
                type="button"
                onClick={() => setBannerModalOpen(false)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBanner} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'টাইটেল (বাংলা)' : 'Title (Bangla)'}
                  </label>
                  <input
                    type="text"
                    required
                    value={bannerForm.titleBn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, titleBn: e.target.value }))}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'টাইটেল (ইংরেজি)' : 'Title (English)'}
                  </label>
                  <input
                    type="text"
                    required
                    value={bannerForm.titleEn}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, titleEn: e.target.value }))}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-300 mb-1">
                  {language === 'bn' ? 'সাবটাইটেল (বাংলা)' : 'Subtitle (Bangla)'}
                </label>
                <input
                  type="text"
                  value={bannerForm.subtitleBn}
                  onChange={(e) => setBannerForm(prev => ({ ...prev, subtitleBn: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                />
              </div>

              <div>
                <ImageUploadField
                  label={language === 'bn' ? 'ব্যানার ছবি আপলোড (ফোন থেকে সরাসরি সিলেক্ট করুন)' : 'Banner Image (Upload from Phone)'}
                  sublabel={language === 'bn' ? 'গ্যালারি / ক্যামেরা' : 'Gallery / Camera'}
                  value={bannerForm.imageUrl}
                  onChange={(img) => setBannerForm(prev => ({ ...prev, imageUrl: img }))}
                  aspectRatio="banner"
                  language={language}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'ব্যাজ টেক্সট (বাংলা)' : 'Badge (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={bannerForm.badgeBn || ''}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, badgeBn: e.target.value }))}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-neutral-300 mb-1">
                    {language === 'bn' ? 'বাটন টেক্সট (বাংলা)' : 'Button Text (Bangla)'}
                  </label>
                  <input
                    type="text"
                    value={bannerForm.buttonTextBn || 'এখনই কিনুন'}
                    onChange={(e) => setBannerForm(prev => ({ ...prev, buttonTextBn: e.target.value }))}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-white text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={() => setBannerModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-md cursor-pointer"
                >
                  {language === 'bn' ? 'ব্যানার সংরক্ষণ করুন' : 'Save Banner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
