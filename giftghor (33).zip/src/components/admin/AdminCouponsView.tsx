import React, { useState } from 'react';
import { 
  TicketPercent, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  X, 
  Calendar, 
  Percent, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';
import { Coupon, Language } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';

interface AdminCouponsViewProps {
  coupons?: Coupon[];
  language: Language;
  onSaveCoupon?: (coupon: Coupon) => void;
  onDeleteCoupon?: (couponId: string) => void;
  onToggleCouponStatus?: (couponId: string) => void;
}

export const AdminCouponsView: React.FC<AdminCouponsViewProps> = ({
  coupons = [],
  language,
  onSaveCoupon,
  onDeleteCoupon,
  onToggleCouponStatus,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);

  // Form Fields
  const [formCode, setFormCode] = useState('EID50');
  const [formType, setFormType] = useState<'percentage' | 'fixed'>('percentage');
  const [formValue, setFormValue] = useState('15');
  const [formMinAmount, setFormMinAmount] = useState('1000');
  const [formMaxDiscount, setFormMaxDiscount] = useState('200');
  const [formExpiryDate, setFormExpiryDate] = useState('2026-12-31');
  const [formUsageLimit, setFormUsageLimit] = useState('100');
  const [formIsActive, setFormIsActive] = useState(true);

  const handleOpenAdd = () => {
    setEditingCoupon(null);
    setFormCode('SALE' + Math.floor(10 + Math.random() * 90));
    setFormType('percentage');
    setFormValue('10');
    setFormMinAmount('800');
    setFormMaxDiscount('150');
    const futureDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    setFormExpiryDate(futureDate);
    setFormUsageLimit('100');
    setFormIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: Coupon) => {
    setEditingCoupon(c);
    setFormCode(c.code);
    setFormType(c.discountType);
    setFormValue(String(c.discountValue));
    setFormMinAmount(c.minOrderAmount ? String(c.minOrderAmount) : '');
    setFormMaxDiscount(c.maxDiscountAmount ? String(c.maxDiscountAmount) : '');
    setFormExpiryDate(c.expiryDate);
    setFormUsageLimit(c.usageLimit ? String(c.usageLimit) : '');
    setFormIsActive(c.isActive);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newCoupon: Coupon = {
      id: editingCoupon ? editingCoupon.id : `cpn-${Date.now()}`,
      code: formCode.trim().toUpperCase(),
      discountType: formType,
      discountValue: Number(formValue) || 10,
      minOrderAmount: formMinAmount ? Number(formMinAmount) : undefined,
      maxDiscountAmount: formMaxDiscount ? Number(formMaxDiscount) : undefined,
      expiryDate: formExpiryDate,
      usageLimit: formUsageLimit ? Number(formUsageLimit) : undefined,
      usedCount: editingCoupon ? editingCoupon.usedCount : 0,
      isActive: formIsActive,
      createdAt: editingCoupon?.createdAt || new Date().toISOString()
    };

    onSaveCoupon(newCoupon);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <TicketPercent className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'কুপন ও প্রোমো কোড' : 'Discount Coupons & Promos'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'নতুন প্রমোশনাল ভাউচার কোড, শতকরা ও নির্দিষ্ট অংকের ছাড় তৈরি ও পরিচালনা করুন।' 
              : 'Create promotional vouchers, configure percentage / flat discounts and expiry dates.'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'bn' ? 'নতুন কুপন কোড' : 'Create New Coupon'}</span>
        </button>
      </div>

      {/* Coupons Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {coupons.length === 0 ? (
          <div className="col-span-full py-12 text-center text-neutral-500 bg-neutral-900 border border-neutral-800 rounded-3xl">
            <TicketPercent className="w-10 h-10 mx-auto mb-2 text-neutral-600" />
            <p>No coupons found. Create your first promotional discount coupon!</p>
          </div>
        ) : (
          coupons.map(coupon => {
            const isExpired = new Date(coupon.expiryDate) < new Date();

            return (
              <div 
                key={coupon.id} 
                className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 space-y-4 hover:border-neutral-700 transition relative overflow-hidden group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center font-black">
                      <TicketPercent className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="font-mono font-black text-lg text-white tracking-wider">
                        {coupon.code}
                      </span>
                      <p className="text-[10px] text-neutral-400">
                        {coupon.discountType === 'percentage' ? `${coupon.discountValue}% OFF` : `৳${coupon.discountValue} Flat Discount`}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => onToggleCouponStatus(coupon.id)}
                    className={`px-2.5 py-1 rounded-xl text-[10px] font-bold transition cursor-pointer ${
                      coupon.isActive && !isExpired
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    {isExpired ? 'Expired' : (coupon.isActive ? 'Active' : 'Disabled')}
                  </button>
                </div>

                {/* Requirements details */}
                <div className="space-y-1.5 text-xs text-neutral-300 border-t border-b border-neutral-800/80 py-3">
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Min Purchase:</span>
                    <span className="font-semibold text-neutral-200">
                      {coupon.minOrderAmount ? `৳${coupon.minOrderAmount}` : 'No minimum'}
                    </span>
                  </div>
                  {coupon.maxDiscountAmount && coupon.discountType === 'percentage' && (
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Max Discount:</span>
                      <span className="font-semibold text-neutral-200">৳{coupon.maxDiscountAmount}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Expiry Date:</span>
                    <span className={`font-semibold ${isExpired ? 'text-red-400 font-bold' : 'text-neutral-200'}`}>
                      {new Date(coupon.expiryDate).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Redemptions:</span>
                    <span className="font-semibold text-white">
                      {coupon.usedCount} {coupon.usageLimit ? `/ ${coupon.usageLimit}` : ''}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-2">
                  <button
                    onClick={() => handleOpenEdit(coupon)}
                    className="p-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs flex items-center gap-1 transition"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => onDeleteCoupon(coupon.id)}
                    className="p-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 text-xs flex items-center gap-1 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Coupon Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 w-full max-w-md rounded-3xl p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h3 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                <TicketPercent className="w-5 h-5 text-rose-600" />
                <span>{editingCoupon ? 'Edit Discount Coupon' : 'Create New Promo Coupon'}</span>
              </h3>
              <button 
                type="button"
                onClick={() => setIsModalOpen(false)} 
                className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-neutral-800 font-bold">Coupon Code (Uppercase): *</label>
                <input
                  type="text"
                  required
                  value={formCode}
                  onChange={(e) => setFormCode(e.target.value.toUpperCase())}
                  placeholder="e.g. FLASH20"
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 font-mono font-bold mt-1 uppercase focus:border-rose-500 outline-none shadow-2xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-800 font-bold">Discount Type:</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 focus:border-rose-500 outline-none shadow-2xs cursor-pointer"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount (৳)</option>
                  </select>
                </div>

                <div>
                  <label className="text-neutral-800 font-bold">Discount Value: *</label>
                  <input
                    type="number"
                    required
                    value={formValue}
                    onChange={(e) => setFormValue(e.target.value)}
                    placeholder={formType === 'percentage' ? '15' : '100'}
                    className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 font-bold mt-1 focus:border-rose-500 outline-none shadow-2xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-700 font-medium">Min Order Amount (৳):</label>
                  <input
                    type="number"
                    value={formMinAmount}
                    onChange={(e) => setFormMinAmount(e.target.value)}
                    placeholder="800"
                    className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 focus:border-rose-500 outline-none shadow-2xs"
                  />
                </div>

                <div>
                  <label className="text-neutral-700 font-medium">Max Discount Limit (৳):</label>
                  <input
                    type="number"
                    value={formMaxDiscount}
                    onChange={(e) => setFormMaxDiscount(e.target.value)}
                    placeholder="200"
                    className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 focus:border-rose-500 outline-none shadow-2xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-neutral-800 font-bold">Expiry Date: *</label>
                  <input
                    type="date"
                    required
                    value={formExpiryDate}
                    onChange={(e) => setFormExpiryDate(e.target.value)}
                    className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 focus:border-rose-500 outline-none shadow-2xs cursor-pointer"
                  />
                </div>

                <div>
                  <label className="text-neutral-700 font-medium">Total Usage Limit:</label>
                  <input
                    type="number"
                    value={formUsageLimit}
                    onChange={(e) => setFormUsageLimit(e.target.value)}
                    placeholder="100"
                    className="w-full px-3.5 py-2 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 focus:border-rose-500 outline-none shadow-2xs"
                  />
                </div>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-neutral-800 select-none">
                  <input
                    type="checkbox"
                    checked={formIsActive}
                    onChange={(e) => setFormIsActive(e.target.checked)}
                    className="w-4 h-4 accent-rose-600 rounded cursor-pointer"
                  />
                  <span>Active & Ready to Redeem</span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black shadow-md shadow-rose-600/20 transition cursor-pointer"
                >
                  Save Coupon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
