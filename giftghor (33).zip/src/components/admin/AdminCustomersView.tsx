import React, { useState, useMemo } from 'react';
import { 
  Users, 
  Search, 
  Eye, 
  ShoppingBag, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  DollarSign, 
  ShieldAlert, 
  ShieldCheck, 
  UserCheck, 
  UserX, 
  X, 
  ChevronRight,
  FileText
} from 'lucide-react';
import { Customer, Order, Language } from '../../types';
import { formatPrice, toBengaliNumber } from '../../utils/translations';
import { safeDateToLocaleString } from '../../utils/dateUtils';

interface AdminCustomersViewProps {
  customers?: Customer[];
  orders?: Order[];
  language: Language;
  onToggleBlockCustomer?: (customerId: string) => void;
  onSaveCustomerNote?: (customerId: string, note: string) => void;
  onViewCustomerOrders?: (customer: Customer) => void;
}

export const AdminCustomersView: React.FC<AdminCustomersViewProps> = ({
  customers = [],
  orders = [],
  language,
  onToggleBlockCustomer,
  onSaveCustomerNote,
  onViewCustomerOrders,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'blocked'>('all');
  const [activeCustomer, setActiveCustomer] = useState<Customer | null>(null);
  const [customerNote, setCustomerNote] = useState('');

  // Filtered Customers
  const filteredCustomers = useMemo(() => {
    return customers.filter(c => {
      if (filterStatus === 'active' && c.status === 'blocked') return false;
      if (filterStatus === 'blocked' && c.status !== 'blocked') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = String(c.name || '').toLowerCase().includes(q);
        const matchEmail = String(c.email || '').toLowerCase().includes(q);
        const matchPhone = String(c.phone || '').toLowerCase().includes(q);
        const matchAddress = String(c.address || '').toLowerCase().includes(q);
        return matchName || matchEmail || matchPhone || matchAddress;
      }
      return true;
    });
  }, [customers, filterStatus, searchQuery]);

  const handleOpenCustomerDetails = (customer: Customer) => {
    setActiveCustomer(customer);
    setCustomerNote(customer.notes || '');
  };

  const handleSaveNote = () => {
    if (!activeCustomer) return;
    onSaveCustomerNote(activeCustomer.id, customerNote);
    setActiveCustomer(prev => prev ? { ...prev, notes: customerNote } : null);
  };

  // Calculate customer specific orders
  const customerOrders = useMemo(() => {
    if (!activeCustomer) return [];
    return orders.filter(o => 
      (activeCustomer.phone && o.phone === activeCustomer.phone) || 
      (activeCustomer.email && o.email === activeCustomer.email) ||
      (Boolean(o.customerName) && Boolean(activeCustomer.name) && String(o.customerName).toLowerCase() === String(activeCustomer.name).toLowerCase())
    );
  }, [orders, activeCustomer]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'গ্রাহক তালিকা ও প্রোফাইল' : 'Customer Relationship Directory'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? `মোট ${toBengaliNumber(customers.length)} জন নিবন্ধিত গ্রাহক ও ক্রেতা। সম্পূর্ণ অর্ডার হিস্ট্রি ও স্পেন্ডিং রেকর্ড দেখুন।` 
              : `Total ${customers.length} registered customers and shoppers. View lifetime value and purchase history.`}
          </p>
        </div>

        <div className="flex items-center gap-2 bg-neutral-950 p-1.5 rounded-2xl border border-neutral-800">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterStatus === 'all' ? 'bg-rose-600 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            All ({customers.length})
          </button>
          <button
            onClick={() => setFilterStatus('active')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterStatus === 'active' ? 'bg-emerald-600 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Active ({customers.filter(c => c.status !== 'blocked').length})
          </button>
          <button
            onClick={() => setFilterStatus('blocked')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterStatus === 'blocked' ? 'bg-red-600 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Blocked ({customers.filter(c => c.status === 'blocked').length})
          </button>
        </div>
      </div>

      {/* Search Filter */}
      <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-3xl">
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'bn' ? 'নাম, ফোন নম্বর, ইমেইল বা ঠিকানা দিয়ে গ্রাহক খুঁজুন...' : 'Search customers by name, phone, email, or delivery address...'}
            className="w-full pl-9.5 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-2xl text-xs text-neutral-200 placeholder-neutral-500 focus:border-rose-500 outline-none"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
              <tr>
                <th className="py-3.5 px-4">{language === 'bn' ? 'গ্রাহক' : 'Customer'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'যোগাযোগ' : 'Contact'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'ঠিকানা' : 'Address'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'মোট অর্ডার' : 'Orders'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'মোট খরচ (LTV)' : 'Total Spent'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'স্ট্যাটাস' : 'Status'}</th>
                <th className="py-3.5 px-4 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-neutral-500">
                    <Users className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                    <p>{language === 'bn' ? 'কোনো গ্রাহক পাওয়া যায়নি।' : 'No customers found.'}</p>
                  </td>
                </tr>
              ) : (
                filteredCustomers.map(customer => (
                  <tr key={customer.id} className="hover:bg-neutral-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-neutral-800 to-neutral-700 flex items-center justify-center font-bold text-white border border-neutral-700">
                          {customer.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-neutral-100">{customer.name}</p>
                          <p className="text-[10px] text-neutral-500 font-mono">ID: {customer.id.slice(-6)}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-semibold text-neutral-200">{customer.phone}</p>
                      {customer.email && <p className="text-[10px] text-neutral-500">{customer.email}</p>}
                    </td>
                    <td className="py-3 px-4 max-w-xs truncate text-neutral-400">
                      {customer.address}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-white">
                        {language === 'bn' ? toBengaliNumber(customer.totalOrders) : customer.totalOrders}
                      </span> {language === 'bn' ? 'টি' : 'orders'}
                    </td>
                    <td className="py-3 px-4 font-black text-sm text-emerald-400">
                      {formatPrice(customer.totalSpent, language)}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                        customer.status === 'blocked' 
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30' 
                          : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                      }`}>
                        {customer.status === 'blocked' ? 'Blocked' : 'Active'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onToggleBlockCustomer(customer.id)}
                          className={`p-1.5 rounded-lg transition cursor-pointer ${
                            customer.status === 'blocked'
                              ? 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30'
                              : 'bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30'
                          }`}
                          title={customer.status === 'blocked' ? 'Unblock Customer' : 'Block Customer'}
                        >
                          {customer.status === 'blocked' ? <UserCheck className="w-3.5 h-3.5" /> : <UserX className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          onClick={() => handleOpenCustomerDetails(customer)}
                          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition cursor-pointer"
                          title="View Profile & Orders"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Profile & Purchase History Modal */}
      {activeCustomer && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-neutral-900 border border-neutral-800 w-full max-w-2xl rounded-3xl p-6 space-y-6 my-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-rose-500 to-red-600 flex items-center justify-center text-white font-black text-lg">
                  {activeCustomer.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>{activeCustomer.name}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      activeCustomer.status === 'blocked' ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {activeCustomer.status || 'Active'}
                    </span>
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Customer ID: #{activeCustomer.id}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setActiveCustomer(null)}
                className="p-2 rounded-xl text-neutral-400 hover:text-white bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 max-h-[65vh] overflow-y-auto pr-1 custom-scrollbar text-xs">
              {/* Stats Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800">
                  <span className="text-neutral-400">Total Spent:</span>
                  <p className="text-base font-black text-emerald-400 mt-1">
                    {formatPrice(activeCustomer.totalSpent, language)}
                  </p>
                </div>
                <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800">
                  <span className="text-neutral-400">Total Orders:</span>
                  <p className="text-base font-black text-white mt-1">
                    {activeCustomer.totalOrders} Orders
                  </p>
                </div>
                <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800 col-span-2 sm:col-span-1">
                  <span className="text-neutral-400">First Registered:</span>
                  <p className="text-xs font-semibold text-neutral-200 mt-1">
                    {safeDateToLocaleString(activeCustomer.createdAt)}
                  </p>
                </div>
              </div>

              {/* Contact Info */}
              <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
                <h4 className="font-bold text-neutral-300 uppercase tracking-wider text-[10px]">Contact & Address</h4>
                <p className="text-neutral-200 flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-neutral-500" />
                  <span>{activeCustomer.phone}</span>
                </p>
                {activeCustomer.email && (
                  <p className="text-neutral-200 flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-neutral-500" />
                    <span>{activeCustomer.email}</span>
                  </p>
                )}
                <p className="text-neutral-300 flex items-start gap-2 pt-1">
                  <MapPin className="w-3.5 h-3.5 text-neutral-500 shrink-0 mt-0.5" />
                  <span>{activeCustomer.address}</span>
                </p>
              </div>

              {/* Customer Notes */}
              <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
                <h4 className="font-bold text-neutral-300 uppercase tracking-wider text-[10px]">Staff Internal Note</h4>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customerNote}
                    onChange={(e) => setCustomerNote(e.target.value)}
                    placeholder="e.g. VIP loyal customer, requires prompt delivery."
                    className="flex-1 px-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-xl text-neutral-200 outline-none"
                  />
                  <button
                    onClick={handleSaveNote}
                    className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold"
                  >
                    Save
                  </button>
                </div>
              </div>

              {/* Customer Order History */}
              <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-3">
                <h4 className="font-bold text-neutral-300 uppercase tracking-wider text-[10px]">
                  Order History ({customerOrders.length})
                </h4>
                {customerOrders.length === 0 ? (
                  <p className="text-neutral-500 text-center py-3">No direct order match found in active log.</p>
                ) : (
                  <div className="divide-y divide-neutral-800/80">
                    {customerOrders.map(ord => (
                      <div key={ord.id} className="py-2.5 flex items-center justify-between gap-2">
                        <div>
                          <p className="font-bold text-neutral-100 font-mono">#{ord.id}</p>
                          <p className="text-[10px] text-neutral-500">
                            {safeDateToLocaleString(ord.date)} • {Array.isArray(ord.items) ? ord.items.length : 0} items
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-black text-white">{formatPrice(ord.total, language)}</p>
                          <span className="text-[10px] text-emerald-400 capitalize">{ord.orderStatus}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-neutral-800">
              <button
                onClick={() => onToggleBlockCustomer(activeCustomer.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                  activeCustomer.status === 'blocked' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
                }`}
              >
                {activeCustomer.status === 'blocked' ? 'Unblock Customer Account' : 'Block Customer from Ordering'}
              </button>

              <button
                onClick={() => setActiveCustomer(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-neutral-800 text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
