import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Edit3, 
  UserCheck, 
  UserX, 
  Lock, 
  Check, 
  X, 
  AlertCircle,
  Key
} from 'lucide-react';
import { AdminUser, AdminRole, Language } from '../../types';

interface AdminUsersViewProps {
  adminUsers?: AdminUser[];
  language: Language;
  onSaveAdminUser?: (user: AdminUser) => void;
  onDeleteAdminUser?: (userId: string) => void;
  onToggleUserStatus?: (userId: string) => void;
}

const ROLES_LIST: { id: AdminRole; label: string; desc: string }[] = [
  { id: 'super_admin', label: 'Super Admin', desc: 'Full unrestricted access to all dashboard tools, financial reports, settings, and staff accounts.' },
  { id: 'product_manager', label: 'Product Manager', desc: 'Can manage catalog products, categories, inventory stock in/out, reviews, and SEO.' },
  { id: 'order_manager', label: 'Order Dispatcher', desc: 'Can manage orders, verify courier tracking, update status, and manage customer shipments.' },
  { id: 'customer_support', label: 'Customer Support', desc: 'Can view customer records, order status, moderate reviews, and respond to inquiries.' },
  { id: 'marketing_manager', label: 'Marketing Lead', desc: 'Can manage discount coupons, promo banners, flash sale deals, and sales analytics.' },
];

export const AdminUsersView: React.FC<AdminUsersViewProps> = ({
  adminUsers = [],
  language,
  onSaveAdminUser,
  onDeleteAdminUser,
  onToggleUserStatus,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);

  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formRole, setFormRole] = useState<AdminRole>('order_manager');
  const [formStatus, setFormStatus] = useState<'active' | 'disabled'>('active');

  const handleOpenAdd = () => {
    setEditingUser(null);
    setFormName('');
    setFormEmail('');
    setFormRole('order_manager');
    setFormStatus('active');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (user: AdminUser) => {
    setEditingUser(user);
    setFormName(user.name);
    setFormEmail(user.email);
    setFormRole(user.role);
    setFormStatus(user.status);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: AdminUser = {
      id: editingUser ? editingUser.id : `adm-${Date.now()}`,
      name: formName.trim(),
      email: formEmail.trim().toLowerCase(),
      role: formRole,
      status: formStatus,
      createdAt: editingUser?.createdAt || new Date().toISOString(),
      lastLogin: editingUser?.lastLogin || 'Never'
    };

    onSaveAdminUser(newUser);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-5 rounded-3xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-rose-400" />
            <span>{language === 'bn' ? 'এডমিন টিম ও রোল পারমিশন' : 'Staff Accounts & Role Permissions'}</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            {language === 'bn' 
              ? 'স্টোর স্টাফদের অ্যাকাউন্ট পরিচালনা এবং সুপার এডমিন, প্রোডাক্ট ম্যানেজার ও অর্ডার ম্যানেজার রোল নির্ধারণ করুন।' 
              : 'Assign role-based access control (RBAC) to your operations and fulfillment staff.'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'bn' ? 'নতুন এডমিন যোগ করুন' : 'Add Staff Account'}</span>
        </button>
      </div>

      {/* Admin Users Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-300">
            <thead className="bg-neutral-950/80 text-neutral-400 uppercase text-[10px] font-black border-b border-neutral-800">
              <tr>
                <th className="py-3.5 px-4">{language === 'bn' ? 'এডমিন নাম' : 'Staff Member'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'ইমেইল' : 'Email Address'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'রোল' : 'Assigned Role'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'স্ট্যাটাস' : 'Status'}</th>
                <th className="py-3.5 px-4">{language === 'bn' ? 'সর্বশেষ লগইন' : 'Last Active'}</th>
                <th className="py-3.5 px-4 text-right">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {adminUsers.map(user => {
                const roleObj = ROLES_LIST.find(r => r.id === user.role) || ROLES_LIST[0];

                return (
                  <tr key={user.id} className="hover:bg-neutral-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-600 to-red-600 flex items-center justify-center font-bold text-white text-xs">
                          {user.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-neutral-100">{user.name}</p>
                          {user.email === 'winlucky414@gmail.com' && (
                            <span className="text-[9px] font-bold text-rose-400">Master Super Admin</span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-neutral-300">
                      {user.email}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-neutral-800 text-neutral-200 border border-neutral-700">
                        {roleObj.label}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                        user.status === 'active' 
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                          : 'bg-red-500/20 text-red-400 border border-red-500/30'
                      }`}>
                        {user.status === 'active' ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-neutral-500 text-[11px]">
                      {user.lastLogin || 'Recent'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {user.email !== 'winlucky414@gmail.com' ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onToggleUserStatus(user.id)}
                            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
                            title="Toggle Status"
                          >
                            {user.status === 'active' ? <UserX className="w-3.5 h-3.5 text-amber-400" /> : <UserCheck className="w-3.5 h-3.5 text-emerald-400" />}
                          </button>
                          <button
                            onClick={() => handleOpenEdit(user)}
                            className="p-1.5 rounded-lg bg-blue-600/20 text-blue-400 hover:bg-blue-600/30 border border-blue-500/30"
                            title="Edit Role"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteAdminUser(user.id)}
                            className="p-1.5 rounded-lg bg-red-600/20 text-red-400 hover:bg-red-600/30 border border-red-500/30"
                            title="Delete Account"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-neutral-500 italic">Protected</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Role Matrix Reference Card */}
      <div className="bg-neutral-900 border border-neutral-800 p-5 rounded-3xl space-y-3">
        <h3 className="text-xs font-black uppercase text-neutral-400 tracking-wider">
          Role Permissions Matrix Reference
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          {ROLES_LIST.map(r => (
            <div key={r.id} className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800/80 space-y-1">
              <h4 className="font-bold text-white">{r.label}</h4>
              <p className="text-[11px] text-neutral-400 leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Add / Edit Admin User Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="bg-white border border-neutral-200 w-full max-w-md rounded-3xl p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <h3 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-rose-600" />
                <span>{editingUser ? 'Edit Staff Account' : 'Add New Staff Member'}</span>
              </h3>
              <button 
                type="button"
                onClick={() => setIsModalOpen(false)} 
                className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-neutral-800 font-bold">Full Name: *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Sazzad Hossain"
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 outline-none focus:border-rose-500 shadow-2xs"
                />
              </div>

              <div>
                <label className="text-neutral-800 font-bold">Email Address: *</label>
                <input
                  type="email"
                  required
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="e.g. staff@shoppingmall.com"
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 outline-none focus:border-rose-500 shadow-2xs"
                />
              </div>

              <div>
                <label className="text-neutral-800 font-bold">Assign Role & Permissions: *</label>
                <select
                  value={formRole}
                  onChange={(e) => setFormRole(e.target.value as AdminRole)}
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 outline-none focus:border-rose-500 shadow-2xs cursor-pointer"
                >
                  {ROLES_LIST.map(r => (
                    <option key={r.id} value={r.id}>{r.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-neutral-800 font-bold">Account Status:</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 bg-white border border-neutral-300 rounded-xl text-neutral-900 mt-1 outline-none focus:border-rose-500 shadow-2xs cursor-pointer"
                >
                  <option value="active">Active (Permitted to Log In)</option>
                  <option value="disabled">Disabled (Suspended Access)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black shadow-md shadow-rose-600/20 transition cursor-pointer"
                >
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
