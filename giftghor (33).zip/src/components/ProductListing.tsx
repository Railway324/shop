import React from 'react';
import { 
  Filter, 
  SlidersHorizontal, 
  RotateCcw, 
  Grid, 
  List,
  Sparkles,
  ShoppingBag
} from 'lucide-react';
import { Product, Language, CategoryId, FilterState, Category } from '../types';
import { translations, formatPrice, toBengaliNumber } from '../utils/translations';
import { initialCategories } from '../data/initialData';
import { ProductCard } from './ProductCard';
import { matchesCategoryFilter, normalizeCategoryId, isWatchProductTitle } from '../utils/categoryUtils';
import { getInterleavedMixedProducts } from '../utils/interleaveUtils';
import { getStoredDeletedProductIdsSet } from '../utils/storage';

interface ProductListingProps {
  products: Product[];
  categories?: Category[];
  language: Language;
  filters: FilterState;
  onFilterChange: (newFilters: Partial<FilterState>) => void;
  onResetFilters: () => void;
  onSelectProduct: (p: Product) => void;
  onAddToCart: (p: Product, e: React.MouseEvent) => void;
  cartItemIds: Set<string>;
}

export const ProductListing: React.FC<ProductListingProps> = React.memo(({
  products,
  categories = [],
  language,
  filters,
  onFilterChange,
  onResetFilters,
  onSelectProduct,
  onAddToCart,
  cartItemIds,
}) => {
  const t = translations[language];
  const [viewMode, setViewMode] = React.useState<'grid' | 'list'>('grid');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = React.useState(false);
  const [displayCount, setDisplayCount] = React.useState(24);
  const loadMoreRef = React.useRef<HTMLDivElement | null>(null);

  // Reset pagination count when filters change
  React.useEffect(() => {
    setDisplayCount(24);
  }, [filters.category, filters.searchQuery, filters.sortBy, filters.minPrice, filters.maxPrice, filters.inStockOnly]);

  // Exclude deleted products
  const activeProducts = React.useMemo(() => {
    const deletedIds = getStoredDeletedProductIdsSet();
    return (products || []).filter(p => p && p.id && p.status !== 'inactive' && !deletedIds.has(String(p.id).trim()));
  }, [products]);

  const baseCategories = React.useMemo(() => {
    return categories && categories.length > 0 ? categories : initialCategories;
  }, [categories]);

  // Single O(N) pass category counts (instead of 10 x 3,073 = 30,730 iterations)
  const dynamicCategories = React.useMemo(() => {
    const counts = new Map<string, number>();
    for (let i = 0; i < activeProducts.length; i++) {
      const p = activeProducts[i];
      const catId = p.category === 'watches' || isWatchProductTitle(p.titleEn, p.titleBn)
        ? 'watches'
        : normalizeCategoryId(p.category);
      counts.set(catId, (counts.get(catId) || 0) + 1);
    }
    return baseCategories.map(cat => ({
      ...cat,
      itemCount: cat.id === 'all' ? activeProducts.length : (counts.get(cat.id) || 0),
    }));
  }, [baseCategories, activeProducts]);

  // Memoize Filtered Products so scrolling (displayCount updates) NEVER re-filters or re-sorts 3,073 products
  const filteredProducts = React.useMemo(() => {
    const q = filters.searchQuery.trim().toLowerCase();
    return activeProducts.filter(p => {
      if (!matchesCategoryFilter(p, filters.category)) return false;
      if (q) {
        const matchTitle = (p.titleBn && p.titleBn.toLowerCase().includes(q)) || (p.titleEn && p.titleEn.toLowerCase().includes(q));
        const matchCat = p.category && p.category.toLowerCase().includes(q);
        if (!matchTitle && !matchCat) return false;
      }
      if (p.price < filters.minPrice || p.price > filters.maxPrice) return false;
      if (filters.inStockOnly && p.stock <= 0) return false;
      return true;
    });
  }, [activeProducts, filters.category, filters.searchQuery, filters.minPrice, filters.maxPrice, filters.inStockOnly]);

  // Sort Products
  const sortedProducts = React.useMemo(() => {
    if (filters.category === 'all' && filters.sortBy === 'popular' && !filters.searchQuery.trim()) {
      return getInterleavedMixedProducts(filteredProducts);
    }

    return [...filteredProducts].sort((a, b) => {
      if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
      if (!a.isPinnedToTop && b.isPinnedToTop) return 1;

      if (filters.sortBy === 'popular') {
        const orderA = typeof a.displayOrder === 'number' ? a.displayOrder : 99999;
        const orderB = typeof b.displayOrder === 'number' ? b.displayOrder : 99999;
        if (orderA !== orderB) return orderA - orderB;
      }

      switch (filters.sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'newest':
          return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
        case 'discount':
          return (b.discountPercent || 0) - (a.discountPercent || 0);
        case 'popular':
        default:
          return (b.rating || 5) * (b.reviewsCount || 1) - (a.rating || 5) * (a.reviewsCount || 1);
      }
    });
  }, [filteredProducts, filters.category, filters.sortBy, filters.searchQuery]);

  const visibleProducts = React.useMemo(() => {
    return sortedProducts.slice(0, displayCount);
  }, [sortedProducts, displayCount]);

  React.useEffect(() => {
    const el = loadMoreRef.current;
    if (!el || displayCount >= sortedProducts.length) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        setDisplayCount(prev => Math.min(prev + 24, sortedProducts.length));
      }
    }, { rootMargin: '300px 0px' });

    observer.observe(el);
    return () => observer.disconnect();
  }, [displayCount, sortedProducts.length]);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-4 py-3 sm:py-6 space-y-4 sm:space-y-6">
      {/* Title & Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 border-b border-[#520510] pb-3 sm:pb-4">
        <div>
          <h1 className="text-lg sm:text-2xl font-black text-white flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />
            <span>{t.allProductsTitle}</span>
          </h1>
          <p className="text-[11px] sm:text-xs text-neutral-300 mt-0.5">
            {language === 'bn' ? toBengaliNumber(sortedProducts.length) : sortedProducts.length} {t.productsFound}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Mobile Filter Toggle Button */}
          <button
            onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
            className="md:hidden flex items-center gap-1.5 px-3 py-2 bg-[#2D0208] text-amber-300 rounded-xl text-xs font-bold border border-[#6B0B1D]"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>{t.filters}</span>
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-neutral-300 font-semibold hidden sm:inline">{t.sortBy}:</span>
            <select
              id="sort-select-dropdown"
              value={filters.sortBy}
              onChange={(e) => onFilterChange({ sortBy: e.target.value as FilterState['sortBy'] })}
              className="px-3 py-2 bg-[#240106] border border-[#6B0B1D] text-white rounded-xl text-xs font-semibold focus:outline-hidden focus:border-amber-400"
            >
              <option value="popular" className="bg-[#240106] text-white">{t.sortPopular}</option>
              <option value="price-low" className="bg-[#240106] text-white">{t.sortPriceLow}</option>
              <option value="price-high" className="bg-[#240106] text-white">{t.sortPriceHigh}</option>
              <option value="newest" className="bg-[#240106] text-white">{t.sortNewest}</option>
              <option value="discount" className="bg-[#240106] text-white">{t.sortDiscount}</option>
            </select>
          </div>

          {/* Grid / List View Toggle */}
          <div className="hidden sm:flex items-center bg-[#240106] p-1 rounded-xl border border-[#520510]">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition ${
                viewMode === 'grid' ? 'bg-amber-400 text-neutral-950 font-bold shadow-xs' : 'text-neutral-300 hover:text-white'
              }`}
              title="Grid View"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition ${
                viewMode === 'list' ? 'bg-amber-400 text-neutral-950 font-bold shadow-xs' : 'text-neutral-300 hover:text-white'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Grid with Sidebar Filter */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Filter Sidebar (Desktop and Mobile collapsible) */}
        <div className={`md:block space-y-6 ${isMobileFilterOpen ? 'block' : 'hidden md:block'}`}>
          <div className="bg-[#240106] p-5 rounded-2xl border border-[#5A0617] space-y-6 shadow-md">
            <div className="flex items-center justify-between border-b border-[#520510] pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Filter className="w-4 h-4 text-amber-400" />
                <span>{t.filters}</span>
              </h3>
              <button
                id="reset-filter-btn"
                onClick={onResetFilters}
                className="text-[11px] text-amber-300 hover:text-amber-200 flex items-center gap-1 font-semibold cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t.resetFilters}</span>
              </button>
            </div>

            {/* Category Filter */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-amber-300/80 block">
                {t.category}
              </label>
              <div className="space-y-1">
                {dynamicCategories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => onFilterChange({ category: cat.id })}
                    className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition flex items-center justify-between cursor-pointer ${
                      filters.category === cat.id
                        ? 'bg-amber-400 text-neutral-950 font-black'
                        : 'text-neutral-300 hover:bg-[#3B030B] hover:text-white'
                    }`}
                  >
                    <span>{language === 'bn' ? cat.nameBn : cat.nameEn}</span>
                    <span className={`text-[10px] ${filters.category === cat.id ? 'text-neutral-900 font-black' : 'text-neutral-400'}`}>
                      {language === 'bn' ? toBengaliNumber(cat.itemCount) : cat.itemCount}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div className="space-y-3 pt-2 border-t border-[#520510]">
              <div className="flex items-center justify-between text-xs">
                <label className="font-bold uppercase tracking-wider text-amber-300/80">
                  {t.priceRange}
                </label>
                <span className="font-mono font-bold text-amber-400">
                  {formatPrice(filters.maxPrice, language)}
                </span>
              </div>
              <input
                id="price-range-slider"
                type="range"
                min={0}
                max={50000}
                step={100}
                value={filters.maxPrice}
                onChange={(e) => onFilterChange({ maxPrice: Number(e.target.value) })}
                className="w-full accent-amber-400 cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-neutral-400 font-mono">
                <span>{formatPrice(0, language)}</span>
                <span>{formatPrice(50000, language)}</span>
              </div>
            </div>

            {/* In Stock Only */}
            <div className="pt-2 border-t border-[#520510]">
              <label className="flex items-center gap-2 text-xs font-semibold text-neutral-300 cursor-pointer hover:text-white">
                <input
                  id="in-stock-only-checkbox"
                  type="checkbox"
                  checked={filters.inStockOnly}
                  onChange={(e) => onFilterChange({ inStockOnly: e.target.checked })}
                  className="rounded text-amber-400 focus:ring-amber-400 w-4 h-4 cursor-pointer accent-amber-400"
                />
                <span>{t.onlyInStock}</span>
              </label>
            </div>
          </div>
        </div>

        {/* Products Grid / List */}
        <div className="md:col-span-3">
          {sortedProducts.length === 0 ? (
            <div className="bg-[#240106] rounded-3xl p-12 text-center border border-[#6B0B1D] space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#3B030B] text-amber-400 flex items-center justify-center mx-auto">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  {products.length === 0 
                    ? (language === 'bn' ? 'স্টোরে বর্তমানে কোনো পণ্য নেই' : 'No products in store')
                    : t.noProductsFound}
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  {products.length === 0
                    ? (language === 'bn' ? 'আপনার নির্দেশ অনুযায়ী সকল পণ্য সফলভাবে মুছে ফেলা হয়েছে।' : 'All products have been removed.')
                    : (language === 'bn' ? 'অন্য কোনো ফিল্টার বা অনুসন্ধান শব্দ চেষ্টা করুন।' : 'Try different filters or search terms.')}
                </p>
              </div>
              {products.length > 0 && (
                <button
                  onClick={onResetFilters}
                  className="px-5 py-2 rounded-xl bg-amber-400 text-neutral-950 text-xs font-black transition shadow-sm hover:bg-amber-300 cursor-pointer"
                >
                  {t.resetFilters}
                </button>
              )}
            </div>
          ) : (
            <>
              <div className={
                viewMode === 'grid'
                  ? "grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-4"
                  : "space-y-3"
              }>
                {visibleProducts.map((p, idx) => (
                  <ProductCard
                    key={p.id}
                    product={p}
                    language={language}
                    onSelectProduct={onSelectProduct}
                    onAddToCart={onAddToCart}
                    isInCart={cartItemIds.has(p.id)}
                    priority={idx < 4}
                  />
                ))}
              </div>

              {displayCount < sortedProducts.length && (
                <div ref={loadMoreRef} className="pt-8 pb-4 text-center">
                  <button
                    onClick={() => setDisplayCount(prev => Math.min(prev + 24, sortedProducts.length))}
                    className="px-6 py-2.5 bg-[#3B030B] hover:bg-[#520510] text-amber-300 font-bold text-xs rounded-xl border border-amber-400/30 transition shadow-sm cursor-pointer hover:scale-105 active:scale-95"
                  >
                    {language === 'bn'
                      ? `আরও পণ্য লোড করুন (${toBengaliNumber(sortedProducts.length - displayCount)}টি বাকি)`
                      : `Load More Products (${sortedProducts.length - displayCount} remaining)`}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
});
