import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowRight, 
  Tag, 
  Check, 
  AlertCircle,
  UserPlus
} from 'lucide-react';
import { CartItem, Language } from '../types';
import { translations, formatPrice, toBengaliNumber } from '../utils/translations';
import { VALID_COUPONS } from '../data/initialData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  language: Language;
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: (appliedCoupon?: { code: string; discount: number }) => void;
  onContinueShopping: () => void;
  isLoggedIn?: boolean;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  language,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  onContinueShopping,
  isLoggedIn = false,
}) => {
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | null>(null);
  const [couponError, setCouponError] = useState('');

  if (!isOpen) return null;

  const t = translations[language];

  const subtotal = cartItems.reduce((acc, item) => acc + (item.product?.price || 0) * item.quantity, 0);
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  
  // Standard estimated delivery: Free if subtotal >= 1500, else 60
  const deliveryFee = subtotal >= 1500 || subtotal === 0 ? 0 : 60;
  const total = Math.max(0, subtotal - discountAmount + deliveryFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = couponInput.trim().toUpperCase();
    if (!cleanCode) return;

    if (VALID_COUPONS[cleanCode]) {
      setAppliedCoupon({ code: cleanCode, discount: VALID_COUPONS[cleanCode] });
      setCouponError('');
    } else {
      setCouponError(t.couponInvalid);
      setAppliedCoupon(null);
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponInput('');
    setCouponError('');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-0 sm:pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col border-l border-neutral-200 animate-slideLeft">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-100 flex items-center justify-between bg-rose-50/50">
            <div className="flex items-center gap-2 text-neutral-900 font-bold text-base sm:text-lg">
              <ShoppingBag className="w-5 h-5 text-rose-600" />
              <span>{t.yourCart}</span>
              <span className="text-xs bg-rose-600 text-white font-black px-2 py-0.5 rounded-full">
                {language === 'bn' ? toBengaliNumber(cartItems.reduce((a, b) => a + b.quantity, 0)) : cartItems.reduce((a, b) => a + b.quantity, 0)}
              </span>
            </div>
            <button
              id="close-cart-drawer-btn"
              onClick={onClose}
              className="w-8 h-8 rounded-full hover:bg-neutral-200 text-neutral-500 flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart items list or empty state */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 divide-y divide-neutral-100">
            {cartItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-20 h-20 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center">
                  <ShoppingBag className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-neutral-800">{t.emptyCartTitle}</h3>
                  <p className="text-xs text-neutral-500 mt-1 max-w-xs">{t.emptyCartDesc}</p>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onContinueShopping();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                >
                  {t.continueShopping}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {cartItems.map(({ product, quantity, selectedSize, selectedColor }, idx) => (
                  <div key={`${product.id}-${selectedSize || ''}-${selectedColor || ''}-${idx}`} className="flex gap-3 pt-3 first:pt-0">
                    {/* Item image */}
                    <img
                      src={product.image}
                      alt={product.titleEn}
                      className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-xl border border-neutral-200 shrink-0"
                    />

                    {/* Item info */}
                    <div className="flex-1 flex flex-col justify-between min-w-0">
                      <div>
                        <h4 className="text-xs sm:text-sm font-semibold text-neutral-800 line-clamp-1">
                          {language === 'bn' ? product.titleBn : product.titleEn}
                        </h4>
                        {(selectedSize || selectedColor) && (
                          <div className="flex items-center gap-1.5 flex-wrap mt-1">
                            {selectedSize && (
                              <span className="text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200 px-1.5 py-0.5 rounded-md">
                                {language === 'bn' ? 'সাইজ:' : 'Size:'} {selectedSize}
                              </span>
                            )}
                            {selectedColor && (
                              <span className="text-[10px] font-bold bg-neutral-100 text-neutral-700 border border-neutral-200 px-1.5 py-0.5 rounded-md">
                                {language === 'bn' ? 'কালার:' : 'Color:'} {selectedColor}
                              </span>
                            )}
                          </div>
                        )}
                        <div className="flex items-baseline gap-2 mt-0.5">
                          <span className="text-xs sm:text-sm font-bold text-rose-600">
                            {formatPrice(product.price, language)}
                          </span>
                          {product.originalPrice && (
                            <span className="text-[11px] text-neutral-400 line-through">
                              {formatPrice(product.originalPrice, language)}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Quantity & Delete */}
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center border border-neutral-200 rounded-lg overflow-hidden bg-neutral-50">
                          <button
                            onClick={() => onUpdateQuantity(product.id, -1)}
                            className="w-7 h-7 flex items-center justify-center text-neutral-600 hover:bg-neutral-200 transition cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center text-xs font-bold text-neutral-800 font-mono">
                            {language === 'bn' ? toBengaliNumber(quantity) : quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(product.id, 1)}
                            disabled={quantity >= product.stock}
                            className="w-7 h-7 flex items-center justify-center text-neutral-600 hover:bg-neutral-200 transition disabled:opacity-30 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(product.id)}
                          className="text-neutral-400 hover:text-red-600 p-1 transition cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer calculation & checkout */}
          {cartItems.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-neutral-200 bg-neutral-50 space-y-3">
              {/* Coupon input */}
              <div>
                {!appliedCoupon ? (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={couponInput}
                        onChange={(e) => setCouponInput(e.target.value)}
                        placeholder="কুপন কোড (যেমন: SHOPPINGMALL)"
                        className="w-full pl-9 pr-3 py-2 text-xs bg-white rounded-xl border border-neutral-300 focus:outline-hidden focus:border-rose-500 uppercase font-semibold"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-3.5 py-2 bg-neutral-800 hover:bg-neutral-900 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                    >
                      {t.applyCoupon}
                    </button>
                  </form>
                ) : (
                  <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800">
                    <div className="flex items-center gap-1.5 font-semibold">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>{appliedCoupon.code} (-{formatPrice(appliedCoupon.discount, language)})</span>
                    </div>
                    <button
                      onClick={handleRemoveCoupon}
                      className="text-emerald-700 hover:text-red-600 font-bold cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}
                {couponError && (
                  <p className="text-[11px] text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{couponError}</span>
                  </p>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-neutral-600 pt-1">
                <div className="flex justify-between">
                  <span>{t.subtotal}</span>
                  <span className="font-semibold text-neutral-800">{formatPrice(subtotal, language)}</span>
                </div>

                <div className="flex justify-between">
                  <span>{t.deliveryFee}</span>
                  <span className="font-semibold text-neutral-800">
                    {deliveryFee === 0 ? (
                      <span className="text-emerald-600 font-bold uppercase">{t.free}</span>
                    ) : (
                      formatPrice(deliveryFee, language)
                    )}
                  </span>
                </div>

                {appliedCoupon && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>{t.discount}</span>
                    <span>-{formatPrice(discountAmount, language)}</span>
                  </div>
                )}

                <div className="flex justify-between text-sm font-black text-neutral-900 pt-2 border-t border-neutral-200">
                  <span>{t.totalAmount}</span>
                  <span className="text-rose-600 text-base">{formatPrice(total, language)}</span>
                </div>
              </div>

              {/* Friendly Trust Notice */}
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] flex items-center gap-2 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                <span>
                  {language === 'bn' 
                    ? '১০০% ক্যাশ অন ডেলিভারি | পণ্য হাতে পেয়ে মূল্য পরিশোধ করুন' 
                    : '100% Cash on Delivery | Pay cash after delivery'}
                </span>
              </div>

              {/* Checkout Button */}
              <button
                id="cart-proceed-checkout-btn"
                onClick={() => {
                  onProceedToCheckout(appliedCoupon || undefined);
                  onClose();
                }}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-bold text-sm shadow-md shadow-rose-200 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
              >
                <span>
                  {language === 'bn' ? 'অর্ডার সম্পন্ন করুন' : t.checkout}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
