import React, { useState } from 'react';
import { 
  AlertTriangle, 
  X, 
  CheckCircle2, 
  Package, 
  HelpCircle,
  Clock
} from 'lucide-react';
import { Order, Language } from '../types';
import { formatPrice } from '../utils/translations';
import { CANCELLATION_REASONS, canUserCancelOrder } from '../utils/orderUtils';

interface CancelOrderModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirmCancel: (orderId: string, reason: string) => Promise<void> | void;
  language: Language;
}

export const CancelOrderModal: React.FC<CancelOrderModalProps> = ({
  order,
  isOpen,
  onClose,
  onConfirmCancel,
  language
}) => {
  const [selectedReason, setSelectedReason] = useState(CANCELLATION_REASONS[0].id);
  const [customReason, setCustomReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen || !order) return null;

  const isEligible = canUserCancelOrder(order);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEligible || isSubmitting) return;

    setIsSubmitting(true);
    try {
      const reasonObj = CANCELLATION_REASONS.find(r => r.id === selectedReason);
      const reasonText = selectedReason === 'other' && customReason.trim()
        ? customReason.trim()
        : (language === 'bn' ? reasonObj?.labelBn : reasonObj?.labelEn) || 'গ্রাহকের অনুরোধে বাতিল';

      await onConfirmCancel(order.id, reasonText);
      onClose();
    } catch (err) {
      console.error('Error cancelling order:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
      onClick={onClose}
    >
      <div 
        className="relative bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 sm:p-7 border border-neutral-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-neutral-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100 shrink-0">
              <AlertTriangle className="w-5 h-5 text-rose-600" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-neutral-900 leading-tight">
                {language === 'bn' ? 'অর্ডার বাতিল করুন' : 'Cancel Your Order'}
              </h3>
              <p className="text-xs text-neutral-500 font-mono mt-0.5">
                {language === 'bn' ? 'অর্ডার নম্বর:' : 'Order ID:'} <span className="font-bold text-rose-600">#{order.id}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!isEligible ? (
          <div className="py-6 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto border border-amber-200">
              <Clock className="w-7 h-7" />
            </div>
            <h4 className="text-sm font-black text-neutral-900">
              {language === 'bn' ? 'অর্ডারটি এখন আর বাতিল করা সম্ভব নয়' : 'Order Cannot Be Cancelled'}
            </h4>
            <p className="text-xs text-neutral-600 max-w-sm mx-auto leading-relaxed">
              {language === 'bn'
                ? 'আপনার অর্ডারটি ইতিমধ্যে প্যাকেজিং সম্পন্ন হয়ে কুরিয়ার সার্ভিসের নিকট হস্তান্তর করা হয়েছে। কুরিয়ারে দেওয়ার পর সরাসরি ওয়েবসাইট থেকে অর্ডার বাতিল করা যায় না।'
                : 'Your order has already been handed over to the courier for delivery. Once handed to courier, direct cancellation is no longer permitted.'}
            </p>
            <div className="pt-2">
              <button
                onClick={onClose}
                className="px-5 py-2.5 bg-neutral-900 text-white rounded-xl text-xs font-bold hover:bg-neutral-800 transition cursor-pointer"
              >
                {language === 'bn' ? 'ঠিক আছে' : 'Got it'}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 pt-4 text-xs">
            {/* Order summary mini-card */}
            <div className="p-3.5 bg-neutral-50 border border-neutral-200 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-neutral-400" />
                  <span>{language === 'bn' ? 'পণ্যের সংখ্যা:' : 'Total Items:'}</span>
                </span>
                <span className="font-bold text-neutral-900">{order.items.length} টি</span>
              </div>
              <div className="flex items-center justify-between text-neutral-600">
                <span>{language === 'bn' ? 'সর্বমোট মূল্য:' : 'Total Payable:'}</span>
                <span className="font-black text-rose-600 font-mono text-sm">{formatPrice(order.total, language)}</span>
              </div>
              <div className="text-[11px] text-neutral-500 line-clamp-1">
                {order.items.map(i => language === 'bn' ? i.product.titleBn : i.product.titleEn).join(', ')}
              </div>
            </div>

            {/* Policy Info Notice */}
            <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-xl text-neutral-700 space-y-1">
              <div className="font-bold text-rose-800 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-rose-600" />
                <span>{language === 'bn' ? 'কুরিয়ারে হস্তান্তরের পূর্বে সহজ বাতিল সুবিধা' : 'Pre-Courier Cancellation Policy'}</span>
              </div>
              <p className="text-[11px] text-neutral-600 leading-relaxed">
                {language === 'bn'
                  ? 'আপনার অর্ডারটি এখনো কুরিয়ারে হস্তান্তর করা হয়নি। তাই আপনি নিরাপদে এটি এখনই বাতিল করতে পারেন। বাতিল করার পর সংরক্ষিত স্টক স্বয়ংক্রিয়ভাবে ফেরত দেওয়া হবে।'
                  : 'Your order has not been dispatched to courier yet. You can safely cancel now. Product inventory will be restored automatically.'}
              </p>
            </div>

            {/* Reason selection */}
            <div className="space-y-2">
              <label className="font-bold text-neutral-800 flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5 text-neutral-500" />
                <span>{language === 'bn' ? 'বাতিল করার কারণ নির্বাচন করুন:' : 'Please select reason for cancellation:'}</span>
              </label>

              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {CANCELLATION_REASONS.map(reason => (
                  <label
                    key={reason.id}
                    className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition cursor-pointer ${
                      selectedReason === reason.id
                        ? 'bg-rose-50/70 border-rose-400 text-rose-900 font-semibold'
                        : 'bg-white border-neutral-200 hover:bg-neutral-50 text-neutral-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="cancellationReason"
                      value={reason.id}
                      checked={selectedReason === reason.id}
                      onChange={(e) => setSelectedReason(e.target.value)}
                      className="mt-0.5 accent-rose-600"
                    />
                    <span className="text-xs leading-tight">
                      {language === 'bn' ? reason.labelBn : reason.labelEn}
                    </span>
                  </label>
                ))}
              </div>

              {selectedReason === 'other' && (
                <div className="pt-1">
                  <textarea
                    rows={2}
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    placeholder={language === 'bn' ? 'অন্যান্য কারণ বিস্তারিত লিখুন (ঐচ্ছিক)...' : 'Write details (optional)...'}
                    className="w-full p-2.5 rounded-xl border border-neutral-300 focus:outline-hidden focus:ring-2 focus:ring-rose-400 text-xs bg-neutral-50"
                  />
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2.5 pt-2 border-t border-neutral-100">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="flex-1 py-2.5 px-4 rounded-xl border border-neutral-300 text-neutral-700 font-bold hover:bg-neutral-100 transition cursor-pointer text-xs"
              >
                {language === 'bn' ? 'না, অর্ডার রাখব' : 'Keep Order'}
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-bold transition shadow-xs cursor-pointer flex items-center justify-center gap-1.5 text-xs disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>{language === 'bn' ? 'বাতিল হচ্ছে...' : 'Cancelling...'}</span>
                ) : (
                  <span>{language === 'bn' ? 'হ্যাঁ, অর্ডার বাতিল করুন' : 'Confirm Cancellation'}</span>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
