import React from 'react';
import { Sparkles, ArrowRight, Heart } from 'lucide-react';
import { Product, Language } from '../types';
import { formatPrice } from '../utils/translations';
import { getOptimizedImageUrl } from '../utils/imageOptimizer';

interface TopCuteCollectionsProps {
  products: Product[];
  language: Language;
  onSelectProduct: (p: Product) => void;
  onFilterCategory: (categoryKeyword: string) => void;
}

interface CuteCollectionItem {
  id: string;
  title: string;
  subtitle: string;
  tag: string;
  gradient: string;
  borderHover: string;
  badgeBg: string;
  badgeText: string;
  iconEmoji: string;
  keywords: string[];
}

export const TopCuteCollections: React.FC<TopCuteCollectionsProps> = ({
  products,
  language,
  onSelectProduct,
  onFilterCategory,
}) => {
  const collections: CuteCollectionItem[] = [
    {
      id: 'cute-sarees',
      title: 'Cute Sarees',
      subtitle: 'Gorgeous party, festive & traditional sarees',
      tag: 'Cute Sarees',
      gradient: 'from-pink-500/10 via-rose-500/5 to-amber-500/10',
      borderHover: 'hover:border-pink-400 group-hover:shadow-pink-100',
      badgeBg: 'bg-pink-100',
      badgeText: 'text-pink-700',
      iconEmoji: '🌸',
      keywords: ['saree', 'শাড়ি', 'শাড়ী'],
    },
    {
      id: 'cute-dresses',
      title: 'Cute Dresses & Tops',
      subtitle: 'Stylish kurtis, frocks & trendy wear',
      tag: 'Cute Dresses',
      gradient: 'from-purple-500/10 via-fuchsia-500/5 to-rose-500/10',
      borderHover: 'hover:border-purple-400 group-hover:shadow-purple-100',
      badgeBg: 'bg-purple-100',
      badgeText: 'text-purple-700',
      iconEmoji: '👗',
      keywords: ['dress', 'kurti', 'frock', 'জামা', 'ড্রেস', 'কামিজ', 'top'],
    },
    {
      id: 'cute-watches',
      title: 'Cute Watches',
      subtitle: 'Smartwatches & luxury analog timepieces',
      tag: 'Cute Watches',
      gradient: 'from-sky-500/10 via-blue-500/5 to-indigo-500/10',
      borderHover: 'hover:border-sky-400 group-hover:shadow-sky-100',
      badgeBg: 'bg-sky-100',
      badgeText: 'text-sky-700',
      iconEmoji: '⌚',
      keywords: ['watch', 'ঘড়ি', 'ঘড়ি', 'smartwatch'],
    },
    {
      id: 'cute-pants',
      title: 'Cute Pants & Bottoms',
      subtitle: 'Premium joggers, chinos & casual denim',
      tag: 'Cute Pants',
      gradient: 'from-emerald-500/10 via-teal-500/5 to-cyan-500/10',
      borderHover: 'hover:border-emerald-400 group-hover:shadow-emerald-100',
      badgeBg: 'bg-emerald-100',
      badgeText: 'text-emerald-700',
      iconEmoji: '👖',
      keywords: ['pant', 'trouser', 'jeans', 'jogger', 'প্যান্ট', 'প্যান'],
    },
  ];

  // Helper to find matching products for each cute group
  const getCollectionProducts = (keywords: string[]) => {
    return products.filter((p) => {
      const fullText = `${p.titleEn || ''} ${p.titleBn || ''} ${p.category || ''} ${p.tags ? p.tags.join(' ') : ''}`.toLowerCase();
      return keywords.some((k) => fullText.includes(k.toLowerCase()));
    });
  };

  return (
    <section className="space-y-4 py-2">
      {/* Top Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#520510] pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-600 text-neutral-950 flex items-center justify-center shadow-md shadow-amber-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                Top Featured Cute Collections
              </h2>
              <span className="hidden sm:inline-flex items-center gap-1 bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[11px] font-bold px-2 py-0.5 rounded-full">
                <Heart className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span>Trending Now</span>
              </span>
            </div>
            <p className="text-xs text-neutral-300 font-medium">
              Explore our handpicked Cute Sarees, Cute Dresses, Cute Watches & Cute Pants
            </p>
          </div>
        </div>

        {/* Quick Clickable Tag Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {collections.map((col) => (
            <button
              key={col.id}
              onClick={() => onFilterCategory(col.keywords[0])}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-[#2A0207] hover:bg-[#3D030C] text-neutral-200 hover:text-white transition border border-[#520510] hover:border-amber-400/40 shrink-0 cursor-pointer shadow-xs"
            >
              <span>{col.iconEmoji}</span>
              <span>{col.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid of 4 Cute Collection Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {collections.map((col) => {
          const matched = getCollectionProducts(col.keywords);
          const matchedCount = matched.length;

          return (
            <div
              key={col.id}
              onClick={() => onFilterCategory(col.keywords[0])}
              className={`group relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#2D0208] to-[#1F0104] border border-[#5A0617] hover:border-amber-400/50 p-4 transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between`}
            >
              {/* Top Card Info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30`}>
                    <span>{col.iconEmoji}</span>
                    <span>{col.tag}</span>
                  </span>
                  <span className="text-[11px] font-bold text-neutral-400">
                    {matchedCount} items
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-black text-white group-hover:text-amber-300 transition-colors">
                    {col.title}
                  </h3>
                  <p className="text-[11px] text-neutral-300 line-clamp-1 mt-0.5">
                    {col.subtitle}
                  </p>
                </div>
              </div>

              {/* Product preview thumbnails */}
              <div className="mt-4 pt-3 border-t border-[#520510] flex items-center justify-between gap-2">
                <div className="flex items-center -space-x-2 overflow-hidden">
                  {matched.slice(0, 3).map((item, idx) => (
                    <div
                      key={item.id || idx}
                      className="relative w-10 h-10 rounded-xl overflow-hidden border-2 border-[#520510] bg-[#140003] shadow-xs shrink-0"
                    >
                      <img
                        src={getOptimizedImageUrl(item.image, 100, 70)}
                        alt={item.titleEn}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        decoding="async"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          const target = e.currentTarget as HTMLImageElement;
                          const clean = item.image ? item.image.replace('public//storage', 'public/storage') : '';
                          if (clean && target.src !== clean && !target.src.includes('image-proxy')) {
                            target.src = clean;
                            return;
                          }
                          if (clean && !target.src.includes('image-proxy')) {
                            target.src = `/api/image-proxy?url=${encodeURIComponent(clean)}`;
                          }
                        }}
                      />
                    </div>
                  ))}
                </div>

                <div className="inline-flex items-center gap-1 text-xs font-bold text-amber-300 group-hover:translate-x-0.5 transition-transform">
                  <span>View All</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
