import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  MapPin, 
  Phone, 
  User, 
  UserPlus,
  Sparkles,
  CreditCard, 
  CheckCircle2, 
  Banknote, 
  ArrowRight,
  Truck,
  Copy,
  Check,
  Smartphone,
  Info,
  Lock
} from 'lucide-react';
import { CartItem, Language, PaymentMethod, Order, UserProfile } from '../types';
import { translations, formatPrice, toBengaliNumber } from '../utils/translations';
import { getProductSizes, getProductColors } from '../utils/variantUtils';
import { BD_DIVISIONS } from '../data/initialData';
import { 
  getDistrictsForDivision, 
  getThanasForDistrict, 
  findDistrict,
  DROPSHIPPING_DELIVERY_ZONES,
  resolveDeliveryZone,
  DeliveryZoneId
} from '../data/bangladeshGeoData';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  language: Language;
  appliedCoupon?: { code: string; discount: number };
  onOrderSuccess: (order: Order) => void;
  currentUserProfile?: UserProfile | null;
  onOpenLogin?: () => void;
  onOpenSignup?: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  language,
  appliedCoupon,
  onOrderSuccess,
  currentUserProfile,
  onOpenLogin,
  onOpenSignup,
}) => {
  const t = translations[language];

  const [customerName, setCustomerName] = useState(currentUserProfile?.displayName || '');
  const [phone, setPhone] = useState(currentUserProfile?.phone || '');
  const [address, setAddress] = useState(currentUserProfile?.address || '');
  const [notes, setNotes] = useState('');
  const paymentMethod: PaymentMethod = 'cod';

  // DropshippingBD delivery zone state
  const [selectedDeliveryZone, setSelectedDeliveryZone] = useState<DeliveryZoneId>('inside_dhaka');

  // Auto-resolve delivery zone from address
  const autoResolvedZone = React.useMemo(() => {
    return resolveDeliveryZone('', '', address);
  }, [address]);

  React.useEffect(() => {
    if (address.trim().length > 3) {
      setSelectedDeliveryZone(autoResolvedZone.zone);
    }
  }, [autoResolvedZone.zone, address]);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [modalItems, setModalItems] = useState<CartItem[]>(() =>
    cartItems.map(item => {
      const sizes = getProductSizes(item.product);
      const colors = getProductColors(item.product);
      return {
        ...item,
        selectedSize: item.selectedSize || (sizes.length === 1 ? sizes[0] : undefined),
        selectedColor: item.selectedColor || (colors.length === 1 ? colors[0] : undefined),
      };
    })
  );

  React.useEffect(() => {
    setModalItems(
      cartItems.map(item => {
        const sizes = getProductSizes(item.product);
        const colors = getProductColors(item.product);
        return {
          ...item,
          selectedSize: item.selectedSize || (sizes.length === 1 ? sizes[0] : undefined),
          selectedColor: item.selectedColor || (colors.length === 1 ? colors[0] : undefined),
        };
      })
    );
  }, [cartItems, isOpen]);

  // Sync profile details if user logs in / signs up
  React.useEffect(() => {
    if (currentUserProfile) {
      if (currentUserProfile.displayName) setCustomerName(currentUserProfile.displayName);
      if (currentUserProfile.phone) setPhone(currentUserProfile.phone);
      if (currentUserProfile.address) setAddress(currentUserProfile.address);
    }
  }, [currentUserProfile]);

  // Lock background scroll while modal is open
  React.useEffect(() => {
    if (isOpen) {
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prevOverflow;
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const subtotal = modalItems.reduce((acc, item) => acc + (item.product?.price || 0) * item.quantity, 0);
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  
  // DropshippingBD delivery fee or Free Delivery
  const isFreeDelivery = modalItems.length > 0 && modalItems.every(item => item.product?.freeDelivery);
  const deliveryZoneConfig = DROPSHIPPING_DELIVERY_ZONES.find(z => z.id === selectedDeliveryZone);
  const deliveryFee = isFreeDelivery ? 0 : (deliveryZoneConfig ? deliveryZoneConfig.fee : 65);
  const total = Math.max(0, subtotal - discountAmount + deliveryFee);

  const validate = () => {
    const err: Record<string, string> = {};
    if (!currentUserProfile) {
      err.auth = language === 'bn' 
        ? 'অর্ডার নিশ্চিত করতে অনুগ্রহ করে একটি অ্যাকাউন্ট তৈরি করুন অথবা লগইন করুন।' 
        : 'Please create an account or sign in to confirm your order.';
    }
    if (!customerName.trim()) {
      err.name = language === 'bn' ? 'অনুগ্রহ করে আপনার পুরো নাম লিখুন' : 'Please enter your full name';
    }
    const cleanPhone = phone.trim().replace(/[\s-]/g, '');
    if (!cleanPhone || !/^01[3-9]\d{8}$/.test(cleanPhone)) {
      err.phone = language === 'bn' ? 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন' : 'Valid 11-digit Bangladeshi mobile number required';
    }
    if (!address.trim() || address.trim().length < 5) {
      err.address = language === 'bn' ? 'অনুগ্রহ করে সম্পূর্ণ ঠিকানা লিখুন' : 'Please provide detailed delivery address';
    }

    modalItems.forEach((item, idx) => {
      const colors = getProductColors(item.product);
      const sizes = getProductSizes(item.product);
      if (colors.length > 1 && !item.selectedColor) {
        err[`color_${idx}`] = language === 'bn' ? 'অনুগ্রহ করে কালার সিলেক্ট করুন' : 'Please select color';
      }
      if (sizes.length > 1 && !item.selectedSize) {
        err[`size_${idx}`] = language === 'bn' ? 'অনুগ্রহ করে সাইজ সিলেক্ট করুন' : 'Please select size';
      }
    });

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!currentUserProfile) {
      if (onOpenSignup) {
        onOpenSignup();
      } else if (onOpenLogin) {
        onOpenLogin();
      }
      return;
    }

    if (!validate()) return;

    setIsSubmitting(true);

    try {
      const timestampSuffix = Date.now().toString().slice(-6);
      const randomChars = Math.random().toString(36).substring(2, 6).toUpperCase();
      const newOrderId = `ORD-${timestampSuffix}-${randomChars}`;
      const now = new Date().toISOString();

      const finalName = customerName.trim() || currentUserProfile.displayName || 'গ্রাহক';
      const finalPhone = phone.trim();
      const finalAddress = address.trim();

      const newOrder: Order = {
        id: newOrderId,
        orderId: newOrderId,
        userId: currentUserProfile.uid,
        userEmail: currentUserProfile.email || '',
        email: currentUserProfile.email || '',
        date: now.split('T')[0],
        createdAt: now,
        updatedAt: now,
        customerName: finalName,
        phone: finalPhone,
        address: finalAddress,
        notes: notes.trim() || undefined,
        items: [...modalItems],
        subtotal,
        deliveryFee,
        discount: discountAmount,
        couponCode: appliedCoupon?.code,
        total,
        paymentMethod: 'cod',
        paymentStatus: 'pending',
        orderStatus: 'pending',
        courier: 'Steadfast Courier',
        courierName: 'Steadfast Courier',
        courierTrackingCode: `ST-${Date.now().toString().slice(-7)}`,
        statusHistory: [
          {
            id: `hist_${Date.now()}`,
            status: 'pending',
            timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
            date: now,
            note: language === 'bn' 
              ? 'অর্ডার সফলভাবে জমা হয়েছে (পেন্ডিং / অ্যাডমিন অনুমোদনের অপেক্ষায়)' 
              : 'Order placed (Pending admin approval)',
            updatedBy: finalName
          }
        ]
      };

      await onOrderSuccess(newOrder);
      onClose();
    } catch (err) {
      console.error('Error placing order:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Top helper banner if guest wants to sign in, but direct order is always enabled!
  return (
    <div 
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fadeIn"
      onClick={onClose}
    >
      <div 
        className="relative bg-white rounded-2xl sm:rounded-3xl shadow-2xl max-w-2xl w-full p-4 sm:p-8 border border-neutral-100 my-4 sm:my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-100 pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100 shadow-xs">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-neutral-900">{t.checkoutTitle}</h2>
              <p className="text-xs text-neutral-500">
                {language === 'bn' ? 'সরাসরি ক্যাশ অন ডেলিভারিতে অর্ডার করতে তথ্য পূরণ করুন' : 'Fill details to place Cash on Delivery order'}
              </p>
            </div>
          </div>
          <button
            id="close-checkout-modal-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mandatory account requirement notice for guest users */}
        {!currentUserProfile ? (
          <div className="mb-4 p-3.5 bg-amber-50 border border-amber-300 rounded-2xl flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 text-amber-900 font-medium">
              <Sparkles className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                {language === 'bn' 
                  ? '⚠️ অর্ডার কনফার্ম করতে অ্যাকাউন্ট থাকা আবশ্যক' 
                  : '⚠️ Account required to confirm your order'}
              </span>
            </div>
            {onOpenLogin && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenLogin();
                }}
                className="px-3 py-1.5 bg-[#800020] hover:bg-[#68001a] text-white rounded-lg text-[11px] font-bold shrink-0 cursor-pointer shadow-xs transition"
              >
                {language === 'bn' ? 'লগইন / সাইন আপ' : 'Login / Register'}
              </button>
            )}
          </div>
        ) : (
          <div className="mb-4 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900">
            <span className="font-semibold">✓ লগইন করা আছেন: {currentUserProfile.displayName}</span>
            <span className="text-[10px] bg-emerald-200/60 px-2 py-0.5 rounded-full font-mono">{currentUserProfile.email || currentUserProfile.phone}</span>
          </div>
        )}

        <form onSubmit={handleSubmitOrder} className="space-y-6">
          {/* Selected Items & Real Variant Selection (only when item has sizes/colors) */}
          {modalItems.length > 0 && (
            <div className="space-y-2.5 max-h-52 overflow-y-auto pr-1">
              {modalItems.map((item, idx) => {
                const colors = getProductColors(item.product);
                const sizes = getProductSizes(item.product);
                return (
                  <div key={`${item.product.id}-${idx}`} className="p-3 bg-neutral-50 border border-neutral-200 rounded-2xl space-y-2 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-neutral-900 line-clamp-1">
                        {language === 'bn' ? (item.product.titleBn || item.product.titleEn) : (item.product.titleEn || item.product.titleBn)} × {item.quantity}
                      </span>
                      <span className="font-black text-rose-600 shrink-0">
                        {formatPrice(item.product.price * item.quantity, language)}
                      </span>
                    </div>
                    {colors.length > 0 && (
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[11px] font-bold text-neutral-700">🎨 {language === 'bn' ? 'কালার:' : 'Color:'}</span>
                        {colors.map(c => (
                          <button
                            key={c}
                            type="button"
                            onClick={() => {
                              setModalItems(prev => prev.map((it, i) => i === idx ? { ...it, selectedColor: c } : it));
                              setErrors(prev => ({ ...prev, [`color_${idx}`]: '' }));
                            }}
                            className={`px-2 py-0.5 rounded-lg text-[11px] font-bold border cursor-pointer ${
                              item.selectedColor === c ? 'bg-rose-600 text-white border-rose-600' : 'bg-white text-neutral-700 border-neutral-300'
                            }`}
                          >
                            {c}
                          </button>
                        ))}
                        {errors[`color_${idx}`] && <span className="text-[10px] text-red-600 font-bold">{errors[`color_${idx}`]}</span>}
                      </div>
                    )}
                    {sizes.length > 0 && (
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[11px] font-bold text-neutral-700">📏 {language === 'bn' ? 'সাইজ:' : 'Size:'}</span>
                        {sizes.map(s => (
                          <button
                            key={s}
                            type="button"
                            onClick={() => {
                              setModalItems(prev => prev.map((it, i) => i === idx ? { ...it, selectedSize: s } : it));
                              setErrors(prev => ({ ...prev, [`size_${idx}`]: '' }));
                            }}
                            className={`px-2 py-0.5 rounded-lg text-[11px] font-bold border cursor-pointer ${
                              item.selectedSize === s ? 'bg-rose-600 text-white border-rose-600' : 'bg-white text-neutral-700 border-neutral-300'
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                        {errors[`size_${idx}`] && <span className="text-[10px] text-red-600 font-bold">{errors[`size_${idx}`]}</span>}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Customer Information Section */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-rose-800 flex items-center gap-1.5">
              <User className="w-4 h-4" />
              <span>{t.customerInfo}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  {t.fullName} *
                </label>
                <input
                  id="checkout-name-input"
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder={language === 'bn' ? 'আপনার পূর্ণ নাম লিখুন' : 'Enter your full name'}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs text-neutral-900 bg-white focus:outline-hidden ${
                    errors.name ? 'border-red-500 focus:border-red-500' : 'border-neutral-300 focus:border-rose-500'
                  }`}
                />
                {errors.name && <p className="text-[10px] text-red-500 mt-1">{errors.name}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  {t.phone} *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-400">
                    +88
                  </span>
                  <input
                    id="checkout-phone-input"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    maxLength={11}
                    className={`w-full pl-11 pr-3.5 py-2.5 rounded-xl border text-xs font-mono font-bold text-neutral-900 bg-white focus:outline-hidden ${
                      errors.phone ? 'border-red-500 focus:border-red-500' : 'border-neutral-300 focus:border-rose-500'
                    }`}
                  />
                </div>
                {errors.phone && <p className="text-[10px] text-red-500 mt-1">{errors.phone}</p>}
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {t.fullAddress} *
              </label>
              <textarea
                id="checkout-address-input"
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder={language === 'bn' ? 'বাসা/রোড নম্বর, এলাকা, থানা, জেলা উল্লেখ করুন' : 'House/Road, Area, Thana, District'}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs text-neutral-900 bg-white focus:outline-hidden ${
                  errors.address ? 'border-red-500 focus:border-red-500' : 'border-neutral-300 focus:border-rose-500'
                }`}
              />
              {errors.address && <p className="text-[10px] text-red-500 mt-1">{errors.address}</p>}
            </div>

            {/* DropshippingBD Delivery Area & Rate Selection */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1 text-rose-700">
                  <Truck className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'ডেলিভারি এলাকা ও চার্জ (DropshippingBD রেট)' : 'Delivery Zone & Charge'} *</span>
                </span>
                <span className="text-[10px] text-neutral-400">
                  {language === 'bn' ? 'ঠিকানা অনুযায়ী অটো-সিলেক্টেড' : 'Auto-detected'}
                </span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {DROPSHIPPING_DELIVERY_ZONES.map((zone) => {
                  const isSelected = selectedDeliveryZone === zone.id;
                  return (
                    <button
                      key={zone.id}
                      type="button"
                      onClick={() => setSelectedDeliveryZone(zone.id)}
                      className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-rose-50/80 border-rose-600 ring-2 ring-rose-500/20 shadow-xs'
                          : 'bg-neutral-50 hover:bg-white border-neutral-200 text-neutral-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-bold text-[11px] text-neutral-900">
                          {zone.nameBn.split('(')[0].trim()}
                        </span>
                        <span className={`text-[11px] font-black px-1.5 py-0.5 rounded ${
                          isSelected ? 'bg-rose-600 text-white' : 'bg-neutral-200 text-neutral-800'
                        }`}>
                          {zone.fee}.00 ৳
                        </span>
                      </div>
                      <span className="text-[9px] text-neutral-500 mt-1">
                        ⏱️ {zone.estimatedDaysBn}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                {t.orderNotes}
              </label>
              <input
                id="checkout-notes-input"
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={t.orderNotesPlaceholder}
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-300 text-xs text-neutral-900 bg-white focus:outline-hidden focus:border-rose-500"
              />
            </div>
          </div>

          {/* Payment Method Section (Cash on Delivery Only) */}
          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-rose-800 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Banknote className="w-4 h-4 text-emerald-600" />
                <span>{language === 'bn' ? 'পেমেন্ট পদ্ধতি' : 'Payment Method'}</span>
              </div>
              <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1 normal-case">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>100% Secure Checkout</span>
              </span>
            </h3>

            {/* Single COD Selection Card */}
            <div className="p-4 rounded-2xl border-2 border-emerald-500 bg-gradient-to-br from-emerald-50/70 to-teal-50/40 shadow-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-xs shrink-0">
                  <Banknote className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-black text-neutral-900">
                      {language === 'bn' ? 'ক্যাশ অন ডেলিভারি (Cash on Delivery)' : 'Cash on Delivery (COD)'}
                    </p>
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase">
                      {language === 'bn' ? 'অ্যাক্টিভ' : 'Active'}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-600 leading-relaxed mt-0.5">
                    {language === 'bn' 
                      ? 'অর্ডার করার সময় কোনো অগ্রিম টাকা দেওয়া লাগবে না। পার্সেল হাতে পেয়ে ডেলিভারিম্যানকে মূল্য দিন।' 
                      : 'No advance payment needed. Pay cash directly to the delivery person upon receiving your parcel.'}
                  </p>
                </div>
              </div>
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            </div>
          </div>

          {/* Order Bill Summary */}
          <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-2 text-xs">
            <div className="flex justify-between text-neutral-600">
              <span>{t.subtotal} ({language === 'bn' ? toBengaliNumber(cartItems.reduce((a, b) => a + b.quantity, 0)) : cartItems.reduce((a, b) => a + b.quantity, 0)} items):</span>
              <span className="font-semibold text-neutral-800">{formatPrice(subtotal, language)}</span>
            </div>

            <div className="flex justify-between text-neutral-600">
              <span className="flex items-center gap-1">
                {t.deliveryFee} 
                {deliveryFee > 0 && (
                  <span className="text-[10px] bg-neutral-100 px-1.5 py-0.5 rounded-md font-medium">
                    ({selectedDeliveryZone === 'inside_dhaka' 
                      ? (language === 'bn' ? 'ঢাকার ভিতরে — 65.00 ৳' : 'Inside Dhaka — 65.00 ৳') 
                      : (language === 'bn' ? 'ঢাকার বাইরে — 120.00 ৳' : 'Outside Dhaka — 120.00 ৳')})
                  </span>
                )}:
              </span>
              <span className="font-semibold text-neutral-800">
                {deliveryFee === 0 ? (
                  <span className="text-emerald-600 font-bold">{language === 'bn' ? 'ফ্রি (০.০০ ৳)' : 'FREE (0.00 ৳)'}</span>
                ) : (
                  formatPrice(deliveryFee, language)
                )}
              </span>
            </div>

            {appliedCoupon && (
              <div className="flex justify-between text-emerald-600 font-semibold">
                <span>{t.discount} ({appliedCoupon.code}):</span>
                <span>-{formatPrice(discountAmount, language)}</span>
              </div>
            )}

            <div className="flex justify-between text-sm font-black text-neutral-900 pt-2 border-t border-neutral-200">
              <span>{t.totalAmount}:</span>
              <span className="text-rose-600 text-base">{formatPrice(total, language)}</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            id="confirm-order-submit-btn"
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#800020] to-[#5B0616] hover:from-[#6B1124] hover:to-[#45020D] text-white font-black text-sm sm:text-base shadow-lg shadow-[#800020]/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              <span>{t.placingOrder}</span>
            ) : !currentUserProfile ? (
              <>
                <Lock className="w-5 h-5 text-amber-300" />
                <span>{language === 'bn' ? '🔒 অ্যাকাউন্ট তৈরি / লগইন করে অর্ডার করুন' : '🔒 Login / Register to Place Order'}</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-5 h-5" />
                <span>
                  {paymentMethod === 'cod' 
                    ? `${t.placeOrder} (${formatPrice(total, language)})`
                    : `${language === 'bn' ? 'অর্ডার কনফার্ম করুন' : 'Confirm Order'} (${formatPrice(total, language)})`}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
