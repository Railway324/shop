import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Package, 
  Truck, 
  ShoppingBag, 
  MapPin,
  XCircle,
  RotateCcw,
  Info
} from 'lucide-react';
import { Order, Language } from '../types';
import { formatPrice } from '../utils/translations';
import { CancelOrderModal } from './CancelOrderModal';
import { canUserCancelOrder } from '../utils/orderUtils';

interface OrderSuccessPageProps {
  order: Order;
  language: Language;
  onContinueShopping: () => void;
  onViewAccountOrders: () => void;
  onTrackOrder?: (orderId: string) => void;
  onCancelOrder?: (orderId: string, reason?: string) => Promise<void> | void;
}

export const OrderSuccessPage: React.FC<OrderSuccessPageProps> = ({
  order,
  language,
  onContinueShopping,
  onViewAccountOrders,
  onTrackOrder,
  onCancelOrder
}) => {
  const [currentOrder, setCurrentOrder] = useState<Order>(order);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);

  const isCancelled = currentOrder.orderStatus === 'cancelled' || currentOrder.orderStatus === 'returned';
  const cancellable = canUserCancelOrder(currentOrder);

  const handleConfirmCancel = async (orderId: string, reason?: string) => {
    setIsCancelling(true);
    try {
      if (onCancelOrder) {
        await onCancelOrder(orderId, reason);
      }
      setCurrentOrder(prev => ({
        ...prev,
        orderStatus: 'cancelled'
      }));
      setIsCancelModalOpen(false);
    } catch (err) {
      console.error('Failed to cancel order:', err);
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#380208] text-white py-8 px-4 flex items-center justify-center animate-fadeIn">
      <div className="max-w-2xl w-full bg-[#240106] border border-[#6B0B1D] rounded-3xl p-6 sm:p-10 shadow-md space-y-6">
        
        {/* Status Header */}
        {isCancelled ? (
          <div className="text-center space-y-3">
            <div className="w-20 h-20 bg-red-500/20 border-2 border-red-500/40 text-red-400 rounded-3xl flex items-center justify-center mx-auto shadow-xs">
              <RotateCcw className="w-10 h-10" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              {language === 'bn' ? 'অর্ডারটি বাতিল করা হয়েছে' : 'Order Has Been Cancelled'}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-md mx-auto">
              {language === 'bn' 
                ? 'আপনার অনুরোধ অনুযায়ী এই অর্ডারটি সফলভাবে বাতিল করা হয়েছে। আপনি চাইলে যেকোনো সময় পুনরায় নতুন অর্ডার দিতে পারেন।' 
                : 'This order has been cancelled per your request. You are welcome to browse and place a new order anytime.'}
            </p>
          </div>
        ) : (
          <div className="text-center space-y-3">
            <div className="w-20 h-20 bg-emerald-500/20 border-2 border-emerald-500/40 text-emerald-400 rounded-3xl flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              {language === 'bn' ? 'আপনার অর্ডারটি সফলভাবে সম্পন্ন হয়েছে!' : 'Order Placed Successfully!'}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 max-w-md mx-auto">
              {language === 'bn' 
                ? 'ধন্যবাদ আমাদের সাথে কেনাকাটা করার জন্য। আমাদের প্রতিনিধি শীঘ্রই আপনার মোবাইল নম্বরে ফোন করে অর্ডারটি ভেরিফাই করবেন।' 
                : 'Thank you for shopping with us! Our representative will call your phone shortly to verify your delivery details.'}
            </p>
          </div>
        )}

        {/* Order ID & Basic Meta */}
        <div className="p-4 bg-[#1C0104] border border-[#520510] rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
          <div>
            <span className="text-neutral-400">{language === 'bn' ? 'অর্ডার নম্বর:' : 'Order ID:'}</span>
            <div className="font-mono text-base font-black text-amber-400 mt-0.5">#{currentOrder.id}</div>
          </div>
          <div>
            <span className="text-neutral-400">{language === 'bn' ? 'তারিখ:' : 'Date:'}</span>
            <div className="font-medium text-white mt-0.5">{currentOrder.date || new Date().toLocaleDateString()}</div>
          </div>
          <div>
            <span className="text-neutral-400">{language === 'bn' ? 'স্ট্যাটাস:' : 'Status:'}</span>
            <div className="mt-0.5">
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                isCancelled ? 'bg-red-500/20 text-red-300 border border-red-500/30' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              }`}>
                {isCancelled 
                  ? (language === 'bn' ? 'বাতিলকৃত' : 'Cancelled') 
                  : (language === 'bn' ? 'অর্ডার গৃহীত' : 'Order Placed')}
              </span>
            </div>
          </div>
        </div>

        {/* Cancellation Notice and Action Banner (Before Courier Handover) */}
        {!isCancelled && (
          cancellable ? (
            <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-start gap-2.5 text-rose-900">
                <Info className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-neutral-900">
                    {language === 'bn' ? 'ভুল বা পরিবর্তন? অর্ডার বাতিল করার সুবিধা' : 'Need to change or cancel this order?'}
                  </p>
                  <p className="text-[11px] text-neutral-600 mt-0.5">
                    {language === 'bn'
                      ? 'অর্ডারটি কুরিয়ার সার্ভিসে হস্তান্তরের পূর্ব পর্যন্ত আপনি সরাসরি এখান থেকেই বাতিল করতে পারবেন।'
                      : 'You can cancel this order anytime directly before it is handed over to the courier.'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsCancelModalOpen(true)}
                className="px-3.5 py-2 bg-white hover:bg-red-50 text-red-700 border border-red-200 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-2xs shrink-0 self-end sm:self-auto"
              >
                <XCircle className="w-4 h-4 text-red-600" />
                <span>{language === 'bn' ? 'অর্ডার বাতিল করুন' : 'Cancel Order'}</span>
              </button>
            </div>
          ) : (
            <div className="p-3 bg-neutral-100 border border-neutral-200 rounded-2xl flex items-center gap-2 text-xs text-neutral-600">
              <Truck className="w-4 h-4 text-neutral-500 shrink-0" />
              <span>
                {language === 'bn'
                  ? 'অর্ডারটি কুরিয়ার সার্ভিসে হস্তান্তর করা হয়েছে, তাই এটি আর সরাসরি বাতিল করা সম্ভব নয়।'
                  : 'Order has already been handed to courier and cannot be cancelled.'}
              </span>
            </div>
          )
        )}

        {/* Delivery & Customer Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-neutral-800">
              <MapPin className="w-4 h-4 text-rose-600" />
              <span>{language === 'bn' ? 'ডেলিভারি ঠিকানা' : 'Delivery Address'}</span>
            </div>
            <p className="font-bold text-neutral-900">{currentOrder.customerName}</p>
            <p className="text-neutral-600 font-mono">{currentOrder.phone}</p>
            <p className="text-neutral-700 text-[11px] leading-relaxed pt-1">{currentOrder.address}</p>
          </div>

          <div className="p-4 bg-neutral-50 rounded-2xl border border-neutral-200 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-neutral-800">
              <Truck className="w-4 h-4 text-rose-600" />
              <span>{language === 'bn' ? 'ডেলিভারি ও পেমেন্ট বিবরণ' : 'Payment Summary'}</span>
            </div>
            <div className="flex justify-between text-neutral-600">
              <span>{language === 'bn' ? 'সাবটোটাল:' : 'Subtotal:'}</span>
              <span className="font-mono text-neutral-900">{formatPrice(currentOrder.subtotal, language)}</span>
            </div>
            <div className="flex justify-between text-neutral-600">
              <span>{language === 'bn' ? 'ডেলিভারি চার্জ:' : 'Delivery Fee:'}</span>
              <span className="font-mono text-neutral-900">{formatPrice(currentOrder.deliveryFee, language)}</span>
            </div>
            <div className="flex justify-between text-rose-600 font-bold pt-1 border-t border-neutral-200">
              <span>{language === 'bn' ? 'সর্বমোট প্রদেয়:' : 'Total Payable:'}</span>
              <span className="font-mono font-black text-sm">{formatPrice(currentOrder.total, language)}</span>
            </div>
          </div>
        </div>

        {/* Ordered Items Preview */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-neutral-700 uppercase tracking-wider">
            {language === 'bn' ? 'অর্ডারকৃত পণ্যের তালিকা' : 'Items in this order'} ({currentOrder.items.length})
          </h4>
          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {currentOrder.items.map((item, i) => (
              <div key={i} className="flex items-center gap-3 p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-xs">
                <img
                  src={item.product.image}
                  alt={item.product.titleEn}
                  className="w-12 h-12 rounded-lg object-cover bg-white border border-neutral-200 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-neutral-900 truncate">
                    {language === 'bn' ? item.product.titleBn : item.product.titleEn}
                  </p>
                  <p className="text-[11px] text-neutral-500">
                    {item.selectedSize ? `Size: ${item.selectedSize} ` : ''}
                    {item.selectedColor ? `Color: ${item.selectedColor}` : ''}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="font-mono font-bold text-neutral-700">
                    {formatPrice(item.product.price, language)} × {item.quantity}
                  </p>
                  <p className="font-mono font-black text-rose-600">
                    {formatPrice(item.product.price * item.quantity, language)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {onTrackOrder && (
            <button
              onClick={() => onTrackOrder(currentOrder.id)}
              className="w-full py-3.5 px-4 rounded-2xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
            >
              <Truck className="w-4 h-4" />
              <span>{language === 'bn' ? 'লাইভ ট্র্যাক করুন' : 'Live Track Order'}</span>
            </button>
          )}

          <button
            onClick={onContinueShopping}
            className={`w-full py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition cursor-pointer ${!onTrackOrder ? 'sm:col-span-1' : ''}`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{language === 'bn' ? 'আরও কেনাকাটা' : 'Continue Shopping'}</span>
          </button>

          <button
            onClick={onViewAccountOrders}
            className={`w-full py-3.5 px-4 rounded-2xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 border border-neutral-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer ${!onTrackOrder ? 'sm:col-span-1' : ''}`}
          >
            <Package className="w-4 h-4" />
            <span>{language === 'bn' ? 'আমার অ্যাকাউন্ট' : 'My Account'}</span>
          </button>
        </div>

      </div>

      {/* Cancellation Modal */}
      <CancelOrderModal
        order={currentOrder}
        isOpen={isCancelModalOpen}
        onClose={() => setIsCancelModalOpen(false)}
        onConfirmCancel={handleConfirmCancel}
        language={language}
      />
    </div>
  );
};
