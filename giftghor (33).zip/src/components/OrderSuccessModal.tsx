import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Copy, 
  Check, 
  ShoppingBag, 
  Clock,
  User
} from 'lucide-react';
import { Order, Language } from '../types';
import { translations, formatPrice } from '../utils/translations';

interface OrderSuccessModalProps {
  order: Order | null;
  onClose: () => void;
  language: Language;
  onViewOrders?: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  onClose,
  language,
  onViewOrders,
}) => {
  const [copied, setCopied] = useState(false);

  if (!order) return null;

  const t = translations[language];

  const handleCopy = () => {
    navigator.clipboard.writeText(order.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div 
        className="relative bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 sm:p-8 text-center border border-neutral-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Animated Check icon */}
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
          <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12" />
        </div>

        <h2 className="text-lg sm:text-xl font-black text-neutral-900 leading-snug">
          {t.orderSuccessTitle}
        </h2>
        <p className="text-xs text-neutral-500 mt-1.5 leading-relaxed">
          {t.orderSuccessDesc}
        </p>

        {/* Order ID Box with Copy */}
        <div className="my-5 p-4 rounded-2xl bg-neutral-50 border border-neutral-200">
          <span className="text-xs text-neutral-500 font-semibold block mb-1">
            {t.orderId}
          </span>
          <div className="flex items-center justify-center gap-2">
            <span className="text-xl sm:text-2xl font-black font-mono tracking-wider text-rose-600">
              {order.id}
            </span>
            <button
              id="copy-order-id-btn"
              onClick={handleCopy}
              className="p-1.5 rounded-lg hover:bg-neutral-200 text-neutral-600 transition cursor-pointer"
              title={t.copyOrderId}
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          {copied && (
            <span className="text-[11px] text-emerald-600 font-bold block mt-1">
              {t.copied}
            </span>
          )}
        </div>

        {/* Brief Details */}
        <div className="space-y-1.5 text-xs text-neutral-600 text-left bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 mb-6">
          <div className="flex justify-between">
            <span>{t.customer}:</span>
            <span className="font-semibold text-neutral-800">{order.customerName}</span>
          </div>
          <div className="flex justify-between">
            <span>{t.phone}:</span>
            <span className="font-semibold text-neutral-800 font-mono">{order.phone}</span>
          </div>
          <div className="flex justify-between items-center">
            <span>{t.paymentMethod}:</span>
            <span className="font-bold text-rose-600 uppercase text-[11px]">
              {order.paymentMethod === 'card' 
                ? `${order.cardBrand === 'mastercard' ? 'Mastercard' : 'Visa'} (****${order.cardLast4 || '****'})`
                : order.paymentMethod}
            </span>
          </div>
          {order.trxId && (
            <div className="flex justify-between items-center">
              <span>TrxID:</span>
              <span className="font-mono font-bold text-neutral-800 text-[11px] bg-neutral-200/60 px-1.5 py-0.5 rounded">
                {order.trxId}
              </span>
            </div>
          )}
          <div className="flex justify-between items-center">
            <span>{language === 'bn' ? 'পেমেন্ট স্ট্যাটাস:' : 'Payment Status:'}</span>
            <span className={`font-bold text-[10px] px-2 py-0.5 rounded-full ${
              order.paymentStatus === 'paid' 
                ? 'bg-emerald-100 text-emerald-800' 
                : order.paymentStatus === 'verified'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-amber-100 text-amber-800'
            }`}>
              {order.paymentStatus === 'paid' 
                ? (language === 'bn' ? 'পরিশোধিত (Paid)' : 'Paid') 
                : order.paymentStatus === 'verified'
                ? (language === 'bn' ? 'ভেরিফাইড (Verified)' : 'Verified')
                : (language === 'bn' ? 'বাকি (Pending)' : 'Pending')}
            </span>
          </div>
          <div className="flex justify-between">
            <span>{t.totalAmount}:</span>
            <span className="font-bold text-neutral-900">{formatPrice(order.total, language)}</span>
          </div>
          <div className="flex items-center gap-1.5 pt-1 text-[11px] text-amber-700 font-medium">
            <Clock className="w-3.5 h-3.5" />
            <span>{'৩-৫ দিনের মধ্যে ডেলিভারি'}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5">
          {onViewOrders && (
            <button
              id="success-view-orders-btn"
              onClick={() => {
                onClose();
                onViewOrders();
              }}
              className="w-full py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm shadow-md shadow-rose-200 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <User className="w-4 h-4" />
              <span>{language === 'bn' ? 'আমার অর্ডার সমূহ দেখুন' : 'View My Orders'}</span>
            </button>
          )}

          <button
            id="success-continue-shopping-btn"
            onClick={onClose}
            className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2 cursor-pointer ${
              onViewOrders 
                ? 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700' 
                : 'bg-rose-600 hover:bg-rose-700 text-white font-bold py-3 text-sm'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{t.continueShopping}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
