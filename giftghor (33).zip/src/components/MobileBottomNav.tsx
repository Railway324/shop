import React from 'react';
import { Home, Grid, PackageCheck, User, ShoppingBag, Truck } from 'lucide-react';
import { Language } from '../types';
import { translations, toBengaliNumber } from '../utils/translations';

interface MobileBottomNavProps {
  activeView: string;
  onChangeView: (view: any) => void;
  cartCount?: number;
  onOpenCart?: () => void;
  onOpenTracking?: () => void;
  language: Language;
  isLoggedIn: boolean;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = React.memo(({
  activeView,
  onChangeView,
  cartCount = 0,
  onOpenCart,
  onOpenTracking,
  language,
  isLoggedIn,
}) => {
  const t = translations[language];

  return (
    <nav
      aria-label="Bottom Quick Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-neutral-200 px-1 sm:px-2 py-1.5 shadow-[0_-4px_12px_rgba(0,0,0,0.08)] pb-safe md:hidden transform-gpu select-none"
    >
      <div className="grid grid-cols-5 items-center">
        {/* 1. Home */}
        <button
          id="bottom-nav-home-btn"
          onClick={() => onChangeView('home')}
          className={`group flex flex-col items-center justify-center py-1 rounded-xl cursor-pointer transition-all duration-150 touch-manipulation active:scale-95 ${
            activeView === 'home'
              ? 'text-[#800020] font-bold'
              : 'text-neutral-600 hover:text-neutral-950'
          }`}
        >
          <div className={`p-1 rounded-full transition ${activeView === 'home' ? 'bg-[#800020]/10' : ''}`}>
            <Home className="w-5 h-5 group-hover:scale-110 transition-transform" />
          </div>
          <span className="text-[9px] sm:text-[10px] tracking-tight">
            {t.homeNav}
          </span>
        </button>

        {/* 2. Shop / All Products */}
        <button
          id="bottom-nav-shop-btn"
          onClick={() => onChangeView('products')}
          className={`group flex flex-col items-center justify-center py-1 rounded-xl cursor-pointer transition-all duration-150 touch-manipulation active:scale-95 ${
            activeView === 'products'
              ? 'text-[#800020] font-bold'
              : 'text-neutral-600 hover:text-neutral-950'
          }`}
        >
          <div className={`p-1 rounded-full transition ${activeView === 'products' ? 'bg-[#800020]/10' : ''}`}>
            <Grid className="w-5 h-5 group-hover:scale-110 transition-transform" />
          </div>
          <span className="text-[9px] sm:text-[10px] tracking-tight">
            {language === 'bn' ? 'সব পণ্য' : 'Shop'}
          </span>
        </button>

        {/* 3. Cart Option (with badge count) */}
        <button
          id="bottom-nav-cart-btn"
          onClick={onOpenCart}
          className="group relative flex flex-col items-center justify-center py-1 rounded-xl cursor-pointer text-neutral-700 hover:text-[#800020] transition-all duration-150 touch-manipulation active:scale-95"
        >
          <div className="relative p-1 rounded-full transition">
            <ShoppingBag className="w-5 h-5 text-[#800020] group-hover:scale-110 transition-transform" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-gradient-to-r from-rose-600 to-red-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                {language === 'bn' ? toBengaliNumber(cartCount) : cartCount}
              </span>
            )}
          </div>
          <span className="text-[9px] sm:text-[10px] tracking-tight">
            {language === 'bn' ? 'কার্ট' : 'Cart'}
          </span>
        </button>

        {/* 4. Tracking Option */}
        <button
          id="bottom-nav-track-btn"
          onClick={onOpenTracking}
          className="group flex flex-col items-center justify-center py-1 rounded-xl cursor-pointer text-neutral-700 hover:text-[#800020] transition-all duration-150 touch-manipulation active:scale-95"
        >
          <div className="p-1 rounded-full transition">
            <Truck className="w-5 h-5 text-[#800020] group-hover:scale-110 transition-transform" />
          </div>
          <span className="text-[9px] sm:text-[10px] tracking-tight">
            {language === 'bn' ? 'ট্র্যাকিং' : 'Track'}
          </span>
        </button>

        {/* 5. Account / Orders */}
        <button
          id="bottom-nav-account-btn"
          onClick={() => onChangeView('account')}
          className={`group flex flex-col items-center justify-center py-1 rounded-xl cursor-pointer transition-all duration-150 touch-manipulation active:scale-95 ${
            activeView === 'account'
              ? 'text-[#800020] font-bold'
              : 'text-neutral-600 hover:text-neutral-950'
          }`}
        >
          <div className={`p-1 rounded-full transition ${activeView === 'account' ? 'bg-[#800020]/10' : ''}`}>
            {isLoggedIn ? (
              <PackageCheck className="w-5 h-5 group-hover:scale-110 transition-transform" />
            ) : (
              <User className="w-5 h-5 group-hover:scale-110 transition-transform" />
            )}
          </div>
          <span className="text-[9px] sm:text-[10px] tracking-tight">
            {language === 'bn'
              ? (isLoggedIn ? 'প্রোফাইল' : 'একাউন্ট')
              : (isLoggedIn ? 'Account' : 'Sign In')}
          </span>
        </button>
      </div>
    </nav>
  );
});

