import React, { useMemo, useState } from 'react';
import { 
  Sparkles, 
  ShoppingBag, 
  Watch, 
  Zap, 
  Home, 
  Baby, 
  Flame, 
  ArrowRight, 
  ChevronRight, 
  Grid,
  ChevronDown,
  Shirt,
  Bike,
  Package,
  Gem,
  Scissors,
  Gift,
  Heart,
  Star,
  Palette,
  Tag,
  UtensilsCrossed
} from 'lucide-react';
import { Product, Language, CategoryId, WebsiteCustomizerSettings, Category } from '../types';
import { ProductCard } from './ProductCard';
import { toBengaliNumber } from '../utils/translations';
import { isSareeProduct } from '../utils/interleaveUtils';
import { normalizeCategoryId, isWatchProductTitle } from '../utils/categoryUtils';
import { getStoredDeletedProductIdsSet } from '../utils/storage';

const ICON_MAP: Record<string, any> = {
  Shirt,
  ShoppingBag,
  Watch,
  Zap,
  Home,
  Baby,
  Bike,
  Package,
  Sparkles,
  Flame,
  Gem,
  Scissors,
  Gift,
  UtensilsCrossed,
  Heart,
  Star,
  Palette,
  Tag
};

interface HomeCategorySectionsProps {
  products: Product[];
  categories?: Category[];
  language: Language;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  cartItemIds: Set<string>;
  onViewCategory: (categoryId: CategoryId) => void;
  customizerSettings?: WebsiteCustomizerSettings | null;
}

interface CategorySectionDef {
  id: CategoryId;
  nameBn: string;
  nameEn: string;
  subtitleBn: string;
  subtitleEn: string;
  icon: React.ComponentType<{ className?: string }>;
  badgeColor: string;
  filterFn: (p: Product) => boolean;
}

export const HomeCategorySections: React.FC<HomeCategorySectionsProps> = React.memo(({
  products,
  categories = [],
  language,
  onSelectProduct,
  onAddToCart,
  cartItemIds,
  onViewCategory,
  customizerSettings,
}) => {
  // Store expanded counts for each category if user chooses to view more inline
  const [expandedSections, setExpandedSections] = useState<Record<string, number>>({});

  // Filter active products only (strictly omitting any deleted products)
  const activeProducts = useMemo(() => {
    const deletedIds = getStoredDeletedProductIdsSet();
    return (products || []).filter(p => p && p.id && p.status !== 'inactive' && !deletedIds.has(String(p.id).trim()));
  }, [products]);

  // Structured category sections strictly matching Top Category Bar:
  const categorySections: CategorySectionDef[] = useMemo(() => {
    const baseSections: CategorySectionDef[] = [
      {
        id: 'winter',
        nameBn: 'উইন্টার কালেকশন (Winter)',
        nameEn: 'Winter Collection',
        subtitleBn: 'হুডি, সোয়েটশার্ট, জ্যাকেট ও উইন্টার কম্বো কালেকশন',
        subtitleEn: 'Exclusive winter hoodies, sweatshirts, jackets & winter combo deals',
        icon: Flame,
        badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'winter' || normalizeCategoryId(p.category) === 'winter'),
      },
      {
        id: 'mens-fashion',
        nameBn: 'মেনস ফ্যাশন (Men\'s Fashion)',
        nameEn: 'Men\'s Fashion',
        subtitleBn: 'পাঞ্জাবি, টি-শার্ট, লাক্সারি শার্ট, প্যান্ট ও মেনস এক্সেসরিজ',
        subtitleEn: 'Premium panjabi, t-shirts, luxury shirts, pants & stylish men\'s accessories',
        icon: Shirt,
        badgeColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'mens-fashion' || normalizeCategoryId(p.category) === 'mens-fashion'),
      },
      {
        id: 'watches',
        nameBn: 'ঘড়ি কালেকশন (Watches)',
        nameEn: 'Watches Collection',
        subtitleBn: 'অ্যানালগ, ডিজিটাল, লাক্সারি চেইন ও স্মার্টওয়াচ কালেকশন',
        subtitleEn: 'Premium analog, digital, luxury chain & smartwatch timepieces',
        icon: Watch,
        badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
        filterFn: (p) => p.category === 'watches' || normalizeCategoryId(p.category) === 'watches' || isWatchProductTitle(p.titleEn, p.titleBn),
      },
      {
        id: 'womens-fashion',
        nameBn: 'ওমেনস ফ্যাশন (Women\'s Fashion)',
        nameEn: 'Women\'s Fashion',
        subtitleBn: 'এক্সক্লুসিভ শাড়ি, সালোয়ার কামিজ, বোরকা, লেডিস ব্যাগ ও কসমেটিক্স',
        subtitleEn: 'Exclusive sarees, salwar-kameez, borka, ladies bags & cosmetics',
        icon: Sparkles,
        badgeColor: 'bg-rose-50 text-rose-700 border-rose-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'womens-fashion' || normalizeCategoryId(p.category) === 'womens-fashion'),
      },
      {
        id: 'jewelry',
        nameBn: "জুয়েলারি কালেকশন (Jewelry's)",
        nameEn: "Jewelry's",
        subtitleBn: 'নেকলেস সেট, কানের দুল, আংটি, ব্রেসলেট, নাকফুল ও চুড়ি কালেকশন',
        subtitleEn: 'Necklace sets, earrings, rings, bracelets, nose pins & bridal bangles',
        icon: Gem,
        badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'jewelry' || normalizeCategoryId(p.category) === 'jewelry'),
      },
      {
        id: 'home-lifestyle',
        nameBn: 'হোম ও লাইফস্টাইল (Home & Lifestyle)',
        nameEn: 'Home & Lifestyle',
        subtitleBn: 'বেডশিট, কিচেন সামগ্রী, হোম অ্যাপ্লায়েন্স, ব্যাকপ্যাক ও হোম ডেকোর',
        subtitleEn: 'Bed sheets, kitchen dining, home appliances, bags & modern lifestyle',
        icon: Home,
        badgeColor: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'home-lifestyle' || normalizeCategoryId(p.category) === 'home-lifestyle'),
      },
      {
        id: 'gadgets-electronics',
        nameBn: 'গ্যাজেটস ও ইলেকট্রনিক্স (Gadgets & Electronics)',
        nameEn: 'Gadgets & Electronics',
        subtitleBn: 'আধুনিক স্মার্ট ডিভাইস, ব্লুটুথ অডিও, চার্জার, ট্রিমার ও নিত্যপ্রয়োজনীয় গ্যাজেট',
        subtitleEn: 'Smart tech, wireless audio, fast chargers, trimmers & innovative electronics',
        icon: Zap,
        badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'gadgets-electronics' || normalizeCategoryId(p.category) === 'gadgets-electronics'),
      },
      {
        id: 'kids-zone',
        nameBn: 'কিডস জোন (Kids Zone)',
        nameEn: 'Kids Zone',
        subtitleBn: 'ছোট্ট সোনামণিদের আকর্ষণীয় পোশাক, বেবি বাউন্সার, খেলনা ও বেবি আইটেম',
        subtitleEn: 'Cute kidswear, baby comfort bouncers, robot cars & play toys',
        icon: Baby,
        badgeColor: 'bg-pink-50 text-pink-700 border-pink-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'kids-zone' || normalizeCategoryId(p.category) === 'kids-zone'),
      },
      {
        id: 'foods',
        nameBn: "ফুডস কালেকশন (Food's)",
        nameEn: "Food's",
        subtitleBn: 'খাঁটি মধু, ঘি, খেজুর, বাদাম, মসলা, চা ও পুষ্টিকর অর্গানিক ফুডস',
        subtitleEn: 'Pure natural honey, ghee, dates, nuts, organic spices, tea & wholesome foods',
        icon: UtensilsCrossed,
        badgeColor: 'bg-orange-50 text-orange-700 border-orange-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'foods' || normalizeCategoryId(p.category) === 'foods'),
      },
      {
        id: 'others',
        nameBn: 'অন্যান্য কালেকশন (Other\'s)',
        nameEn: 'Other Collections',
        subtitleBn: 'ধামাকা কম্বো প্যাক, গিফট আইটেম, কাপল সেট, স্টক ক্লিয়ারেন্স ও মিস্ট্রি বক্স',
        subtitleEn: 'Special combo packs, gift items, clearance deals & mystery boxes',
        icon: Gift,
        badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
        filterFn: (p) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === 'others' || normalizeCategoryId(p.category) === 'others'),
      },
    ];

    if (!categories || categories.length === 0) return baseSections;

    // Dynamically include any custom or additional categories
    const existingIds = new Set(baseSections.map(s => s.id));
    const extraSections: CategorySectionDef[] = categories
      .filter(c => c.id !== 'all' && !existingIds.has(c.id))
      .map(c => {
        const IconComponent = ICON_MAP[c.iconName] || Sparkles;
        return {
          id: c.id,
          nameBn: c.nameBn,
          nameEn: c.nameEn,
          subtitleBn: c.subtitleBn || `${c.nameBn} - এক্সক্লুসিভ কালেকশন ও স্পেশাল অফার`,
          subtitleEn: c.subtitleEn || `${c.nameEn} - Exclusive collections & special offers`,
          icon: IconComponent,
          badgeColor: 'bg-rose-50 text-rose-700 border-rose-200',
          filterFn: (p: Product) => !isWatchProductTitle(p.titleEn, p.titleBn) && (p.category === c.id || normalizeCategoryId(p.category) === c.id)
        };
      });

    return [...baseSections, ...extraSections];
  }, [categories]);

  // Compute products for each section using a single O(N) pass instead of 10x regex scans
  const sectionsData = useMemo(() => {
    const orderedSections = [...categorySections];
    const customOrder = customizerSettings?.homeCategoryOrder;
    if (Array.isArray(customOrder) && customOrder.length > 0) {
      orderedSections.sort((a, b) => {
        const indexA = customOrder.indexOf(a.id);
        const indexB = customOrder.indexOf(b.id);
        if (indexA !== -1 && indexB !== -1) return indexA - indexB;
        if (indexA !== -1) return -1;
        if (indexB !== -1) return 1;
        return 0;
      });
    }

    const buckets = new Map<string, Product[]>();
    for (const s of orderedSections) buckets.set(s.id, []);

    for (const p of activeProducts) {
      const catId = p.category === 'watches' || isWatchProductTitle(p.titleEn, p.titleBn)
        ? 'watches'
        : (buckets.has(p.category) ? p.category : normalizeCategoryId(p.category));
      const arr = buckets.get(catId);
      if (arr) arr.push(p);
    }

    const isSeedMode = activeProducts.length <= 120;
    const catCountMap = new Map<string, number>();
    for (const c of categories) {
      if (typeof c.itemCount === 'number' && c.itemCount > 0) {
        catCountMap.set(c.id, c.itemCount);
      }
    }

    return orderedSections.map(section => {
      const sectionProducts = (buckets.get(section.id) || []).sort((a, b) => {
        if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
        if (!a.isPinnedToTop && b.isPinnedToTop) return 1;

        const orderA = typeof a.displayOrder === 'number' ? a.displayOrder : 99999;
        const orderB = typeof b.displayOrder === 'number' ? b.displayOrder : 99999;
        if (orderA !== orderB) return orderA - orderB;

        return 0;
      });

      const limit = expandedSections[section.id] || 8;
      const visibleProducts = sectionProducts.slice(0, limit);
      const effectiveTotalCount = isSeedMode
        ? Math.max(sectionProducts.length, catCountMap.get(section.id) || sectionProducts.length)
        : sectionProducts.length;
      const hasMore = sectionProducts.length > limit;

      return {
        ...section,
        totalCount: effectiveTotalCount,
        visibleProducts,
        hasMore,
        currentLimit: limit
      };
    }).filter(s => s.visibleProducts.length > 0);
  }, [categorySections, activeProducts, expandedSections, customizerSettings?.homeCategoryOrder, categories]);

  const handleToggleExpand = (sectionId: CategoryId, totalCount: number) => {
    setExpandedSections(prev => {
      const current = prev[sectionId] || 8;
      if (current >= totalCount) {
        // Reset to initial 8
        const next = { ...prev };
        delete next[sectionId];
        return next;
      }
      // Expand by 8 more
      return { ...prev, [sectionId]: current + 8 };
    });
  };

  if (activeProducts.length === 0) {
    return (
      <div className="bg-[#240106] rounded-3xl p-8 sm:p-12 text-center border border-[#6B0B1D] shadow-md my-6 space-y-3">
        <div className="w-14 h-14 rounded-2xl bg-[#3D030C] text-amber-400 flex items-center justify-center mx-auto">
          <ShoppingBag className="w-7 h-7" />
        </div>
        <div className="max-w-md mx-auto space-y-1">
          <h3 className="text-base sm:text-lg font-bold text-white">
            {language === 'bn' ? 'বর্তমানে কোনো পণ্য পাওয়া যায়নি' : 'No products available'}
          </h3>
          <p className="text-xs text-neutral-400">
            {language === 'bn' 
              ? 'এডমিন প্যানেল থেকে পণ্য যুক্ত করুন।' 
              : 'Add products from Admin Panel to see them here.'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="my-6 sm:my-10 space-y-8 sm:space-y-12" id="home-category-sections">
      {sectionsData.map((section, sectionIdx) => {
        const IconComponent = section.icon;

        return (
          <section
            key={section.id}
            id={`section-${section.id}`}
            className="bg-[#220105] rounded-3xl p-4 sm:p-7 border border-[#5A0617] shadow-lg space-y-4 sm:space-y-6"
          >
            {/* Section Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 sm:pb-4 border-b border-[#520510]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center shrink-0 bg-[#3B030B] border border-amber-400/40 text-amber-400 shadow-sm">
                  <IconComponent className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-base sm:text-xl md:text-2xl font-black text-white tracking-tight">
                      {language === 'bn' ? section.nameBn : section.nameEn}
                    </h2>
                    <span className="text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40">
                      {language === 'bn' 
                        ? `${toBengaliNumber(section.totalCount)} টি পণ্য` 
                        : `${section.totalCount} Items`}
                    </span>
                  </div>
                  <p className="text-[11px] sm:text-xs text-neutral-300 font-medium mt-0.5">
                    {language === 'bn' ? section.subtitleBn : section.subtitleEn}
                  </p>
                </div>
              </div>

              {/* View All Text Link */}
              <button
                id={`view-all-link-${section.id}`}
                onClick={() => onViewCategory(section.id)}
                className="self-start sm:self-center text-xs font-bold text-amber-300 hover:text-amber-200 flex items-center gap-1.5 transition-colors cursor-pointer group"
              >
                <span>{language === 'bn' ? 'ক্যাটাগরি পেজ দেখুন' : 'View Full Catalog'}</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

            {/* Product Sample Grid (2 columns on mobile, 4 columns on desktop) */}
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-4">
              {section.visibleProducts.map((product, pIdx) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  language={language}
                  onSelectProduct={onSelectProduct}
                  onAddToCart={onAddToCart}
                  isInCart={cartItemIds.has(product.id)}
                  priority={sectionIdx === 0 && pIdx < 4}
                />
              ))}
            </div>

            {/* Prominent "আরো দেখুন" (View More) Big Action Button */}
            <div className="pt-2 sm:pt-4 flex flex-col sm:flex-row items-center justify-center gap-2.5">
              {/* Primary Big View More Button */}
              <button
                id={`view-more-btn-${section.id}`}
                onClick={() => onViewCategory(section.id)}
                className="w-full sm:w-auto min-w-[260px] sm:min-w-[320px] py-3 sm:py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black text-xs sm:text-sm shadow-md hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98] group"
              >
                <span>
                  {language === 'bn' 
                    ? `আরো দেখুন — ${section.nameBn} (${toBengaliNumber(section.totalCount)}+ টি)` 
                    : `View More — ${section.nameEn} (${section.totalCount}+)`}
                </span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Inline Expand More Button if there are more products in this category */}
              {section.hasMore && (
                <button
                  id={`inline-expand-btn-${section.id}`}
                  onClick={() => handleToggleExpand(section.id, section.totalCount)}
                  className="w-full sm:w-auto py-3 sm:py-3.5 px-5 rounded-2xl bg-[#3B030B] hover:bg-[#4D0510] text-amber-300 border border-[#6B0B1D] font-bold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer active:scale-[0.98]"
                  title="এই পেজেই আরো পণ্য দেখুন"
                >
                  <ChevronDown className="w-4 h-4" />
                  <span>
                    {language === 'bn' ? 'এই পেজেই আরো দেখুন' : 'Show 8 More Here'}
                  </span>
                </button>
              )}
            </div>
          </section>
        );
      })}
    </div>
  );
});
