import { Product, Category, Banner, Order } from '../types';
import defaultProductsJson from './homeSeedProducts.json';

export const initialCategories: Category[] = [
  {
    "id": "all",
    "nameBn": "সকল প্রোডাক্ট",
    "nameEn": "All Products",
    "iconName": "LayoutGrid",
    "itemCount": 3074
  },
  {
    "id": "winter",
    "nameBn": "উইন্টার (Winter)",
    "nameEn": "Winter",
    "iconName": "Flame",
    "itemCount": 330,
    "subtitleBn": "হুডি, সোয়েটশার্ট, জ্যাকেট ও উইন্টার কম্বো কালেকশন",
    "subtitleEn": "Hoodies, Sweatshirts, Jackets & Winter Combos",
    "badgeBn": "উইন্টার স্পেশাল",
    "badgeEn": "Winter Special",
    "accentColor": "blue"
  },
  {
    "id": "mens-fashion",
    "nameBn": "মেনস ফ্যাশন (Men's Fashion)",
    "nameEn": "Men's Fashion",
    "iconName": "Shirt",
    "itemCount": 649,
    "subtitleBn": "পাঞ্জাবি, টি-শার্ট, শার্ট, প্যান্ট ও মেনস এক্সেসরিজ",
    "subtitleEn": "Panjabi, T-Shirts, Shirts, Pants & Accessories",
    "badgeBn": "মেনস ট্রেন্ড",
    "badgeEn": "Men's Trend",
    "accentColor": "indigo"
  },
  {
    "id": "watches",
    "nameBn": "ঘড়ি (Watches)",
    "nameEn": "Watches",
    "iconName": "Watch",
    "itemCount": 275,
    "subtitleBn": "অ্যানালগ, ডিজিটাল, লাক্সারি ও স্মার্টওয়াচ কালেকশন",
    "subtitleEn": "Analog, Digital, Luxury & Smartwatch Collection",
    "badgeBn": "ঘড়ি স্পেশাল",
    "badgeEn": "Watches Special",
    "accentColor": "amber"
  },
  {
    "id": "womens-fashion",
    "nameBn": "ওমেনস ফ্যাশন (Women's Fashion)",
    "nameEn": "Women's Fashion",
    "iconName": "Sparkles",
    "itemCount": 289,
    "subtitleBn": "এক্সক্লুসিভ শাড়ি, সালোয়ার কামিজ, বোরকা, লেডিস ব্যাগ ও কসমেটিক্স",
    "subtitleEn": "Exclusive Sarees, Salwar-Kameez, Borka, Ladies Bags & Cosmetics",
    "badgeBn": "লেডিস স্পেশাল",
    "badgeEn": "Women's Special",
    "accentColor": "rose"
  },
  {
    "id": "jewelry",
    "nameBn": "জুয়েলারি (Jewelry's)",
    "nameEn": "Jewelry's",
    "iconName": "Gem",
    "itemCount": 160,
    "subtitleBn": "নেকলেস সেট, কানের দুল, আংটি, ব্রেসলেট, নাকফুল ও চুড়ি কালেকশন",
    "subtitleEn": "Necklace Sets, Earrings, Rings, Bracelets, Nose Pins & Bangles",
    "badgeBn": "জুয়েলারি স্পেশাল",
    "badgeEn": "Jewelry's Special",
    "accentColor": "amber"
  },
  {
    "id": "home-lifestyle",
    "nameBn": "হোম ও লাইফস্টাইল (Home & Lifestyle)",
    "nameEn": "Home & Lifestyle",
    "iconName": "Home",
    "itemCount": 533,
    "subtitleBn": "বেডশিট, কিচেন সামগ্রী, হোম অ্যাপ্লায়েন্স, ব্যাগ ও ডেকোর",
    "subtitleEn": "Bed Sheets, Kitchen & Dining, Home Appliances & Bags",
    "badgeBn": "হোম স্পেশাল",
    "badgeEn": "Home Special",
    "accentColor": "emerald"
  },
  {
    "id": "gadgets-electronics",
    "nameBn": "গ্যাজেটস ও ইলেকট্রনিক্স (Gadgets & Electronics)",
    "nameEn": "Gadgets & Electronics",
    "iconName": "Zap",
    "itemCount": 529,
    "subtitleBn": "স্মার্ট গ্যাজেট, ব্লুটুথ অডিও, চার্জার, ট্রিমার ও নিত্যপ্রয়োজনীয় ইলেকট্রনিক্স",
    "subtitleEn": "Smart Tech, Wireless Audio, Chargers, Trimmers & Electronics",
    "badgeBn": "স্মার্ট গ্যাজেট",
    "badgeEn": "Smart Tech",
    "accentColor": "amber"
  },
  {
    "id": "kids-zone",
    "nameBn": "কিডস জোন (Kids Zone)",
    "nameEn": "Kids Zone",
    "iconName": "Baby",
    "itemCount": 219,
    "subtitleBn": "ছোট্ট সোনামণিদের ড্রেস, কিডস উইন্টার হুডি, খেলনা ও বেবি গিয়ার",
    "subtitleEn": "Kids Clothing, Kids Winter Wear, Learning Toys & Baby Gear",
    "badgeBn": "কিডস স্পেশাল",
    "badgeEn": "Kids Special",
    "accentColor": "pink"
  },
  {
    "id": "foods",
    "nameBn": "ফুডস (Food's)",
    "nameEn": "Food's",
    "iconName": "UtensilsCrossed",
    "itemCount": 15,
    "subtitleBn": "খাঁটি মধু, চিয়া সিড, ওটস, বাদাম, মসলা ও পুষ্টিকর অর্গানিক ফুডস",
    "subtitleEn": "Pure Honey, Chia Seeds, Oats, Nuts, Spices & Organic Superfoods",
    "badgeBn": "ফুডস স্পেশাল",
    "badgeEn": "Food's Special",
    "accentColor": "amber"
  },
  {
    "id": "others",
    "nameBn": "অন্যান্য (Other's)",
    "nameEn": "Other's",
    "iconName": "Gift",
    "itemCount": 75,
    "subtitleBn": "ধামাকা কম্বো প্যাক, গিফট আইটেম, কাস্টমাইজ গিফট, কাপল সেট ও মিস্ট্রি বক্স",
    "subtitleEn": "Combo Packs, Gift Items, Customized Gifts, Couple Sets & Mystery Box",
    "badgeBn": "ধামাকা অফার",
    "badgeEn": "Special Deals",
    "accentColor": "purple"
  }
];

export const initialBanners: Banner[] = [
  {
    "id": "b-happyshopping-official",
    "titleBn": "উইন্টার ও প্রিমিয়াম ফ্যাশন কালেকশন",
    "titleEn": "Winter & Premium Fashion Collection",
    "subtitleBn": "সেরা মানের পণ্য • দ্রুত হোম ডেলিভারি ও ১০০% ক্যাশ অন ডেলিভারি সুবিধা",
    "subtitleEn": "Authentic Quality • Express Home Delivery & 100% Cash on Delivery",
    "badgeBn": "অফিশিয়াল স্টোর",
    "badgeEn": "Official Store",
    "buttonTextBn": "কালেকশন দেখুন",
    "buttonTextEn": "Explore Collection",
    "bgGradient": "from-[#5B0616] via-[#800020] to-neutral-950",
    "accentColor": "bg-[#800020] text-amber-300 border border-amber-400/40",
    "imageUrl": "https://dropshipping.com.bd/public/storage/images/products/img_6ac488c494a11_0_1791264964.jpg",
    "linkCategory": "winter"
  }
];

// Initial products catalog (synced with products.json for published builds)
export const initialProducts: Product[] = Array.isArray(defaultProductsJson) ? (defaultProductsJson as Product[]) : [];

// Empty initial orders
export const initialOrders: Order[] = [];

export const BD_DIVISIONS = [
  { id: 'dhaka', nameBn: 'ঢাকা (Dhaka)', nameEn: 'Dhaka', deliveryFee: 65 },
  { id: 'chittagong', nameBn: 'চট্টগ্রাম (Chittagong)', nameEn: 'Chittagong', deliveryFee: 120 },
  { id: 'rajshahi', nameBn: 'রাজশাহী (Rajshahi)', nameEn: 'Rajshahi', deliveryFee: 120 },
  { id: 'khulna', nameBn: 'খুলনা (Khulna)', nameEn: 'Khulna', deliveryFee: 120 },
  { id: 'sylhet', nameBn: 'সিলেট (Sylhet)', nameEn: 'Sylhet', deliveryFee: 120 },
  { id: 'barisal', nameBn: 'বরিশাল (Barisal)', nameEn: 'Barisal', deliveryFee: 120 },
  { id: 'rangpur', nameBn: 'রংপুর (Rangpur)', nameEn: 'Rangpur', deliveryFee: 120 },
  { id: 'mymensingh', nameBn: 'ময়মনসিংহ (Mymensingh)', nameEn: 'Mymensingh', deliveryFee: 120 },
];

export const bangladeshDivisions = BD_DIVISIONS;

export const VALID_COUPONS: Record<string, number> = {
  'EID50': 50,
  'SHOPPINGMALL': 100,
  'WELCOME10': 150,
};
