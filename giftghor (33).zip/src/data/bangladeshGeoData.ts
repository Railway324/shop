export interface GeoThana {
  nameEn: string;
  nameBn: string;
}

export interface GeoDistrict {
  id: string;
  nameEn: string;
  nameBn: string;
  divisionId: string;
  thanas: GeoThana[];
}

export interface GeoDivision {
  id: string;
  nameEn: string;
  nameBn: string;
  deliveryFee: number;
}

export const BD_DIVISIONS_LIST: GeoDivision[] = [
  { id: 'dhaka', nameEn: 'Dhaka', nameBn: 'ঢাকা (Dhaka)', deliveryFee: 65 },
  { id: 'chittagong', nameEn: 'Chattogram', nameBn: 'চট্টগ্রাম (Chattogram)', deliveryFee: 120 },
  { id: 'rajshahi', nameEn: 'Rajshahi', nameBn: 'রাজশাহী (Rajshahi)', deliveryFee: 120 },
  { id: 'khulna', nameEn: 'Khulna', nameBn: 'খুলনা (Khulna)', deliveryFee: 120 },
  { id: 'barisal', nameEn: 'Barishal', nameBn: 'বরিশাল (Barishal)', deliveryFee: 120 },
  { id: 'sylhet', nameEn: 'Sylhet', nameBn: 'সিলেট (Sylhet)', deliveryFee: 120 },
  { id: 'rangpur', nameEn: 'Rangpur', nameBn: 'রংপুর (Rangpur)', deliveryFee: 120 },
  { id: 'mymensingh', nameEn: 'Mymensingh', nameBn: 'ময়মনসিংহ (Mymensingh)', deliveryFee: 120 },
];

export const BD_64_DISTRICTS: GeoDistrict[] = [
  // ================= 1. DHAKA DIVISION (13 Districts) =================
  {
    id: 'dhaka',
    nameEn: 'Dhaka',
    nameBn: 'ঢাকা',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Dhanmondi', nameBn: 'ধানমন্ডি' },
      { nameEn: 'Gulshan', nameBn: 'গুলশান' },
      { nameEn: 'Banani', nameBn: 'বনানী' },
      { nameEn: 'Mirpur', nameBn: 'মিরপুর' },
      { nameEn: 'Uttara', nameBn: 'উত্তরা' },
      { nameEn: 'Mohammadpur', nameBn: 'মোহাম্মদপুর' },
      { nameEn: 'Motijheel', nameBn: 'মতিঝিল' },
      { nameEn: 'Badda', nameBn: 'বাড্ডা' },
      { nameEn: 'Rampura', nameBn: 'রামপুরা' },
      { nameEn: 'Khilgaon', nameBn: 'খিলগাঁও' },
      { nameEn: 'Tejgaon', nameBn: 'তেজগাঁও' },
      { nameEn: 'Paltan', nameBn: 'পল্টন' },
      { nameEn: 'Chawkbazar', nameBn: 'চকবাজার' },
      { nameEn: 'Kotwali', nameBn: 'কোতোয়ালী' },
      { nameEn: 'Lalbagh', nameBn: 'লালবাগ' },
      { nameEn: 'Sutrapur', nameBn: 'সূত্রাপুর' },
      { nameEn: 'Jatrabari', nameBn: 'যাত্রাবাড়ী' },
      { nameEn: 'Kadamtali', nameBn: 'কদমতলী' },
      { nameEn: 'Shyampur', nameBn: 'শ্যামপুর' },
      { nameEn: 'Demra', nameBn: 'ডেমরা' },
      { nameEn: 'Savar', nameBn: 'সাভার' },
      { nameEn: 'Dhamrai', nameBn: 'ধামরাই' },
      { nameEn: 'Keraniganj', nameBn: 'কেরানীগঞ্জ' },
      { nameEn: 'Nawabganj', nameBn: 'নবাবগঞ্জ' },
      { nameEn: 'Dohar', nameBn: 'দোহার' },
    ]
  },
  {
    id: 'gazipur',
    nameEn: 'Gazipur',
    nameBn: 'গাজীপুর',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Gazipur Sadar', nameBn: 'গাজীপুর সদর' },
      { nameEn: 'Tongi', nameBn: 'টঙ্গী' },
      { nameEn: 'Kaliakair', nameBn: 'কালিয়াকৈর' },
      { nameEn: 'Sreepur', nameBn: 'শ্রীপুর' },
      { nameEn: 'Kapasia', nameBn: 'কাপাসিয়া' },
      { nameEn: 'Kaliganj', nameBn: 'কালীগঞ্জ' },
    ]
  },
  {
    id: 'narayanganj',
    nameEn: 'Narayanganj',
    nameBn: 'নারায়ণগঞ্জ',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Narayanganj Sadar', nameBn: 'নারায়ণগঞ্জ সদর' },
      { nameEn: 'Fatullah', nameBn: 'ফতুল্লা' },
      { nameEn: 'Siddhirganj', nameBn: 'সিদ্ধিরগঞ্জ' },
      { nameEn: 'Bandar', nameBn: 'বন্দর' },
      { nameEn: 'Rupganj', nameBn: 'রূপগঞ্জ' },
      { nameEn: 'Sonargaon', nameBn: 'সোনারগাঁও' },
      { nameEn: 'Araihazar', nameBn: 'আড়াইহাজার' },
    ]
  },
  {
    id: 'tangail',
    nameEn: 'Tangail',
    nameBn: 'টাঙ্গাইল',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Tangail Sadar', nameBn: 'টাঙ্গাইল সদর' },
      { nameEn: 'Mirzapur', nameBn: 'মির্জাপুর' },
      { nameEn: 'Kalihati', nameBn: 'কালিহাতী' },
      { nameEn: 'Ghatail', nameBn: 'ঘাটাইল' },
      { nameEn: 'Sakhipur', nameBn: 'সখিপুর' },
      { nameEn: 'Nagarpur', nameBn: 'নাগরপুর' },
      { nameEn: 'Madhupur', nameBn: 'মধুপুর' },
      { nameEn: 'Delduar', nameBn: 'দেলদুয়ার' },
      { nameEn: 'Gopalpur', nameBn: 'গোপালপুর' },
      { nameEn: 'Bhuapur', nameBn: 'ভূঞাপুর' },
      { nameEn: 'Basail', nameBn: 'বাসাইল' },
      { nameEn: 'Dhanbari', nameBn: 'ধনবাড়ী' },
    ]
  },
  {
    id: 'kishoreganj',
    nameEn: 'Kishoreganj',
    nameBn: 'কিশোরগঞ্জ',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Kishoreganj Sadar', nameBn: 'কিশোরগঞ্জ সদর' },
      { nameEn: 'Bhairab', nameBn: 'ভৈরব' },
      { nameEn: 'Bajitpur', nameBn: 'বাজিতপুর' },
      { nameEn: 'Kuliarchar', nameBn: 'কুলিয়ারচর' },
      { nameEn: 'Karimganj', nameBn: 'করিমগঞ্জ' },
      { nameEn: 'Hossainpur', nameBn: 'হোসেনপুর' },
      { nameEn: 'Tarail', nameBn: 'তাড়াইল' },
      { nameEn: 'Pakundia', nameBn: 'পাকুন্দিয়া' },
      { nameEn: 'Katiadi', nameBn: 'কটিয়াদী' },
      { nameEn: 'Nikli', nameBn: 'নিকলী' },
      { nameEn: 'Austagram', nameBn: 'অষ্টগ্রাম' },
      { nameEn: 'Itna', nameBn: 'ইটনা' },
      { nameEn: 'Mithamain', nameBn: 'মিঠামইন' },
    ]
  },
  {
    id: 'manikganj',
    nameEn: 'Manikganj',
    nameBn: 'মানিকগঞ্জ',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Manikganj Sadar', nameBn: 'মানিকগঞ্জ সদর' },
      { nameEn: 'Singair', nameBn: 'সিংগাইর' },
      { nameEn: 'Shibalaya', nameBn: 'শিবালয়' },
      { nameEn: 'Saturia', nameBn: 'সাটুরিয়া' },
      { nameEn: 'Ghior', nameBn: 'ঘিওর' },
      { nameEn: 'Daulatpur', nameBn: 'দৌলতপুর' },
      { nameEn: 'Harirampur', nameBn: 'হরিরামপুর' },
    ]
  },
  {
    id: 'munshiganj',
    nameEn: 'Munshiganj',
    nameBn: 'মুন্সীগঞ্জ',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Munshiganj Sadar', nameBn: 'মুন্সীগঞ্জ সদর' },
      { nameEn: 'Sreenagar', nameBn: 'শ্রীনগর' },
      { nameEn: 'Sirajdikhan', nameBn: 'সিরাজদিখান' },
      { nameEn: 'Lohajang', nameBn: 'লৌহজং' },
      { nameEn: 'Gazaria', nameBn: 'গজারিয়া' },
      { nameEn: 'Tongibari', nameBn: 'টংগিবাড়ী' },
    ]
  },
  {
    id: 'narsingdi',
    nameEn: 'Narsingdi',
    nameBn: 'নরসিংদী',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Narsingdi Sadar', nameBn: 'নরসিংদী সদর' },
      { nameEn: 'Palash', nameBn: 'পলাশ' },
      { nameEn: 'Raipura', nameBn: 'রায়পুরা' },
      { nameEn: 'Shibpur', nameBn: 'শিবপুর' },
      { nameEn: 'Belabo', nameBn: 'বেলাব' },
      { nameEn: 'Monohardi', nameBn: 'মনোহরদী' },
    ]
  },
  {
    id: 'faridpur',
    nameEn: 'Faridpur',
    nameBn: 'ফরিদপুর',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Faridpur Sadar', nameBn: 'ফরিদপুর সদর' },
      { nameEn: 'Madhukhali', nameBn: 'মধুখালী' },
      { nameEn: 'Boalmari', nameBn: 'বোয়ালমারী' },
      { nameEn: 'Alfadanga', nameBn: 'আলফাডাঙ্গা' },
      { nameEn: 'Nagarkanda', nameBn: 'নগরকান্দা' },
      { nameEn: 'Saltha', nameBn: 'সালথা' },
      { nameEn: 'Charbhadrasan', nameBn: 'চরভদ্রাসন' },
      { nameEn: 'Sadarpur', nameBn: 'সদরপুর' },
      { nameEn: 'Bhanga', nameBn: 'ভাঙ্গা' },
    ]
  },
  {
    id: 'gopalganj',
    nameEn: 'Gopalganj',
    nameBn: 'গোপালগঞ্জ',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Gopalganj Sadar', nameBn: 'গোপালগঞ্জ সদর' },
      { nameEn: 'Kashiani', nameBn: 'কাশিয়ানী' },
      { nameEn: 'Kotalipara', nameBn: 'কোটালীপাড়া' },
      { nameEn: 'Muksudpur', nameBn: 'মুকসুদপুর' },
      { nameEn: 'Tungipara', nameBn: 'টুঙ্গিপাড়া' },
    ]
  },
  {
    id: 'madaripur',
    nameEn: 'Madaripur',
    nameBn: 'মাদারীপুর',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Madaripur Sadar', nameBn: 'মাদারীপুর সদর' },
      { nameEn: 'Shivchar', nameBn: 'শিবচর' },
      { nameEn: 'Kalkini', nameBn: 'কালকিনি' },
      { nameEn: 'Rajoir', nameBn: 'রাজৈর' },
      { nameEn: 'Dasar', nameBn: 'ডাসার' },
    ]
  },
  {
    id: 'rajbari',
    nameEn: 'Rajbari',
    nameBn: 'রাজবাড়ী',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Rajbari Sadar', nameBn: 'রাজবাড়ী সদর' },
      { nameEn: 'Goalanda', nameBn: 'গোয়ালন্দ' },
      { nameEn: 'Pangsha', nameBn: 'পাংশা' },
      { nameEn: 'Baliakandi', nameBn: 'বালিয়াকান্দি' },
      { nameEn: 'Kalukhali', nameBn: 'কালুখালী' },
    ]
  },
  {
    id: 'shariatpur',
    nameEn: 'Shariatpur',
    nameBn: 'শরীয়তপুর',
    divisionId: 'dhaka',
    thanas: [
      { nameEn: 'Shariatpur Sadar', nameBn: 'শরীয়তপুর সদর' },
      { nameEn: 'Jajira', nameBn: 'জাজিরা' },
      { nameEn: 'Naria', nameBn: 'নড়িয়া' },
      { nameEn: 'Bhedarganj', nameBn: 'ভেদরগঞ্জ' },
      { nameEn: 'Damudya', nameBn: 'ডামুড্যা' },
      { nameEn: 'Gosairhat', nameBn: 'গোসাইরহাট' },
    ]
  },

  // ================= 2. CHATTOGRAM DIVISION (11 Districts) =================
  {
    id: 'chattogram',
    nameEn: 'Chattogram',
    nameBn: 'চট্টগ্রাম',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Kotwali', nameBn: 'কোতোয়ালী' },
      { nameEn: 'Panchlaish', nameBn: 'পাঁচলাইশ' },
      { nameEn: 'Double Mooring', nameBn: 'ডবলমুরিং' },
      { nameEn: 'Khulshi', nameBn: 'খুলশী' },
      { nameEn: 'Chandgaon', nameBn: 'চান্দগাঁও' },
      { nameEn: 'Bakalia', nameBn: 'বাকলিয়া' },
      { nameEn: 'Halishahar', nameBn: 'হালিশহর' },
      { nameEn: 'Pahartali', nameBn: 'পাহাড়তলী' },
      { nameEn: 'Bandar', nameBn: 'বন্দর' },
      { nameEn: 'Patenga', nameBn: 'পতেঙ্গা' },
      { nameEn: 'Hathazari', nameBn: 'হাটহাজারী' },
      { nameEn: 'Sitakunda', nameBn: 'সীতাকুণ্ড' },
      { nameEn: 'Mirsarai', nameBn: 'মীরসরাই' },
      { nameEn: 'Patiya', nameBn: 'পটিয়া' },
      { nameEn: 'Raozan', nameBn: 'রাউজান' },
      { nameEn: 'Fatikchhari', nameBn: 'ফটিকছড়ি' },
      { nameEn: 'Boalkhali', nameBn: 'বোয়ালখালী' },
      { nameEn: 'Anwara', nameBn: 'আনোয়ারা' },
      { nameEn: 'Chandanaish', nameBn: 'চন্দনাইশ' },
      { nameEn: 'Satkania', nameBn: 'সাতকানিয়া' },
      { nameEn: 'Lohagara', nameBn: 'লোহাগাড়া' },
      { nameEn: 'Banshkhali', nameBn: 'বাঁশখালী' },
      { nameEn: 'Sandwip', nameBn: 'সন্দ্বীপ' },
      { nameEn: 'Karnafuli', nameBn: 'কর্ণফুলী' },
    ]
  },
  {
    id: 'coxs-bazar',
    nameEn: "Cox's Bazar",
    nameBn: 'কক্সবাজার',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: "Cox's Bazar Sadar", nameBn: 'কক্সবাজার সদর' },
      { nameEn: 'Chakaria', nameBn: 'চকোরিয়া' },
      { nameEn: 'Pekua', nameBn: 'পেকুয়া' },
      { nameEn: 'Maheshkhali', nameBn: 'মহেশখালী' },
      { nameEn: 'Kutubdia', nameBn: 'কুতুবদিয়া' },
      { nameEn: 'Ramu', nameBn: 'রামু' },
      { nameEn: 'Ukhiya', nameBn: 'উখিয়া' },
      { nameEn: 'Teknaf', nameBn: 'টেকনাফ' },
      { nameEn: 'Eidgaon', nameBn: 'ঈদগাঁও' },
    ]
  },
  {
    id: 'cumilla',
    nameEn: 'Cumilla',
    nameBn: 'কুমিল্লা',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Adarsha Sadar', nameBn: 'আদর্শ সদর' },
      { nameEn: 'Sadar Dakshin', nameBn: 'সদর দক্ষিণ' },
      { nameEn: 'Barura', nameBn: 'বরুড়া' },
      { nameEn: 'Chandina', nameBn: 'চান্দিনা' },
      { nameEn: 'Chauddagram', nameBn: 'চৌদ্দগ্রাম' },
      { nameEn: 'Daudkandi', nameBn: 'দাউদকান্দি' },
      { nameEn: 'Debidwar', nameBn: 'দেবিদ্বার' },
      { nameEn: 'Homna', nameBn: 'হোমনা' },
      { nameEn: 'Laksam', nameBn: 'লাকসাম' },
      { nameEn: 'Muradnagar', nameBn: 'মুরাদনগর' },
      { nameEn: 'Nangalkot', nameBn: 'নাঙ্গলকোট' },
      { nameEn: 'Meghna', nameBn: 'মেঘনা' },
      { nameEn: 'Titas', nameBn: 'তিতাস' },
      { nameEn: 'Monohargonj', nameBn: 'মনোহরগঞ্জ' },
      { nameEn: 'Burichang', nameBn: 'বুড়িচং' },
      { nameEn: 'Brahmanpara', nameBn: 'ব্রাহ্মণপাড়া' },
      { nameEn: 'Lalmai', nameBn: 'লালমাই' },
    ]
  },
  {
    id: 'feni',
    nameEn: 'Feni',
    nameBn: 'ফেনী',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Feni Sadar', nameBn: 'ফেনী সদর' },
      { nameEn: 'Daganbhuiyan', nameBn: 'দাগনভূঞা' },
      { nameEn: 'Sonagazi', nameBn: 'সোনাগাজী' },
      { nameEn: 'Chhagalnaiya', nameBn: 'ছাগলনাইয়া' },
      { nameEn: 'Parshuram', nameBn: 'পরশুরাম' },
      { nameEn: 'Fulgazi', nameBn: 'ফুলগাজী' },
    ]
  },
  {
    id: 'brahmanbaria',
    nameEn: 'Brahmanbaria',
    nameBn: 'ব্রাহ্মণবাড়িয়া',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Brahmanbaria Sadar', nameBn: 'ব্রাহ্মণবাড়িয়া সদর' },
      { nameEn: 'Kasba', nameBn: 'কসবা' },
      { nameEn: 'Nabinagar', nameBn: 'নবীনগর' },
      { nameEn: 'Nasirnagar', nameBn: 'নাসিরনগর' },
      { nameEn: 'Bancharampur', nameBn: 'বাঞ্ছারামপুর' },
      { nameEn: 'Sarail', nameBn: 'সরাইল' },
      { nameEn: 'Ashuganj', nameBn: 'আশুগঞ্জ' },
      { nameEn: 'Akhaura', nameBn: 'আখাউড়া' },
      { nameEn: 'Bijoynagar', nameBn: 'বিজয়নগর' },
    ]
  },
  {
    id: 'noakhali',
    nameEn: 'Noakhali',
    nameBn: 'নোয়াখালী',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Noakhali Sadar', nameBn: 'নোয়াখালী সদর' },
      { nameEn: 'Begumganj', nameBn: 'বেগমগঞ্জ' },
      { nameEn: 'Chatkhil', nameBn: 'চাটখিল' },
      { nameEn: 'Companiganj', nameBn: 'কোম্পানীগঞ্জ' },
      { nameEn: 'Hatiya', nameBn: 'হাতিয়া' },
      { nameEn: 'Senbagh', nameBn: 'সেনবাগ' },
      { nameEn: 'Subarnachar', nameBn: 'সুবর্ণচর' },
      { nameEn: 'Sonaimuri', nameBn: 'সোনাইমুড়ী' },
      { nameEn: 'Kabirhat', nameBn: 'কবিরহাট' },
    ]
  },
  {
    id: 'lakshmipur',
    nameEn: 'Lakshmipur',
    nameBn: 'লক্ষ্মীপুর',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Lakshmipur Sadar', nameBn: 'লক্ষ্মীপুর সদর' },
      { nameEn: 'Raipur', nameBn: 'রায়পুর' },
      { nameEn: 'Ramganj', nameBn: 'রামগঞ্জ' },
      { nameEn: 'Ramgati', nameBn: 'রামগতি' },
      { nameEn: 'Kamalnagar', nameBn: 'কমলনগর' },
    ]
  },
  {
    id: 'chandpur',
    nameEn: 'Chandpur',
    nameBn: 'চাঁদপুর',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Chandpur Sadar', nameBn: 'চাঁদপুর সদর' },
      { nameEn: 'Faridganj', nameBn: 'ফরিদগঞ্জ' },
      { nameEn: 'Hajiganj', nameBn: 'হাজীগঞ্জ' },
      { nameEn: 'Matlab North', nameBn: 'মতলব উত্তর' },
      { nameEn: 'Matlab South', nameBn: 'মতলব দক্ষিণ' },
      { nameEn: 'Shahrasti', nameBn: 'শাহরাস্তি' },
      { nameEn: 'Kachua', nameBn: 'কচুয়া' },
      { nameEn: 'Haimchar', nameBn: 'হাইমচর' },
    ]
  },
  {
    id: 'rangamati',
    nameEn: 'Rangamati',
    nameBn: 'রাঙ্গামাটি',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Rangamati Sadar', nameBn: 'রাঙ্গামাটি সদর' },
      { nameEn: 'Kaptai', nameBn: 'কাপ্তাই' },
      { nameEn: 'Kawkhali', nameBn: 'কাউখালী' },
      { nameEn: 'Baghaichhari', nameBn: 'বাঘাইছড়ি' },
      { nameEn: 'Barkal', nameBn: 'বরকল' },
      { nameEn: 'Langadu', nameBn: 'লংগদু' },
      { nameEn: 'Rajasthali', nameBn: 'রাজস্থলী' },
      { nameEn: 'Belaichhari', nameBn: 'বিলাইছড়ি' },
      { nameEn: 'Juraichhari', nameBn: 'জুরাছড়ি' },
      { nameEn: 'Naniarchar', nameBn: 'নানিয়ারচর' },
    ]
  },
  {
    id: 'bandarban',
    nameEn: 'Bandarban',
    nameBn: 'বান্দরবান',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Bandarban Sadar', nameBn: 'বান্দরবান সদর' },
      { nameEn: 'Rowangchhari', nameBn: 'রোয়াংছড়ি' },
      { nameEn: 'Ruma', nameBn: 'রুমা' },
      { nameEn: 'Thanchi', nameBn: 'থানচি' },
      { nameEn: 'Lama', nameBn: 'লামা' },
      { nameEn: 'Ali Kadam', nameBn: 'আলীকদম' },
      { nameEn: 'Naikhongchhari', nameBn: 'নাইক্ষ্যংছড়ি' },
    ]
  },
  {
    id: 'khagrachhari',
    nameEn: 'Khagrachhari',
    nameBn: 'খাগড়াছড়ি',
    divisionId: 'chittagong',
    thanas: [
      { nameEn: 'Khagrachhari Sadar', nameBn: 'খাগড়াছড়ি সদর' },
      { nameEn: 'Dighinala', nameBn: 'দীঘিনালা' },
      { nameEn: 'Panchhari', nameBn: 'পানছড়ি' },
      { nameEn: 'Matiranga', nameBn: 'মাটিরাঙ্গা' },
      { nameEn: 'Mohalchhari', nameBn: 'মহালছড়ি' },
      { nameEn: 'Manikchhari', nameBn: 'মানিকছড়ি' },
      { nameEn: 'Ramgarh', nameBn: 'রামগড়' },
      { nameEn: 'Lakshmichhari', nameBn: 'লক্ষ্মীছড়ি' },
      { nameEn: 'Guimara', nameBn: 'গুইমারা' },
    ]
  },

  // ================= 3. RAJSHAHI DIVISION (8 Districts) =================
  {
    id: 'rajshahi',
    nameEn: 'Rajshahi',
    nameBn: 'রাজশাহী',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Boalia', nameBn: 'বোয়ালিয়া' },
      { nameEn: 'Rajpara', nameBn: 'রাজপাড়া' },
      { nameEn: 'Motihar', nameBn: 'মতিহার' },
      { nameEn: 'Shah Makhdum', nameBn: 'শাহ মখদুম' },
      { nameEn: 'Paba', nameBn: 'পবা' },
      { nameEn: 'Godagari', nameBn: 'গোদাগাড়ী' },
      { nameEn: 'Tanor', nameBn: 'তানোর' },
      { nameEn: 'Bagmara', nameBn: 'বাগমারা' },
      { nameEn: 'Durgapur', nameBn: 'দুর্গাপুর' },
      { nameEn: 'Puthia', nameBn: 'পুঠিয়া' },
      { nameEn: 'Charghat', nameBn: 'চারঘাট' },
      { nameEn: 'Bagha', nameBn: 'বাঘা' },
      { nameEn: 'Mohanpur', nameBn: 'মোহনপুর' },
    ]
  },
  {
    id: 'bogura',
    nameEn: 'Bogura',
    nameBn: 'বগুড়া',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Bogura Sadar', nameBn: 'বগুড়া সদর' },
      { nameEn: 'Shibganj', nameBn: 'শিবগঞ্জ' },
      { nameEn: 'Sherpur', nameBn: 'শেরপুর' },
      { nameEn: 'Shajahanpur', nameBn: 'শাজাহানপুর' },
      { nameEn: 'Nandigram', nameBn: 'নন্দীগ্রাম' },
      { nameEn: 'Dhunat', nameBn: 'ধুনট' },
      { nameEn: 'Gabtali', nameBn: 'গাবতলী' },
      { nameEn: 'Adamdighi', nameBn: 'আদমদীঘি' },
      { nameEn: 'Dupchanchia', nameBn: 'দুপচাঁচিয়া' },
      { nameEn: 'Sonatala', nameBn: 'সোনাতলা' },
      { nameEn: 'Sariakandi', nameBn: 'সারিয়াকান্দি' },
      { nameEn: 'Kahalu', nameBn: 'কাহালু' },
    ]
  },
  {
    id: 'pabna',
    nameEn: 'Pabna',
    nameBn: 'পাবনা',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Pabna Sadar', nameBn: 'পাবনা সদর' },
      { nameEn: 'Ishwardi', nameBn: 'ঈশ্বরদী' },
      { nameEn: 'Atgharia', nameBn: 'আটঘরিয়া' },
      { nameEn: 'Chatmohar', nameBn: 'চাটমোহর' },
      { nameEn: 'Bhangura', nameBn: 'ভাঙ্গুড়া' },
      { nameEn: 'Faridpur', nameBn: 'ফরিদপুর' },
      { nameEn: 'Bera', nameBn: 'বেড়া' },
      { nameEn: 'Sujanagar', nameBn: 'সুজানগর' },
      { nameEn: 'Santhia', nameBn: 'সাঁথিয়া' },
    ]
  },
  {
    id: 'sirajganj',
    nameEn: 'Sirajganj',
    nameBn: 'সিরাজগঞ্জ',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Sirajganj Sadar', nameBn: 'সিরাজগঞ্জ সদর' },
      { nameEn: 'Kazipur', nameBn: 'কাজীপুর' },
      { nameEn: 'Ullapara', nameBn: 'উল্লাপাড়া' },
      { nameEn: 'Shahjadpur', nameBn: 'শাহজাদপুর' },
      { nameEn: 'Raiganj', nameBn: 'রায়গঞ্জ' },
      { nameEn: 'Tarash', nameBn: 'তাড়াশ' },
      { nameEn: 'Belkuchi', nameBn: 'বেলকুচি' },
      { nameEn: 'Kamarkhanda', nameBn: 'কামারখন্দ' },
      { nameEn: 'Chauhali', nameBn: 'চৌহালী' },
    ]
  },
  {
    id: 'naogaon',
    nameEn: 'Naogaon',
    nameBn: 'নওগাঁ',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Naogaon Sadar', nameBn: 'নওগাঁ সদর' },
      { nameEn: 'Patnitala', nameBn: 'পত্নীতলা' },
      { nameEn: 'Dhamoirhat', nameBn: 'ধামইরহাট' },
      { nameEn: 'Mohadevpur', nameBn: 'মহাদেবপুর' },
      { nameEn: 'Porsha', nameBn: 'পোরশা' },
      { nameEn: 'Sapahar', nameBn: 'সাপাহার' },
      { nameEn: 'Badalgachhi', nameBn: 'বদলগাছী' },
      { nameEn: 'Manda', nameBn: 'মান্দা' },
      { nameEn: 'Atrai', nameBn: 'আত্রাই' },
      { nameEn: 'Raninagar', nameBn: 'রানীনগর' },
      { nameEn: 'Niamatpur', nameBn: 'নিয়ামতপুর' },
    ]
  },
  {
    id: 'natore',
    nameEn: 'Natore',
    nameBn: 'নাটোর',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Natore Sadar', nameBn: 'নাটোর সদর' },
      { nameEn: 'Singra', nameBn: 'সিংড়া' },
      { nameEn: 'Baraigram', nameBn: 'বড়াইগ্রাম' },
      { nameEn: 'Bagatipara', nameBn: 'বাগাতিপাড়া' },
      { nameEn: 'Lalpur', nameBn: 'লালপুর' },
      { nameEn: 'Gurudaspur', nameBn: 'গুরুদাসপুর' },
      { nameEn: 'Naldanga', nameBn: 'নলডাঙ্গা' },
    ]
  },
  {
    id: 'chapainawabganj',
    nameEn: 'Chapainawabganj',
    nameBn: 'চাঁপাইনবাবগঞ্জ',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Chapainawabganj Sadar', nameBn: 'চাঁপাইনবাবগঞ্জ সদর' },
      { nameEn: 'Shibganj', nameBn: 'শিবগঞ্জ' },
      { nameEn: 'Gomastapur', nameBn: 'গোমস্তাপুর' },
      { nameEn: 'Nachole', nameBn: 'নাচোল' },
      { nameEn: 'Bholahat', nameBn: 'ভোলাহাট' },
    ]
  },
  {
    id: 'joypurhat',
    nameEn: 'Joypurhat',
    nameBn: 'জয়পুরহাট',
    divisionId: 'rajshahi',
    thanas: [
      { nameEn: 'Joypurhat Sadar', nameBn: 'জয়পুরহাট সদর' },
      { nameEn: 'Panchbibi', nameBn: 'পাঁচবিবি' },
      { nameEn: 'Akkelpur', nameBn: 'আক্কেলপুর' },
      { nameEn: 'Kalai', nameBn: 'কালাই' },
      { nameEn: 'Khetlal', nameBn: 'ক্ষেতলাল' },
    ]
  },

  // ================= 4. KHULNA DIVISION (10 Districts) =================
  {
    id: 'khulna',
    nameEn: 'Khulna',
    nameBn: 'খুলনা',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Khulna Sadar', nameBn: 'খুলনা সদর' },
      { nameEn: 'Sonadanga', nameBn: 'সোনাডাঙ্গা' },
      { nameEn: 'Khalishpur', nameBn: 'খালিশপুর' },
      { nameEn: 'Daulatpur', nameBn: 'দৌলতপুর' },
      { nameEn: 'Khan Jahan Ali', nameBn: 'খানজাহান আলী' },
      { nameEn: 'Rupsha', nameBn: 'রূপসা' },
      { nameEn: 'Dumuria', nameBn: 'ডুমুরিয়া' },
      { nameEn: 'Terokhada', nameBn: 'তেরখাদা' },
      { nameEn: 'Phultala', nameBn: 'ফুলতলা' },
      { nameEn: 'Batiaghata', nameBn: 'বটিয়াঘাটা' },
      { nameEn: 'Dacope', nameBn: 'দাকোপ' },
      { nameEn: 'Paikgachha', nameBn: 'পাইকগাছা' },
      { nameEn: 'Koyra', nameBn: 'কয়রা' },
      { nameEn: 'Dighalia', nameBn: 'দিঘলিয়া' },
    ]
  },
  {
    id: 'jashore',
    nameEn: 'Jashore',
    nameBn: 'যশোর',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Jashore Sadar', nameBn: 'যশোর সদর' },
      { nameEn: 'Jhikargachha', nameBn: 'ঝিকরগাছা' },
      { nameEn: 'Sharsha', nameBn: 'শার্শা' },
      { nameEn: 'Bagherpara', nameBn: 'বাঘারপাড়া' },
      { nameEn: 'Manirampur', nameBn: 'মণিরামপুর' },
      { nameEn: 'Keshabpur', nameBn: 'কেশবপুর' },
      { nameEn: 'Abhaynagar', nameBn: 'অভয়নগর' },
      { nameEn: 'Chaugachha', nameBn: 'চৌগাছা' },
    ]
  },
  {
    id: 'kushtia',
    nameEn: 'Kushtia',
    nameBn: 'কুষ্টিয়া',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Kushtia Sadar', nameBn: 'কুষ্টিয়া সদর' },
      { nameEn: 'Kumarkhali', nameBn: 'কুমারখালী' },
      { nameEn: 'Khoksa', nameBn: 'খোকসা' },
      { nameEn: 'Mirpur', nameBn: 'মিরপুর' },
      { nameEn: 'Bheramara', nameBn: 'ভেড়ামারা' },
      { nameEn: 'Daulatpur', nameBn: 'দৌলতপুর' },
    ]
  },
  {
    id: 'jhenaidah',
    nameEn: 'Jhenaidah',
    nameBn: 'ঝিনাইদহ',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Jhenaidah Sadar', nameBn: 'ঝিনাইদহ সদর' },
      { nameEn: 'Shailkupa', nameBn: 'শৈলকুপা' },
      { nameEn: 'Harinakunda', nameBn: 'হরিণাকুণ্ডু' },
      { nameEn: 'Kaliganj', nameBn: 'কালীগঞ্জ' },
      { nameEn: 'Kotchandpur', nameBn: 'কোটচাঁদপুর' },
      { nameEn: 'Maheshpur', nameBn: 'মহেশপুর' },
    ]
  },
  {
    id: 'satkhira',
    nameEn: 'Satkhira',
    nameBn: 'সাতক্ষীরা',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Satkhira Sadar', nameBn: 'সাতক্ষীরা সদর' },
      { nameEn: 'Kalaroa', nameBn: 'কলারোয়া' },
      { nameEn: 'Tala', nameBn: 'তালা' },
      { nameEn: 'Debhata', nameBn: 'দেবহাটা' },
      { nameEn: 'Kaliganj', nameBn: 'কালিগঞ্জ' },
      { nameEn: 'Assasuni', nameBn: 'আশাশুনি' },
      { nameEn: 'Shyamnagar', nameBn: 'শ্যামনগর' },
    ]
  },
  {
    id: 'bagerhat',
    nameEn: 'Bagerhat',
    nameBn: 'বাগেরহাট',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Bagerhat Sadar', nameBn: 'বাগেরহাট সদর' },
      { nameEn: 'Fakirhat', nameBn: 'ফকিরহাট' },
      { nameEn: 'Mollahat', nameBn: 'মোল্লাহাট' },
      { nameEn: 'Chitalmari', nameBn: 'চিতলমারী' },
      { nameEn: 'Kachua', nameBn: 'কচুয়া' },
      { nameEn: 'Rampal', nameBn: 'রামপাল' },
      { nameEn: 'Mongla', nameBn: 'মোংলা' },
      { nameEn: 'Morrelganj', nameBn: 'মোড়েলগঞ্জ' },
      { nameEn: 'Sarankhola', nameBn: 'শরণখোলা' },
    ]
  },
  {
    id: 'chuadanga',
    nameEn: 'Chuadanga',
    nameBn: 'চুয়াডাঙ্গা',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Chuadanga Sadar', nameBn: 'চুয়াডাঙ্গা সদর' },
      { nameEn: 'Alamdanga', nameBn: 'আলমডাঙ্গা' },
      { nameEn: 'Damurhuda', nameBn: 'দামুড়হুদা' },
      { nameEn: 'Jibannagar', nameBn: 'জীবননগর' },
    ]
  },
  {
    id: 'meherpur',
    nameEn: 'Meherpur',
    nameBn: 'মেহেরপুর',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Meherpur Sadar', nameBn: 'মেহেরপুর সদর' },
      { nameEn: 'Gangni', nameBn: 'গাংনী' },
      { nameEn: 'Mujibnagar', nameBn: 'মুজিবনগর' },
    ]
  },
  {
    id: 'narail',
    nameEn: 'Narail',
    nameBn: 'নড়াইল',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Narail Sadar', nameBn: 'নড়াইল সদর' },
      { nameEn: 'Lohagara', nameBn: 'লোহাগড়া' },
      { nameEn: 'Kalia', nameBn: 'কালিয়া' },
    ]
  },
  {
    id: 'magura',
    nameEn: 'Magura',
    nameBn: 'মাগুরা',
    divisionId: 'khulna',
    thanas: [
      { nameEn: 'Magura Sadar', nameBn: 'মাগুরা সদর' },
      { nameEn: 'Sreepur', nameBn: 'শ্রীপুর' },
      { nameEn: 'Shalikha', nameBn: 'শালিখা' },
      { nameEn: 'Mohammadpur', nameBn: 'মহম্মদপুর' },
    ]
  },

  // ================= 5. BARISHAL DIVISION (6 Districts) =================
  {
    id: 'barishal',
    nameEn: 'Barishal',
    nameBn: 'বরিশাল',
    divisionId: 'barisal',
    thanas: [
      { nameEn: 'Barishal Sadar', nameBn: 'বরিশাল সদর' },
      { nameEn: 'Bakerganj', nameBn: 'বাকেরগঞ্জ' },
      { nameEn: 'Babuganj', nameBn: 'বাবুগঞ্জ' },
      { nameEn: 'Wazirpur', nameBn: 'উজিরপুর' },
      { nameEn: 'Banaripara', nameBn: 'বানারীপাড়া' },
      { nameEn: 'Gournadi', nameBn: 'গৌরনদী' },
      { nameEn: 'Agailjhara', nameBn: 'আগৈলঝাড়া' },
      { nameEn: 'Mehendiganj', nameBn: 'মেহেন্দীগঞ্জ' },
      { nameEn: 'Muladi', nameBn: 'মুলাদী' },
      { nameEn: 'Hizla', nameBn: 'হিজলা' },
    ]
  },
  {
    id: 'patuakhali',
    nameEn: 'Patuakhali',
    nameBn: 'পটুয়াখালী',
    divisionId: 'barisal',
    thanas: [
      { nameEn: 'Patuakhali Sadar', nameBn: 'পটুয়াখালী সদর' },
      { nameEn: 'Bauphal', nameBn: 'বাউফল' },
      { nameEn: 'Galachipa', nameBn: 'গলাচিপা' },
      { nameEn: 'Dashmina', nameBn: 'দশমিনা' },
      { nameEn: 'Kalapara', nameBn: 'কলাপাড়া' },
      { nameEn: 'Mirzaganj', nameBn: 'মির্জাগঞ্জ' },
      { nameEn: 'Dumki', nameBn: 'দুমকি' },
      { nameEn: 'Rangabali', nameBn: 'রাঙ্গাবালী' },
    ]
  },
  {
    id: 'bhola',
    nameEn: 'Bhola',
    nameBn: 'ভোলা',
    divisionId: 'barisal',
    thanas: [
      { nameEn: 'Bhola Sadar', nameBn: 'ভোলা সদর' },
      { nameEn: 'Borhanuddin', nameBn: 'বোরহানউদ্দিন' },
      { nameEn: 'Daulatkhan', nameBn: 'দৌলতখান' },
      { nameEn: 'Lalmohan', nameBn: 'লালমোহন' },
      { nameEn: 'Tazumuddin', nameBn: 'তজুমদ্দিন' },
      { nameEn: 'Char Fasson', nameBn: 'চরফ্যাশন' },
      { nameEn: 'Monpura', nameBn: 'মনপুরা' },
    ]
  },
  {
    id: 'pirojpur',
    nameEn: 'Pirojpur',
    nameBn: 'পিরোজপুর',
    divisionId: 'barisal',
    thanas: [
      { nameEn: 'Pirojpur Sadar', nameBn: 'পিরোজপুর সদর' },
      { nameEn: 'Mathbaria', nameBn: 'মঠবাড়িয়া' },
      { nameEn: 'Bhandaria', nameBn: 'ভান্ডারিয়া' },
      { nameEn: 'Kawkhali', nameBn: 'কাউখালী' },
      { nameEn: 'Nazirpur', nameBn: 'নাজিরপুর' },
      { nameEn: 'Indurkani', nameBn: 'ইন্দুরকানী' },
      { nameEn: 'Nesarabad', nameBn: 'নেছারাবাদ (স্বরূপকাঠি)' },
    ]
  },
  {
    id: 'barguna',
    nameEn: 'Barguna',
    nameBn: 'বরগুনা',
    divisionId: 'barisal',
    thanas: [
      { nameEn: 'Barguna Sadar', nameBn: 'বরগুনা সদর' },
      { nameEn: 'Amtali', nameBn: 'আমতলী' },
      { nameEn: 'Patharghata', nameBn: 'পাথরঘাটা' },
      { nameEn: 'Betagi', nameBn: 'বেতাগী' },
      { nameEn: 'Bamna', nameBn: 'বামনা' },
      { nameEn: 'Taltali', nameBn: 'তালতলী' },
    ]
  },
  {
    id: 'jhalokathi',
    nameEn: 'Jhalokathi',
    nameBn: 'ঝালকাঠি',
    divisionId: 'barisal',
    thanas: [
      { nameEn: 'Jhalokathi Sadar', nameBn: 'ঝালকাঠি সদর' },
      { nameEn: 'Nalchhiti', nameBn: 'নলছিটি' },
      { nameEn: 'Rajapur', nameBn: 'রাজাপুর' },
      { nameEn: 'Kathalia', nameBn: 'কাঁঠালিয়া' },
    ]
  },

  // ================= 6. SYLHET DIVISION (4 Districts) =================
  {
    id: 'sylhet',
    nameEn: 'Sylhet',
    nameBn: 'সিলেট',
    divisionId: 'sylhet',
    thanas: [
      { nameEn: 'Sylhet Sadar', nameBn: 'সিলেট সদর' },
      { nameEn: 'Dakshin Surma', nameBn: 'দক্ষিণ সুরমা' },
      { nameEn: 'Golapganj', nameBn: 'গোলাপগঞ্জ' },
      { nameEn: 'Beanibazar', nameBn: 'বিয়ানীবাজার' },
      { nameEn: 'Zakiganj', nameBn: 'জকিগঞ্জ' },
      { nameEn: 'Kanaighat', nameBn: 'কানাইঘাট' },
      { nameEn: 'Bishwanath', nameBn: 'বিশ্বনাথ' },
      { nameEn: 'Balaganj', nameBn: 'বালাগঞ্জ' },
      { nameEn: 'Osmani Nagar', nameBn: 'ওসমানীনগর' },
      { nameEn: 'Fenchuganj', nameBn: 'ফেঞ্চুগঞ্জ' },
      { nameEn: 'Companiganj', nameBn: 'কোম্পানীগঞ্জ' },
      { nameEn: 'Gowainghat', nameBn: 'গোয়াইনঘাট' },
      { nameEn: 'Jaintiapur', nameBn: 'জৈন্তাপুর' },
    ]
  },
  {
    id: 'moulvibazar',
    nameEn: 'Moulvibazar',
    nameBn: 'মৌলভীবাজার',
    divisionId: 'sylhet',
    thanas: [
      { nameEn: 'Moulvibazar Sadar', nameBn: 'মৌলভীবাজার সদর' },
      { nameEn: 'Sreemangal', nameBn: 'শ্রীমঙ্গল' },
      { nameEn: 'Kamalganj', nameBn: 'কমলগঞ্জ' },
      { nameEn: 'Kulaura', nameBn: 'কুলাউড়া' },
      { nameEn: 'Rajnagar', nameBn: 'রাজনগর' },
      { nameEn: 'Juri', nameBn: 'জুড়ী' },
      { nameEn: 'Barlekha', nameBn: 'বড়লেখা' },
    ]
  },
  {
    id: 'habiganj',
    nameEn: 'Habiganj',
    nameBn: 'হবিগঞ্জ',
    divisionId: 'sylhet',
    thanas: [
      { nameEn: 'Habiganj Sadar', nameBn: 'হবিগঞ্জ সদর' },
      { nameEn: 'Sayestaganj', nameBn: 'শায়েস্তাগঞ্জ' },
      { nameEn: 'Madhabpur', nameBn: 'মাধবপুর' },
      { nameEn: 'Chunarughat', nameBn: 'চুনারুঘাট' },
      { nameEn: 'Bahubal', nameBn: 'বাহুবল' },
      { nameEn: 'Nabiganj', nameBn: 'নবীগঞ্জ' },
      { nameEn: 'Baniachong', nameBn: 'বানিয়াচং' },
      { nameEn: 'Lakhai', nameBn: 'লাখাই' },
      { nameEn: 'Ajmiriganj', nameBn: 'আজমিরীগঞ্জ' },
    ]
  },
  {
    id: 'sunamganj',
    nameEn: 'Sunamganj',
    nameBn: 'সুনামগঞ্জ',
    divisionId: 'sylhet',
    thanas: [
      { nameEn: 'Sunamganj Sadar', nameBn: 'সুনামগঞ্জ সদর' },
      { nameEn: 'Chhatak', nameBn: 'ছাতক' },
      { nameEn: 'Dowarabazar', nameBn: 'দোয়ারাবাজার' },
      { nameEn: 'Shantiganj', nameBn: 'শান্তিগঞ্জ' },
      { nameEn: 'Jagannathpur', nameBn: 'জগন্নাথপুর' },
      { nameEn: 'Dirai', nameBn: 'দিরাই' },
      { nameEn: 'Sulla', nameBn: 'শাল্লা' },
      { nameEn: 'Jamalganj', nameBn: 'জামালগঞ্জ' },
      { nameEn: 'Tahirpur', nameBn: 'তাহিরপুর' },
      { nameEn: 'Dharmapasha', nameBn: 'ধর্মপাশা' },
      { nameEn: 'Madhyanagar', nameBn: 'মধ্যনগর' },
      { nameEn: 'Bishwamvarpur', nameBn: 'বিশ্বম্ভরপুর' },
    ]
  },

  // ================= 7. RANGPUR DIVISION (8 Districts) =================
  {
    id: 'rangpur',
    nameEn: 'Rangpur',
    nameBn: 'রংপুর',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Rangpur Sadar', nameBn: 'রংপুর সদর' },
      { nameEn: 'Pirgachha', nameBn: 'পীরগাছা' },
      { nameEn: 'Kaunia', nameBn: 'কাউনিয়া' },
      { nameEn: 'Gangachhara', nameBn: 'গংগাচড়া' },
      { nameEn: 'Mithapukur', nameBn: 'মিঠাপুকুর' },
      { nameEn: 'Pirganj', nameBn: 'পীরগঞ্জ' },
      { nameEn: 'Badarganj', nameBn: 'বদরগঞ্জ' },
      { nameEn: 'Taraganj', nameBn: 'তারাগঞ্জ' },
    ]
  },
  {
    id: 'dinajpur',
    nameEn: 'Dinajpur',
    nameBn: 'দিনাজপুর',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Dinajpur Sadar', nameBn: 'দিনাজপুর সদর' },
      { nameEn: 'Parbatipur', nameBn: 'পার্বতীপুর' },
      { nameEn: 'Fulbari', nameBn: 'ফুলবাড়ী' },
      { nameEn: 'Nawabganj', nameBn: 'নবাবগঞ্জ' },
      { nameEn: 'Birampur', nameBn: 'বিরামপুর' },
      { nameEn: 'Hakimpur', nameBn: 'হাকিমপুর' },
      { nameEn: 'Ghoraghat', nameBn: 'ঘোড়াঘাট' },
      { nameEn: 'Kaharole', nameBn: 'কাহারোল' },
      { nameEn: 'Birganj', nameBn: 'বীরগঞ্জ' },
      { nameEn: 'Bochaganj', nameBn: 'বোচাগঞ্জ' },
      { nameEn: 'Chirirbandar', nameBn: 'চিরিরবন্দর' },
      { nameEn: 'Khansama', nameBn: 'খানসামা' },
      { nameEn: 'Biral', nameBn: 'বিরল' },
    ]
  },
  {
    id: 'kurigram',
    nameEn: 'Kurigram',
    nameBn: 'কুড়িগ্রাম',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Kurigram Sadar', nameBn: 'কুড়িগ্রাম সদর' },
      { nameEn: 'Nageshwari', nameBn: 'নাগেশ্বরী' },
      { nameEn: 'Bhurungamari', nameBn: 'ভূরুঙ্গামারী' },
      { nameEn: 'Phulbari', nameBn: 'ফুলবাড়ী' },
      { nameEn: 'Rajarhat', nameBn: 'রাজারহাট' },
      { nameEn: 'Ulipur', nameBn: 'উলিপুর' },
      { nameEn: 'Chilmari', nameBn: 'চিলমারী' },
      { nameEn: 'Rowmari', nameBn: 'রৌমারী' },
      { nameEn: 'Rajibpur', nameBn: 'রাজিবপুর' },
    ]
  },
  {
    id: 'gaibandha',
    nameEn: 'Gaibandha',
    nameBn: 'গাইবান্ধা',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Gaibandha Sadar', nameBn: 'গাইবান্ধা সদর' },
      { nameEn: 'Sadullapur', nameBn: 'সাদুল্লাপুর' },
      { nameEn: 'Sundarganj', nameBn: 'সুন্দরগঞ্জ' },
      { nameEn: 'Gobindaganj', nameBn: 'গোবিন্দগঞ্জ' },
      { nameEn: 'Palashbari', nameBn: 'পলাশবাড়ী' },
      { nameEn: 'Saghata', nameBn: 'সাঘাটা' },
      { nameEn: 'Fulchhari', nameBn: 'ফুলছড়ি' },
    ]
  },
  {
    id: 'nilphamari',
    nameEn: 'Nilphamari',
    nameBn: 'নীলফামারী',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Nilphamari Sadar', nameBn: 'নীলফামারী সদর' },
      { nameEn: 'Saidpur', nameBn: 'সৈয়দপুর' },
      { nameEn: 'Domar', nameBn: 'ডোমার' },
      { nameEn: 'Dimla', nameBn: 'ডিমলা' },
      { nameEn: 'Jaldhaka', nameBn: 'জলঢাকা' },
      { nameEn: 'Kishoreganj', nameBn: 'কিশোরগঞ্জ' },
    ]
  },
  {
    id: 'lalmonirhat',
    nameEn: 'Lalmonirhat',
    nameBn: 'লালমনিরহাট',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Lalmonirhat Sadar', nameBn: 'লালমনিরহাট সদর' },
      { nameEn: 'Hatibandha', nameBn: 'হাতীবান্ধা' },
      { nameEn: 'Patgram', nameBn: 'পাটগ্রাম' },
      { nameEn: 'Kaliganj', nameBn: 'কালীগঞ্জ' },
      { nameEn: 'Aditmari', nameBn: 'আদিতমারী' },
    ]
  },
  {
    id: 'panchagarh',
    nameEn: 'Panchagarh',
    nameBn: 'পঞ্চগড়',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Panchagarh Sadar', nameBn: 'পঞ্চগড় সদর' },
      { nameEn: 'Boda', nameBn: 'বোদা' },
      { nameEn: 'Debiganj', nameBn: 'দেবীগঞ্জ' },
      { nameEn: 'Tetulia', nameBn: 'তেঁতুলিয়া' },
      { nameEn: 'Atwari', nameBn: 'আটোয়ারী' },
    ]
  },
  {
    id: 'thakurgaon',
    nameEn: 'Thakurgaon',
    nameBn: 'ঠাকুরগাঁও',
    divisionId: 'rangpur',
    thanas: [
      { nameEn: 'Thakurgaon Sadar', nameBn: 'ঠাকুরগাঁও সদর' },
      { nameEn: 'Baliadangi', nameBn: 'বালিয়াডাঙ্গী' },
      { nameEn: 'Pirganj', nameBn: 'পীরগঞ্জ' },
      { nameEn: 'Ranisankail', nameBn: 'রাণীশংকৈল' },
      { nameEn: 'Haripur', nameBn: 'হরিপুর' },
    ]
  },

  // ================= 8. MYMENSINGH DIVISION (4 Districts) =================
  {
    id: 'mymensingh',
    nameEn: 'Mymensingh',
    nameBn: 'ময়মনসিংহ',
    divisionId: 'mymensingh',
    thanas: [
      { nameEn: 'Mymensingh Sadar', nameBn: 'ময়মনসিংহ সদর' },
      { nameEn: 'Muktagachha', nameBn: 'মুক্তাগাছা' },
      { nameEn: 'Trishal', nameBn: 'ত্রিশাল' },
      { nameEn: 'Fulbaria', nameBn: 'ফুলবাড়িয়া' },
      { nameEn: 'Gauripur', nameBn: 'গৌরীপুর' },
      { nameEn: 'Ishwarganj', nameBn: 'ঈশ্বরগঞ্জ' },
      { nameEn: 'Nandail', nameBn: 'নান্দাইল' },
      { nameEn: 'Haluaghat', nameBn: 'হালুয়াঘাট' },
      { nameEn: 'Dhobaura', nameBn: 'ধোবাউড়া' },
      { nameEn: 'Phulpur', nameBn: 'ফুলপুর' },
      { nameEn: 'Tarakanda', nameBn: 'তারাকান্দা' },
      { nameEn: 'Bhaluka', nameBn: 'ভালুকা' },
      { nameEn: 'Gafargaon', nameBn: 'গফরগাঁও' },
    ]
  },
  {
    id: 'jamalpur',
    nameEn: 'Jamalpur',
    nameBn: 'জামালপুর',
    divisionId: 'mymensingh',
    thanas: [
      { nameEn: 'Jamalpur Sadar', nameBn: 'জামালপুর সদর' },
      { nameEn: 'Sarishabari', nameBn: 'সরিষাবাড়ী' },
      { nameEn: 'Melandaha', nameBn: 'মেলান্দহ' },
      { nameEn: 'Islampur', nameBn: 'ইসলামপুর' },
      { nameEn: 'Madarganj', nameBn: 'মাদারগঞ্জ' },
      { nameEn: 'Dewanganj', nameBn: 'দেওয়ানগঞ্জ' },
      { nameEn: 'Bakshiganj', nameBn: 'বকশীগঞ্জ' },
    ]
  },
  {
    id: 'netrokona',
    nameEn: 'Netrokona',
    nameBn: 'নেত্রকোণা',
    divisionId: 'mymensingh',
    thanas: [
      { nameEn: 'Netrokona Sadar', nameBn: 'নেত্রকোণা সদর' },
      { nameEn: 'Durgapur', nameBn: 'দুর্গাপুর' },
      { nameEn: 'Kendua', nameBn: 'কেন্দুয়া' },
      { nameEn: 'Madan', nameBn: 'মদন' },
      { nameEn: 'Atpara', nameBn: 'আটপাড়া' },
      { nameEn: 'Barhatta', nameBn: 'বারহাট্টা' },
      { nameEn: 'Kalmakanda', nameBn: 'কলমাকান্দা' },
      { nameEn: 'Purbadhala', nameBn: 'পূর্বধলা' },
      { nameEn: 'Khaliajuri', nameBn: 'খালিয়াজুড়ী' },
      { nameEn: 'Mohanganj', nameBn: 'মোহনগঞ্জ' },
    ]
  },
  {
    id: 'sherpur',
    nameEn: 'Sherpur',
    nameBn: 'শেরপুর',
    divisionId: 'mymensingh',
    thanas: [
      { nameEn: 'Sherpur Sadar', nameBn: 'শেরপুর সদর' },
      { nameEn: 'Nakla', nameBn: 'নকলা' },
      { nameEn: 'Nalitabari', nameBn: 'নালিতাবাড়ী' },
      { nameEn: 'Sreebardi', nameBn: 'শ্রীবরদী' },
      { nameEn: 'Jhenaigati', nameBn: 'ঝিনাইগাতী' },
    ]
  },
];

// Helper functions for quick and accurate lookup
export function getDistrictsForDivision(divisionIdOrName: string): GeoDistrict[] {
  const norm = divisionIdOrName.trim().toLowerCase();
  const matchedDiv = BD_DIVISIONS_LIST.find(
    d => d.id.toLowerCase() === norm || 
         d.nameEn.toLowerCase() === norm || 
         d.nameBn.includes(divisionIdOrName)
  );
  const divId = matchedDiv ? matchedDiv.id : norm;
  return BD_64_DISTRICTS.filter(dist => dist.divisionId.toLowerCase() === divId);
}

export function getThanasForDistrict(districtNameOrId: string): GeoThana[] {
  if (!districtNameOrId) return [];
  const norm = districtNameOrId.trim().toLowerCase();
  const district = BD_64_DISTRICTS.find(
    d => d.id.toLowerCase() === norm || 
         d.nameEn.toLowerCase() === norm || 
         d.nameBn === districtNameOrId ||
         norm.includes(d.nameEn.toLowerCase()) ||
         d.nameBn.includes(districtNameOrId)
  );
  return district ? district.thanas : [];
}

export function findDistrict(districtNameOrId: string): GeoDistrict | undefined {
  if (!districtNameOrId) return undefined;
  const norm = districtNameOrId.trim().toLowerCase();
  return BD_64_DISTRICTS.find(
    d => d.id.toLowerCase() === norm || 
         d.nameEn.toLowerCase() === norm || 
         d.nameBn === districtNameOrId ||
         norm.includes(d.nameEn.toLowerCase()) ||
         d.nameBn.includes(districtNameOrId)
  );
}

// ================= DROPSHIPPINGBD DELIVERY AREAS & RATES =================
// Reference: DropshippingBD / Steadfast courier standardized rates
// Inside Dhaka: 65.00 ৳
// Outside Dhaka: 120.00 ৳

export type DeliveryZoneId = 'inside_dhaka' | 'outside_dhaka';

export interface DropshippingDeliveryZone {
  id: DeliveryZoneId;
  nameBn: string;
  nameEn: string;
  badgeBn: string;
  fee: number;
  estimatedDaysBn: string;
  estimatedDaysEn: string;
  descriptionBn: string;
  descriptionEn: string;
}

export const DROPSHIPPING_DELIVERY_ZONES: DropshippingDeliveryZone[] = [
  {
    id: 'inside_dhaka',
    nameBn: 'ঢাকার ভিতরে (Inside Dhaka)',
    nameEn: 'Inside Dhaka',
    badgeBn: '৳৬৫.০০',
    fee: 65,
    estimatedDaysBn: '২৪-৪৮ ঘণ্টার মধ্যে',
    estimatedDaysEn: '24-48 Hours',
    descriptionBn: 'ঢাকা সিটি কর্পোরেশন ও মেট্রোপলিটন এলাকা',
    descriptionEn: 'Inside Dhaka Metropolitan Area',
  },
  {
    id: 'outside_dhaka',
    nameBn: 'ঢাকার বাইরে (Outside Dhaka)',
    nameEn: 'Outside Dhaka',
    badgeBn: '৳১২০.০০',
    fee: 120,
    estimatedDaysBn: '২-৩ কার্যদিবস',
    estimatedDaysEn: '2-3 Business Days',
    descriptionBn: 'সারা বাংলাদেশ - দেশের যেকোনো জেলা ও থানা',
    descriptionEn: 'All other 63 districts & upazilas across Bangladesh',
  },
];

// All 64 Districts / Cities exactly ordered and matching DropshippingBD reseller app
export interface DropshippingCity {
  id: string;
  nameEn: string;
  nameBn: string;
  isDhaka: boolean;
}

export const DROPSHIPPING_64_CITIES: DropshippingCity[] = [
  { id: 'b_baria', nameEn: 'B. Baria', nameBn: 'ব্রাহ্মণবাড়িয়া', isDhaka: false },
  { id: 'bagerhat', nameEn: 'Bagerhat', nameBn: 'বাগেরহাট', isDhaka: false },
  { id: 'bandarban', nameEn: 'Bandarban', nameBn: 'বান্দরবান', isDhaka: false },
  { id: 'barguna', nameEn: 'Barguna', nameBn: 'বরগুনা', isDhaka: false },
  { id: 'barisal', nameEn: 'Barisal', nameBn: 'বরিশাল', isDhaka: false },
  { id: 'bhola', nameEn: 'Bhola', nameBn: 'ভোলা', isDhaka: false },
  { id: 'bogra', nameEn: 'Bogra', nameBn: 'বগুড়া', isDhaka: false },
  { id: 'chandpur', nameEn: 'Chandpur', nameBn: 'চাঁদপুর', isDhaka: false },
  { id: 'chapainawabganj', nameEn: 'Chapainawabganj', nameBn: 'চাঁপাইনবাবগঞ্জ', isDhaka: false },
  { id: 'chittagong', nameEn: 'Chittagong', nameBn: 'চট্টগ্রাম', isDhaka: false },
  { id: 'chuadanga', nameEn: 'Chuadanga', nameBn: 'চুয়াডাঙ্গা', isDhaka: false },
  { id: 'coxs_bazar', nameEn: "Cox's Bazar", nameBn: 'কক্সবাজার', isDhaka: false },
  { id: 'cumilla', nameEn: 'Cumilla', nameBn: 'কুমিল্লা', isDhaka: false },
  { id: 'dhaka', nameEn: 'Dhaka', nameBn: 'ঢাকা', isDhaka: true },
  { id: 'dinajpur', nameEn: 'Dinajpur', nameBn: 'দিনাজপুর', isDhaka: false },
  { id: 'faridpur', nameEn: 'Faridpur', nameBn: 'ফরিদপুর', isDhaka: false },
  { id: 'feni', nameEn: 'Feni', nameBn: 'ফেনী', isDhaka: false },
  { id: 'gaibandha', nameEn: 'Gaibandha', nameBn: 'গাইবান্ধা', isDhaka: false },
  { id: 'gazipur', nameEn: 'Gazipur', nameBn: 'গাজীপুর', isDhaka: false },
  { id: 'gopalgonj', nameEn: 'Gopalgonj', nameBn: 'গোপালগঞ্জ', isDhaka: false },
  { id: 'habiganj', nameEn: 'Habiganj', nameBn: 'হবিগঞ্জ', isDhaka: false },
  { id: 'jamalpur', nameEn: 'Jamalpur', nameBn: 'জামালপুর', isDhaka: false },
  { id: 'jashore', nameEn: 'Jashore', nameBn: 'যশোর', isDhaka: false },
  { id: 'jhalokathi', nameEn: 'Jhalokathi', nameBn: 'ঝালকাঠি', isDhaka: false },
  { id: 'jhenidah', nameEn: 'Jhenidah', nameBn: 'ঝিনাইদহ', isDhaka: false },
  { id: 'joypurhat', nameEn: 'Joypurhat', nameBn: 'জয়পুরহাট', isDhaka: false },
  { id: 'khagrachari', nameEn: 'Khagrachari', nameBn: 'খাগড়াছড়ি', isDhaka: false },
  { id: 'khulna', nameEn: 'Khulna', nameBn: 'খুলনা', isDhaka: false },
  { id: 'kishoreganj', nameEn: 'Kishoreganj', nameBn: 'কিশোরগঞ্জ', isDhaka: false },
  { id: 'kurigram', nameEn: 'Kurigram', nameBn: 'কুড়িগ্রাম', isDhaka: false },
  { id: 'kushtia', nameEn: 'Kushtia', nameBn: 'কুষ্টিয়া', isDhaka: false },
  { id: 'lakshmipur', nameEn: 'Lakshmipur', nameBn: 'লক্ষ্মীপুর', isDhaka: false },
  { id: 'lalmonirhat', nameEn: 'Lalmonirhat', nameBn: 'লালমনিরহাট', isDhaka: false },
  { id: 'madaripur', nameEn: 'Madaripur', nameBn: 'মাদারীপুর', isDhaka: false },
  { id: 'magura', nameEn: 'Magura', nameBn: 'মাগুরা', isDhaka: false },
  { id: 'manikganj', nameEn: 'Manikganj', nameBn: 'মানিকগঞ্জ', isDhaka: false },
  { id: 'meherpur', nameEn: 'Meherpur', nameBn: 'মেহেরপুর', isDhaka: false },
  { id: 'moulvibazar', nameEn: 'Moulvibazar', nameBn: 'মৌলভীবাজার', isDhaka: false },
  { id: 'munshiganj', nameEn: 'Munshiganj', nameBn: 'মুন্সীগঞ্জ', isDhaka: false },
  { id: 'mymensingh', nameEn: 'Mymensingh', nameBn: 'ময়মনসিংহ', isDhaka: false },
  { id: 'naogaon', nameEn: 'Naogaon', nameBn: 'নওগাঁ', isDhaka: false },
  { id: 'narail', nameEn: 'Narail', nameBn: 'নড়াইল', isDhaka: false },
  { id: 'narayanganj', nameEn: 'Narayanganj', nameBn: 'নারায়ণগঞ্জ', isDhaka: false },
  { id: 'narshingdi', nameEn: 'Narshingdi', nameBn: 'নরসিংদী', isDhaka: false },
  { id: 'natore', nameEn: 'Natore', nameBn: 'নাটোর', isDhaka: false },
  { id: 'netrokona', nameEn: 'Netrokona', nameBn: 'নেত্রকোণা', isDhaka: false },
  { id: 'nilphamari', nameEn: 'Nilphamari', nameBn: 'নীলফামারী', isDhaka: false },
  { id: 'noakhali', nameEn: 'Noakhali', nameBn: 'নোয়াখালী', isDhaka: false },
  { id: 'pabna', nameEn: 'Pabna', nameBn: 'পাবনা', isDhaka: false },
  { id: 'panchagarh', nameEn: 'Panchagarh', nameBn: 'পঞ্চগড়', isDhaka: false },
  { id: 'patuakhali', nameEn: 'Patuakhali', nameBn: 'পটুয়াখালী', isDhaka: false },
  { id: 'pirojpur', nameEn: 'Pirojpur', nameBn: 'পিরোজপুর', isDhaka: false },
  { id: 'rajbari', nameEn: 'Rajbari', nameBn: 'রাজবাড়ী', isDhaka: false },
  { id: 'rajshahi', nameEn: 'Rajshahi', nameBn: 'রাজশাহী', isDhaka: false },
  { id: 'rangamati', nameEn: 'Rangamati', nameBn: 'রাঙ্গামাটি', isDhaka: false },
  { id: 'rangpur', nameEn: 'Rangpur', nameBn: 'রংপুর', isDhaka: false },
  { id: 'satkhira', nameEn: 'Satkhira', nameBn: 'সাতক্ষীরা', isDhaka: false },
  { id: 'shariatpur', nameEn: 'Shariatpur', nameBn: 'শরীয়তপুর', isDhaka: false },
  { id: 'sherpur', nameEn: 'Sherpur', nameBn: 'শেরপুর', isDhaka: false },
  { id: 'sirajganj', nameEn: 'Sirajganj', nameBn: 'সিরাজগঞ্জ', isDhaka: false },
  { id: 'sunamganj', nameEn: 'Sunamganj', nameBn: 'সুনামগঞ্জ', isDhaka: false },
  { id: 'sylhet', nameEn: 'Sylhet', nameBn: 'সিলেট', isDhaka: false },
  { id: 'tangail', nameEn: 'Tangail', nameBn: 'টাঙ্গাইল', isDhaka: false },
  { id: 'thakurgaon', nameEn: 'Thakurgaon', nameBn: 'ঠাকুরগাঁও', isDhaka: false },
];

export const DHAKA_METRO_KEYWORDS = [
  'dhanmondi', 'ধানমন্ডি',
  'gulshan', 'গুলশান',
  'banani', 'বনানী',
  'mirpur', 'মিরপুর',
  'uttara', 'উত্তরা',
  'mohammadpur', 'মোহাম্মদপুর',
  'badda', 'বাড্ডা',
  'rampura', 'রামপুরা',
  'khilgaon', 'খিলগাঁও',
  'motijheel', 'মতিঝিল',
  'tejgaon', 'তেজগাঁও',
  'paltan', 'পল্টন',
  'lalbagh', 'লালবাগ',
  'sutrapur', 'সূত্রাপুর',
  'chawkbazar', 'চকবাজার',
  'kotwali', 'কোতোয়ালী',
  'jatrabari', 'যাত্রাবাড়ী', 'যাত্রাবাড়ী',
  'kadamtali', 'কদমতলী',
  'shyampur', 'শ্যামপুর',
  'demra', 'ডেমরা',
  'malibagh', 'মালিবাগ',
  'moghbazar', 'মগবাজার',
  'kakrail', 'কাকরাইল',
  'shahbagh', 'শাহবাগ',
  'elephant road', 'এলিফ্যান্ট রোড',
  'farmgate', 'ফার্মগেট',
  'shyamoli', 'শ্যামলী',
  'kalyanpur', 'কল্যাণপুর',
  'bashundhara', 'বসুন্ধরা',
  'baridhara', 'বারিধারা',
  'khilkhet', 'খিলক্ষেত',
  'nikunja', 'নিকুঞ্জ',
  'cantonment', 'ক্যান্টনমেন্ট',
  'pallabi', 'পল্লবী',
  'kafrul', 'কাফরুল',
  'bangshal', 'বংশাল',
  'wari', 'ওয়ারী', 'ওয়ারী'
];

/**
 * Resolves accurate DropshippingBD delivery zone and fee
 * Inside Dhaka: 65.00 ৳
 * Outside Dhaka: 120.00 ৳
 */
export function resolveDeliveryZone(
  districtIdOrName: string = '',
  thanaNameOrId: string = '',
  fullAddressText: string = ''
): { zone: DeliveryZoneId; fee: number; zoneInfo: DropshippingDeliveryZone } {
  const normDist = (districtIdOrName || '').toLowerCase().trim();
  const normAddr = (fullAddressText || '').toLowerCase().trim();

  // 1. Check if district is explicitly Dhaka
  if (normDist === 'dhaka' || normDist === 'ঢাকা') {
    const zoneInfo = DROPSHIPPING_DELIVERY_ZONES.find(z => z.id === 'inside_dhaka')!;
    return { zone: 'inside_dhaka', fee: 65, zoneInfo };
  }

  // 2. Check address keywords if district not specified
  if (!normDist && normAddr) {
    if (DHAKA_METRO_KEYWORDS.some(k => normAddr.includes(k)) || normAddr.includes('dhaka') || normAddr.includes('ঢাকা')) {
      const zoneInfo = DROPSHIPPING_DELIVERY_ZONES.find(z => z.id === 'inside_dhaka')!;
      return { zone: 'inside_dhaka', fee: 65, zoneInfo };
    }
  }

  // 3. Default for all other 63 districts (Outside Dhaka)
  const zoneInfo = DROPSHIPPING_DELIVERY_ZONES.find(z => z.id === 'outside_dhaka')!;
  return { zone: 'outside_dhaka', fee: 120, zoneInfo };
}

