// Utility to generate valid Google-compliant XML Sitemap for Happy Shopping

export interface SitemapProduct {
  id: string;
  titleEn?: string;
  titleBn?: string;
  category?: string;
  createdAt?: string;
  updatedAt?: string;
}

export function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}

export const CATEGORIES = [
  'fashion',
  'gadgets',
  'accessories',
  'anime',
  'streetwear',
  'sports',
];

export function generateSitemapXml(products: SitemapProduct[] = [], baseUrl = 'https://gift-ghor.ai.studio'): string {
  const cleanBaseUrl = baseUrl.replace(/\/+$/, '');
  const today = new Date().toISOString().split('T')[0];

  const urls: { loc: string; lastmod: string; changefreq: string; priority: string }[] = [];

  // 1. Homepage
  urls.push({
    loc: `${cleanBaseUrl}/`,
    lastmod: today,
    changefreq: 'daily',
    priority: '1.0',
  });

  // 2. Main Product Catalog
  urls.push({
    loc: `${cleanBaseUrl}/products`,
    lastmod: today,
    changefreq: 'daily',
    priority: '0.9',
  });

  // 3. Categories
  for (const cat of CATEGORIES) {
    urls.push({
      loc: `${cleanBaseUrl}/category/${cat}`,
      lastmod: today,
      changefreq: 'weekly',
      priority: '0.8',
    });
  }

  // 4. Products (Deduplicated, Public Only)
  const seenIds = new Set<string>();
  for (const p of products) {
    if (!p || !p.id || seenIds.has(p.id)) continue;
    seenIds.add(p.id);

    const prodLastMod = p.updatedAt
      ? p.updatedAt.split('T')[0]
      : p.createdAt
        ? p.createdAt.split('T')[0]
        : today;

    urls.push({
      loc: `${cleanBaseUrl}/product/${encodeURIComponent(p.id)}`,
      lastmod: prodLastMod,
      changefreq: 'weekly',
      priority: '0.8',
    });
  }

  // 5. Official Info & Policy Pages
  const infoPages = [
    'about-us',
    'privacy-policy',
    'terms',
    'return-policy',
    'shipping-policy',
    'contact',
  ];

  for (const page of infoPages) {
    urls.push({
      loc: `${cleanBaseUrl}/${page}`,
      lastmod: today,
      changefreq: 'monthly',
      priority: '0.5',
    });
  }

  // Generate XML
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

  for (const item of urls) {
    xml += '  <url>\n';
    xml += `    <loc>${escapeXml(item.loc)}</loc>\n`;
    xml += `    <lastmod>${item.lastmod}</lastmod>\n`;
    xml += `    <changefreq>${item.changefreq}</changefreq>\n`;
    xml += `    <priority>${item.priority}</priority>\n`;
    xml += '  </url>\n';
  }

  xml += '</urlset>';
  return xml;
}
