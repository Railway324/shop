import { Order, OrderStatus, Language } from '../types';

/**
 * Checks whether a user can cancel an order.
 * Policy: A user can cancel an order at any time before it is dispatched/handed over to a courier.
 * If status is shipped, out_for_delivery, delivered, cancelled, returned, refunded, 
 * or if courier tracking code has been issued, it cannot be cancelled.
 */
export const canUserCancelOrder = (order: Order | null | undefined): boolean => {
  if (!order) return false;

  // Disallowed statuses
  const nonCancellableStatuses: OrderStatus[] = [
    'shipped',
    'out_for_delivery',
    'delivered',
    'cancelled',
    'returned',
    'refunded'
  ];

  if (nonCancellableStatuses.includes(order.orderStatus)) {
    return false;
  }

  // If courier tracking code is already assigned, it has been handed to courier
  if (order.trackingCode && order.trackingCode.trim().length > 0) {
    return false;
  }
  if (order.courierTrackingCode && order.courierTrackingCode.trim().length > 0) {
    return false;
  }

  // Allowed statuses: 'placed', 'pending', 'confirmed', 'processing', 'packed'
  return true;
};

export interface CancellationInfo {
  canCancel: boolean;
  statusTitle: string;
  statusNote: string;
  badgeType: 'cancellable' | 'courier' | 'delivered' | 'cancelled';
}

export const getOrderCancellationInfo = (order: Order | null | undefined, lang: Language): CancellationInfo => {
  if (!order) {
    return {
      canCancel: false,
      statusTitle: lang === 'bn' ? 'অর্ডার পাওয়া যায়নি' : 'Order not found',
      statusNote: '',
      badgeType: 'cancelled'
    };
  }

  if (order.orderStatus === 'cancelled') {
    return {
      canCancel: false,
      statusTitle: lang === 'bn' ? 'অর্ডারটি বাতিল করা হয়েছে' : 'Order Cancelled',
      statusNote: lang === 'bn' ? 'এই অর্ডারটি ইতিপূর্বে বাতিল করা হয়েছে।' : 'This order has already been cancelled.',
      badgeType: 'cancelled'
    };
  }

  if (order.orderStatus === 'delivered') {
    return {
      canCancel: false,
      statusTitle: lang === 'bn' ? 'ডেলিভারি সম্পন্ন' : 'Delivered',
      statusNote: lang === 'bn' ? 'অর্ডারটি সফলভাবে ডেলিভারি করা হয়েছে।' : 'Order delivered successfully.',
      badgeType: 'delivered'
    };
  }

  if (
    order.orderStatus === 'shipped' || 
    order.orderStatus === 'out_for_delivery' || 
    Boolean(order.trackingCode) || 
    Boolean(order.courierTrackingCode)
  ) {
    return {
      canCancel: false,
      statusTitle: lang === 'bn' ? 'কুরিয়ারে হস্তান্তর করা হয়েছে' : 'Handed Over to Courier',
      statusNote: lang === 'bn' 
        ? 'পণ্যটি ইতিমধ্যে কুরিয়ারে বুকিং দেওয়া হয়েছে, তাই এখন আর সরাসরি বাতিল করা সম্ভব নয়।' 
        : 'Order has already been dispatched to courier and cannot be cancelled.',
      badgeType: 'courier'
    };
  }

  return {
    canCancel: true,
    statusTitle: lang === 'bn' ? 'বাতিলযোগ্য (কুরিয়ারে হস্তান্তরের অপেক্ষায়)' : 'Cancellable (Awaiting Courier Dispatch)',
    statusNote: lang === 'bn' 
      ? 'কুরিয়ারে পাঠানোর আগ পর্যন্ত আপনি যেকোনো সময় অর্ডারটি বাতিল করতে পারবেন।' 
      : 'You may cancel this order at any time before it is dispatched to the courier.',
    badgeType: 'cancellable'
  };
};

export const CANCELLATION_REASONS = [
  { id: 'wrong_item', labelBn: 'ভুল পণ্য অথবা ভুল সাইজ/কালার সিলেক্ট করেছি', labelEn: 'Selected wrong item, size or color' },
  { id: 'address_phone_edit', labelBn: 'ডেলিভারি ঠিকানা অথবা ফোন নম্বরে ভুল হয়েছে', labelEn: 'Error in delivery address or phone number' },
  { id: 'not_needed', labelBn: 'এই মুহূর্তে পণ্যটির আর প্রয়োজন নেই', labelEn: 'No longer need this product' },
  { id: 'switch_product', labelBn: 'অন্য একটি পণ্য পছন্দ হয়েছে, নতুন করে অর্ডার করব', labelEn: 'Want to choose a different item instead' },
  { id: 'accidental_duplicate', labelBn: 'ভুলবশত একাধিকবার অর্ডার হয়ে গেছে', labelEn: 'Accidentally placed duplicate order' },
  { id: 'other', labelBn: 'অন্যান্য ব্যক্তিগত কারণ', labelEn: 'Other reason' },
];
