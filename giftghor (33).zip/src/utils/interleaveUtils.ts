import { Product } from '../types';
import { getProductSectionKey } from './categoryUtils';

/**
 * Calculates attractiveness score based on AI trend score, featured tag, and reviews
 */
export function getProductAttractivenessScore(p: Product): number {
  let score = 100;

  // Dynamic AI market trend score
  if (typeof p.aiTrendScore === 'number' && p.aiTrendScore > 0) {
    score += p.aiTrendScore * 25;
  }

  const id = p.id || '';

  // Priority attractive products
  if (id === 'prod-gdrive-new-1') score += 1200; // Top Maroon Katan Saree
  if (id === 'prod-gdrive-new-2') score += 1150; // Black Cotton Printed Saree
  if (id === 'prod-drive-hoodie-799') score += 1100; // Royal Edition Hoodie
  if (id === 'prod-drive-hoodie-760') score += 1050; // Premium Hoodie
  if (id === 'prod-cute-casual-backpack-pink') score += 1000;
  if (id === 'prod-cute-backpack-pink') score += 980;
  if (id === 'prod-d1240') score += 950; // Cartier style watch
  if (id === 'prod-t800-ultra-smartwatch') score += 920;

  if (p.isFeatured) score += 500;
  if (p.rating && p.rating >= 4.8) score += 200;

  return score;
}

/**
 * Saree classifier
 */
export function isSareeProduct(p: Product): boolean {
  const text = `${p.id} ${p.titleEn} ${p.titleBn} ${p.category} ${p.subcategory || ''} ${(p.tags || []).join(' ')}`.toLowerCase();
  return text.includes('saree') || text.includes('sharee') || text.includes('শাড়ি') || text.includes('শাড়ি');
}

/**
 * Hoodie classifier
 */
export function isHoodieProduct(p: Product): boolean {
  if (isSareeProduct(p)) return false;
  const text = `${p.id} ${p.titleEn} ${p.titleBn} ${p.category} ${p.subcategory || ''} ${(p.tags || []).join(' ')}`.toLowerCase();
  return text.includes('hoodie') || text.includes('হুডি') || text.includes('fleece');
}

/**
 * Bag classifier
 */
export function isBagProduct(p: Product): boolean {
  if (isSareeProduct(p) || isHoodieProduct(p)) return false;
  const text = `${p.id} ${p.titleEn} ${p.titleBn} ${p.category} ${p.subcategory || ''} ${(p.tags || []).join(' ')}`.toLowerCase();
  if (text.includes('combo pack') || text.includes('কম্বো প্যাক')) return false;
  return (
    text.includes('bag') ||
    text.includes('backpack') ||
    text.includes('handbag') ||
    text.includes('crossbody') ||
    text.includes('tote') ||
    text.includes('purse') ||
    text.includes('ব্যাগ') ||
    text.includes('ব্যাকপ্যাক')
  );
}

/**
 * Watch classifier
 */
export function isWatchProduct(p: Product): boolean {
  if (isSareeProduct(p) || isHoodieProduct(p) || isBagProduct(p)) return false;
  const text = `${p.id} ${p.titleEn} ${p.titleBn} ${p.category} ${p.subcategory || ''} ${(p.tags || []).join(' ')}`.toLowerCase();
  return text.includes('watch') || text.includes('clock') || text.includes('ঘড়ি') || text.includes('ঘড়ি') || text.includes('timepiece');
}

/**
 * Electronic / Gadgets classifier
 */
export function isElectronicProduct(p: Product): boolean {
  if (isSareeProduct(p) || isHoodieProduct(p) || isBagProduct(p) || isWatchProduct(p)) return false;
  const section = getProductSectionKey(p);
  if (section === 'gadgets_electronics') return true;
  const text = `${p.id} ${p.titleEn} ${p.titleBn} ${p.category} ${p.subcategory || ''} ${(p.tags || []).join(' ')}`.toLowerCase();
  return (
    text.includes('gadget') ||
    text.includes('electronic') ||
    text.includes('electric') ||
    text.includes('earbud') ||
    text.includes('trimmer') ||
    text.includes('shaver') ||
    text.includes('headphone') ||
    text.includes('speaker') ||
    text.includes('bluetooth') ||
    text.includes('charger') ||
    text.includes('powerbank') ||
    text.includes('power bank') ||
    text.includes('fan') ||
    text.includes('nebulizer') ||
    text.includes('peeler') ||
    text.includes('router') ||
    text.includes('ইলেকট্রিক') ||
    text.includes('ইলোকট্রনিক') ||
    text.includes('গ্যাজেট') ||
    text.includes('ট্রিমার') ||
    text.includes('শেভার') ||
    text.includes('ইয়ারবাড') ||
    text.includes('হেডফোন') ||
    text.includes('চার্জার')
  );
}

/**
 * Checks if a product is pure clothing / apparel (dresses, panjabi, kurtis, three-piece, t-shirts, etc.)
 */
export function isPureApparel(p: Product): boolean {
  const text = `${p.id} ${p.titleEn} ${p.titleBn} ${p.category} ${p.subcategory || ''} ${(p.tags || []).join(' ')}`.toLowerCase();
  return (
    text.includes('dress') ||
    text.includes('shirt') ||
    text.includes('panjabi') ||
    text.includes('kurti') ||
    text.includes('borkha') ||
    text.includes('pant') ||
    text.includes('t-shirt') ||
    text.includes('polo') ||
    text.includes('salwar') ||
    text.includes('three piece') ||
    text.includes('থ্রি পিস') ||
    text.includes('পোশাক') ||
    text.includes('জামা') ||
    text.includes('পাঞ্জাবি') ||
    text.includes('কুর্তি') ||
    text.includes('বোরকা') ||
    text.includes('টি-শার্ট') ||
    text.includes('প্যান্ট') ||
    p.category === 'clothes' ||
    p.category === 'fashion' ||
    p.category === 'mens-fashion' ||
    p.category === 'womens-fashion'
  );
}

/**
 * Jama classifier: Dresses, kurtis, suits, apparel
 */
export function isJamaProduct(p: Product): boolean {
  if (isSareeProduct(p) || isHoodieProduct(p) || isBagProduct(p) || isWatchProduct(p) || isElectronicProduct(p)) return false;
  return true;
}

/**
 * Orders products strictly according to the user requested repeating cyclical pattern:
 * 1. সাড়ি (Saree)
 * 2. ব্যাগ (Bag)
 * 3. ঘড়ি (Watch)
 * 4. ইলোকট্রনিক (Electronic)
 * 5. জামা (Jama / Dress / Clothing)
 * 6. সাড়ি (Saree)
 * 7. হুডি (Hoodie)
 * 8. ব্যাগ (Bag)
 * 9. ইলোকট্রনিক (Electronic)
 *
 * "এভাবে পন্য সাজাও, আর এই পদ্ধতি বারবার চলমান থাকবে।"
 * This pattern continuously repeats over and over for all items in the catalog.
 */
export function getInterleavedMixedProducts(products: Product[]): Product[] {
  if (!Array.isArray(products) || products.length === 0) return [];

  const active = products.filter(p => p.status !== 'inactive');
  if (active.length === 0) return [];

  // Bucket separation with attractiveness sorting
  const sareeBucket = active
    .filter(isSareeProduct)
    .sort((a, b) => getProductAttractivenessScore(b) - getProductAttractivenessScore(a));

  const hoodieBucket = active
    .filter(isHoodieProduct)
    .sort((a, b) => getProductAttractivenessScore(b) - getProductAttractivenessScore(a));

  const bagBucket = active
    .filter(isBagProduct)
    .sort((a, b) => getProductAttractivenessScore(b) - getProductAttractivenessScore(a));

  const watchBucket = active
    .filter(isWatchProduct)
    .sort((a, b) => getProductAttractivenessScore(b) - getProductAttractivenessScore(a));

  const electronicBucket = active
    .filter(isElectronicProduct)
    .sort((a, b) => getProductAttractivenessScore(b) - getProductAttractivenessScore(a));

  const jamaBucket = active
    .filter(isJamaProduct)
    .sort((a, b) => {
      // Prioritize pure apparel (dresses, kurtis, three-pieces, panjabis, shirts)
      const aPure = isPureApparel(a) ? 1 : 0;
      const bPure = isPureApparel(b) ? 1 : 0;
      if (aPure !== bPure) return bPure - aPure;
      return getProductAttractivenessScore(b) - getProductAttractivenessScore(a);
    });

  const buckets = {
    saree: sareeBucket,
    bag: bagBucket,
    watch: watchBucket,
    electronic: electronicBucket,
    jama: jamaBucket,
    hoodie: hoodieBucket,
  };

  // Exact 9-step cycle requested by user:
  // সাড়ি, ব্যাগ, ঘড়ি, ইলোকট্রনিক, জামা, সাড়ি, হুডি, ব্যাগ, ইলোকট্রনিক
  const cycleTypes = [
    'saree',
    'bag',
    'watch',
    'electronic',
    'jama',
    'saree',
    'hoodie',
    'bag',
    'electronic',
  ] as const;

  const counters = {
    saree: 0,
    bag: 0,
    watch: 0,
    electronic: 0,
    jama: 0,
    hoodie: 0,
  };

  const result: Product[] = [];
  // Ensure enough cycles to seamlessly display the catalog and continuous scrolling
  const totalItemsNeeded = Math.max(active.length, 360);
  const totalCycles = Math.ceil(totalItemsNeeded / cycleTypes.length);

  for (let c = 0; c < totalCycles; c++) {
    for (const slotType of cycleTypes) {
      const bucket = buckets[slotType];
      if (bucket.length > 0) {
        const item = bucket[counters[slotType] % bucket.length];
        counters[slotType]++;
        result.push(item);
      }
    }
  }

  return result;
}
