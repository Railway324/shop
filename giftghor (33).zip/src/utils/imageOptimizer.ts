import { useEffect, useState, useRef, useCallback } from 'react';

/**
 * Ultra-Smooth Singleton Viewport Observer & Image Optimizer
 * - Uses ONE shared IntersectionObserver across all ProductCards instead of 100+ individual observers
 * - Remembers already-decoded image URLs in RAM so navigating Back/Forward renders in 0ms with zero flash
 */

const preloadedSet = new Set<string>();
const failedProxies = new Set<string>();
const decodedUrlsCache = new Set<string>();

// Shared Singleton IntersectionObserver across the entire app
type VisibilityCallback = () => void;
const observedElements = new Map<Element, VisibilityCallback>();
let sharedObserver: IntersectionObserver | null = null;

function getSharedIntersectionObserver(): IntersectionObserver | null {
  if (typeof window === 'undefined' || typeof IntersectionObserver === 'undefined') {
    return null;
  }
  if (!sharedObserver) {
    sharedObserver = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const cb = observedElements.get(entry.target);
            if (cb) {
              observedElements.delete(entry.target);
              sharedObserver?.unobserve(entry.target);
              cb();
            }
          }
        }
      },
      {
        rootMargin: '420px 0px',
        threshold: 0.01,
      }
    );
  }
  return sharedObserver;
}

/**
 * Get compressed WebP image URL
 */
export function getOptimizedImageUrl(
  url: string | undefined | null,
  width: number = 320,
  quality: number = 72
): string {
  if (!url || typeof url !== 'string') return '/favicon.png';
  const cleanUrl = url.trim();
  if (!cleanUrl) return '/favicon.png';
  if (cleanUrl === '/logo.png' || cleanUrl.startsWith('/logo.png?')) return '/favicon.png';

  if (cleanUrl.startsWith('/') || cleanUrl.startsWith('data:') || cleanUrl.startsWith('blob:') || cleanUrl.endsWith('.svg')) {
    return cleanUrl;
  }

  if (failedProxies.has(cleanUrl)) {
    return cleanUrl;
  }

  if (cleanUrl.includes('drive.google.com/file/d/') || cleanUrl.includes('drive.google.com/uc?')) {
    const match = cleanUrl.match(/\/file\/d\/([a-zA-Z0-9_-]+)/) || cleanUrl.match(/id=([a-zA-Z0-9_-]+)/);
    if (match && match[1]) {
      return `https://lh3.googleusercontent.com/d/${match[1]}=w${width}-nu`;
    }
  }

  if (cleanUrl.includes('googleusercontent.com/d/')) {
    try {
      const baseUrl = cleanUrl.split('=')[0];
      return `${baseUrl}=w${width}-nu`;
    } catch {
      return cleanUrl;
    }
  }

  if (cleanUrl.includes('images.unsplash.com')) {
    try {
      const parsed = new URL(cleanUrl);
      parsed.searchParams.set('auto', 'format');
      parsed.searchParams.set('fit', 'crop');
      parsed.searchParams.set('w', String(width));
      parsed.searchParams.set('q', String(quality));
      return parsed.toString();
    } catch {
      return cleanUrl;
    }
  }

  if (cleanUrl.includes('res.cloudinary.com')) {
    try {
      return cleanUrl.replace('/image/upload/', `/image/upload/w_${width},q_${quality},f_auto,c_limit/`);
    } catch {
      return cleanUrl;
    }
  }

  if (cleanUrl.startsWith('http://') || cleanUrl.startsWith('https://')) {
    if (cleanUrl.includes('wsrv.nl')) return cleanUrl;
    const normalized = cleanUrl.replace('public//storage', 'public/storage');
    return `https://wsrv.nl/?url=${encodeURIComponent(normalized)}&w=${width}&q=${quality}&output=webp&il`;
  }

  return cleanUrl;
}

export function preloadImages(urls: (string | undefined | null)[]): void {
  if (typeof window === 'undefined') return;
  urls.forEach((url) => {
    if (!url || typeof url !== 'string') return;
    const optimized = getOptimizedImageUrl(url, 320, 72);
    if (preloadedSet.has(optimized)) return;
    preloadedSet.add(optimized);

    const img = new Image();
    img.decoding = 'async';
    img.onload = () => decodedUrlsCache.add(optimized);
    img.src = optimized;
  });
}

export function startBackgroundCatalogPreload(
  _items?: (string | { image?: string })[],
  _delayMs?: number
): void {}

export function useProgressiveImage(rawUrl: string | undefined | null, priority: boolean = false) {
  const cleanUrl = rawUrl && typeof rawUrl === 'string'
    ? rawUrl.trim().replace('public//storage', 'public/storage')
    : '';
  const initialOptimized = cleanUrl ? getOptimizedImageUrl(cleanUrl, 320, 72) : '';
  const alreadyCached = Boolean(initialOptimized && decodedUrlsCache.has(initialOptimized));

  const [isInView, setIsInView] = useState(priority || alreadyCached);
  const [isLoaded, setIsLoaded] = useState(alreadyCached);
  const [fallbackStep, setFallbackStep] = useState<0 | 1 | 2>(0);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (priority || isInView) return;
    const el = containerRef.current;
    if (!el) return;

    const observer = getSharedIntersectionObserver();
    if (!observer) {
      setIsInView(true);
      return;
    }

    observedElements.set(el, () => setIsInView(true));
    observer.observe(el);

    return () => {
      observedElements.delete(el);
      observer.unobserve(el);
    };
  }, [priority, isInView]);

  let currentSrc = '';
  if (cleanUrl) {
    if (fallbackStep === 0) {
      currentSrc = initialOptimized;
    } else if (fallbackStep === 1) {
      currentSrc = cleanUrl;
    } else {
      currentSrc = `/api/image-proxy?url=${encodeURIComponent(cleanUrl)}`;
    }
  }

  const handleLoad = useCallback(() => {
    if (currentSrc) decodedUrlsCache.add(currentSrc);
    setIsLoaded(true);
  }, [currentSrc]);

  const handleError = useCallback(() => {
    if (fallbackStep === 0 && cleanUrl) {
      failedProxies.add(cleanUrl);
      setFallbackStep(1);
    } else if (fallbackStep === 1 && cleanUrl) {
      setFallbackStep(2);
    } else {
      setIsLoaded(true);
    }
  }, [fallbackStep, cleanUrl]);

  return {
    containerRef,
    isInView,
    isLoaded,
    currentSrc,
    handleLoad,
    handleError,
  };
}
