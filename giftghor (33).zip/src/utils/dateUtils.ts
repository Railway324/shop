/**
 * Safe Date Parsing and Formatting Utilities
 * Prevents RangeError: Invalid time value and React White Screen crashes
 * when processing orders with non-standard date formats (e.g. DD/MM/YYYY, ISO, timestamps).
 */

export function safeParseDate(input: any): Date {
  if (!input) {
    return new Date();
  }

  if (input instanceof Date) {
    return isNaN(input.getTime()) ? new Date() : input;
  }

  if (typeof input === 'number') {
    const d = new Date(input);
    return isNaN(d.getTime()) ? new Date() : d;
  }

  if (typeof input === 'string') {
    const trimmed = input.trim();
    if (!trimmed) return new Date();

    // Check for DD/MM/YYYY or DD-MM-YYYY (e.g., "22/09/2026" or "22-09-2026")
    const slashParts = trimmed.split(/[/ -]/);
    if (slashParts.length >= 3 && slashParts[0].length <= 2 && slashParts[2].length === 4) {
      const day = parseInt(slashParts[0], 10);
      const month = parseInt(slashParts[1], 10) - 1;
      const year = parseInt(slashParts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        const parsed = new Date(year, month, day);
        if (!isNaN(parsed.getTime())) {
          return parsed;
        }
      }
    }

    // Try default ISO/Date parser
    try {
      const parsed = new Date(trimmed);
      if (!isNaN(parsed.getTime())) {
        return parsed;
      }
    } catch {
      // Ignore error
    }
  }

  return new Date();
}

/**
 * Returns YYYY-MM-DD string safely without throwing RangeError.
 */
export function safeDateToISODate(input: any): string {
  try {
    const d = safeParseDate(input);
    return d.toISOString().split('T')[0];
  } catch {
    return new Date().toISOString().split('T')[0];
  }
}

/**
 * Formats a date using toLocaleDateString safely with error recovery.
 */
export function safeDateToLocaleString(
  input: any,
  locale: string = 'en-US',
  options?: Intl.DateTimeFormatOptions
): string {
  try {
    const d = safeParseDate(input);
    return d.toLocaleDateString(locale, options);
  } catch {
    return new Date().toLocaleDateString(locale, options);
  }
}

/**
 * Formats date and time safely.
 */
export function safeDateToDateTimeString(
  input: any,
  locale: string = 'en-US',
  options?: Intl.DateTimeFormatOptions
): string {
  try {
    const d = safeParseDate(input);
    return d.toLocaleString(locale, options);
  } catch {
    return new Date().toLocaleString(locale, options);
  }
}
