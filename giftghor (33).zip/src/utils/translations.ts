import { Language, OrderStatus } from '../types';

export const toBengaliNumber = (num: number | string | undefined | null): string => {
  if (num === undefined || num === null) return '০';
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/[0-9]/g, (w) => bnDigits[+w]);
};

export const toEnglishNumber = (str: string | undefined | null): string => {
  if (!str) return '';
  const bnToEnMap: Record<string, string> = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
  };
  return String(str).replace(/[০-৯]/g, (w) => bnToEnMap[w] || w);
};

export const formatPrice = (amount: number | undefined | null, lang: Language): string => {
  const safeAmount = typeof amount === 'number' && !isNaN(amount) ? amount : (Number(amount) || 0);
  const formatted = safeAmount.toLocaleString();
  if (lang === 'bn') {
    return `৳${toBengaliNumber(formatted)}`;
  }
  return `৳${formatted}`;
};

export const translations = {
  bn: {
    // Header & Brand
    storeName: 'হ্যাপি শপিং',
    storeTagline: 'Better Product • Happier You',
    searchPlaceholder: 'পণ্য বা ক্যাটাগরি অনুসন্ধান করুন...',
    hotline: 'হটলাইন: 01700-000000',
    trackOrderNav: 'অর্ডার ট্র্যাকিং',
    cartNav: 'কার্ট',
    adminNav: 'এডমিন প্যানেল',
    homeNav: 'হোম',
    allProductsNav: 'সকল পণ্য',

    // Badges & Offers
    freeDeliveryBadge: '১৫০০ টাকার অর্ডারে ফ্রি হোম ডেলিভারি!',
    codAvailable: 'সারা দেশে ক্যাশ অন ডেলিভারি সুবিধা',
    authenticGuaranteed: '১০০% অরিজিনাল পণ্য',
    easyReturn: '৭ দিনের সহজ রিটার্ন পলিসি',

    // Sections
    flashSaleTitle: 'ফ্ল্যাশ সেল',
    flashSaleSubtitle: 'সীমিত সময়ের জন্য বিশেষ মূল্যছাড়',
    flashSaleEnds: 'অফার শেষ হতে বাকি:',
    categoriesTitle: 'জনপ্রিয় ক্যাটাগরি সমূহ',
    featuredProductsTitle: 'সেরা ফিচার্ড পণ্যসমূহ',
    allProductsTitle: 'পণ্য সম্ভার',
    similarProductsTitle: 'অনুরূপ পণ্যসমূহ',
    viewAll: 'সব দেখুন',

    // Product Card & Details
    addToCart: 'কার্টে যোগ করুন',
    buyNow: 'এখনই কিনুন',
    addedToCart: 'কার্টে যোগ করা হয়েছে!',
    inStock: 'স্টকে আছে',
    outOfStock: 'স্টক শেষ',
    itemsLeft: 'টি পণ্য বাকি',
    rating: 'রেটিং',
    reviews: 'রিভিউ',
    specifications: 'বৈশিষ্ট্য ও স্পেসিফিকেশন',
    description: 'পণ্যের বিবরণ',
    deliveryReturnInfo: 'ডেলিভারি ও রিটার্ন তথ্য',
    dhakaDelivery: 'ঢাকার ভিতরে ২-৩ কার্যদিবসের মধ্যে ডেলিভারি (৳৬০)',
    outsideDhakaDelivery: 'ঢাকার বাইরে ৩-৫ কার্যদিবসের মধ্যে ডেলিভারি (৳১২০)',
    codNotice: 'পণ্য হাতে পেয়ে চেক করে মূল্য পরিশোধ করুন',

    // Filters & Sorting
    filters: 'ফিল্টার',
    category: 'ক্যাটাগরি',
    allCategories: 'সব ক্যাটাগরি',
    priceRange: 'মূল্য সীমা',
    minPrice: 'সর্বনিম্ন',
    maxPrice: 'সর্বোচ্চ',
    onlyInStock: 'শুধুমাত্র স্টকে থাকা পণ্য',
    sortBy: 'সর্টিং',
    sortPopular: 'জনপ্রিয়তা অনুযায়ী',
    sortPriceLow: 'দাম: কম থেকে বেশি',
    sortPriceHigh: 'দাম: বেশি থেকে কম',
    sortNewest: 'নতুন আগমন',
    sortDiscount: 'সর্বোচ্চ ছাড়',
    resetFilters: 'ফিল্টার রিসেট',
    productsFound: 'টি পণ্য পাওয়া গেছে',
    noProductsFound: 'কোনো পণ্য খুঁজে পাওয়া যায়নি!',

    // Cart
    yourCart: 'আপনার শপিং কার্ট',
    emptyCartTitle: 'আপনার কার্ট খালি!',
    emptyCartDesc: 'পছন্দের পণ্য কার্টে যুক্ত করুন এবং কেনাকাটা শুরু করুন।',
    continueShopping: 'কেনাকাটা চালিয়ে যান',
    checkout: 'অর্ডার নিশ্চিত করতে এগিয়ে যান',
    subtotal: 'সাবটোটাল',
    deliveryFee: 'ডেলিভারি চার্জ',
    free: 'ফ্রি',
    discount: 'ছাড়',
    couponCode: 'কুপন কোড',
    applyCoupon: 'প্রয়োগ করুন',
    couponSuccess: 'কুপন প্রয়োগ করা হয়েছে!',
    couponInvalid: 'অকার্যকর কুপন কোড (ব্যবহার করুন: EID50 বা SHOPPINGMALL)',
    totalAmount: 'সর্বমোট',

    // Checkout
    checkoutTitle: 'ডেলিভারি তথ্য ও পেমেন্ট',
    customerInfo: 'গ্রাহকের তথ্য',
    fullName: 'আপনার সম্পূর্ণ নাম',
    fullNamePlaceholder: '',
    phone: 'মোবাইল নম্বর',
    phonePlaceholder: '',
    division: 'বিভাগ',
    district: 'জেলা',
    thana: 'থানা / উপজেলা',
    selectDivision: 'বিভাগ নির্বাচন করুন',
    selectDistrict: 'জেলা নির্বাচন করুন',
    selectThana: 'থানা/উপজেলা নির্বাচন করুন',
    fullAddress: 'বিস্তারিত ঠিকানা (বাসা/রোড/এলাকা)',
    addressPlaceholder: '',
    orderNotes: 'অর্ডার নোট (ঐচ্ছিক)',
    orderNotesPlaceholder: 'ডেলিভারি সংক্রান্ত কোনো বিশেষ নির্দেশ থাকলে লিখুন...',

    // Payment Methods
    paymentMethod: 'মূল্য পরিশোধের মাধ্যম',
    cod: 'ক্যাশ অন ডেলিভারি (COD)',
    codDesc: 'পণ্য হাতে পেয়ে মূল্য পরিশোধ করুন। কোনো অগ্রিম টাকা দেওয়ার প্রয়োজন নেই।',
    bkash: 'বিকাশ (ম্যানুয়াল সেন্ড মানি)',
    bkashDesc: 'বিকাশে সেন্ড মানি করে TrxID প্রদান করুন।',
    nagad: 'নগদ (ম্যানুয়াল সেন্ড মানি)',
    nagadDesc: 'নগদে সেন্ড মানি করে TrxID প্রদান করুন।',
    card: 'ভিসা ও মাস্টারকার্ড (Visa / Mastercard)',
    cardDesc: 'যেকোনো ডেবিট বা ক্রেডিট কার্ড দিয়ে পেমেন্ট করুন।',
    cardPaymentTitle: 'কার্ড পেমেন্ট বিবরণ',
    cardNumber: 'কার্ড নম্বর',
    cardHolderName: 'কার্ডধারীর নাম',
    cardExpiry: 'মেয়াদ (MM/YY)',
    cardCvv: 'CVV / CVC',
    cardPayNow: 'নিরাপদে কার্ডে পেমেন্ট করুন',
    verifyPayment: 'পেমেন্ট যাচাই করুন',
    paymentVerified: 'পেমেন্ট ভেরিফাইড',
    manualTrxIdPay: 'সেন্ড মানি করে TrxID দিন',
    verifyingPayment: 'পেমেন্ট ভেরিফাই করা হচ্ছে...',
    paymentSuccessNotice: 'পেমেন্ট তথ্য সফলভাবে যুক্ত হয়েছে!',
    paymentInstructionHeader: 'ম্যানুয়াল পেমেন্ট নির্দেশিকা:',
    sendMoneyTo: 'নিচের নম্বরে সেন্ড মানি (Send Money) করুন (পার্সোনাল নম্বর):',
    merchantNumber: '০১৭০০-০০০০০০',
    trxIdLabel: 'ট্রানজেকশন আইডি (TrxID)',
    trxIdPlaceholder: 'যেমন: 9J3K8L2M',
    senderPhoneLabel: 'প্রেরকের মোবাইল নম্বর (যে নম্বর থেকে পাঠিয়েছেন)',
    senderPhonePlaceholder: 'যেমন: 017XXXXXXXX',
    placeOrder: 'অর্ডার কনফার্ম করুন',
    placingOrder: 'অর্ডার প্রস্তুত হচ্ছে...',

    // Order Tracking
    trackYourOrder: 'আপনার অর্ডার ট্র্যাক করুন',
    trackOrderSubtitle: 'আপনার অর্ডার আইডি বা মোবাইল নম্বর দিয়ে অর্ডারের বর্তমান অবস্থা জানুন',
    orderIdOrPhone: 'অর্ডার আইডি অথবা ফোন নম্বর',
    orderIdPlaceholder: 'অর্ডার আইডি বা মোবাইল নম্বর লিখুন',
    trackButton: 'ট্র্যাক করুন',
    orderNotFound: 'কোনো অর্ডার খুঁজে পাওয়া যায়নি। অনুগ্রহ করে সঠিক অর্ডার আইডি বা ফোন নম্বর দিন।',
    orderDetails: 'অর্ডার বিবরণ',
    orderId: 'অর্ডার আইডি',
    orderDate: 'অর্ডারের তারিখ',
    orderStatus: 'বর্তমান স্ট্যাটাস',
    estimatedDelivery: 'আনুমানিক ডেলিভারি সময়',
    deliveryAddress: 'ডেলিভারি ঠিকানা',
    orderedItems: 'অর্ডারকৃত পণ্যসমূহ',
    courierPartner: 'কুরিয়ার পার্টনার',
    courierTrackingId: 'কুরিয়ার ট্র্যাকিং কোড',

    // Status Timeline
    statusPlaced: 'পেন্ডিং (অনুমোদনের অপেক্ষায়)',
    statusConfirmed: 'অনুমোদিত (Approved)',
    statusProcessing: 'পণ্য প্যাকেজিং ও প্রস্তুতকরণ',
    statusShipped: 'কুরিয়ারে হস্তান্তর করা হয়েছে',
    statusDelivered: 'সফলভাবে ডেলিভারি সম্পন্ন',
    statusCancelled: 'অর্ডার বাতিল করা হয়েছে',

    // Order Success
    orderSuccessTitle: 'অভিনন্দন! আপনার অর্ডারটি সফলভাবে গৃহীত হয়েছে।',
    orderSuccessDesc: 'শীঘ্রই আমাদের প্রতিনিধি আপনার সাথে ফোন করে অর্ডারটি কনফার্ম করবে।',
    copyOrderId: 'অর্ডার আইডি কপি করুন',
    copied: 'কপি হয়েছে!',
    trackNow: 'অর্ডার ট্র্যাক করুন',

    // Admin Panel
    adminTitle: 'Shopping Mall এডমিন ড্যাশবোর্ড',
    adminSubtitle: 'পণ্য ও অর্ডার পরিচালনা করুন',
    enterAdminPin: 'এডমিন সিকিউরিটি পিন দিন (ডিফল্ট: 1234)',
    adminPinPlaceholder: 'পিন কোড দিন...',
    loginAdmin: 'প্রবেশ করুন',
    adminStats: 'বিক্রয় সারসংক্ষেপ',
    totalRevenue: 'মোট বিক্রয়',
    totalOrders: 'মোট অর্ডার',
    totalProducts: 'মোট পণ্য',
    pendingOrders: 'অপেক্ষারত অর্ডার',
    manageProducts: 'পণ্য ব্যবস্থাপনা',
    manageOrders: 'অর্ডার ব্যবস্থাপনা',
    addNewProduct: 'নতুন পণ্য যোগ করুন',
    editProduct: 'পণ্য সম্পাদনা',
    productTitleBn: 'পণ্যের নাম (বাংলা)',
    productTitleEn: 'পণ্যের নাম (ইংরেজি)',
    priceLabel: 'মূল্য (৳)',
    originalPriceLabel: 'আগের মূল্য (৳, যদি থাকে)',
    stockLabel: 'স্টক সংখ্যা',
    imageUrlLabel: 'ছবির লিংক (URL)',
    descriptionBnLabel: 'বিবরণ (বাংলা)',
    descriptionEnLabel: 'বিবরণ (ইংরেজি)',
    saveProduct: 'সংরক্ষণ করুন',
    cancel: 'বাতিল',
    deleteProductConfirm: 'আপনি কি নিশ্চিতভাবে এই পণ্যটি মুছে ফেলতে চান?',
    actions: 'অ্যাকশন',
    edit: 'এডিট',
    delete: 'ডিলিট',
    updateStatus: 'স্ট্যাটাস পরিবর্তন করুন',
    customer: 'গ্রাহক',
    changePaymentStatus: 'পেমেন্ট স্ট্যাটাস',
    paid: 'পরিশোধিত',
    pending: 'অপেক্ষমাণ',
    verified: 'যাচাইকৃত',

    // Footer
    aboutShopTitle: 'Happy Shopping সম্পর্কে',
    aboutShopDesc: 'Happy Shopping একটি বিশ্বস্ত অনলাইন শপ। "Better Product • Happier You" প্রত্যয়ে আমরা গ্রাহকদের জন্য সেরা পোশাক, ফ্যাশন, লাইফস্টাইল ও মানসম্পন্ন পণ্য এবং দ্রুততম হোম ডেলিভারি নিশ্চিত করি।',
    customerServiceTitle: 'গ্রাহক সেবা',
    privacyPolicy: 'গোপনীয়তা নীতি',
    termsConditions: 'ব্যবহারের শর্তাবলী',
    returnRefund: 'রিটার্ন ও রিফান্ড নীতি',
    faq: 'সাধারণ জিজ্ঞাসা (FAQ)',
    contactUs: 'যোগাযোগের ঠিকানা',
    addressText: 'বাড়ি # ৪৫, ধানমন্ডি ২৭, ঢাকা ১২০৯, বাংলাদেশ',
    emailText: 'support@happyshopping.com',
    paymentPartners: 'পেমেন্ট পার্টনারস',
    allRightsReserved: 'সর্বস্বত্ব সংরক্ষিত © ২০২৬ Happy Shopping',
  },
  en: {
    // Header & Brand
    storeName: 'Happy Shopping',
    storeTagline: 'Better Product • Happier You',
    searchPlaceholder: 'Search products or categories...',
    hotline: 'Hotline: 01700-000000',
    trackOrderNav: 'Track Order',
    cartNav: 'Cart',
    adminNav: 'Admin Panel',
    homeNav: 'Home',
    allProductsNav: 'All Products',

    // Badges & Offers
    freeDeliveryBadge: 'Free home delivery on orders over ৳1,500!',
    codAvailable: 'Cash on Delivery Nationwide in Bangladesh',
    authenticGuaranteed: '100% Authentic Products',
    easyReturn: '7-Day Easy Return Policy',

    // Sections
    flashSaleTitle: 'Flash Sale',
    flashSaleSubtitle: 'Special discounts for a limited time',
    flashSaleEnds: 'Offer ends in:',
    categoriesTitle: 'Popular Categories',
    featuredProductsTitle: 'Featured Top Picks',
    allProductsTitle: 'Our Products',
    similarProductsTitle: 'Similar Products',
    viewAll: 'View All',

    // Product Card & Details
    addToCart: 'Add to Cart',
    buyNow: 'Buy Now',
    addedToCart: 'Added to Cart!',
    inStock: 'In Stock',
    outOfStock: 'Out of Stock',
    itemsLeft: 'items left',
    rating: 'Rating',
    reviews: 'Reviews',
    specifications: 'Key Specifications',
    description: 'Product Description',
    deliveryReturnInfo: 'Delivery & Return Info',
    dhakaDelivery: 'Inside Dhaka delivery within 2-3 business days (৳60)',
    outsideDhakaDelivery: 'Outside Dhaka delivery within 3-5 business days (৳120)',
    codNotice: 'Check the parcel and pay upon receiving',

    // Filters & Sorting
    filters: 'Filters',
    category: 'Category',
    allCategories: 'All Categories',
    priceRange: 'Price Range',
    minPrice: 'Min',
    maxPrice: 'Max',
    onlyInStock: 'In Stock Only',
    sortBy: 'Sort By',
    sortPopular: 'Most Popular',
    sortPriceLow: 'Price: Low to High',
    sortPriceHigh: 'Price: High to Low',
    sortNewest: 'New Arrivals',
    sortDiscount: 'Biggest Discount',
    resetFilters: 'Reset Filters',
    productsFound: 'products found',
    noProductsFound: 'No products found!',

    // Cart
    yourCart: 'Your Shopping Cart',
    emptyCartTitle: 'Your cart is empty!',
    emptyCartDesc: 'Explore our catalog and add your favorite items to cart.',
    continueShopping: 'Continue Shopping',
    checkout: 'Proceed to Checkout',
    subtotal: 'Subtotal',
    deliveryFee: 'Delivery Fee',
    free: 'Free',
    discount: 'Discount',
    couponCode: 'Coupon Code',
    applyCoupon: 'Apply',
    couponSuccess: 'Coupon applied successfully!',
    couponInvalid: 'Invalid coupon (Try: EID50 or SHOPPINGMALL)',
    totalAmount: 'Total Amount',

    // Checkout
    checkoutTitle: 'Delivery Information & Payment',
    customerInfo: 'Customer Information',
    fullName: 'Full Name',
    fullNamePlaceholder: '',
    phone: 'Phone Number',
    phonePlaceholder: '',
    division: 'Division',
    district: 'District',
    thana: 'Thana / Upazila',
    selectDivision: 'Select Division',
    selectDistrict: 'Select District',
    selectThana: 'Select Thana / Upazila',
    fullAddress: 'Detailed Address (House/Road/Area)',
    addressPlaceholder: '',
    orderNotes: 'Order Notes (Optional)',
    orderNotesPlaceholder: 'Special instructions for delivery...',

    // Payment Methods
    paymentMethod: 'Select Payment Method',
    cod: 'Cash on Delivery (COD)',
    codDesc: 'Pay in cash when you receive the product. Zero advance payment.',
    bkash: 'bKash (Manual Send Money)',
    bkashDesc: 'Send Money to personal number & enter TrxID.',
    nagad: 'Nagad (Manual Send Money)',
    nagadDesc: 'Send Money to personal number & enter TrxID.',
    card: 'Visa & Mastercard',
    cardDesc: 'Secure checkout with any Debit or Credit Card.',
    cardPaymentTitle: 'Card Details',
    cardNumber: 'Card Number',
    cardHolderName: 'Cardholder Name',
    cardExpiry: 'Expiry (MM/YY)',
    cardCvv: 'CVV / CVC',
    cardPayNow: 'Pay Securely via Card',
    verifyPayment: 'Verify Payment',
    paymentVerified: 'Payment Verified',
    manualTrxIdPay: 'Send Money & Enter TrxID',
    verifyingPayment: 'Verifying payment info...',
    paymentSuccessNotice: 'Payment info submitted successfully!',
    paymentInstructionHeader: 'Manual Payment Instructions:',
    sendMoneyTo: 'Please Send Money to this Personal Account number:',
    merchantNumber: '01700-000000',
    trxIdLabel: 'Transaction ID (TrxID)',
    trxIdPlaceholder: 'e.g. 9J3K8L2M',
    senderPhoneLabel: 'Sender Phone Number',
    senderPhonePlaceholder: 'e.g. 017XXXXXXXX',
    placeOrder: 'Confirm Order',
    placingOrder: 'Placing order...',

    // Order Tracking
    trackYourOrder: 'Track Your Order',
    trackOrderSubtitle: 'Enter your Order ID or phone number to check current live delivery status',
    orderIdOrPhone: 'Order ID or Phone Number',
    orderIdPlaceholder: 'e.g. SM-82914 or 017XXXXXXXX',
    trackButton: 'Track',
    orderNotFound: 'No order found with this information. Please verify your Order ID or phone number.',
    orderDetails: 'Order Details',
    orderId: 'Order ID',
    orderDate: 'Order Date',
    orderStatus: 'Current Status',
    estimatedDelivery: 'Estimated Delivery',
    deliveryAddress: 'Delivery Address',
    orderedItems: 'Ordered Items',
    courierPartner: 'Courier Partner',
    courierTrackingId: 'Courier Tracking Code',

    // Status Timeline
    statusPlaced: 'Order Placed',
    statusConfirmed: 'Order Confirmed',
    statusProcessing: 'Packaging & Processing',
    statusShipped: 'Handed to Courier',
    statusDelivered: 'Delivered Successfully',
    statusCancelled: 'Order Cancelled',

    // Order Success
    orderSuccessTitle: 'Congratulations! Your order has been placed.',
    orderSuccessDesc: 'Our customer representative will call you soon to confirm your order.',
    copyOrderId: 'Copy Order ID',
    copied: 'Copied!',
    trackNow: 'Track Order',

    // Admin Panel
    adminTitle: 'Happy Shopping Admin Dashboard',
    adminSubtitle: 'Manage products, stock, and orders',
    enterAdminPin: 'Enter Admin Security PIN (Default: 1234)',
    adminPinPlaceholder: 'Enter PIN...',
    loginAdmin: 'Access Dashboard',
    adminStats: 'Sales Overview',
    totalRevenue: 'Total Revenue',
    totalOrders: 'Total Orders',
    totalProducts: 'Total Products',
    pendingOrders: 'Pending Orders',
    manageProducts: 'Manage Products',
    manageOrders: 'Manage Orders',
    addNewProduct: 'Add New Product',
    editProduct: 'Edit Product',
    productTitleBn: 'Product Title (Bengali)',
    productTitleEn: 'Product Title (English)',
    priceLabel: 'Price (৳)',
    originalPriceLabel: 'Original Price (৳, if any)',
    stockLabel: 'Stock Quantity',
    imageUrlLabel: 'Image URL',
    descriptionBnLabel: 'Description (Bengali)',
    descriptionEnLabel: 'Description (English)',
    saveProduct: 'Save Product',
    cancel: 'Cancel',
    deleteProductConfirm: 'Are you sure you want to delete this product?',
    actions: 'Actions',
    edit: 'Edit',
    delete: 'Delete',
    updateStatus: 'Update Status',
    customer: 'Customer',
    changePaymentStatus: 'Payment Status',
    paid: 'Paid',
    pending: 'Pending',
    verified: 'Verified',

    // Footer
    aboutShopTitle: 'About Happy Shopping',
    aboutShopDesc: 'Happy Shopping is a premier online retail store. Guided by "Better Product • Happier You", we ensure 100% authentic quality apparel, gifts and lifestyle items with express nationwide delivery.',
    customerServiceTitle: 'Customer Care',
    privacyPolicy: 'Privacy Policy',
    termsConditions: 'Terms & Conditions',
    returnRefund: 'Return & Refund Policy',
    faq: 'FAQ',
    contactUs: 'Store Address',
    addressText: 'House #45, Dhanmondi 27, Dhaka 1209, Bangladesh',
    emailText: 'support@happyshopping.com',
    paymentPartners: 'Payment Partners',
    allRightsReserved: 'All rights reserved © 2026 Happy Shopping',
  }
};

export const getStatusLabel = (status: OrderStatus, lang: Language): string => {
  switch (status) {
    case 'pending':
    case 'placed':
      return lang === 'bn' ? 'পেন্ডিং (অনুমোদনের অপেক্ষায়)' : 'Pending Approval';
    case 'confirmed':
      return lang === 'bn' ? 'অনুমোদিত (Approved)' : 'Approved / Confirmed';
    case 'processing':
    case 'packed':
      return lang === 'bn' ? 'প্যাকেজিং ও প্রস্তুতকরণ' : 'Packaging & Processing';
    case 'shipped':
    case 'out_for_delivery':
      return lang === 'bn' ? 'কুরিয়ারে পাঠানো হয়েছে' : 'Shipped';
    case 'delivered':
      return lang === 'bn' ? 'ডেলিভারি সম্পন্ন' : 'Delivered';
    case 'cancelled':
      return lang === 'bn' ? 'বাতিল' : 'Cancelled';
    case 'returned':
      return lang === 'bn' ? 'রিটার্ন' : 'Returned';
    default:
      return status;
  }
};
