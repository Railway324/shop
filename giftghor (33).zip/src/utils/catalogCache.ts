import { Product } from '../types';

export const CATALOG_CACHE_VERSION = 'v49_exact_names_sizes_colors';
const IDB_NAME = 'happy_shopping_fast_catalog_db';
const IDB_STORE = 'catalog_store';
const IDB_KEY = `products_index_${CATALOG_CACHE_VERSION}`;

const fullDetailMemCache = new Map<string, Product>();
let inFlightCatalogPromise: Promise<Product[]> | null = null;
let saveDebounceTimer: ReturnType<typeof setTimeout> | null = null;

function openCatalogDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export async function readCatalogFromIdb(): Promise<Product[] | null> {
  const db = await openCatalogDb();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.get(IDB_KEY);
      req.onsuccess = () => {
        const val = req.result;
        resolve(Array.isArray(val) && val.length > 0 ? (val as Product[]) : null);
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export async function writeCatalogToIdb(products: Product[]): Promise<void> {
  if (!Array.isArray(products) || products.length < 100) return;
  const db = await openCatalogDb();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      // Clean up old cache versions while writing current one
      const keysReq = store.getAllKeys();
      keysReq.onsuccess = () => {
        for (const k of keysReq.result || []) {
          if (String(k) !== IDB_KEY) {
            store.delete(k);
          }
        }
      };
      store.put(products, IDB_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

export function scheduleCatalogSaveToIdb(products: Product[]): void {
  if (!Array.isArray(products) || products.length < 100) return;
  if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    writeCatalogToIdb(products).catch(() => {});
  }, 900);
}

async function fetchNetworkCatalogIndex(): Promise<Product[]> {
  try {
    const res = await fetch('/api/products-index');
    const ct = res.headers.get('content-type') || '';
    if (res.ok && ct.includes('application/json')) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        return data as Product[];
      }
    }
  } catch {
    // Fall through to async chunk fallback
  }

  // Fallback to /api/products if /api/products-index is unavailable
  try {
    const res = await fetch('/api/products');
    const ct = res.headers.get('content-type') || '';
    if (res.ok && ct.includes('application/json')) {
      const list = (await res.json()) as Product[];
      if (Array.isArray(list) && list.length > 0) {
        return list;
      }
    }
  } catch {
    // Ignore
  }
  return [];
}

/**
 * Loads the full 3,073+ product catalog index without blocking initial render:
 * 1. Immediately resolves from IndexedDB if cached (~15ms), and refreshes from /api/products-index in background.
 * 2. Otherwise fetches pre-gzipped /api/products-index (~220 KB) and caches in IndexedDB.
 */
export async function loadFastCatalogIndex(
  onBackgroundRefresh?: (fresh: Product[]) => void
): Promise<Product[]> {
  const cached = await readCatalogFromIdb();
  if (cached && cached.length > 100) {
    // Revalidate quietly in the background after 1.2s so initial images get 100% bandwidth
    setTimeout(() => {
      fetchNetworkCatalogIndex()
        .then((fresh) => {
          if (fresh.length > 0) {
            writeCatalogToIdb(fresh).catch(() => {});
            if (onBackgroundRefresh) onBackgroundRefresh(fresh);
          }
        })
        .catch(() => {});
    }, 1200);
    return cached;
  }

  if (!inFlightCatalogPromise) {
    inFlightCatalogPromise = fetchNetworkCatalogIndex().finally(() => {
      inFlightCatalogPromise = null;
    });
  }
  const fresh = await inFlightCatalogPromise;
  if (fresh.length > 0) {
    writeCatalogToIdb(fresh).catch(() => {});
  }
  return fresh;
}

/**
 * Fetches full details (long description, additionalImages gallery, specifications)
 * for a single product in < 15ms from the server's in-memory map.
 */
export async function fetchFullProductDetails(productId: string): Promise<Product | null> {
  if (!productId) return null;
  const cached = fullDetailMemCache.get(productId);
  if (cached) return cached;

  try {
    const res = await fetch(`/api/products/${encodeURIComponent(productId)}`);
    const ct = res.headers.get('content-type') || '';
    if (res.ok && ct.includes('application/json')) {
      const fullProd = (await res.json()) as Product;
      if (fullProd && fullProd.id) {
        fullDetailMemCache.set(productId, fullProd);
        return fullProd;
      }
    }
  } catch {
    // Ignore network error
  }
  return null;
}

export function primeFullProductDetailCache(product: Product): void {
  if (product && product.id && (product.additionalImages?.length || (product.descriptionBn && product.descriptionBn.length > 260))) {
    fullDetailMemCache.set(product.id, product);
  }
}
