import { 
  Product, 
  Order, 
  CartItem, 
  Language, 
  Coupon, 
  ProductReview, 
  StockLog, 
  AdminUser, 
  StoreSettings, 
  DeliverySettings, 
  SeoSettings, 
  ActivityLogItem, 
  AdminNotification,
  Banner,
  WebsiteCustomizerSettings,
  TrustFeature
} from '../types';
import { initialProducts, initialOrders, initialBanners } from '../data/initialData';
import { saveSettingsToFirestore, getSettingsFromFirestore } from '../lib/firebase';
import { scheduleCatalogSaveToIdb } from './catalogCache';

const STORAGE_KEYS = {
  PRODUCTS: 'shopping_mall_products_live_catalog_v49_exact_names_sizes_colors',
  ORDERS: 'shopping_mall_orders_v5',
  CART: 'shopping_mall_cart_v7_variants_clean',
  LANGUAGE: 'shopping_mall_lang_v4',
  COUPONS: 'shopping_mall_coupons_v1',
  REVIEWS: 'shopping_mall_reviews_v1',
  STOCK_LOGS: 'shopping_mall_stock_logs_v1',
  ADMIN_USERS: 'shopping_mall_admin_users_v1',
  STORE_SETTINGS: 'shopping_mall_store_settings_v1',
  DELIVERY_SETTINGS: 'shopping_mall_delivery_settings_v1',
  SEO_SETTINGS: 'shopping_mall_seo_settings_v1',
  ACTIVITY_LOGS: 'shopping_mall_activity_logs_v1',
  NOTIFICATIONS: 'shopping_mall_notifications_v1',
  BANNERS: 'shopping_mall_banners_v2_gdrive',
  CUSTOMIZER: 'gift_ghor_customizer_settings_v1',
  DELETED_PRODUCT_IDS: 'shopping_mall_deleted_product_ids_v4_fresh',
};

let didCleanupStorageOnce = false;

// Safely clear old / obsolete localStorage versions to free up quota (runs at most once per session)
export const cleanupOldStorageVersions = () => {
  if (didCleanupStorageOnce) return;
  didCleanupStorageOnce = true;
  try {
    if (typeof localStorage === 'undefined') return;
    const currentKeys = new Set(Object.values(STORAGE_KEYS));
    const keysToRemove: string[] = [];
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (
        key.startsWith('shopping_mall_products_') || 
        key.startsWith('gift_ghor_products_') ||
        key.startsWith('shopping_mall_orders_') ||
        key.startsWith('shopping_mall_cart_')
      )) {
        // Always remove large product blobs from localStorage (products now live in IndexedDB)
        if (key.startsWith('shopping_mall_products_') || key.startsWith('gift_ghor_products_') || !currentKeys.has(key)) {
          keysToRemove.push(key);
        }
      }
    }

    keysToRemove.forEach(k => {
      try {
        localStorage.removeItem(k);
      } catch (_) {}
    });
  } catch (_) {}
};

// Safe localStorage setItem with automatic quota management
export const safeLocalStorageSet = (key: string, value: string): boolean => {
  try {
    if (typeof localStorage === 'undefined') return false;
    localStorage.setItem(key, value);
    return true;
  } catch (err: any) {
    // If quota exceeded, clean up old storage keys and try once more
    cleanupOldStorageVersions();
    try {
      localStorage.setItem(key, value);
      return true;
    } catch (retryErr) {
      // If still exceeding, try cleaning non-critical temporary keys
      try {
        const nonCritical = ['shopping_mall_stock_logs_v1', 'shopping_mall_activity_logs_v1', 'shopping_mall_notifications_v1'];
        nonCritical.forEach(k => { if (k !== key) localStorage.removeItem(k); });
        localStorage.setItem(key, value);
        return true;
      } catch (finalErr) {
        // Silently fallback without throwing uncaught errors
        return false;
      }
    }
  }
};

const OBSOLETE_PRODUCT_IDS = new Set([
  'prod-trendy-premium-hoodie',
  'prod-drop-shoulder-hoodie',
  'prod-stylish-hoodie',
  'prod-cotton-hoodie',
  'prod-cotton-and-brush-hoodie',
  'prod-hoodie-colorblock-superhero',
  'prod-hoodie-drop-shoulder-tokyo',
  'prod-winter-dropshoulder-hoodie',
  'prod-winter-zipper-jacket-hoodie',
]);

let cachedDeletedIdsList: string[] | null = null;
let cachedDeletedIdsSet: Set<string> | null = null;

export const getStoredDeletedProductIds = (): string[] => {
  if (cachedDeletedIdsList !== null) return cachedDeletedIdsList;
  try {
    if (typeof localStorage === 'undefined') return [];
    const raw = localStorage.getItem(STORAGE_KEYS.DELETED_PRODUCT_IDS);
    if (!raw) {
      cachedDeletedIdsList = [];
      cachedDeletedIdsSet = new Set();
      return cachedDeletedIdsList;
    }
    const parsed = JSON.parse(raw);
    cachedDeletedIdsList = Array.isArray(parsed) ? parsed.map(String).map(s => s.trim()).filter(Boolean) : [];
    cachedDeletedIdsSet = new Set(cachedDeletedIdsList);
    return cachedDeletedIdsList;
  } catch {
    cachedDeletedIdsList = [];
    cachedDeletedIdsSet = new Set();
    return cachedDeletedIdsList;
  }
};

export const getStoredDeletedProductIdsSet = (): Set<string> => {
  if (!cachedDeletedIdsSet) {
    getStoredDeletedProductIds();
  }
  return cachedDeletedIdsSet || new Set();
};

export const addDeletedProductIdToStorage = (id: string | string[]) => {
  try {
    const current = getStoredDeletedProductIds();
    const idsToAdd = Array.isArray(id) ? id : [id];
    const set = new Set(current);
    idsToAdd.forEach(i => {
      const clean = String(i || '').trim();
      if (clean) set.add(clean);
    });
    const updated = Array.from(set);
    cachedDeletedIdsList = updated;
    cachedDeletedIdsSet = set;
    if (typeof localStorage !== 'undefined') {
      safeLocalStorageSet(STORAGE_KEYS.DELETED_PRODUCT_IDS, JSON.stringify(updated));
    }
  } catch (err) {
    console.warn('Failed to add deleted product ID to storage:', err);
  }
};

export const isProductDeleted = (id: string): boolean => {
  if (!id) return false;
  const clean = String(id).trim();
  if (OBSOLETE_PRODUCT_IDS.has(clean)) return true;
  return getStoredDeletedProductIdsSet().has(clean);
};

export const sanitizeProduct = (p: Product): Product => p;

// Deduplicate products safely by ID, and strictly omit deleted products
export const deduplicateProducts = (products: Product[]): Product[] => {
  if (!Array.isArray(products)) return [];
  const seenIds = new Set<string>();
  const deletedIds = new Set(getStoredDeletedProductIds());
  const result: Product[] = [];

  for (const rawP of products) {
    if (!rawP) continue;
    const p = sanitizeProduct(rawP);
    const id = p.id ? String(p.id).trim() : '';
    if (id && (seenIds.has(id) || OBSOLETE_PRODUCT_IDS.has(id) || deletedIds.has(id))) {
      continue;
    }

    if (id) seenIds.add(id);
    result.push(p);
  }
  return result;
};

/**
 * Returns the ultra-fast 80-product home seed synchronously (< 1ms) for instant first paint,
 * while IndexedDB / /api/products-index hydrates all 3,073+ products asynchronously.
 */
export const getStoredProducts = (): Product[] => {
  try {
    cleanupOldStorageVersions();
    const deletedIds = new Set(getStoredDeletedProductIds());
    if (initialProducts && initialProducts.length > 0) {
      const activeInitial = initialProducts.filter(p => p && p.id && !deletedIds.has(String(p.id).trim()));
      return deduplicateProducts(activeInitial);
    }
    return [];
  } catch {
    return [];
  }
};

export const clearAllProductsStorage = () => {
  try {
    if (typeof localStorage !== 'undefined') {
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const key = localStorage.key(i);
        if (key && (key.startsWith('shopping_mall_products_') || key.startsWith('gift_ghor_products_'))) {
          localStorage.removeItem(key);
        }
      }
    }
  } catch (_) {}
};

export const saveProductsToStorage = (products: Product[]) => {
  try {
    // Persist full catalog asynchronously to IndexedDB without blocking the main thread
    scheduleCatalogSaveToIdb(products);
  } catch {
    // Handled safely
  }
};

// ==========================================
// Full-Stack Server Sync API Helpers
// ==========================================

export const fetchProductsFromServer = async (): Promise<Product[]> => {
  try {
    const res = await fetch('/api/products');
    const ct = res.headers.get('content-type');
    if (res.ok && ct && ct.includes('application/json')) {
      const data = await res.json();
      if (Array.isArray(data)) {
        return data;
      }
    }
  } catch (err) {
    console.warn('[Storage] Server fetch failed, using local/bundled data:', err);
  }
  return [];
};

export const syncProductsToServer = async (products: Product[]): Promise<boolean> => {
  try {
    const res = await fetch('/api/products/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ products })
    });
    const ct = res.headers.get('content-type');
    return res.ok && (!ct || ct.includes('application/json'));
  } catch (err) {
    console.warn('[Storage] Server sync failed:', err);
    return false;
  }
};

export const createProductOnServer = async (product: Partial<Product>): Promise<Product | null> => {
  try {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    const ct = res.headers.get('content-type');
    if (res.ok && ct && ct.includes('application/json')) {
      const json = await res.json();
      return json.product || null;
    }
  } catch (err) {
    console.warn('[Storage] Create product on server failed:', err);
  }
  return null;
};

export const updateProductOnServer = async (product: Product): Promise<Product | null> => {
  try {
    const res = await fetch(`/api/products/${encodeURIComponent(product.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product)
    });
    const ct = res.headers.get('content-type');
    if (res.ok && ct && ct.includes('application/json')) {
      const json = await res.json();
      return json.product || null;
    }
  } catch (err) {
    console.warn('[Storage] Update product on server failed:', err);
  }
  return null;
};

export const deleteProductOnServer = async (productId: string): Promise<boolean> => {
  try {
    const res = await fetch(`/api/products/${encodeURIComponent(productId)}`, {
      method: 'DELETE'
    });
    const ct = res.headers.get('content-type');
    return res.ok && (!ct || ct.includes('application/json'));
  } catch (err) {
    console.warn('[Storage] Delete product on server failed:', err);
    return false;
  }
};

export const bulkDeleteProductsOnServer = async (productIds: string[]): Promise<boolean> => {
  try {
    const res = await fetch('/api/products/bulk-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productIds })
    });
    return res.ok;
  } catch (err) {
    console.warn('[Storage] Bulk delete products on server failed:', err);
    return false;
  }
};

export const getStoredOrders = (): Order[] => {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.ORDERS) : null;
    if (!raw) {
      safeLocalStorageSet(STORAGE_KEYS.ORDERS, JSON.stringify([]));
      return [];
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map(o => ({
      ...o,
      items: Array.isArray(o.items) ? o.items.filter(it => it && it.product && it.product.id) : []
    }));
  } catch (e) {
    return [];
  }
};

export const saveOrdersToStorage = (orders: Order[]) => {
  try {
    safeLocalStorageSet(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  } catch (e) {}
};

export const getStoredCart = (): CartItem[] => {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.CART) : null;
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(it => it && it.product && it.product.id);
  } catch (e) {
    return [];
  }
};

export const saveCartToStorage = (cart: CartItem[]) => {
  try {
    safeLocalStorageSet(STORAGE_KEYS.CART, JSON.stringify(cart));
  } catch (e) {}
};

export const getStoredLanguage = (): Language => {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language : null;
    return raw === 'bn' ? 'en' : (raw || 'en');
  } catch {
    return 'en';
  }
};

export const saveLanguageToStorage = (lang: Language) => {
  try {
    safeLocalStorageSet(STORAGE_KEYS.LANGUAGE, lang);
  } catch (e) {}
};

// Initial Coupons
export const initialCoupons: Coupon[] = [
  {
    id: 'coup-1',
    code: 'EID50',
    discountType: 'fixed',
    discountValue: 50,
    minOrderAmount: 800,
    maxDiscount: 50,
    expiryDate: '2026-12-31',
    usageLimit: 500,
    usedCount: 42,
    perCustomerLimit: 1,
    isActive: true,
    createdAt: '2026-01-01'
  },
  {
    id: 'coup-2',
    code: 'SHOPPINGMALL',
    discountType: 'percentage',
    discountValue: 10,
    minOrderAmount: 1200,
    maxDiscount: 200,
    expiryDate: '2026-12-31',
    usageLimit: 1000,
    usedCount: 118,
    perCustomerLimit: 2,
    isActive: true,
    createdAt: '2026-01-05'
  },
  {
    id: 'coup-3',
    code: 'FREESHIP',
    discountType: 'fixed',
    discountValue: 60,
    minOrderAmount: 1500,
    expiryDate: '2026-12-31',
    usageLimit: 300,
    usedCount: 89,
    perCustomerLimit: 1,
    isActive: true,
    createdAt: '2026-02-01'
  }
];

export const getStoredCoupons = (): Coupon[] => {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.COUPONS) : null;
    if (!raw) {
      safeLocalStorageSet(STORAGE_KEYS.COUPONS, JSON.stringify(initialCoupons));
      return initialCoupons;
    }
    return JSON.parse(raw);
  } catch {
    return initialCoupons;
  }
};

export const saveCouponsToStorage = (coupons: Coupon[]) => {
  try {
    safeLocalStorageSet(STORAGE_KEYS.COUPONS, JSON.stringify(coupons));
  } catch (e) {}
};

// Initial Reviews
export const initialReviews: ProductReview[] = [
  {
    id: 'rev-1',
    productId: 'prod-1719939868',
    productTitle: 'পুরুষদের ফ্লোরাল গ্রাফিক প্রিন্ট শর্ট স্লিভ টি-শার্ট',
    userName: 'Tanvir Hossain',
    userEmail: 'tanvir@gmail.com',
    rating: 5,
    comment: 'কাপড়ের কোয়ালিটি অত্যন্ত চমৎকার এবং কালার একদম ছবির মতোই। ৪৫০ টাকায় দারুণ অফার!',
    status: 'approved',
    createdAt: '2026-09-08',
    verifiedPurchase: true
  },
  {
    id: 'rev-2',
    productId: 'prod-1719939868',
    productTitle: 'পুরুষদের ফ্লোরাল গ্রাফিক প্রিন্ট শর্ট স্লিভ টি-শার্ট',
    userName: 'Sakib Al Hasan',
    userEmail: 'sakib@outlook.com',
    rating: 5,
    comment: 'ঢাকার ভেতরে ২ দিনের মধ্যে ডেলিভারি পেয়েছি। সাইজ একদম পারফেক্ট।',
    status: 'approved',
    createdAt: '2026-09-09',
    verifiedPurchase: true
  },
  {
    id: 'rev-3',
    productId: 'prod-1746284974',
    productTitle: 'পুরুষদের জাপানি ক্যালিগ্রাফি ও কার গ্রাফিক টি-শার্ট',
    userName: 'Mahmudur Rahman',
    userEmail: 'mahmud@gmail.com',
    rating: 4,
    comment: 'প্রিন্ট খুব সুন্দর। তবে আরও ১টা কালার ভ্যারিয়েন্ট থাকলে ভালো হতো।',
    status: 'approved',
    createdAt: '2026-09-10',
    verifiedPurchase: true
  },
  {
    id: 'rev-4',
    productId: 'prod-1753389136',
    productTitle: 'পুরুষদের মাউন্টেন ক্যাম্পিং গ্রাফিক ড্রপ শোল্ডার টি-শার্ট',
    userName: 'Jahidul Islam',
    userEmail: 'jahid@gmail.com',
    rating: 5,
    comment: 'অসাধারণ ফেব্রিক, খুব কমফোর্টেবল।',
    status: 'pending',
    createdAt: '2026-09-12',
    verifiedPurchase: true
  }
];

export const getStoredReviews = (): ProductReview[] => {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.REVIEWS) : null;
    if (!raw) {
      safeLocalStorageSet(STORAGE_KEYS.REVIEWS, JSON.stringify(initialReviews));
      return initialReviews;
    }
    return JSON.parse(raw);
  } catch {
    return initialReviews;
  }
};

export const saveReviewsToStorage = (reviews: ProductReview[]) => {
  try {
    safeLocalStorageSet(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
  } catch (e) {}
};

// Initial Stock Logs
export const initialStockLogs: StockLog[] = [
  {
    id: 'log-1',
    productId: 'prod-1719939868',
    productName: 'পুরুষদের ফ্লোরাল গ্রাফিক প্রিন্ট শর্ট স্লিভ টি-শার্ট',
    type: 'stock_in',
    quantity: 50,
    previousStock: 0,
    newStock: 50,
    reason: 'Initial Batch Import from Factory',
    adminName: 'Admin Manager (winlucky414@gmail.com)',
    date: '2026-09-01 10:30 AM'
  },
  {
    id: 'log-2',
    productId: 'prod-1719939868',
    productName: 'পুরুষদের ফ্লোরাল গ্রাফিক প্রিন্ট শর্ট স্লিভ টি-শার্ট',
    type: 'order',
    quantity: -17,
    previousStock: 50,
    newStock: 33,
    reason: 'Customer Online Orders Dispatched',
    adminName: 'System Auto Sync',
    date: '2026-09-11 04:15 PM'
  }
];

export const getStoredStockLogs = (): StockLog[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STOCK_LOGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.STOCK_LOGS, JSON.stringify(initialStockLogs));
      return initialStockLogs;
    }
    return JSON.parse(raw);
  } catch {
    return initialStockLogs;
  }
};

export const saveStockLogsToStorage = (logs: StockLog[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.STOCK_LOGS, JSON.stringify(logs));
  } catch (e) {
    console.error('Failed to save stock logs', e);
  }
};

// Initial Admin Users
export const initialAdminUsers: AdminUser[] = [
  {
    id: 'adm-1',
    name: 'Super Admin Manager',
    email: 'winlucky414@gmail.com',
    role: 'super_admin',
    status: 'active',
    lastLogin: 'Active Now',
    createdAt: '2026-01-01'
  },
  {
    id: 'adm-2',
    name: 'Product Manager',
    email: 'products@shoppingmall.com',
    role: 'product_manager',
    status: 'active',
    lastLogin: '2026-09-12 11:20 AM',
    createdAt: '2026-02-15'
  },
  {
    id: 'adm-3',
    name: 'Dispatch & Order Lead',
    email: 'orders@shoppingmall.com',
    role: 'order_manager',
    status: 'active',
    lastLogin: '2026-09-13 08:45 AM',
    createdAt: '2026-03-01'
  },
  {
    id: 'adm-4',
    name: 'Customer Support Lead',
    email: 'support@shoppingmall.com',
    role: 'customer_support',
    status: 'active',
    lastLogin: '2026-09-11 06:10 PM',
    createdAt: '2026-04-10'
  }
];

export const getStoredAdminUsers = (): AdminUser[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ADMIN_USERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(initialAdminUsers));
      return initialAdminUsers;
    }
    return JSON.parse(raw);
  } catch {
    return initialAdminUsers;
  }
};

export const saveAdminUsersToStorage = (users: AdminUser[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(users));
  } catch (e) {
    console.error('Failed to save admin users', e);
  }
};

// Initial Store Settings
export const initialStoreSettings: StoreSettings = {
  storeName: 'Happy Shopping',
  storeTagline: 'Better Product • Happier You',
  storeLogo: '/logo.png',
  storeEmail: 'support@happyshopping.com',
  phone: '01732408652',
  address: 'House 42, Road 11, Sector 4, Uttara, Dhaka 1230, Bangladesh',
  currency: '৳',
  taxRatePercent: 0,
  maintenanceMode: false,
  allowGuestCheckout: true,
  lowStockThreshold: 5,
  socialLinks: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    youtube: 'https://youtube.com',
    whatsapp: 'https://wa.me/8801732408652'
  }
};

export const getStoredStoreSettings = (): StoreSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STORE_SETTINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.STORE_SETTINGS, JSON.stringify(initialStoreSettings));
      return initialStoreSettings;
    }
    const parsed = JSON.parse(raw);
    if (parsed.storeName === 'Gift Ghor') {
      parsed.storeName = 'Happy Shopping';
      localStorage.setItem(STORAGE_KEYS.STORE_SETTINGS, JSON.stringify(parsed));
    }
    return parsed;
  } catch {
    return initialStoreSettings;
  }
};

export const saveStoreSettingsToStorage = (settings: StoreSettings) => {
  try {
    localStorage.setItem(STORAGE_KEYS.STORE_SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save store settings', e);
  }
};

// Initial Delivery Settings
export const initialDeliverySettings: DeliverySettings = {
  insideDhakaFee: 65,
  outsideDhakaFee: 120,
  freeDeliveryThreshold: 1500,
  freeShippingThreshold: 1500,
  estimatedDaysInside: '24-48 Hours',
  estimatedDaysOutside: '3-5 Days',
  couriers: [
    { id: 'steadfast', name: 'SteadFast Courier', trackingUrlPrefix: 'https://steadfast.com.bd/t/', trackingUrlTemplate: 'https://steadfast.com.bd/t/', enabled: true, active: true },
    { id: 'pathao', name: 'Pathao Courier', trackingUrlPrefix: 'https://merchant.pathao.com/tracking?consignment_id=', trackingUrlTemplate: 'https://merchant.pathao.com/tracking?consignment_id=', enabled: true, active: true },
    { id: 'redx', name: 'RedX Delivery', trackingUrlPrefix: 'https://redx.com.bd/track-order?trackingId=', trackingUrlTemplate: 'https://redx.com.bd/track-order?trackingId=', enabled: true, active: true },
    { id: 'paperfly', name: 'Paperfly Courier', trackingUrlPrefix: 'https://paperfly.com.bd/tracking?order_id=', trackingUrlTemplate: 'https://paperfly.com.bd/tracking?order_id=', enabled: true, active: true },
    { id: 'ecourier', name: 'eCourier', trackingUrlPrefix: 'https://ecourier.com.bd/track-order/?track_id=', trackingUrlTemplate: 'https://ecourier.com.bd/track-order/?track_id=', enabled: true, active: true },
    { id: 'sundarban', name: 'Sundarban Courier Service', trackingUrlPrefix: '', trackingUrlTemplate: '', enabled: true, active: true },
    { id: 'sa_paribahan', name: 'SA Paribahan', trackingUrlPrefix: '', trackingUrlTemplate: '', enabled: true, active: true },
  ],
  supportedCouriers: [
    { id: 'steadfast', name: 'SteadFast Courier', trackingUrlTemplate: 'https://steadfast.com.bd/t/', active: true },
    { id: 'pathao', name: 'Pathao Courier', trackingUrlTemplate: 'https://merchant.pathao.com/tracking?consignment_id=', active: true },
    { id: 'redx', name: 'RedX Delivery', trackingUrlTemplate: 'https://redx.com.bd/track-order?trackingId=', active: true },
    { id: 'paperfly', name: 'Paperfly Courier', trackingUrlTemplate: 'https://paperfly.com.bd/tracking?order_id=', active: true },
    { id: 'ecourier', name: 'eCourier', trackingUrlTemplate: 'https://ecourier.com.bd/track-order/?track_id=', active: true },
    { id: 'sundarban', name: 'Sundarban Courier Service', trackingUrlTemplate: '', active: true },
    { id: 'sa_paribahan', name: 'SA Paribahan', trackingUrlTemplate: '', active: true },
  ]
};

export const getStoredDeliverySettings = (): DeliverySettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DELIVERY_SETTINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.DELIVERY_SETTINGS, JSON.stringify(initialDeliverySettings));
      return initialDeliverySettings;
    }
    return JSON.parse(raw);
  } catch {
    return initialDeliverySettings;
  }
};

export const saveDeliverySettingsToStorage = (settings: DeliverySettings) => {
  try {
    localStorage.setItem(STORAGE_KEYS.DELIVERY_SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save delivery settings', e);
  }
};

// Initial SEO Settings
export const initialSeoSettings: SeoSettings = {
  metaTitle: 'Shopping Mall - Trendy T-Shirts, Fashion & Lifestyle in Bangladesh',
  metaDescription: 'Shop premium 100% cotton oversized t-shirts, anime edition tees, streetwear, and lifestyle apparel across Bangladesh with Cash on Delivery at best prices.',
  keywords: 'shopping mall bd, online shopping dhaka, oversized t-shirt, anime t-shirt, streetwear bangladesh, cash on delivery',
  ogImage: '/products/1719939868_L_3.jpg',
  robots: 'index, follow'
};

export const getStoredSeoSettings = (): SeoSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SEO_SETTINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SEO_SETTINGS, JSON.stringify(initialSeoSettings));
      return initialSeoSettings;
    }
    return JSON.parse(raw);
  } catch {
    return initialSeoSettings;
  }
};

export const saveSeoSettingsToStorage = (settings: SeoSettings) => {
  try {
    localStorage.setItem(STORAGE_KEYS.SEO_SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save seo settings', e);
  }
};

// Initial Activity Logs
export const initialActivityLogs: ActivityLogItem[] = [
  {
    id: 'act-1',
    adminName: 'Admin Manager',
    adminEmail: 'winlucky414@gmail.com',
    action: 'Logged into Admin Dashboard',
    category: 'security',
    timestamp: new Date().toLocaleString('en-GB'),
    details: 'Authenticated from secure session'
  },
  {
    id: 'act-2',
    adminName: 'Admin Manager',
    adminEmail: 'winlucky414@gmail.com',
    action: 'Verified live Firestore synchronization',
    category: 'settings',
    timestamp: new Date(Date.now() - 3600000).toLocaleString('en-GB'),
    details: 'Database listener active'
  }
];

export const getStoredActivityLogs = (): ActivityLogItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(initialActivityLogs));
      return initialActivityLogs;
    }
    return JSON.parse(raw);
  } catch {
    return initialActivityLogs;
  }
};

export const saveActivityLogsToStorage = (logs: ActivityLogItem[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(logs.slice(0, 100))); // Keep latest 100
  } catch (e) {
    console.error('Failed to save activity logs', e);
  }
};

// Initial Notifications
export const initialNotifications: AdminNotification[] = [
  {
    id: 'notif-1',
    type: 'order',
    title: 'নতুন অনলাইন অর্ডার গ্রহণ করা হয়েছে',
    message: 'গ্রাহক তানভীর আহমেদ ৩টি টি-শার্ট অর্ডার করেছেন (৳১৩৫০)।',
    timestamp: '১০ মিনিট আগে',
    read: false,
    linkTab: 'orders'
  },
  {
    id: 'notif-2',
    type: 'payment',
    title: 'বিকাশ পেমেন্ট ভেরিফিকেশন অনুরোধ',
    message: 'অর্ডার #SM-82914 এর TrxID: 9K72LM8Q যাচাই করুন।',
    timestamp: '২৫ মিনিট আগে',
    read: false,
    linkTab: 'payments'
  },
  {
    id: 'notif-3',
    type: 'low_stock',
    title: 'কম স্টকের সতর্কবার্তা',
    message: 'জাপানি ক্যালিগ্রাফি টি-শার্টের স্টক ৫টির নিচে নেমে গেছে।',
    timestamp: '১ ঘণ্টা আগে',
    read: false,
    linkTab: 'inventory'
  },
  {
    id: 'notif-4',
    type: 'review',
    title: 'নতুন কাস্টমার রিভিউ জমা পড়েছে',
    message: 'সাকিব আল হাসান ৫ স্টার রেটিং দিয়েছেন।',
    timestamp: '২ ঘণ্টা আগে',
    read: true,
    linkTab: 'reviews'
  }
];

export const getStoredNotifications = (): AdminNotification[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(initialNotifications));
      return initialNotifications;
    }
    return JSON.parse(raw);
  } catch {
    return initialNotifications;
  }
};

export const saveNotificationsToStorage = (notifs: AdminNotification[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
  } catch (e) {
    console.error('Failed to save notifications', e);
  }
};

// Stored Banners
export const getStoredBanners = (): Banner[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BANNERS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(initialBanners));
      return initialBanners;
    }
    return JSON.parse(raw);
  } catch {
    return initialBanners;
  }
};

export const saveBannersToStorage = (banners: Banner[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
  } catch (e) {
    console.error('Failed to save banners', e);
  }
};

// Initial Website Customizer & Design Settings
export const initialWebsiteCustomizerSettings: WebsiteCustomizerSettings = {
  // 1. Branding & Identity
  brandNameBn: 'হ্যাপি শপিং',
  brandNameEn: 'Happy Shopping',
  brandAccentWordBn: 'শপিং',
  brandAccentWordEn: 'Shopping',
  taglineBn: 'সেরা পণ্য • সুন্দর জীবন',
  taglineEn: 'Better Product • Happier You',
  logoUrl: '/logo.png?v=20260924_2',
  faviconUrl: '/favicon.ico',
  showOfficialStoreBadge: false,
  officialStoreBadgeBn: 'অফিসিয়াল স্টোর',
  officialStoreBadgeEn: 'Official Store',

  // 2. Theme & Styling
  themePreset: 'maroon',
  primaryColorHex: '#800020',
  accentColorHex: '#D4AF37',
  fontFamily: 'inter',
  borderRadius: 'rounded-2xl',

  // 3. Top Announcement Marquee Bar
  showAnnouncementBar: true,
  announcementTextBn: '⚡ স্পেশাল অফার: সারা বাংলাদেশে ১০০% ক্যাশ অন ডেলিভারি ও দ্রুততম হোম ডেলিভারি সুবিধা!',
  announcementTextEn: '⚡ Special Offer: 100% Cash on Delivery and express nationwide shipping on all orders!',
  announcementBgColor: '#5B0616',
  announcementTextColor: '#FFFFFF',
  freeDeliveryBadgeBn: 'Cash on Delivery Across Bangladesh',
  freeDeliveryBadgeEn: 'Cash on Delivery Across Bangladesh',

  // 4. Hero Banners & Slider
  heroBanners: initialBanners || [],
  useCustomBannersOnly: false,

  // 5. Flash Sale & Offers
  flashSaleEnabled: false,
  flashSaleTitleBn: 'Flash Deals',
  flashSaleTitleEn: 'Midnight Flash Deal',
  flashSaleSubtitleBn: 'সীমিত সময়ের জন্য বিশেষ আকর্ষণীয় মূল্যে সেরা কালেকশন',
  flashSaleSubtitleEn: 'Exclusive top-selling collections at irresistible limited-time prices',
  flashSaleEndTime: '2026-12-31T23:59',
  flashSaleBadgeTextBn: 'হট ডিল',
  flashSaleBadgeTextEn: 'HOT DEAL',

  // 6. Section Headings
  categorySectionTitleBn: 'ক্যাটাগরি সমূহ',
  categorySectionTitleEn: 'Shop by Category',
  categorySectionSubtitleBn: 'আপনার পছন্দের ক্যাটাগরি বেছে নিন এবং অর্ডার করুন',
  categorySectionSubtitleEn: 'Select your preferred category and explore curated products',

  catalogSectionTitleBn: 'সকল প্রোডাক্ট কালেকশন',
  catalogSectionTitleEn: 'All Products Collection',
  catalogSectionSubtitleBn: '১০০% অরিজিনাল ও প্রিমিয়াম কোয়ালিটি নিশ্চিত',
  catalogSectionSubtitleEn: '100% authentic and premium quality guaranteed',

  // 7. Direct Order / Callout Section
  showDirectOrderBanner: true,
  directOrderTitleBn: 'অনলাইনে অর্ডারে সমস্যা? আমাদের হটলাইনে সরাসরি যোগাযোগ করুন!',
  directOrderTitleEn: 'Trouble ordering online? Contact our direct customer hotline!',
  directOrderSubtitleBn: 'আমাদের কাস্টমার কেয়ার টিম সর্বদা প্রস্তুত আপনার পছন্দের পণ্য পৌঁছে দিতে সাহায্য করতে।',
  directOrderSubtitleEn: 'Our friendly customer service is ready to assist and confirm your delivery.',
  directOrderBadgeBn: 'সরাসরি হটলাইন যোগাযোগ',
  directOrderBadgeEn: 'Direct Hotline Support',
  hotlineEmail: 'support@happyshopping.com',
  hotlinePhone: '01732408652',

  // 8. Trust Features Bar
  showFeaturesBar: true,
  features: [
    {
      id: 'feat-1',
      icon: 'truck',
      titleBn: 'ক্যাশ অন ডেলিভারি',
      titleEn: 'Cash on Delivery',
      descBn: 'পণ্য হাতে পেয়ে মূল্য পরিশোধ করার পূর্ণ নিশ্চয়তা',
      descEn: 'Pay in cash after safely receiving your parcel'
    },
    {
      id: 'feat-2',
      icon: 'shield',
      titleBn: '১০০% অরিজিনাল পণ্য',
      titleEn: '100% Authentic',
      descBn: 'সরাসরি প্রিমিয়াম কোয়ালিটি ও খাঁটি পণ্যের গ্যারান্টি',
      descEn: 'Direct premium quality and original verified products'
    },
    {
      id: 'feat-3',
      icon: 'refresh',
      titleBn: 'সহজ রিটার্ন পলিসি',
      titleEn: 'Easy Replacement',
      descBn: 'যেকোনো ত্রুটিতে দ্রুততম রিপ্লেসমেন্ট সুবিধা',
      descEn: 'Hassle-free return & replacement on damaged goods'
    },
    {
      id: 'feat-4',
      icon: 'clock',
      titleBn: '২৪/৭ কাস্টমার সাপোর্ট',
      titleEn: '24/7 Support',
      descBn: 'হটলাইন ও মেসেঞ্জারে সার্বক্ষণিক আন্তরিক সেবা',
      descEn: 'Dedicated helpline & assistance at your convenience'
    }
  ],

  // 9. Footer & Socials
  footerAboutBn: 'Happy Shopping - বাংলাদেশের অন্যতম নির্ভরযোগ্য অনলাইন শপ। আধুনিক জীবনযাত্রার প্রয়োজনীয় পোশাক ও সেরা পণ্যসামগ্রীর এক বিশ্বস্ত ঠিকানা।',
  footerAboutEn: 'Happy Shopping - One of Bangladesh\'s most trusted online stores for curated apparel, lifestyle essentials and happy shopping experiences.',
  officeAddressBn: 'হাউজ ৪২, রোড ১১, সেক্টর ৪, উত্তরা, ঢাকা ১২৩০, বাংলাদেশ',
  officeAddressEn: 'House 42, Road 11, Sector 4, Uttara, Dhaka 1230, Bangladesh',
  copyrightTextBn: '© ২০২৬ Happy Shopping | সর্বস্বত্ব সংরক্ষিত।',
  copyrightTextEn: '© 2026 Happy Shopping | All rights reserved.',
  facebookUrl: 'https://facebook.com',
  instagramUrl: 'https://instagram.com',
  whatsappUrl: 'https://wa.me/8801732408652',
  youtubeUrl: 'https://youtube.com'
};

export const getStoredCustomizerSettings = (): WebsiteCustomizerSettings => {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.CUSTOMIZER) : null;
    if (!raw) {
      safeLocalStorageSet(STORAGE_KEYS.CUSTOMIZER, JSON.stringify(initialWebsiteCustomizerSettings));
      return initialWebsiteCustomizerSettings;
    }
    const parsed = JSON.parse(raw);
    
    // Automatically migrate old brand name to Happy Shopping
    if (parsed.brandNameEn === 'Gift Ghor' || !parsed.brandNameEn) {
      parsed.brandNameEn = 'Happy Shopping';
      parsed.brandNameBn = 'হ্যাপি শপিং';
      parsed.brandAccentWordEn = 'Shopping';
      parsed.brandAccentWordBn = 'শপিং';
      parsed.footerAboutBn = initialWebsiteCustomizerSettings.footerAboutBn;
      parsed.footerAboutEn = initialWebsiteCustomizerSettings.footerAboutEn;
      parsed.copyrightTextBn = initialWebsiteCustomizerSettings.copyrightTextBn;
      parsed.copyrightTextEn = initialWebsiteCustomizerSettings.copyrightTextEn;
      parsed.logoUrl = '/logo.png?v=20260924_2';
      safeLocalStorageSet(STORAGE_KEYS.CUSTOMIZER, JSON.stringify(parsed));
    }

    // Always update logoUrl if pointing to old logo without fresh query version
    if (!parsed.logoUrl || parsed.logoUrl === '/logo.png' || parsed.logoUrl.includes('gift_ghor') || !parsed.logoUrl.includes('20260924_2')) {
      parsed.logoUrl = '/logo.png?v=20260924_2';
      safeLocalStorageSet(STORAGE_KEYS.CUSTOMIZER, JSON.stringify(parsed));
    }
    // Ensure flash sale is disabled
    parsed.flashSaleEnabled = false;

    // Sanitize old cached banners if they contain stale drive or happy shops banners
    const sanitizedBanners = Array.isArray(parsed.heroBanners)
      ? parsed.heroBanners.filter((b: any) => {
          if (!b) return false;
          const title = `${b.titleBn || ''} ${b.titleEn || ''}`;
          if (title.includes('হ্যাপি শপস') || title.includes('Happy Shops')) return false;
          if (b.imageUrl && b.imageUrl.includes('/products/drive/')) return false;
          return true;
        })
      : initialWebsiteCustomizerSettings.heroBanners;

    return {
      ...initialWebsiteCustomizerSettings,
      ...parsed,
      features: Array.isArray(parsed.features) && parsed.features.length > 0
        ? parsed.features
        : initialWebsiteCustomizerSettings.features,
      heroBanners: sanitizedBanners
    };
  } catch (e) {
    return initialWebsiteCustomizerSettings;
  }
};

export const saveCustomizerSettingsToStorage = (settings: WebsiteCustomizerSettings) => {
  try {
    safeLocalStorageSet(STORAGE_KEYS.CUSTOMIZER, JSON.stringify(settings));
  } catch (e) {}
};

// ==========================================
// Server Persistence API for Settings & Banners
// ==========================================

export const fetchSettingsFromServer = async (): Promise<WebsiteCustomizerSettings | null> => {
  try {
    const data = await getSettingsFromFirestore();
    if (data && typeof data === 'object') {
      return {
        ...initialWebsiteCustomizerSettings,
        ...data,
        features: Array.isArray(data.features) && data.features.length > 0
          ? data.features
          : initialWebsiteCustomizerSettings.features,
        heroBanners: Array.isArray(data.heroBanners)
          ? data.heroBanners
          : initialWebsiteCustomizerSettings.heroBanners
      };
    }
  } catch (err) {
    console.warn('[Storage] Server settings fetch failed:', err);
  }
  return null;
};

export const saveSettingsToServer = async (settings: WebsiteCustomizerSettings): Promise<boolean> => {
  try {
    return await saveSettingsToFirestore(settings);
  } catch (err) {
    console.warn('[Storage] Server settings save failed:', err);
    return false;
  }
};


