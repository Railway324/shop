import { Category, CategoryId, Product, Language } from '../types';

export type HomeSectionId = 
  | 'winter'
  | 'mens_fashion'
  | 'watches'
  | 'womens_fashion'
  | 'jewelry'
  | 'home_lifestyle'
  | 'gadgets_electronics'
  | 'kids_zone'
  | 'foods'
  | 'others';

export interface HomeCategorySectionConfig {
  id: HomeSectionId;
  titleBn: string;
  titleEn: string;
  subtitleBn: string;
  subtitleEn: string;
  badgeBn: string;
  badgeEn: string;
  filterCategoryId: CategoryId;
  iconName: string;
  accentColor: string;
}

/**
 * Canonical watch, smartwatch & clock detector (with Unicode NFKD normalization).
 * Ensures all current and future watch/clock products (ঘড়ি) are consistently placed in the 'watches' category.
 */
export function isWatchProductTitle(titleEn?: string | null, titleBn?: string | null): boolean {
  const t = `${titleEn || ''} ${titleBn || ''}`.normalize('NFKD').toLowerCase().trim();
  if (!t) return false;

  const hasExplicitWatchWord =
    /\bwatch\b/.test(t) ||
    /\bwatches\b/.test(t) ||
    t.includes('smartwatch') ||
    t.includes('smart watch') ||
    t.includes('wrist watch') ||
    t.includes('wristwatch') ||
    t.includes('ঘড়ি') ||
    t.includes('ঘড়ি') ||
    t.includes('স্মার্টওয়াচ') ||
    t.includes('স্মার্টওয়াচ') ||
    t.includes('স্মার্ট ওয়াচ');

  if (
    !hasExplicitWatchWord &&
    (t.includes('earphone') ||
      t.includes('earbud') ||
      t.includes('headphone') ||
      /\btws\b/.test(t) ||
      t.includes('wireless charger') ||
      t.includes('face wash') ||
      t.includes('body wash'))
  ) {
    return false;
  }

  return (
    hasExplicitWatchWord ||
    /\bwatc\b/.test(t) ||
    /\bwtach\b/.test(t) ||
    /\bwacth\b/.test(t) ||
    /\bclock\b/.test(t) ||
    /\bclocks\b/.test(t) ||
    /\brelogio\b/.test(t) ||
    /\brelogios\b/.test(t) ||
    /\breloj\b/.test(t) ||
    t.includes('smart bracelet') ||
    t.includes('smart band') ||
    t.includes('fitness band') ||
    t.includes('timepiece') ||
    t.includes('chronograph') ||
    /\brolex\b/.test(t) ||
    /\bcasio\b/.test(t) ||
    /\bcurren\b/.test(t) ||
    /\bnaviforce\b/.test(t) ||
    /\bskmei\b/.test(t) ||
    /\bpoedagar\b/.test(t) ||
    /\bolevs\b/.test(t) ||
    /\bdenvosi\b/.test(t) ||
    /\bbinbond\b/.test(t) ||
    /\bcrrju\b/.test(t) ||
    /\bcuena\b/.test(t) ||
    /\btrsoye\b/.test(t) ||
    /\btisselly\b/.test(t) ||
    /\bbaisheng\b/.test(t) ||
    /\btosst\b/.test(t) ||
    /\bdiray\b/.test(t) ||
    t.includes('g-shock') ||
    /\bpatek\b/.test(t) ||
    /\btissot\b/.test(t) ||
    /\bhublot\b/.test(t) ||
    /\brado\b/.test(t) ||
    /\bcitizen\b/.test(t) ||
    /\bseiko\b/.test(t) ||
    /\bfossil\b/.test(t) ||
    /\blige\b/.test(t) ||
    /\bforsining\b/.test(t) ||
    /\bbenyar\b/.test(t) ||
    /\bpagani\b/.test(t) ||
    /\bmegir\b/.test(t) ||
    /\bsanda\b/.test(t) ||
    /\bsynoke\b/.test(t) ||
    /\bfngeen\b/.test(t) ||
    /\byazole\b/.test(t) ||
    /\bwlisth\b/.test(t) ||
    /\bbestwin\b/.test(t)
  );
}

export const HOME_CATEGORY_SECTIONS_ORDER: HomeCategorySectionConfig[] = [
  {
    id: 'winter',
    titleBn: 'উইন্টার কালেকশন (Winter)',
    titleEn: 'Winter Collection',
    subtitleBn: 'হুডি, সোয়েটশার্ট, জ্যাকেট ও উইন্টার কম্বো কালেকশন',
    subtitleEn: 'Exclusive Hoodies, Sweatshirts, Jackets & Winter Combos',
    badgeBn: 'উইন্টার স্পেশাল',
    badgeEn: 'Winter Special',
    filterCategoryId: 'winter',
    iconName: 'Flame',
    accentColor: 'blue',
  },
  {
    id: 'mens_fashion',
    titleBn: 'মেনস ফ্যাশন (Men\'s Fashion)',
    titleEn: 'Men\'s Fashion',
    subtitleBn: 'পাঞ্জাবি, টি-শার্ট, শার্ট, প্যান্ট ও মেনস এক্সেসরিজ',
    subtitleEn: 'Panjabi, T-Shirts, Shirts, Pants & Men\'s Accessories',
    badgeBn: 'মেনস ট্রেন্ড',
    badgeEn: 'Men\'s Trend',
    filterCategoryId: 'mens-fashion',
    iconName: 'Shirt',
    accentColor: 'indigo',
  },
  {
    id: 'watches',
    titleBn: 'ঘড়ি কালেকশন (Watches)',
    titleEn: 'Watches Collection',
    subtitleBn: 'অ্যানালগ, ডিজিটাল, লাক্সারি ও স্মার্টওয়াচ কালেকশন',
    subtitleEn: 'Analog, Digital, Luxury & Smartwatch Collection',
    badgeBn: 'ঘড়ি স্পেশাল',
    badgeEn: 'Watches Special',
    filterCategoryId: 'watches',
    iconName: 'Watch',
    accentColor: 'amber',
  },
  {
    id: 'womens_fashion',
    titleBn: 'ওমেনস ফ্যাশন (Women\'s Fashion)',
    titleEn: 'Women\'s Fashion',
    subtitleBn: 'এক্সক্লুসিভ শাড়ি, সালোয়ার কামিজ, বোরকা, লেডিস ব্যাগ ও কসমেটিক্স',
    subtitleEn: 'Exclusive Sarees, Salwar-Kameez, Borka, Ladies Bags & Cosmetics',
    badgeBn: 'লেডিস স্পেশাল',
    badgeEn: 'Women\'s Special',
    filterCategoryId: 'womens-fashion',
    iconName: 'Sparkles',
    accentColor: 'rose',
  },
  {
    id: 'jewelry',
    titleBn: "জুয়েলারি (Jewelry's)",
    titleEn: "Jewelry's",
    subtitleBn: 'নেকলেস সেট, কানের দুল, আংটি, ব্রেসলেট, নাকফুল ও চুড়ি কালেকশন',
    subtitleEn: 'Necklace Sets, Earrings, Rings, Bracelets, Nose Pins & Bangles',
    badgeBn: 'জুয়েলারি স্পেশাল',
    badgeEn: "Jewelry's Special",
    filterCategoryId: 'jewelry',
    iconName: 'Gem',
    accentColor: 'amber',
  },
  {
    id: 'home_lifestyle',
    titleBn: 'হোম ও লাইফস্টাইল (Home & Lifestyle)',
    titleEn: 'Home & Lifestyle',
    subtitleBn: 'বেডশিট, কিচেন সামগ্রী, হোম অ্যাপ্লায়েন্স ও ব্যাগ',
    subtitleEn: 'Bed Sheets, Kitchen & Dining, Home Appliances & Bags',
    badgeBn: 'হোম স্পেশাল',
    badgeEn: 'Home Special',
    filterCategoryId: 'home-lifestyle',
    iconName: 'Home',
    accentColor: 'emerald',
  },
  {
    id: 'gadgets_electronics',
    titleBn: 'গ্যাজেটস ও ইলেকট্রনিক্স (Gadgets & Electronics)',
    titleEn: 'Gadgets & Electronics',
    subtitleBn: 'স্মার্ট গ্যাজেট, ব্লুটুথ অডিও, চার্জার, ট্রিমার ও ইলেকট্রনিক্স',
    subtitleEn: 'Smart Tech, Wireless Audio, Chargers, Trimmers & Electronics',
    badgeBn: 'স্মার্ট গ্যাজেট',
    badgeEn: 'Smart Tech',
    filterCategoryId: 'gadgets-electronics',
    iconName: 'Zap',
    accentColor: 'amber',
  },
  {
    id: 'kids_zone',
    titleBn: 'কিডস জোন (Kids Zone)',
    titleEn: 'Kids Zone',
    subtitleBn: 'ছোট্ট সোনামণিদের ড্রেস, বেবি বাউন্সার, খেলনা ও বেবি আইটেম',
    subtitleEn: 'Baby Items, Children Clothing, Robot Cars & Toys',
    badgeBn: 'কিডস স্পেশাল',
    badgeEn: 'Kids Special',
    filterCategoryId: 'kids-zone',
    iconName: 'Baby',
    accentColor: 'pink',
  },
  {
    id: 'foods',
    titleBn: "ফুডস (Food's)",
    titleEn: "Food's",
    subtitleBn: 'খাঁটি মধু, চিয়া সিড, ওটস, বাদাম, মসলা ও পুষ্টিকর অর্গানিক ফুডস',
    subtitleEn: 'Pure Honey, Chia Seeds, Oats, Nuts, Spices & Organic Superfoods',
    badgeBn: "ফুডস স্পেশাল",
    badgeEn: "Food's Special",
    filterCategoryId: 'foods',
    iconName: 'UtensilsCrossed',
    accentColor: 'amber',
  },
  {
    id: 'others',
    titleBn: 'অন্যান্য (Other\'s)',
    titleEn: 'Other\'s',
    subtitleBn: 'ধামাকা কম্বো প্যাক, গিফট আইটেম, কাস্টমাইজ গিফট, কাপল সেট ও মিস্ট্রি বক্স',
    subtitleEn: 'Combo Packs, Gift Items, Customized Gifts, Couple Sets & Mystery Box',
    badgeBn: 'ধামাকা অফার',
    badgeEn: 'Special Deals',
    filterCategoryId: 'others',
    iconName: 'Gift',
    accentColor: 'purple',
  },
];

/**
 * Standard Categories List for Navigation & Filtering
 */
export const STORE_CATEGORIES: Category[] = [
  {
    id: 'all',
    nameBn: 'সকল প্রোডাক্ট',
    nameEn: 'All Products',
    iconName: 'LayoutGrid',
    itemCount: 3074,
  },
  {
    id: 'winter',
    nameBn: 'উইন্টার (Winter)',
    nameEn: 'Winter',
    iconName: 'Flame',
    itemCount: 330,
  },
  {
    id: 'mens-fashion',
    nameBn: 'মেনস ফ্যাশন (Men\'s Fashion)',
    nameEn: 'Men\'s Fashion',
    iconName: 'Shirt',
    itemCount: 649,
  },
  {
    id: 'watches',
    nameBn: 'ঘড়ি (Watches)',
    nameEn: 'Watches',
    iconName: 'Watch',
    itemCount: 275,
  },
  {
    id: 'womens-fashion',
    nameBn: 'ওমেনস ফ্যাশন (Women\'s Fashion)',
    nameEn: 'Women\'s Fashion',
    iconName: 'Sparkles',
    itemCount: 289,
  },
  {
    id: 'jewelry',
    nameBn: "জুয়েলারি (Jewelry's)",
    nameEn: "Jewelry's",
    iconName: 'Gem',
    itemCount: 160,
  },
  {
    id: 'home-lifestyle',
    nameBn: 'হোম ও লাইফস্টাইল (Home & Lifestyle)',
    nameEn: 'Home & Lifestyle',
    iconName: 'Home',
    itemCount: 531,
  },
  {
    id: 'gadgets-electronics',
    nameBn: 'গ্যাজেটস ও ইলেকট্রনিক্স (Gadgets & Electronics)',
    nameEn: 'Gadgets & Electronics',
    iconName: 'Zap',
    itemCount: 529,
  },
  {
    id: 'kids-zone',
    nameBn: 'কিডস জোন (Kids Zone)',
    nameEn: 'Kids Zone',
    iconName: 'Baby',
    itemCount: 220,
  },
  {
    id: 'foods',
    nameBn: "ফুডস (Food's)",
    nameEn: "Food's",
    iconName: 'UtensilsCrossed',
    itemCount: 15,
  },
  {
    id: 'others',
    nameBn: 'অন্যান্য (Other\'s)',
    nameEn: 'Other\'s',
    iconName: 'Gift',
    itemCount: 76,
  },
];

/**
 * Maps any product strictly to its single, accurate Category Section.
 * NO cross-contamination:
 * - Bags go ONLY to Bags
 * - Watches go ONLY to Watches
 * - Electronics/Gadgets go ONLY to Gadgets & Electronics
 * - Dresses/Clothes go ONLY to Clothes & Dresses
 * - Kids products go ONLY to Kids Zone
 * - Bike gear goes ONLY to Bike Accessories
 * - Combos go ONLY to Combo Product
 */
export function getProductSectionKey(product: Product): HomeSectionId {
  if (!product) return 'others';

  // Primary check: Respect the product's assigned category first and foremost
  if (product.category) {
    const directCat = normalizeCategoryId(product.category);
    if (directCat === 'watches' || isWatchProductTitle(product.titleEn, product.titleBn)) return 'watches';
    if (directCat === 'jewelry') return 'jewelry';
    if (directCat === 'winter') return 'winter';
    if (directCat === 'mens-fashion') return 'mens_fashion';
    if (directCat === 'womens-fashion') return 'womens_fashion';
    if (directCat === 'home-lifestyle') return 'home_lifestyle';
    if (directCat === 'gadgets-electronics') return 'gadgets_electronics';
    if (directCat === 'kids-zone') return 'kids_zone';
    if (directCat === 'foods') return 'foods';
    if (directCat === 'others') return 'others';
  }

  const cat = (product.category || '').toLowerCase().trim();
  const subcat = (product.subcategory || '').toLowerCase().trim();
  const title = ((product.titleEn || '') + ' ' + (product.titleBn || '')).toLowerCase();

  // 1. WATCHES & TIMEPIECES (Highest priority dedicated Watches category)
  if (
    cat === 'watch' ||
    cat === 'watches' ||
    cat.includes('watch') ||
    subcat.includes('watch') ||
    isWatchProductTitle(product.titleEn, product.titleBn)
  ) {
    return 'watches';
  }

  // 2. BAGS & BACKPACKS (Avoid misidentifying as clothing)
  if (
    cat === 'bags' ||
    cat === 'bag' ||
    cat === 'backpack' ||
    cat === 'handbag' ||
    cat === 'luggage' ||
    cat.includes('bag') ||
    subcat.includes('bag') ||
    subcat.includes('backpack') ||
    subcat.includes('handbag') ||
    subcat.includes('purse') ||
    subcat.includes('wallet') ||
    subcat.includes('luggage') ||
    title.includes('bag') ||
    title.includes('backpack') ||
    title.includes('handbag') ||
    title.includes('side bag') ||
    title.includes('purse') ||
    title.includes('luggage') ||
    title.includes('ব্যাগ') ||
    title.includes('ব্যাকপ্যাক') ||
    title.includes('হ্যান্ডব্যাগ') ||
    title.includes('লাগেজ')
  ) {
    return 'home_lifestyle';
  }

  // 3. BIKE ACCESSORIES
  if (
    cat === 'bike-accessories' ||
    cat === 'bike accessories' ||
    cat === 'bike' ||
    cat === 'biking' ||
    cat === 'motorcycle' ||
    cat.includes('bike') ||
    subcat.includes('bike') ||
    subcat.includes('motorcycle') ||
    subcat.includes('helmet') ||
    title.includes('bike') ||
    title.includes('motorcycle') ||
    title.includes('বাইক') ||
    title.includes('মোটরসাইকেল') ||
    title.includes('হেলমেট')
  ) {
    return 'home_lifestyle';
  }

  // 4. COMBO PRODUCT
  if (
    cat === 'combo-product' ||
    cat === 'combo product' ||
    cat === 'combo' ||
    cat === 'bundle' ||
    cat === 'package' ||
    cat.includes('combo') ||
    subcat.includes('combo') ||
    title.includes('combo') ||
    title.includes('কম্বো') ||
    title.includes('বান্ডিল')
  ) {
    return 'others';
  }

  // 5. KIDS ZONE
  if (
    cat === 'kids-zone' ||
    cat === 'kids zone' ||
    cat === 'kids' ||
    cat === 'baby' ||
    cat === 'baby-care' ||
    cat.includes('baby') ||
    cat.includes('kids') ||
    subcat.includes('baby') ||
    subcat.includes('kids') ||
    title.includes('baby') ||
    title.includes('kids') ||
    title.includes('swaddle') ||
    title.includes('বাচ্চা') ||
    title.includes('শিশু') ||
    title.includes('খেলনা')
  ) {
    return 'kids_zone';
  }

  // 4. GADGETS & ELECTRONICS (Hair trimmer, shaver, clippers, earbuds, audio, chargers, adapters, powerbanks)
  if (
    cat === 'gadgets-electronics' ||
    cat === 'gadgets & electronics' ||
    cat === 'gadgets' ||
    cat === 'electronics' ||
    cat === 'gadget' ||
    cat === 'electronic' ||
    cat === 'tech' ||
    cat === 'electric' ||
    cat.includes('gadget') ||
    cat.includes('electronic') ||
    cat.includes('electric') ||
    subcat.includes('gadget') ||
    subcat.includes('electronic') ||
    subcat.includes('shaver') ||
    subcat.includes('trimmer') ||
    subcat.includes('earbuds') ||
    subcat.includes('headphone') ||
    subcat.includes('charger') ||
    subcat.includes('speaker') ||
    title.includes('gadget') ||
    title.includes('electronic') ||
    title.includes('trimmer') ||
    title.includes('shaver') ||
    title.includes('clipper') ||
    title.includes('hair machine') ||
    title.includes('hair cut') ||
    title.includes('haircut') ||
    title.includes('চুল কাটা') ||
    title.includes('দাড়ি কাটা') ||
    title.includes('ট্রিমার') ||
    title.includes('শেভার') ||
    title.includes('ক্লিপার') ||
    title.includes('earbud') ||
    title.includes('headphone') ||
    title.includes('earphone') ||
    title.includes('charger') ||
    title.includes('adapter') ||
    title.includes('powerbank') ||
    title.includes('speaker') ||
    title.includes('bluetooth') ||
    title.includes('হেডফোন') ||
    title.includes('ইয়ারবাড') ||
    title.includes('চার্জার') ||
    title.includes('অ্যাডাপ্টার') ||
    title.includes('মাইক্রোফোন') ||
    title.includes('microphone')
  ) {
    return 'gadgets_electronics';
  }

  // 5. FOODS (Honey, Ghee, Seeds, Dates, Nuts, Tea, Coffee, Spices, Organic Foods)
  if (
    cat === 'foods' ||
    cat === "food's" ||
    cat === 'food' ||
    cat.includes('food') ||
    subcat.includes('food') ||
    subcat.includes('honey') ||
    title.includes('honey') ||
    title.includes('ghee') ||
    title.includes('chia seed') ||
    title.includes('isabgol') ||
    title.includes('মধু') ||
    title.includes('ঘি') ||
    title.includes('খেজুর') ||
    title.includes('চিয়া সিড') ||
    title.includes('ইসবগুল') ||
    title.includes('বাদাম') ||
    title.includes('মসলা')
  ) {
    return 'foods';
  }

  // 6. JEWELRY'S (Necklace, Earrings, Bangles, Bracelets, Rings, Nose Pins)
  if (
    title.includes('bracelet') ||
    title.includes('bangle') ||
    title.includes('চুড়ি') ||
    title.includes('চুড়ি') ||
    title.includes('ব্রেসলেট') ||
    title.includes('necklace') ||
    title.includes('earring') ||
    title.includes('jhumka') ||
    title.includes('nose pin') ||
    title.includes('jewelry') ||
    title.includes('jewellery') ||
    title.includes('গহনা') ||
    title.includes('জুয়েলারি') ||
    /\bring\b/.test(title) ||
    title.includes('আংটি')
  ) {
    return 'jewelry';
  }

  // 6. KIDS ZONE
  if (
    cat === 'kids-zone' ||
    cat === 'kids zone' ||
    cat === 'kids' ||
    cat === 'baby' ||
    cat === 'baby-care' ||
    cat.includes('baby') ||
    cat.includes('kids') ||
    subcat.includes('baby') ||
    subcat.includes('kids') ||
    title.includes('baby nest') ||
    title.includes('baby bed') ||
    title.includes('swaddle') ||
    title.includes('বাচ্চা') ||
    title.includes('শিশু') ||
    title.includes('খেলনা') ||
    title.includes('toy') ||
    title.includes('kids') ||
    title.includes('baby')
  ) {
    return 'kids_zone';
  }

  // 7. HOME & LIFESTYLE
  if (
    cat === 'home-lifestyle' ||
    cat === 'home & lifestyle' ||
    cat === 'home-living' ||
    cat === 'home & living' ||
    cat === 'lifestyle' ||
    cat === 'home' ||
    cat === 'living' ||
    cat.includes('home') ||
    subcat.includes('home') ||
    subcat.includes('kitchen') ||
    subcat.includes('living') ||
    subcat.includes('decor') ||
    title.includes('kitchen') ||
    title.includes('decor') ||
    title.includes('bedding') ||
    title.includes('pillow') ||
    title.includes('mop') ||
    title.includes('cleaning kit') ||
    title.includes('faucet') ||
    title.includes('filter') ||
    title.includes('massager') ||
    title.includes('nebulizer') ||
    title.includes('support belt') ||
    title.includes('posture corrector') ||
    title.includes('হোম') ||
    title.includes('কিচেন') ||
    title.includes('ডেকর')
  ) {
    return 'home_lifestyle';
  }

  // 8. CLOTHES & DRESSES (STRICTLY apparel only: sarees, three-pieces, kurtis, panjabis, hoodies, t-shirts, shirts, pants, jackets)
  if (
    cat === 'clothes' ||
    cat === 'clothing' ||
    cat === 'dress' ||
    cat === 'dresses' ||
    cat === 'mens-fashion' ||
    cat === "men's fashion" ||
    cat === 'men-fashion' ||
    cat === 'womens-fashion' ||
    cat === "women's fashion" ||
    cat === 'women-fashion' ||
    cat === 'fashion' ||
    cat === 'apparel' ||
    cat === 'streetwear' ||
    cat === 'anime' ||
    title.includes('saree') ||
    title.includes('sharee') ||
    title.includes('katan') ||
    title.includes('georgette') ||
    title.includes('three piece') ||
    title.includes('3 piece') ||
    title.includes('salwar kameez') ||
    title.includes('kurti') ||
    title.includes('panjabi') ||
    title.includes('hoodie') ||
    title.includes('shirt') ||
    title.includes('t-shirt') ||
    title.includes('polo') ||
    title.includes('dress') ||
    title.includes('pant') ||
    title.includes('jacket') ||
    title.includes('fleece') ||
    title.includes('borka') ||
    title.includes('abaya') ||
    title.includes('raincoat') ||
    title.includes('শার্ট') ||
    title.includes('টি-শার্ট') ||
    title.includes('পাঞ্জাবি') ||
    title.includes('কুর্তি') ||
    title.includes('শাড়ি') ||
    title.includes('শাড়ি') ||
    title.includes('থ্রি-পিস') ||
    title.includes('থ্রিপিস') ||
    title.includes('কাতান') ||
    title.includes('জর্জেট') ||
    title.includes('হুডি') ||
    title.includes('পোশাক') ||
    title.includes('ড্রেস') ||
    title.includes('জিন্স') ||
    title.includes('প্যান্ট') ||
    title.includes('বোরকা') ||
    title.includes('রেইনকোট')
  ) {
    if (title.includes('saree') || title.includes('শাড়ি') || title.includes('borka') || title.includes('abaya') || title.includes('salwar')) {
      return 'womens_fashion';
    }
    if (title.includes('hoodie') || title.includes('jacket') || title.includes('হুডি')) {
      return 'winter';
    }
    return 'mens_fashion';
  }

  // 9. OTHER'S (fallback for sports, sunglasses, books, groceries, unique products)
  return 'others';
}

/**
 * Checks if a product matches a category filter selected in Navigation / Filter Menu
 */
export function matchesCategoryFilter(product: Product, selectedCategory: CategoryId): boolean {
  if (!selectedCategory || selectedCategory === 'all') return true;
  if (!product) return false;

  const targetNorm = normalizeCategoryId(selectedCategory);
  const prodNorm = normalizeCategoryId(product.category);

  // Standing rule: watches always belong exclusively to 'watches'
  const isWatch = prodNorm === 'watches' || isWatchProductTitle(product.titleEn, product.titleBn);
  if (targetNorm === 'watches') {
    return isWatch;
  }
  if (isWatch) {
    return false;
  }

  // Direct normalized category equality
  if (prodNorm === targetNorm) return true;

  // If both target and product have explicit standard main categories, do not leak across categories via substring keywords
  const mainCategories = new Set([
    'winter',
    'mens-fashion',
    'watches',
    'womens-fashion',
    'jewelry',
    'home-lifestyle',
    'gadgets-electronics',
    'kids-zone',
    'foods',
    'others'
  ]);
  if (mainCategories.has(targetNorm) && mainCategories.has(prodNorm)) {
    return false;
  }

  const text = ((product.category || '') + ' ' + (product.subcategory || '') + ' ' + (product.titleEn || '') + ' ' + (product.titleBn || '')).toLowerCase();
  const sub = (product.subcategory || '').toLowerCase();
  const prodCat = (product.category || '').toLowerCase().trim();

  if (targetNorm === 'womens-fashion') {
    return prodCat === 'womens-fashion' || sub.includes('saree') || sub.includes('borka') || sub.includes('salwar') || sub.includes('ladies') || text.includes('saree') || text.includes('sharee') || text.includes('women') || text.includes('lady');
  }

  if (targetNorm === 'mens-fashion') {
    return prodCat === 'mens-fashion' || sub.includes('panjabi') || /\bmen\b/.test(text) || /\bmens\b/.test(text);
  }

  return prodCat === targetNorm;
}

// ================= AUTOMATIC CATEGORY & SEO GENERATION =================
export interface AutoDetectedCategory {
  categoryId: CategoryId;
  sectionId: HomeSectionId;
  subcategory: string;
  nameBn: string;
  nameEn: string;
  badge: string;
}

export function detectProductCategoryFromTitle(title: string): AutoDetectedCategory {
  const norm = (title || '').toLowerCase().trim();

  // 1. শাড়ি (Saree)
  if (
    norm.includes('শাড়ি') || norm.includes('শাড়ি') || norm.includes('saree') || 
    norm.includes('sharee') || norm.includes('sari') || norm.includes('কাতান') || 
    norm.includes('katan') || norm.includes('জামদানি') || norm.includes('jamdani') || 
    norm.includes('জর্জেট') || norm.includes('georgette') || norm.includes('সিল্ক') || 
    norm.includes('মনিপুরী') || norm.includes('manipuri')
  ) {
    return {
      categoryId: 'womens-fashion',
      sectionId: 'womens_fashion',
      subcategory: 'শাড়ি (Saree)',
      nameBn: 'শাড়ি (Saree)',
      nameEn: 'Saree Collection',
      badge: '👗 শাড়ি'
    };
  }

  // 2. ব্যাগ (Bags & Backpacks)
  if (
    norm.includes('ব্যাগ') || norm.includes('bag') || norm.includes('backpack') || 
    norm.includes('হ্যান্ডব্যাগ') || norm.includes('handbag') || norm.includes('tote') || 
    norm.includes('luggage') || norm.includes('লাগেজ') || norm.includes('ট্রাভেল ব্যাগ') || 
    norm.includes('পার্স') || norm.includes('purse') || norm.includes('wallet') || 
    norm.includes('মানিব্যাগ') || norm.includes('স্কুল ব্যাগ') || norm.includes('side bag') || 
    norm.includes('crossbody') || norm.includes('messenger')
  ) {
    return {
      categoryId: 'home-lifestyle',
      sectionId: 'home_lifestyle',
      subcategory: 'ব্যাগ ও ব্যাকপ্যাক (Bags)',
      nameBn: 'ব্যাগ ও ব্যাকপ্যাক',
      nameEn: 'Bags & Backpacks',
      badge: '🎒 ব্যাগ'
    };
  }

  // 3. ঘড়ি (Watches - Dedicated Watches Category)
  if (isWatchProductTitle(title)) {
    return {
      categoryId: 'watches',
      sectionId: 'watches',
      subcategory: 'ঘড়ি ও স্মার্টওয়াচ (Watches)',
      nameBn: 'ঘড়ি (Watches)',
      nameEn: 'Watches',
      badge: '⌚ ঘড়ি'
    };
  }

  // 4. গ্যাজেটস ও ইলেকট্রনিক্স (Gadgets & Electronics)
  if (
    norm.includes('gadget') || norm.includes('গ্যাজেট') || norm.includes('electronic') || 
    norm.includes('ইলেকট্রনিক') || norm.includes('ইলোকট্রনিক') || norm.includes('ইলেকট্রনিক্স') || 
    norm.includes('trimmer') || norm.includes('ট্রিমার') || norm.includes('shaver') || 
    norm.includes('শেভার') || norm.includes('earbuds') || norm.includes('ইয়ারবাড') || 
    norm.includes('ইয়ারবাড') || norm.includes('headphone') || norm.includes('হেডফোন') || 
    norm.includes('bluetooth') || norm.includes('ব্লুটুথ') || norm.includes('speaker') || 
    norm.includes('স্পিকার') || norm.includes('powerbank') || norm.includes('power bank') || 
    norm.includes('পাওয়ার ব্যাংক') || norm.includes('charger') || norm.includes('চার্জার') || 
    norm.includes('cable') || norm.includes('কেবিল') || norm.includes('fan') || 
    norm.includes('ফ্যান') || norm.includes('nebulizer') || norm.includes('নেবুলাইজার') || 
    norm.includes('camera') || norm.includes('ক্যামেরা') || norm.includes('light') || 
    norm.includes('লাইট') || norm.includes('lamp') || norm.includes('m10') || norm.includes('f9') ||
    norm.includes('kemei') || norm.includes('vgr') || norm.includes('htc')
  ) {
    return {
      categoryId: 'gadgets-electronics',
      sectionId: 'gadgets_electronics',
      subcategory: 'গ্যাজেটস ও ইলেকট্রনিক্স (Gadgets)',
      nameBn: 'গ্যাজেটস ও ইলেকট্রনিক্স',
      nameEn: 'Gadgets & Electronics',
      badge: '⚡ ইলেকট্রনিক্স'
    };
  }

  // 5. হুডি (Hoodie)
  if (
    norm.includes('hoodie') || norm.includes('হুডি') || norm.includes('sweatshirt') || 
    norm.includes('সুইটশার্ট') || norm.includes('জ্যাকেট') || norm.includes('jacket') || 
    norm.includes('হুডি কম্বো') || norm.includes('উইন্টার হুডি') || norm.includes('শীতের হুডি')
  ) {
    return {
      categoryId: 'winter',
      sectionId: 'winter',
      subcategory: 'হুডি (Hoodie)',
      nameBn: 'উইন্টার হুডি',
      nameEn: 'Winter Hoodies & Jackets',
      badge: '🧥 হুডি'
    };
  }

  // 6. জামা / পোশাক (Clothes / Jama / Apparel)
  if (
    norm.includes('জামা') || norm.includes('পোশাক') || norm.includes('shirt') || 
    norm.includes('শার্ট') || norm.includes('t-shirt') || norm.includes('tshirt') || 
    norm.includes('টি-শার্ট') || norm.includes('টি শার্ট') || norm.includes('panjabi') || 
    norm.includes('পাঞ্জাবি') || norm.includes('পাঞ্জাবী') || norm.includes('kurti') || 
    norm.includes('কুর্তি') || norm.includes('dress') || norm.includes('ড্রেস') || 
    norm.includes('থ্রি পিস') || norm.includes('three piece') || norm.includes('থ্রি-পিস') || 
    norm.includes('কামিজ') || norm.includes('kameez') || norm.includes('pant') || 
    norm.includes('প্যান্ট') || norm.includes('জিন্স') || norm.includes('jeans') || 
    norm.includes('polo') || norm.includes('পোলো') || norm.includes('পায়জামা') || 
    norm.includes('পায়জামা') || norm.includes('বোরকা') || norm.includes('burqa') || 
    norm.includes('হিজাব') || norm.includes('hijab') || norm.includes('abaya')
  ) {
    const isWomen = norm.includes('বোরকা') || norm.includes('abaya') || norm.includes('hijab') || norm.includes('হিজাব') || norm.includes('kurti') || norm.includes('কামিজ') || norm.includes('kameez') || norm.includes('থ্রি পিস') || norm.includes('three piece');
    return {
      categoryId: isWomen ? 'womens-fashion' : 'mens-fashion',
      sectionId: isWomen ? 'womens_fashion' : 'mens_fashion',
      subcategory: isWomen ? 'ওমেনস ড্রেস (Women)' : 'মেনস পোশাক (Men)',
      nameBn: isWomen ? 'ওমেনস ফ্যাশন' : 'মেনস ফ্যাশন',
      nameEn: isWomen ? "Women's Fashion" : "Men's Fashion",
      badge: isWomen ? '👗 ওমেনস' : '👕 মেনস'
    };
  }

  // 7. কিডস জোন ও বেবি (Kids & Baby)
  if (
    norm.includes('baby') || norm.includes('বেবি') || norm.includes('kid') || 
    norm.includes('বাচ্চা') || norm.includes('বাচ্চাদের') || norm.includes('toy') || 
    norm.includes('খেলনা') || norm.includes('swaddle') || norm.includes('ডায়াপার') || 
    norm.includes('diaper') || norm.includes('ফিডার') || norm.includes('feeder')
  ) {
    return {
      categoryId: 'kids-zone',
      sectionId: 'kids_zone',
      subcategory: 'কিডস ও বেবি (Kids & Baby)',
      nameBn: 'কিডস জোন',
      nameEn: 'Kids & Baby Zone',
      badge: '👶 কিডস'
    };
  }

  // 8. হোম ও লাইফস্টাইল (Home & Lifestyle)
  if (
    norm.includes('home') || norm.includes('হোম') || norm.includes('kitchen') || 
    norm.includes('কিচেন') || norm.includes('রান্না') || norm.includes('decor') || 
    norm.includes('ডেকর') || norm.includes('পর্দা') || norm.includes('curtain') || 
    norm.includes('বেডশিট') || norm.includes('bedsheet') || norm.includes('pillow') || 
    norm.includes('বালিশ') || norm.includes('বোতল') || norm.includes('bottle') || 
    norm.includes('flask') || norm.includes('মগ') || norm.includes('mug') || 
    norm.includes('র্যাক') || norm.includes('rack') || norm.includes('স্ট্যান্ড') || 
    norm.includes('stand') || norm.includes('পিলার') || norm.includes('peeler')
  ) {
    return {
      categoryId: 'home-lifestyle',
      sectionId: 'home_lifestyle',
      subcategory: 'হোম ও কিচেন (Home & Living)',
      nameBn: 'হোম ও লাইফস্টাইল',
      nameEn: 'Home & Lifestyle',
      badge: '🏠 হোম'
    };
  }

  // 9. বাইক এক্সেসরিজ (Bike Accessories)
  if (
    norm.includes('bike') || norm.includes('বাইক') || norm.includes('motorcycle') || 
    norm.includes('মোটরসাইকেল') || norm.includes('helmet') || norm.includes('হেলমেট') || 
    norm.includes('রাইডিং') || norm.includes('riding')
  ) {
    return {
      categoryId: 'home-lifestyle',
      sectionId: 'home_lifestyle',
      subcategory: 'বাইক এক্সেসরিজ (Bike Gear)',
      nameBn: 'বাইক এক্সেসরিজ',
      nameEn: 'Bike Accessories',
      badge: '🏍️ বাইক'
    };
  }

  // 10. জুতো ও স্নিকার্স
  if (
    norm.includes('shoe') || norm.includes('shoes') || norm.includes('জুতো') || 
    norm.includes('জুতা') || norm.includes('sneaker') || norm.includes('স্নিকার্স') || 
    norm.includes('sandal') || norm.includes('স্যান্ডেল') || norm.includes('loafer') || 
    norm.includes('লোফার') || norm.includes('বুটের') || norm.includes('boot')
  ) {
    return {
      categoryId: 'others',
      sectionId: 'others',
      subcategory: 'জুতো ও ফুটওয়্যার (Footwear)',
      nameBn: 'জুতো ও ফুটওয়্যার',
      nameEn: 'Shoes & Footwear',
      badge: '👟 জুতো'
    };
  }

  // 11. চুড়ি, ব্রেসলেট ও গহনা (Jewelry's Category)
  if (
    norm.includes('bracelet') || norm.includes('bangle') || norm.includes('চুড়ি') || 
    norm.includes('চুড়ি') || norm.includes('ব্রেসলেট') || norm.includes('necklace') || 
    norm.includes('earring') || norm.includes('jhumka') || norm.includes('nose pin') ||
    norm.includes('nosepin') || norm.includes('pendant') || norm.includes('locket') ||
    norm.includes('anklet') || norm.includes('payel') ||
    norm.includes('jewelry') || norm.includes('jewellery') || norm.includes('গহনা') || 
    norm.includes('জুয়েলারি') || norm.includes('আংটি') || /\bring\b/.test(norm)
  ) {
    return {
      categoryId: 'jewelry',
      sectionId: 'jewelry',
      subcategory: "জুয়েলারি ও গহনা (Jewelry's)",
      nameBn: "জুয়েলারি (Jewelry's)",
      nameEn: "Jewelry's",
      badge: '💎 জুয়েলারি'
    };
  }

  // 12. ফুডস ও অর্গানিক খাবার (Food's Category)
  if (
    norm.includes('honey') || norm.includes('মধু') || norm.includes('ghee') || norm.includes('ঘি') ||
    norm.includes('chia') || norm.includes('চিয়া') || norm.includes('isabgol') || norm.includes('ইসবগুল') ||
    norm.includes('খেজুর') || norm.includes('dates') || norm.includes('বাদাম') || norm.includes('almond') ||
    norm.includes('cashew') || norm.includes('মসলা') || norm.includes('tea') || norm.includes('coffee') ||
    norm.includes('oats') || norm.includes('organic food') || norm.includes('ফুড')
  ) {
    return {
      categoryId: 'foods',
      sectionId: 'foods',
      subcategory: 'খাঁটি মধু, ঘি ও অর্গানিক ফুডস (Organic Foods)',
      nameBn: "ফুডস (Food's)",
      nameEn: "Food's",
      badge: '🍯 ফুডস'
    };
  }

  // 13. কম্বো প্যাক, কাপল সেট, গিফট ও মিস্ট্রি বক্স (Other's Category)
  if (
    norm.includes('combo') || norm.includes('কম্বো') || norm.includes('couple') || norm.includes('কাপল') ||
    norm.includes('mystery') || norm.includes('মিস্ট্রি') || norm.includes('gift') || norm.includes('গিফট') ||
    norm.includes('customize') || norm.includes('কাস্টমাইজ')
  ) {
    return {
      categoryId: 'others',
      sectionId: 'others',
      subcategory: 'ধামাকা কম্বো প্যাক ও গিফট আইটেম (Combos & Gifts)',
      nameBn: "অন্যান্য (Other's)",
      nameEn: "Other's",
      badge: '🎁 স্পেশাল অফার'
    };
  }

  // Fallback -> 'others' (Never put unknown items into clothes!)
  return {
    categoryId: 'others',
    sectionId: 'others',
    subcategory: 'গিফট আইটেম ও শোপিস (Gift Items & Showpieces)',
    nameBn: "অন্যান্য (Other's)",
    nameEn: "Other's",
    badge: '🛍️ প্রোডাক্ট'
  };
}

/**
 * Normalizes any category string or legacy alias into the standard CategoryId
 */
export function normalizeCategoryId(cat?: string | null): CategoryId {
  if (!cat) return 'others';
  const c = String(cat).toLowerCase().trim();
  if (c === 'watches' || c === 'watch' || c === 'ঘড়ি' || c === 'ঘড়ি' || c === 'smartwatch' || c === 'wristwatch') return 'watches';
  if (c === 'jewelry' || c === "jewelry's" || c === 'jewellery' || c === "jewellery's" || c === 'জুয়েলারি' || c === 'জুয়েলারি' || c === 'গহনা') return 'jewelry';
  if (c === 'winter' || c.includes('winter') || c.includes('hoodie') || c.includes('jacket')) return 'winter';
  if (c === 'mens-fashion' || c === "men's fashion" || c === 'men' || c === 'mens' || c === 'panjabi') return 'mens-fashion';
  if (c === 'womens-fashion' || c === "women's fashion" || c === 'women' || c === 'womens' || c === 'saree' || c === 'sharee' || c === 'borka' || c === 'salwar') return 'womens-fashion';
  if (c === 'home-lifestyle' || c === 'home_lifestyle' || c === 'home' || c === 'lifestyle' || c === 'bags' || c === 'bag' || c === 'bed-sheet') return 'home-lifestyle';
  if (c === 'gadgets-electronics' || c === 'gadgets_electronics' || c === 'gadgets' || c === 'electronics' || c === 'tech') return 'gadgets-electronics';
  if (c === 'kids-zone' || c === 'kids_zone' || c === 'kids' || c === 'baby') return 'kids-zone';
  if (c === 'foods' || c === "food's" || c === 'food' || c === 'groceries' || c === 'grocery' || c === 'spice' || c === 'honey' || c === 'ফুডস') return 'foods';
  if (c === 'others' || c === 'other' || c === 'combo-product' || c === 'combo' || c === 'bike-accessories') return 'others';
  if (c === 'clothes') return 'mens-fashion';
  return c;
}

export function generateAutoSeo(title: string, description: string = ''): { seoTitle: string; seoDescription: string } {
  const cleanTitle = (title || '').trim();
  const cleanDesc = (description || '').trim().replace(/[\r\n]+/g, ' ');

  if (!cleanTitle) {
    return {
      seoTitle: 'Happy Shopping - সেরা পণ্য ও অনলাইন শপিং বাংলাদেশ',
      seoDescription: 'বাংলাদেশের নির্ভরযোগ্য অনলাইন শপ Happy Shopping। ক্যাশ অন ডেলিভারি এবং দ্রুত হোম ডেলিভারি সুবিধা সারা দেশে।'
    };
  }

  // SEO Title: Clean and punchy under 65 chars
  const seoTitle = `${cleanTitle} - কিনুন সেরা মূল্যে | Happy Shopping`.slice(0, 70);

  // SEO Description: Around 140-160 chars
  let seoDesc = `অনলাইনে কিনুন ${cleanTitle}। ১০০% অরিজিনাল কোয়ালিটি, ক্যাশ অন ডেলিভারি এবং দ্রুত ডেলিভারি সুবিধা সারা দেশে।`;
  if (cleanDesc) {
    const extra = cleanDesc.slice(0, 60);
    seoDesc = `${cleanTitle}: ${extra}... ক্যাশ অন ডেলিভারিতে অর্ডার করুন সারা বাংলাদেশে।`;
  }

  return {
    seoTitle,
    seoDescription: seoDesc.slice(0, 160)
  };
}

/**
 * Reorders product catalog when an admin manually assigns a displayOrder (e.g. #1, #2, #3).
 * If product B is set to position 1, the previous #1 automatically shifts down to #2, #2 to #3, and so on.
 */
export function shiftAndReorderProducts(
  products: Product[],
  targetProductId: string,
  newOrder: number
): Product[] {
  const targetIndex = products.findIndex(p => p.id === targetProductId);
  if (targetIndex === -1) return products;

  const validNewOrder = Math.max(1, Math.floor(newOrder));
  
  // Sort existing products by displayOrder (1-based) or natural position
  const sorted = [...products].sort((a, b) => {
    const ordA = typeof a.displayOrder === 'number' && a.displayOrder > 0 ? a.displayOrder : 99999;
    const ordB = typeof b.displayOrder === 'number' && b.displayOrder > 0 ? b.displayOrder : 99999;
    return ordA - ordB;
  });

  const targetProd = products[targetIndex];
  const remaining = sorted.filter(p => p.id !== targetProductId);
  
  // Insert at desired 1-based position (index = validNewOrder - 1)
  const insertIndex = Math.min(Math.max(0, validNewOrder - 1), remaining.length);
  remaining.splice(insertIndex, 0, { ...targetProd, displayOrder: validNewOrder });

  // Re-number displayOrder sequentially (1, 2, 3...)
  return remaining.map((p, idx) => ({
    ...p,
    displayOrder: idx + 1
  }));
}

