import { Product } from '../types';

/**
 * Returns ONLY the real sizes explicitly assigned to this product.
 * Never invents or falls back to fake sizes (e.g., M/L/XL or Free Size).
 */
export function getProductSizes(product?: Product | null): string[] {
  if (!product) return [];

  const seen = new Set<string>();
  const result: string[] = [];

  const pushClean = (raw?: string) => {
    if (!raw) return;
    const clean = raw.trim();
    if (!clean) return;
    const lower = clean.toLowerCase();
    if (lower === 'none' || lower === 'n/a' || lower === 'null' || lower === 'undefined') return;
    if (!seen.has(lower)) {
      seen.add(lower);
      result.push(clean);
    }
  };

  if (Array.isArray(product.variants) && product.variants.length > 0) {
    for (const v of product.variants) {
      if (v && typeof v.size === 'string') {
        v.size.split(/[,;|]+/).forEach(pushClean);
      }
    }
    if (result.length > 0) return result;
  }

  if (typeof product.size === 'string' && product.size.trim()) {
    product.size.split(/[,;|]+/).forEach(pushClean);
  }

  return result;
}

/**
 * Returns ONLY the real colors explicitly assigned to this product.
 * Never invents or falls back to fake colors (e.g., Black/Navy/Maroon).
 */
export function getProductColors(product?: Product | null): string[] {
  if (!product) return [];

  const seen = new Set<string>();
  const result: string[] = [];

  const pushClean = (raw?: string) => {
    if (!raw) return;
    const clean = raw.trim();
    if (!clean) return;
    const lower = clean.toLowerCase();
    if (lower === 'none' || lower === 'n/a' || lower === 'null' || lower === 'undefined') return;
    if (!seen.has(lower)) {
      seen.add(lower);
      result.push(clean);
    }
  };

  if (Array.isArray(product.variants) && product.variants.length > 0) {
    for (const v of product.variants) {
      if (v && typeof v.color === 'string') {
        v.color.split(/[,;|]+/).forEach(pushClean);
      }
    }
    if (result.length > 0) return result;
  }

  if (typeof product.color === 'string' && product.color.trim()) {
    product.color.split(/[,;|]+/).forEach(pushClean);
  }

  return result;
}
