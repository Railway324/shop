import { Product } from '../types';
import { normalizeCategoryId } from './categoryUtils';

/**
 * Reorders a product to a new position (1-indexed, e.g. 1 for first position).
 * Automatically shifts all existing products so that:
 * - If target is moved to #1, the previous #1 becomes #2, #2 becomes #3, and so on.
 * - Guarantees no duplicate serial numbers and clean continuous ordering.
 * - Reorders within the product's category to ensure #1 is the top card in its category section.
 */
export function shiftProductOrder(
  allProducts: Product[],
  targetProductId: string,
  newOrder: number,
  withinCategory: boolean = true
): Product[] {
  if (!allProducts || allProducts.length === 0 || !targetProductId) {
    return allProducts;
  }

  const targetProd = allProducts.find(p => p.id === targetProductId);
  if (!targetProd) return allProducts;

  const targetCat = normalizeCategoryId(targetProd.category);
  const clampedOrder = Math.max(1, Math.floor(newOrder));

  // Partition products: those within the reordering group vs others
  const inGroup: Product[] = [];
  const outGroup: Product[] = [];

  for (const p of allProducts) {
    if (!withinCategory || normalizeCategoryId(p.category) === targetCat) {
      inGroup.push(p);
    } else {
      outGroup.push(p);
    }
  }

  // Sort group by current order (pinned first, then displayOrder, then createdAt)
  inGroup.sort((a, b) => {
    if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
    if (!a.isPinnedToTop && b.isPinnedToTop) return 1;

    const ordA = typeof a.displayOrder === 'number' && a.displayOrder > 0 ? a.displayOrder : 99999;
    const ordB = typeof b.displayOrder === 'number' && b.displayOrder > 0 ? b.displayOrder : 99999;
    if (ordA !== ordB) return ordA - ordB;

    return (b.createdAt || '').localeCompare(a.createdAt || '');
  });

  // Remove target product from sorted group
  const filteredGroup = inGroup.filter(p => p.id !== targetProductId);

  // Target insert index: 0-indexed (clampedOrder - 1)
  const insertIndex = Math.min(Math.max(0, clampedOrder - 1), filteredGroup.length);

  // Insert target product at desired index
  filteredGroup.splice(insertIndex, 0, targetProd);

  // Re-index displayOrder sequentially 1, 2, 3...
  const updatedGroup = filteredGroup.map((prod, idx) => ({
    ...prod,
    displayOrder: idx + 1,
    updatedAt: prod.id === targetProductId ? new Date().toISOString() : prod.updatedAt
  }));

  // Re-combine products preserving relative ordering of all products
  const updatedMap = new Map(updatedGroup.map(p => [p.id, p]));
  return allProducts.map(p => updatedMap.get(p.id) || p);
}
