import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile, 
  signOut, 
  sendPasswordResetEmail, 
  onAuthStateChanged,
  User 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  orderBy,
  onSnapshot,
  writeBatch,
  deleteDoc
} from 'firebase/firestore';
import { getAnalytics, isSupported } from 'firebase/analytics';
import { UserProfile, Order, Product, WebsiteCustomizerSettings, Coupon, ProductReview, Banner, Category } from '../types';

// User's Firebase Configuration
export const firebaseConfig = {
  apiKey: "AIzaSyAQf4x3vhi5Pq4G9qokXJb1xx4jERRD_qU",
  authDomain: "tanvir-ai-bot-4.firebaseapp.com",
  projectId: "tanvir-ai-bot-4",
  storageBucket: "tanvir-ai-bot-4.firebasestorage.app",
  messagingSenderId: "436344970658",
  appId: "1:436344970658:web:457636142217eca77c66fb",
  measurementId: "G-LERLJ2LLQR"
};

// Initialize App
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

// Safe Analytics init in browser environment
if (typeof window !== 'undefined') {
  isSupported().then(supported => {
    if (supported) {
      getAnalytics(app);
    }
  }).catch(() => {
    // Ignore analytics error in restricted iframe environments
  });
}

// Error Handling conforming to Firebase Guidelines
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.warn('Firestore Operation Note:', errInfo);
}

// Utility: Recursively remove undefined fields so Firestore never rejects payloads
export function removeUndefinedFields<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;
  if (typeof obj === 'string') {
    return obj.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '') as unknown as T;
  }
  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => removeUndefinedFields(item)) as unknown as T;
  }
  if (typeof obj === 'object' && !(obj instanceof Date)) {
    const clean: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        clean[key] = removeUndefinedFields(value);
      }
    }
    return clean as T;
  }
  return obj;
}

// ==========================================
// Firestore User Profile Helpers
// ==========================================

export async function saveUserProfileToFirestore(
  uid: string, 
  data: Partial<UserProfile>
): Promise<void> {
  const path = `users/${uid}`;
  try {
    const userRef = doc(db, 'users', uid);
    const now = new Date().toISOString();
    const cleanData = removeUndefinedFields({
      ...data,
      uid,
      updatedAt: now,
    });
    await setDoc(userRef, cleanData, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function getUserProfileFromFirestore(uid: string): Promise<UserProfile | null> {
  const path = `users/${uid}`;
  try {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
    return null;
  }
}

// ==========================================
// Firestore Products Helpers
// ==========================================

export async function addProductToFirestore(product: Omit<Product, 'id'>): Promise<Product> {
  const path = `products/add`;
  try {
    // Generate a new, unique document reference in the 'products' collection
    const newDocRef = doc(collection(db, 'products'));
    const productWithId: Product = {
      ...product,
      id: newDocRef.id,
      createdAt: product.createdAt || new Date().toISOString()
    };
    const cleanData = removeUndefinedFields(productWithId);
    await setDoc(newDocRef, cleanData);
    return productWithId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    throw err;
  }
}

export async function bulkSyncProductsToFirestore(products: Product[]): Promise<void> {
  const path = `products/bulkSync`;
  try {
    const valid = products.filter(p => p && p.id);
    const chunkSize = 100;
    for (let i = 0; i < valid.length; i += chunkSize) {
      const chunk = valid.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      for (const p of chunk) {
        const ref = doc(db, 'products', p.id);
        const payload = removeUndefinedFields({
          ...p,
          size: p.size || '',
          color: p.color || '',
          variants: p.variants && p.variants.length > 0 ? p.variants : [],
        });
        batch.set(ref, payload, { merge: true });
      }
      await batch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function updateProductInFirestore(productId: string, updates: Partial<Product>): Promise<void> {
  const path = `products/${productId}`;
  try {
    const productRef = doc(db, 'products', productId);
    const normalizedUpdates: Record<string, any> = {
      ...updates,
      id: productId,
      updatedAt: new Date().toISOString()
    };
    if ('size' in updates && !updates.size) normalizedUpdates.size = '';
    if ('color' in updates && !updates.color) normalizedUpdates.color = '';
    if ('variants' in updates && (!updates.variants || updates.variants.length === 0)) normalizedUpdates.variants = [];
    const cleanUpdates = removeUndefinedFields(normalizedUpdates);
    // Use setDoc with merge: true so if document did not exist yet, it is cleanly created
    await setDoc(productRef, cleanUpdates, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function recordDeletedProductInFirestore(productId: string): Promise<void> {
  const cleanId = String(productId || '').trim();
  if (!cleanId) return;
  try {
    const ref = doc(db, 'deleted_products', cleanId);
    await setDoc(ref, { id: cleanId, deletedAt: new Date().toISOString() });
  } catch (err) {
    console.warn('Firestore record deleted product note:', err);
  }
}

export async function getDeletedProductIdsFromFirestore(): Promise<string[]> {
  try {
    const q = collection(db, 'deleted_products');
    const snap = await getDocs(q);
    const ids: string[] = [];
    snap.forEach(d => ids.push(d.id));
    return ids;
  } catch (err) {
    return [];
  }
}

export async function deleteProductFromFirestore(productId: string): Promise<void> {
  const path = `products/${productId}`;
  try {
    const productRef = doc(db, 'products', productId);
    await deleteDoc(productRef);
    await recordDeletedProductInFirestore(productId);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function clearAllProductsFromFirestore(): Promise<void> {
  const path = 'products/clearAll';
  try {
    const q = collection(db, 'products');
    const snap = await getDocs(q);
    if (snap.empty) return;

    const chunkSize = 400;
    for (let i = 0; i < snap.docs.length; i += chunkSize) {
      const chunk = snap.docs.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      chunk.forEach(d => {
        batch.delete(doc(db, 'products', d.id));
      });
      await batch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function getAllProductsFromFirestore(): Promise<Product[]> {
  const path = 'products';
  try {
    const q = query(collection(db, 'products'));
    const snap = await getDocs(q);
    const products: Product[] = [];
    snap.forEach((d) => {
      products.push(d.data() as Product);
    });
    return products;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    return [];
  }
}

export function subscribeToAllProducts(callback: (products: Product[]) => void): () => void {
  const q = query(collection(db, 'products'));
  const unsubscribe = onSnapshot(
    q,
    (snapshot) => {
      if (snapshot.empty) {
        callback([]);
        return;
      }
      const products: Product[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data() as Product;
        if (data && data.id) {
          products.push(data);
        }
      });
      callback(products);
    },
    (err) => {
      console.warn('[Firebase] Error subscribing to products:', err);
    }
  );
  return unsubscribe;
}

// ==========================================
// Firestore Settings Helpers
// ==========================================

export async function saveSettingsToFirestore(
  settings?: WebsiteCustomizerSettings,
  extraSettings?: {
    storeSettings?: any;
    deliverySettings?: any;
    seoSettings?: any;
  }
): Promise<boolean> {
  const path = `settings`;
  try {
    if (settings) {
      const settingsRef = doc(db, 'settings', 'customizer');
      const cleanSettings = removeUndefinedFields(settings);
      await setDoc(settingsRef, cleanSettings, { merge: true });
    }
    if (extraSettings?.storeSettings) {
      const storeRef = doc(db, 'settings', 'store');
      await setDoc(storeRef, removeUndefinedFields(extraSettings.storeSettings), { merge: true });
    }
    if (extraSettings?.deliverySettings) {
      const deliveryRef = doc(db, 'settings', 'delivery');
      await setDoc(deliveryRef, removeUndefinedFields(extraSettings.deliverySettings), { merge: true });
    }
    if (extraSettings?.seoSettings) {
      const seoRef = doc(db, 'settings', 'seo');
      await setDoc(seoRef, removeUndefinedFields(extraSettings.seoSettings), { merge: true });
    }
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
    return false;
  }
}

export async function getSettingsFromFirestore(): Promise<WebsiteCustomizerSettings | null> {
  const path = `settings/customizer`;
  try {
    const settingsRef = doc(db, 'settings', 'customizer');
    const snap = await getDoc(settingsRef);
    if (snap.exists()) {
      return snap.data() as WebsiteCustomizerSettings;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
  return null;
}

export function subscribeToCustomizerSettings(callback: (settings: WebsiteCustomizerSettings) => void): () => void {
  const settingsRef = doc(db, 'settings', 'customizer');
  const unsubscribe = onSnapshot(
    settingsRef,
    (snap) => {
      if (snap.exists()) {
        callback(snap.data() as WebsiteCustomizerSettings);
      }
    },
    (err) => {
      console.warn('[Firebase] Error subscribing to customizer settings:', err);
    }
  );
  return unsubscribe;
}

export function subscribeToLiveSync(callback: (syncData: any) => void): () => void {
  const syncRef = doc(db, 'settings', 'live_sync');
  const unsubscribe = onSnapshot(
    syncRef,
    (snap) => {
      if (snap.exists()) {
        callback(snap.data());
      }
    },
    (err) => {
      console.warn('[Firebase] Error subscribing to live sync:', err);
    }
  );
  return unsubscribe;
}

export interface LivePublishResult {
  success: boolean;
  productsCount: number;
  lastPublishedAt: string;
  liveUrl: string;
  serverSynced: boolean;
  firestoreSynced: boolean;
  permissionDenied?: boolean;
  error?: string;
  details?: string;
}

const OBSOLETE_PRODUCT_IDS_TO_PURGE = [
  'prod-trendy-premium-hoodie',
  'prod-drop-shoulder-hoodie',
  'prod-stylish-hoodie',
  'prod-cotton-hoodie',
  'prod-cotton-and-brush-hoodie',
  'prod-hoodie-colorblock-superhero',
  'prod-hoodie-drop-shoulder-tokyo',
  'prod-winter-dropshoulder-hoodie',
  'prod-winter-zipper-jacket-hoodie'
];

export async function publishAllToLiveWebsite(
  products: Product[],
  customizerSettings?: WebsiteCustomizerSettings,
  extraSettings?: {
    storeSettings?: any;
    deliverySettings?: any;
    seoSettings?: any;
    banners?: any[];
  },
  adminEmail?: string
): Promise<LivePublishResult> {
  const now = new Date().toISOString();
  const validProducts = Array.isArray(products) ? products.filter(p => p && p.id) : [];
  let serverSynced = false;
  let firestoreSynced = false;
  let permissionDenied = false;
  let firestoreErrorMsg = '';

  // 1. DUAL-SYNC: First push to Server API endpoints (/api/products/sync & /api/settings)
  try {
    const serverSyncRes = await fetch('/api/products/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ products: validProducts })
    });
    if (serverSyncRes.ok) {
      serverSynced = true;
    }
  } catch (serverErr) {
    console.warn('[Server Sync] Note:', serverErr);
  }

  if (customizerSettings) {
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(customizerSettings)
      });
    } catch (e) {
      // ignore
    }
  }

  // 2. Clear obsolete items from local storage caches
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      const stored = window.localStorage.getItem('shopping_mall_products_v14_curated_drive_hoodies');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          const filtered = parsed.filter(p => !OBSOLETE_PRODUCT_IDS_TO_PURGE.includes(p.id));
          window.localStorage.setItem('shopping_mall_products_v14_curated_drive_hoodies', JSON.stringify(filtered));
        }
      }
    } catch (lsErr) {
      // ignore
    }
  }

  // 3. DUAL-SYNC: Push to Firestore Cloud Database
  try {
    const { writeBatch, deleteDoc } = await import('firebase/firestore');

    // Clean obsolete IDs from Firestore
    for (const obsoleteId of OBSOLETE_PRODUCT_IDS_TO_PURGE) {
      try {
        const ref = doc(db, 'products', obsoleteId);
        await deleteDoc(ref);
      } catch (err) {
        // ignore if not found
      }
    }

    // Batch write products in chunks of 400
    const chunkSize = 400;
    for (let i = 0; i < validProducts.length; i += chunkSize) {
      const chunk = validProducts.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      for (const p of chunk) {
        const ref = doc(db, 'products', p.id);
        batch.set(ref, removeUndefinedFields(p), { merge: true });
      }
      await batch.commit();
    }

    // Save Customizer Settings & Banners
    if (customizerSettings) {
      const customizerRef = doc(db, 'settings', 'customizer');
      await setDoc(customizerRef, removeUndefinedFields(customizerSettings), { merge: true });
    }

    // Save Additional Settings
    if (extraSettings?.storeSettings) {
      const storeRef = doc(db, 'settings', 'store');
      await setDoc(storeRef, removeUndefinedFields(extraSettings.storeSettings), { merge: true });
    }
    if (extraSettings?.deliverySettings) {
      const deliveryRef = doc(db, 'settings', 'delivery');
      await setDoc(deliveryRef, removeUndefinedFields(extraSettings.deliverySettings), { merge: true });
    }
    if (extraSettings?.seoSettings) {
      const seoRef = doc(db, 'settings', 'seo');
      await setDoc(seoRef, removeUndefinedFields(extraSettings.seoSettings), { merge: true });
    }
    if (extraSettings?.banners) {
      const bannersRef = doc(db, 'settings', 'banners');
      await setDoc(bannersRef, { list: removeUndefinedFields(extraSettings.banners), updatedAt: now }, { merge: true });
    }

    // Broadcast to Live Sync channel
    const liveSyncRef = doc(db, 'settings', 'live_sync');
    const syncData = {
      lastLivePublishedAt: now,
      publishedBy: adminEmail || auth.currentUser?.email || 'admin@gift-ghor.ai.studio',
      productsCount: validProducts.length,
      liveUrl: 'https://gift-ghor.ai.studio',
      message: 'All updates from Google Studio successfully published to live website'
    };
    await setDoc(liveSyncRef, syncData, { merge: true });
    firestoreSynced = true;

  } catch (err: any) {
    console.error('[Firebase] Firestore Live Publish Error:', err);
    firestoreErrorMsg = err?.message || String(err);
    if (
      firestoreErrorMsg.toLowerCase().includes('permission') || 
      firestoreErrorMsg.toLowerCase().includes('insufficient') ||
      firestoreErrorMsg.toLowerCase().includes('denied')
    ) {
      permissionDenied = true;
    }
  }

  const overallSuccess = serverSynced || firestoreSynced;

  return {
    success: overallSuccess,
    productsCount: validProducts.length,
    lastPublishedAt: now,
    liveUrl: 'https://gift-ghor.ai.studio',
    serverSynced,
    firestoreSynced,
    permissionDenied,
    error: firestoreSynced ? undefined : (firestoreErrorMsg || (serverSynced ? undefined : 'Failed to publish to live services')),
    details: firestoreSynced 
      ? 'উভয় ক্লাউড ডেটাবেস এবং সার্ভারে সফলভাবে সিঙ্ক সম্পন্ন হয়েছে।' 
      : serverSynced 
        ? 'সার্ভারে সফলভাবে সংরক্ষিত হয়েছে, তবে ফায়ারবেস কনসোলের রুল আপডেট করা প্রয়োজন।' 
        : 'সিঙ্ক সম্পন্ন হতে পারেনি।'
  };
}

// ==========================================
// Admin Role & Security Helpers
// ==========================================

export const SUPER_ADMIN_EMAILS = [
  'rmd474915@gmail.com',
  'winlucky414@gmail.com'
];

export function isUserAdmin(profile?: UserProfile | null, userEmail?: string | null): boolean {
  const email = (profile?.email || userEmail || auth.currentUser?.email || '').toLowerCase().trim();
  if (SUPER_ADMIN_EMAILS.includes(email)) return true;
  if (profile?.role === 'admin' || profile?.role === 'superadmin') return true;
  return false;
}

// Global Diagnostics Tracker
export const liveDiagnosticState = {
  lastSyncTime: new Date().toISOString(),
  lastOrderCreatedTime: null as string | null,
  listenerStatus: 'initializing' as 'active' | 'initializing' | 'fallback' | 'error',
  firestoreConnected: true,
  ordersCount: 0,
  syncSource: 'firestore' as 'firestore' | 'server_api'
};

// ==========================================
// Firestore Orders Helpers
// ==========================================

export async function saveOrderToFirestore(order: Order): Promise<void> {
  const path = `orders/${order.id}`;
  const now = new Date().toISOString();
  
  const currentAuthUser = auth.currentUser;
  const resolvedUserId = currentAuthUser?.uid || order.userId || 'guest';
  const resolvedEmail = currentAuthUser?.email || order.userEmail || order.email || '';

  const orderToSave: Order = {
    ...order,
    id: String(order.id),
    orderId: String(order.orderId || order.id),
    userId: resolvedUserId,
    userEmail: resolvedEmail,
    email: resolvedEmail || order.email,
    createdAt: order.createdAt || now,
    updatedAt: now,
  };

  const cleanOrder = removeUndefinedFields(orderToSave);

  // 1. Persist directly to Firebase Firestore
  try {
    const orderRef = doc(db, 'orders', order.id);
    await setDoc(orderRef, cleanOrder, { merge: true });
    liveDiagnosticState.lastOrderCreatedTime = now;
    liveDiagnosticState.lastSyncTime = now;
    liveDiagnosticState.firestoreConnected = true;

    // Record status history in subcollection /orders/{orderId}/statusHistory
    try {
      const historyId = `hist_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const historyRef = doc(db, 'orders', order.id, 'statusHistory', historyId);
      const initialHistoryItem = {
        id: historyId,
        status: order.orderStatus || 'pending',
        timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
        date: now,
        note: 'অর্ডার প্লেস করা হয়েছে (Order Created)',
        updatedBy: order.customerName || 'Customer'
      };
      await setDoc(historyRef, initialHistoryItem);
    } catch (historyErr) {
      console.warn('Status history subcollection note:', historyErr);
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    liveDiagnosticState.firestoreConnected = false;
  }

  // 2. Synchronize to Server REST API
  try {
    await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cleanOrder)
    });
  } catch (serverErr) {
    console.warn('Server orders sync note:', serverErr);
  }
}

export async function updateOrderInFirestore(
  orderId: string, 
  updates: Partial<Order>,
  statusNote?: string,
  updatedBy?: string
): Promise<void> {
  const path = `orders/${orderId}`;
  const now = new Date().toISOString();
  const cleanUpdates = removeUndefinedFields({
    ...updates,
    id: orderId,
    updatedAt: now
  });

  // 1. Update in Firebase Firestore
  try {
    const orderRef = doc(db, 'orders', orderId);
    await setDoc(orderRef, cleanUpdates, { merge: true });
    liveDiagnosticState.lastSyncTime = now;
    liveDiagnosticState.firestoreConnected = true;

    // If status changed, record in subcollection /orders/{orderId}/statusHistory
    if (updates.orderStatus) {
      try {
        const historyId = `hist_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        const historyRef = doc(db, 'orders', orderId, 'statusHistory', historyId);
        const historyItem = {
          id: historyId,
          status: updates.orderStatus,
          timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
          date: now,
          note: statusNote || `স্ট্যাটাস পরিবর্তন: ${updates.orderStatus}`,
          updatedBy: updatedBy || 'Admin'
        };
        await setDoc(historyRef, historyItem);
      } catch (subErr) {
        console.warn('Status history subcollection update note:', subErr);
      }
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
    liveDiagnosticState.firestoreConnected = false;
  }

  // 2. Update on Server REST API
  try {
    await fetch(`/api/orders/${encodeURIComponent(orderId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cleanUpdates)
    });
  } catch (serverErr) {
    console.warn('Server orders update note:', serverErr);
  }
}

export async function deleteOrderFromFirestore(orderId: string): Promise<void> {
  const path = `orders/${orderId}`;
  try {
    const { deleteDoc } = await import('firebase/firestore');
    const orderRef = doc(db, 'orders', orderId);
    await deleteDoc(orderRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }

  try {
    await fetch(`/api/orders/${encodeURIComponent(orderId)}`, {
      method: 'DELETE'
    });
  } catch (serverErr) {
    console.warn('Server orders delete note:', serverErr);
  }
}

export function sanitizeOrder(raw: any): Order {
  if (!raw) {
    const now = new Date().toISOString();
    return {
      id: `ORD-${Date.now()}`,
      userId: 'guest',
      customerName: 'Customer',
      phone: '',
      divisionId: 'dhaka',
      districtId: 'dhaka',
      thanaId: '',
      address: '',
      date: now.split('T')[0],
      createdAt: now,
      updatedAt: now,
      items: [],
      subtotal: 0,
      deliveryFee: 60,
      discount: 0,
      total: 0,
      paymentMethod: 'cod',
      paymentStatus: 'pending',
      orderStatus: 'pending',
      statusHistory: [
        {
          id: 'hist-init',
          status: 'pending',
          timestamp: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
          date: now,
          note: 'অর্ডার প্লেস করা হয়েছে'
        }
      ]
    };
  }

  const now = new Date().toISOString();
  const statusHistory = Array.isArray(raw.statusHistory) && raw.statusHistory.length > 0
    ? raw.statusHistory
    : [
        {
          id: 'hist-init',
          status: raw.orderStatus || 'pending',
          timestamp: raw.date || new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
          date: raw.createdAt || now,
          note: 'অর্ডার প্লেস করা হয়েছে'
        }
      ];

  return {
    ...raw,
    id: String(raw.id || raw.orderId || `ORD-${Date.now()}`),
    orderId: String(raw.orderId || raw.id || `ORD-${Date.now()}`),
    items: Array.isArray(raw.items) ? raw.items : [],
    statusHistory,
    orderStatus: raw.orderStatus || 'pending',
    paymentStatus: raw.paymentStatus || 'pending',
    paymentMethod: raw.paymentMethod || 'cod',
    total: typeof raw.total === 'number' ? raw.total : Number(raw.total) || 0,
    subtotal: typeof raw.subtotal === 'number' ? raw.subtotal : Number(raw.subtotal) || 0,
    deliveryFee: typeof raw.deliveryFee === 'number' ? raw.deliveryFee : Number(raw.deliveryFee) || 0,
    discount: typeof raw.discount === 'number' ? raw.discount : Number(raw.discount) || 0,
    customerName: raw.customerName || 'গ্রাহক',
    phone: raw.phone || '',
    address: raw.address || '',
    date: raw.date || (raw.createdAt ? String(raw.createdAt).split('T')[0] : now.split('T')[0]),
    createdAt: raw.createdAt || raw.date || now,
    updatedAt: raw.updatedAt || now
  };
}

export async function getUserOrdersFromFirestore(userId: string): Promise<Order[]> {
  const path = 'orders';
  try {
    const q = query(
      collection(db, 'orders'),
      where('userId', '==', userId)
    );
    const snap = await getDocs(q);
    const orders: Order[] = [];
    snap.forEach((d) => {
      orders.push(sanitizeOrder(d.data()));
    });
    // Sort newest first
    return orders.sort((a, b) => {
      const timeA = new Date(a.createdAt || a.date).getTime() || 0;
      const timeB = new Date(b.createdAt || b.date).getTime() || 0;
      return timeB - timeA;
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    return [];
  }
}

export async function getAllOrdersFromFirestore(): Promise<Order[]> {
  const path = 'orders';
  try {
    const snap = await getDocs(collection(db, 'orders'));
    const orders: Order[] = [];
    snap.forEach((d) => {
      orders.push(sanitizeOrder(d.data()));
    });
    // Sort newest first
    const sorted = orders.sort((a, b) => {
      const timeA = new Date(a.createdAt || a.date).getTime() || 0;
      const timeB = new Date(b.createdAt || b.date).getTime() || 0;
      return timeB - timeA;
    });
    liveDiagnosticState.ordersCount = sorted.length;
    liveDiagnosticState.lastSyncTime = new Date().toISOString();
    return sorted;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    // Fallback to server API if needed
    try {
      const res = await fetch('/api/orders');
      const ct = res.headers.get('content-type');
      if (res.ok && ct && ct.includes('application/json')) {
        const data = await res.json();
        if (Array.isArray(data)) {
          return data.map(sanitizeOrder).sort((a, b) => {
            const timeA = new Date(a.createdAt || a.date).getTime() || 0;
            const timeB = new Date(b.createdAt || b.date).getTime() || 0;
            return timeB - timeA;
          });
        }
      }
    } catch {
      // Ignore fallback error
    }
    return [];
  }
}

// Real-time listener for Orders with Dual-Channel Sync and Safe Merge
export function subscribeToAllOrders(callback: (orders: Order[]) => void): () => void {
  let isSubscribed = true;
  let unsubscribeFirestore: (() => void) | null = null;
  const knownOrdersMap = new Map<string, Order>();

  const emitMergedOrders = (newOrders: Order[]) => {
    if (!isSubscribed) return;
    let hasChanges = false;
    if (Array.isArray(newOrders)) {
      newOrders.forEach(o => {
        if (o && o.id) {
          const sanitized = sanitizeOrder(o);
          const existing = knownOrdersMap.get(sanitized.id);
          if (!existing || JSON.stringify(existing) !== JSON.stringify(sanitized)) {
            knownOrdersMap.set(sanitized.id, sanitized);
            hasChanges = true;
          }
        }
      });
    }

    if (hasChanges || knownOrdersMap.size > 0) {
      const sorted = Array.from(knownOrdersMap.values()).sort((a, b) => {
        const timeA = new Date(a.createdAt || a.date).getTime() || 0;
        const timeB = new Date(b.createdAt || b.date).getTime() || 0;
        return timeB - timeA;
      });

      liveDiagnosticState.ordersCount = sorted.length;
      liveDiagnosticState.lastSyncTime = new Date().toISOString();
      callback(sorted);
    }
  };

  // 1. Initial immediate load from Server / Firestore
  getAllOrdersFromFirestore().then((initialOrders) => {
    if (isSubscribed && Array.isArray(initialOrders) && initialOrders.length > 0) {
      emitMergedOrders(initialOrders);
    }
  }).catch(() => {});

  // 2. Real-time Firestore snapshot listener
  try {
    const ordersRef = collection(db, 'orders');
    unsubscribeFirestore = onSnapshot(
      ordersRef, 
      (snapshot) => {
        if (!isSubscribed) return;
        const orders: Order[] = [];
        snapshot.forEach((docSnap) => {
          orders.push(sanitizeOrder(docSnap.data()));
        });
        
        if (orders.length > 0) {
          liveDiagnosticState.listenerStatus = 'active';
          liveDiagnosticState.firestoreConnected = true;
          liveDiagnosticState.syncSource = 'firestore';
          emitMergedOrders(orders);
        }
      }, 
      (error) => {
        liveDiagnosticState.listenerStatus = 'fallback';
        console.warn('Orders real-time subscription note:', error.message);
      }
    );
  } catch (err) {
    liveDiagnosticState.listenerStatus = 'fallback';
    console.warn('Could not establish real-time snapshot listener', err);
  }

  // 3. Fallback interval sync to guarantee cross-browser sync without wiping
  const pollInterval = setInterval(async () => {
    if (!isSubscribed) return;
    try {
      const res = await fetch('/api/orders');
      const ct = res.headers.get('content-type');
      if (res.ok && ct && ct.includes('application/json')) {
        const serverOrders = await res.json();
        if (Array.isArray(serverOrders) && serverOrders.length > 0 && isSubscribed) {
          emitMergedOrders(serverOrders);
        }
      }
    } catch {
      // Ignore interval error
    }
  }, 4000);

  return () => {
    isSubscribed = false;
    if (unsubscribeFirestore) {
      unsubscribeFirestore();
    }
    clearInterval(pollInterval);
  };
}

// ==========================================
// Firestore Coupons CRUD Helpers
// ==========================================

export async function saveCouponToFirestore(coupon: Coupon): Promise<void> {
  const path = `coupons/${coupon.id}`;
  try {
    const couponRef = doc(db, 'coupons', coupon.id);
    const cleanCoupon = removeUndefinedFields({
      ...coupon,
      updatedAt: new Date().toISOString()
    });
    await setDoc(couponRef, cleanCoupon, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteCouponFromFirestore(couponId: string): Promise<void> {
  const path = `coupons/${couponId}`;
  try {
    const { deleteDoc } = await import('firebase/firestore');
    const couponRef = doc(db, 'coupons', couponId);
    await deleteDoc(couponRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function getAllCouponsFromFirestore(): Promise<Coupon[]> {
  const path = 'coupons';
  try {
    const q = query(collection(db, 'coupons'));
    const snap = await getDocs(q);
    const coupons: Coupon[] = [];
    snap.forEach((d) => {
      coupons.push(d.data() as Coupon);
    });
    return coupons;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    return [];
  }
}

export function subscribeToAllCoupons(callback: (coupons: Coupon[]) => void): () => void {
  const q = query(collection(db, 'coupons'));
  return onSnapshot(
    q,
    (snap) => {
      const coupons: Coupon[] = [];
      snap.forEach(d => coupons.push(d.data() as Coupon));
      callback(coupons);
    },
    (err) => console.warn('[Firebase] Coupons subscription note:', err)
  );
}

// ==========================================
// Firestore Reviews CRUD Helpers
// ==========================================

export async function saveReviewToFirestore(review: ProductReview): Promise<void> {
  const path = `reviews/${review.id}`;
  try {
    const reviewRef = doc(db, 'reviews', review.id);
    const cleanReview = removeUndefinedFields({
      ...review,
      createdAt: review.createdAt || new Date().toISOString()
    });
    await setDoc(reviewRef, cleanReview, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteReviewFromFirestore(reviewId: string): Promise<void> {
  const path = `reviews/${reviewId}`;
  try {
    const { deleteDoc } = await import('firebase/firestore');
    const reviewRef = doc(db, 'reviews', reviewId);
    await deleteDoc(reviewRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function getAllReviewsFromFirestore(): Promise<ProductReview[]> {
  const path = 'reviews';
  try {
    const q = query(collection(db, 'reviews'));
    const snap = await getDocs(q);
    const reviews: ProductReview[] = [];
    snap.forEach((d) => {
      reviews.push(d.data() as ProductReview);
    });
    return reviews;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    return [];
  }
}

export function subscribeToAllReviews(callback: (reviews: ProductReview[]) => void): () => void {
  const q = query(collection(db, 'reviews'));
  return onSnapshot(
    q,
    (snap) => {
      const reviews: ProductReview[] = [];
      snap.forEach(d => reviews.push(d.data() as ProductReview));
      callback(reviews);
    },
    (err) => console.warn('[Firebase] Reviews subscription note:', err)
  );
}

// ==========================================
// Firestore Banners CRUD Helpers
// ==========================================

export async function saveBannerToFirestore(banner: Banner): Promise<void> {
  const path = `banners/${banner.id}`;
  try {
    const bannerRef = doc(db, 'banners', banner.id);
    const cleanBanner = removeUndefinedFields(banner);
    await setDoc(bannerRef, cleanBanner, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteBannerFromFirestore(bannerId: string): Promise<void> {
  const path = `banners/${bannerId}`;
  try {
    const { deleteDoc } = await import('firebase/firestore');
    const bannerRef = doc(db, 'banners', bannerId);
    await deleteDoc(bannerRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==========================================
// Firestore Categories CRUD Helpers
// ==========================================

export async function saveCategoryToFirestore(category: Category): Promise<void> {
  const path = `categories/${category.id}`;
  try {
    const catRef = doc(db, 'categories', category.id);
    const cleanCategory = removeUndefinedFields({
      ...category,
      updatedAt: new Date().toISOString()
    });
    await setDoc(catRef, cleanCategory, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteCategoryFromFirestore(categoryId: string): Promise<void> {
  const path = `categories/${categoryId}`;
  try {
    const { deleteDoc } = await import('firebase/firestore');
    const catRef = doc(db, 'categories', categoryId);
    await deleteDoc(catRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function getAllCategoriesFromFirestore(): Promise<Category[]> {
  const path = 'categories';
  try {
    const q = query(collection(db, 'categories'));
    const snap = await getDocs(q);
    const categories: Category[] = [];
    snap.forEach((d) => {
      categories.push(d.data() as Category);
    });
    return categories;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    return [];
  }
}

export function subscribeToAllCategories(callback: (categories: Category[]) => void): () => void {
  const q = query(collection(db, 'categories'));
  return onSnapshot(
    q,
    (snap) => {
      const categories: Category[] = [];
      snap.forEach(d => categories.push(d.data() as Category));
      callback(categories);
    },
    (err) => console.warn('[Firebase] Categories subscription note:', err)
  );
}

// Authentication Helpers
export {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  type User
};
