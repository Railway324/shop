export type Language = 'bn' | 'en';

export type CategoryId = 
  | 'all'
  | 'winter'
  | 'mens-fashion'
  | 'watches'
  | 'womens-fashion'
  | 'jewelry'
  | 'home-lifestyle'
  | 'gadgets-electronics'
  | 'kids-zone'
  | 'foods'
  | 'others'
  | string;

export type AdminTab = 
  | 'dashboard'
  | 'appearance'
  | 'aiMerchandiser'
  | 'categories'
  | 'products'
  | 'inventory'
  | 'orders'
  | 'customers'
  | 'payments'
  | 'coupons'
  | 'reports'
  | 'delivery'
  | 'reviews'
  | 'banners'
  | 'users'
  | 'activity'
  | 'settings'
  | 'seo';

export type CourierName = 
  | 'SteadFast Courier'
  | 'Pathao Courier'
  | 'RedX Delivery'
  | 'Paperfly Courier'
  | 'eCourier'
  | 'Sundarban Courier'
  | 'SA Paribahan'
  | 'In-house Rider'
  | string;

export interface ProductVariant {
  id?: string;
  size?: string;
  color?: string;
  weight?: string;
  sku?: string;
  stock?: number;
  price?: number;
}

export interface Product {
  id: string;
  titleBn: string;
  titleEn: string;
  category: CategoryId;
  subcategory?: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  sku?: string;
  rating: number;
  reviewsCount: number;
  stock: number;
  brand?: string;
  tags?: string[];
  image: string;
  additionalImages?: string[];
  variants?: ProductVariant[];
  size?: string;
  color?: string;
  weight?: string;
  status?: 'active' | 'inactive';
  descriptionBn: string;
  descriptionEn: string;
  specificationsBn?: string[];
  specificationsEn?: string[];
  isFeatured?: boolean;
  isFlashSale?: boolean;
  freeDelivery?: boolean;
  displayOrder?: number;
  isPinnedToTop?: boolean;
  // AI Trend Merchandising fields
  aiTrendScore?: number;
  aiTrendReasonBn?: string;
  aiTrendReasonEn?: string;
  aiTrendSource?: string;
  aiTrendRank?: number;
  aiLastAnalyzedAt?: string;
  seoTitle?: string;
  seoDescription?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: ProductVariant;
  selectedSize?: string;
  selectedColor?: string;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  role?: string;
  phone?: string;
  photoURL?: string;
  address?: string;
  status?: 'active' | 'blocked';
  createdAt?: string;
  updatedAt?: string;
}

export type PaymentMethod = 'cod' | 'bkash' | 'nagad' | 'card';

export type OrderStatus = 
  | 'placed' 
  | 'pending' 
  | 'confirmed' 
  | 'processing' 
  | 'packed' 
  | 'shipped' 
  | 'out_for_delivery' 
  | 'delivered' 
  | 'cancelled' 
  | 'returned' 
  | 'refunded';

export type PaymentStatus = 'pending' | 'verified' | 'paid' | 'unpaid' | 'failed' | 'refunded';

export interface OrderStatusHistoryItem {
  id?: string;
  status: OrderStatus;
  timestamp: string;
  date?: string;
  note?: string;
  updatedBy?: string;
}

export interface Order {
  id: string; // e.g. SM-82914 or GG-12345
  orderId?: string;
  userId?: string;
  userEmail?: string;
  date: string;
  createdAt?: string;
  updatedAt?: string;
  customerName: string;
  email?: string;
  phone: string;
  divisionId?: string;
  districtId?: string;
  thanaId?: string;
  address: string;
  notes?: string;
  internalNotes?: string;
  adminNotes?: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  couponCode?: string;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  trxId?: string;
  senderPhone?: string;
  cardBrand?: 'visa' | 'mastercard';
  cardLast4?: string;
  cardHolderName?: string;
  paymentVerifiedAt?: string;
  courier?: string;
  courierName?: string;
  courierTrackingCode?: string;
  trackingCode?: string;
  returnReason?: string;
  refundAmount?: number;
  statusHistory?: OrderStatusHistoryItem[];
}

export interface StockLog {
  id: string;
  productId: string;
  productName: string;
  type: 'stock_in' | 'stock_out' | 'adjustment' | 'order' | 'return';
  quantity: number;
  previousStock: number;
  newStock: number;
  reason: string;
  adminName: string;
  date: string;
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone: string;
  address: string;
  registeredAt?: string;
  createdAt?: string;
  totalOrders: number;
  totalSpent: number;
  status: 'active' | 'blocked';
  lastOrderDate?: string;
  notes?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount?: number;
  maxDiscount?: number;
  maxDiscountAmount?: number;
  expiryDate: string;
  usageLimit?: number;
  usedCount: number;
  perCustomerLimit?: number;
  isActive: boolean;
  createdAt: string;
}

export interface ProductReview {
  id: string;
  productId?: string;
  productTitle?: string;
  productName?: string;
  productImage?: string;
  customerName?: string;
  userName?: string;
  userEmail?: string;
  userId?: string;
  userPhoto?: string;
  rating: number;
  comment: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt?: string;
  date?: string;
  verifiedPurchase?: boolean;
  orderId?: string;
  reviewImage?: string;
}

export interface Category {
  id: CategoryId;
  nameBn: string;
  nameEn: string;
  iconName: string;
  itemCount: number;
  image?: string;
  subtitleBn?: string;
  subtitleEn?: string;
  badgeBn?: string;
  badgeEn?: string;
  accentColor?: string;
  isCustom?: boolean;
  displayOrder?: number;
  seoTitle?: string;
  seoDescription?: string;
}

export interface Banner {
  id: string;
  titleBn: string;
  titleEn: string;
  subtitleBn: string;
  subtitleEn: string;
  badgeBn?: string;
  badgeEn?: string;
  buttonTextBn?: string;
  buttonTextEn?: string;
  bgGradient?: string;
  accentColor?: string;
  imageUrl: string;
  linkCategory?: CategoryId;
  linkUrl?: string;
  badge?: string;
  isActive?: boolean;
  position?: 'hero' | 'promo' | 'flash_sale';
}

export interface DeliveryCourier {
  id: string;
  name: string;
  trackingUrlPrefix?: string;
  trackingUrlTemplate?: string;
  enabled?: boolean;
  active?: boolean;
}

export interface DeliverySettings {
  insideDhakaFee: number;
  outsideDhakaFee: number;
  freeShippingThreshold?: number;
  freeDeliveryThreshold?: number;
  estimatedDaysInside?: string;
  estimatedDaysOutside?: string;
  couriers: DeliveryCourier[];
  supportedCouriers?: DeliveryCourier[];
  customLocations?: {
    id: string;
    name: string;
    fee: number;
  }[];
}

export interface StoreSettings {
  storeName?: string;
  storeNameBn?: string;
  storeNameEn?: string;
  storeTagline?: string;
  taglineBn?: string;
  taglineEn?: string;
  storeLogo?: string;
  favicon?: string;
  storeEmail?: string;
  email?: string;
  phone?: string;
  address?: string;
  currency?: string;
  taxRatePercent?: number;
  taxRate?: number;
  maintenanceMode?: boolean;
  allowGuestCheckout?: boolean;
  lowStockThreshold?: number;
  seoMetaTitle?: string;
  seoMetaDescription?: string;
  seoKeywords?: string;
  seoOgImage?: string;
  socialLinks?: {
    facebook?: string;
    instagram?: string;
    youtube?: string;
    whatsapp?: string;
  };
}

export interface SeoSettings {
  metaTitle: string;
  metaDescription: string;
  keywords: string;
  ogImage: string;
  robots: string;
}

export type AdminRole = 
  | 'super_admin' 
  | 'product_manager' 
  | 'order_manager' 
  | 'customer_support' 
  | 'marketing_manager';

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: AdminRole;
  status: 'active' | 'disabled';
  lastLogin?: string;
  createdAt: string;
}

export interface ActivityLogItem {
  id: string;
  adminName: string;
  adminEmail: string;
  action: string;
  category: 
    | 'product' 
    | 'order' 
    | 'inventory' 
    | 'customer' 
    | 'coupon' 
    | 'delivery' 
    | 'review' 
    | 'banner' 
    | 'user' 
    | 'settings' 
    | 'security';
  timestamp: string;
  ipAddress?: string;
  details?: string;
}

export interface AdminNotification {
  id: string;
  type: 'order' | 'low_stock' | 'out_of_stock' | 'customer' | 'review' | 'payment' | 'return';
  title: string;
  message: string;
  timestamp: string;
  read?: boolean;
  isRead?: boolean;
  linkTab?: string;
  linkId?: string;
}

export interface FilterState {
  category: CategoryId;
  searchQuery: string;
  minPrice: number;
  maxPrice: number;
  inStockOnly: boolean;
  sortBy: 'popular' | 'price-low' | 'price-high' | 'newest' | 'discount';
}

export type ThemePreset = 'maroon' | 'rose' | 'emerald' | 'indigo' | 'amber' | 'violet' | 'crimson' | 'cyan' | 'midnight' | 'custom';

export interface TrustFeature {
  id: string;
  icon: 'truck' | 'shield' | 'refresh' | 'clock' | 'headset' | 'gift' | 'banknote';
  titleBn: string;
  titleEn: string;
  descBn: string;
  descEn: string;
}

export interface WebsiteCustomizerSettings {
  // 1. Branding & Identity
  brandNameBn: string;
  brandNameEn: string;
  brandAccentWordBn?: string;
  brandAccentWordEn?: string;
  taglineBn: string;
  taglineEn: string;
  logoUrl: string;
  faviconUrl?: string;
  showOfficialStoreBadge?: boolean;
  officialStoreBadgeBn?: string;
  officialStoreBadgeEn?: string;

  // 2. Theme & Styling
  themePreset: ThemePreset;
  primaryColorHex: string;
  accentColorHex: string;
  fontFamily: 'hind' | 'inter' | 'outfit' | 'poppins';
  borderRadius: 'rounded-xl' | 'rounded-2xl' | 'rounded-3xl';

  // 3. Top Announcement Marquee Bar
  showAnnouncementBar: boolean;
  announcementTextBn: string;
  announcementTextEn: string;
  announcementBgColor: string;
  announcementTextColor: string;
  freeDeliveryBadgeBn: string;
  freeDeliveryBadgeEn: string;

  // 4. Hero Banners & Slider
  heroBanners: Banner[];
  useCustomBannersOnly: boolean;

  // 5. Flash Sale & Offers
  flashSaleEnabled: boolean;
  flashSaleTitleBn: string;
  flashSaleTitleEn: string;
  flashSaleSubtitleBn: string;
  flashSaleSubtitleEn: string;
  flashSaleEndTime: string;
  flashSaleBadgeTextBn: string;
  flashSaleBadgeTextEn: string;

  // 6. Section Headings
  categorySectionTitleBn: string;
  categorySectionTitleEn: string;
  categorySectionSubtitleBn: string;
  categorySectionSubtitleEn: string;

  catalogSectionTitleBn: string;
  catalogSectionTitleEn: string;
  catalogSectionSubtitleBn: string;
  catalogSectionSubtitleEn: string;

  // 7. Direct Order / Callout Section
  showDirectOrderBanner: boolean;
  directOrderTitleBn: string;
  directOrderTitleEn: string;
  directOrderSubtitleBn: string;
  directOrderSubtitleEn: string;
  directOrderBadgeBn: string;
  directOrderBadgeEn: string;
  hotlineEmail: string;
  hotlinePhone: string;

  // 8. Trust Features Bar
  showFeaturesBar: boolean;
  features: TrustFeature[];

  // 9. Footer & Socials
  footerAboutBn: string;
  footerAboutEn: string;
  officeAddressBn: string;
  officeAddressEn: string;
  copyrightTextBn: string;
  copyrightTextEn: string;
  facebookUrl: string;
  instagramUrl: string;
  whatsappUrl: string;
  youtubeUrl: string;

  // 10. AI Trend Auto-Merchandiser
  aiMerchandiserEnabled?: boolean;
  aiTrendBadgeTextBn?: string;
  aiTrendBadgeTextEn?: string;
  aiAutoPromoteToTop?: boolean;
  aiTrendMinScore?: number;
  aiLastRunTimestamp?: string;
  aiActiveSources?: string[];

  // 11. Home Category Display Order
  homeCategoryOrder?: string[];
}

