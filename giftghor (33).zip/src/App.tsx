import React, { useState, useEffect, useMemo, useCallback, useRef, Suspense, lazy } from 'react';
import { 
  Check, 
  MessageCircle
} from 'lucide-react';
import { 
  Product, 
  Order, 
  CartItem, 
  Language, 
  CategoryId, 
  FilterState, 
  OrderStatus,
  PaymentStatus,
  UserProfile,
  ProductReview,
  WebsiteCustomizerSettings,
  Category 
} from './types';
import { 
  getStoredProducts, 
  saveProductsToStorage, 
  deduplicateProducts,
  getStoredOrders, 
  saveOrdersToStorage, 
  getStoredCart, 
  saveCartToStorage, 
  getStoredLanguage, 
  saveLanguageToStorage,
  getStoredReviews,
  saveReviewsToStorage,
  getStoredCustomizerSettings,
  saveCustomizerSettingsToStorage,
  fetchSettingsFromServer,
  saveSettingsToServer,
  fetchProductsFromServer,
  getStoredDeletedProductIds,
  addDeletedProductIdToStorage,
  bulkDeleteProductsOnServer
} from './utils/storage';
import {
  loadFastCatalogIndex,
  fetchFullProductDetails,
  primeFullProductDetailCache
} from './utils/catalogCache';
import { initialCategories } from './data/initialData';
import { translations, toBengaliNumber } from './utils/translations';
import { preloadImages } from './utils/imageOptimizer';
import { shiftProductOrder } from './utils/productOrderUtils';
import { normalizeCategoryId, isWatchProductTitle, matchesCategoryFilter } from './utils/categoryUtils';
import { 
  auth, 
  signOut, 
  onAuthStateChanged, 
  getUserProfileFromFirestore, 
  saveUserProfileToFirestore,
  saveOrderToFirestore, 
  updateOrderInFirestore,
  deleteOrderFromFirestore,
  subscribeToAllOrders,
  addProductToFirestore,
  updateProductInFirestore,
  deleteProductFromFirestore,
  bulkSyncProductsToFirestore,
  subscribeToAllProducts,
  getDeletedProductIdsFromFirestore,
  saveSettingsToFirestore,
  subscribeToCustomizerSettings,
  subscribeToLiveSync,
  subscribeToAllCategories
} from './lib/firebase';

// Eager Home Shell Components (above-the-fold instant render)
import { Header } from './components/Header';
import { BannerSlider } from './components/BannerSlider';
import { CategoryBar } from './components/CategoryBar';
import { HomeCategorySections } from './components/HomeCategorySections';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import type { PolicyTab } from './components/LegalPolicyModal';

// Code-Split Lazy Views & Modals (loaded on demand / idle-prefetched)
const ProductListing = lazy(() => import('./components/ProductListing').then(m => ({ default: m.ProductListing })));
const ProductDetailPage = lazy(() => import('./components/ProductDetailPage').then(m => ({ default: m.ProductDetailPage })));
const CheckoutPage = lazy(() => import('./components/CheckoutPage').then(m => ({ default: m.CheckoutPage })));
const OrderSuccessPage = lazy(() => import('./components/OrderSuccessPage').then(m => ({ default: m.OrderSuccessPage })));
const AccountProfileView = lazy(() => import('./components/AccountProfileView').then(m => ({ default: m.AccountProfileView })));
const AdminPanel = lazy(() => import('./components/AdminPanel').then(m => ({ default: m.AdminPanel })));
const WriteReviewModal = lazy(() => import('./components/WriteReviewModal').then(m => ({ default: m.WriteReviewModal })));
const AuthModal = lazy(() => import('./components/AuthModal').then(m => ({ default: m.AuthModal })));
const LegalPolicyModal = lazy(() => import('./components/LegalPolicyModal').then(m => ({ default: m.LegalPolicyModal })));
const CartDrawer = lazy(() => import('./components/CartDrawer').then(m => ({ default: m.CartDrawer })));
const OrderTrackingModal = lazy(() => import('./components/OrderTrackingModal').then(m => ({ default: m.OrderTrackingModal })));

export default function App() {
  // Persistence state
  const [language, setLanguage] = useState<Language>(getStoredLanguage);
  const [products, setProducts] = useState<Product[]>(getStoredProducts);
  const [orders, setOrders] = useState<Order[]>(getStoredOrders);
  const [cart, setCart] = useState<CartItem[]>(getStoredCart);
  const [reviews, setReviews] = useState<ProductReview[]>(getStoredReviews);
  const [customizerSettings, setCustomizerSettings] = useState<WebsiteCustomizerSettings>(getStoredCustomizerSettings);

  // Legal Policy Modal State
  const [isPolicyModalOpen, setIsPolicyModalOpen] = useState(false);
  const [policyModalTab, setPolicyModalTab] = useState<PolicyTab>('privacy');

  const handleOpenPolicy = (tab: PolicyTab) => {
    setPolicyModalTab(tab);
    setIsPolicyModalOpen(true);
  };

  // Dynamic Categories State with single non-duplicate live Firestore listener
  const [categoriesList, setCategoriesList] = useState<Category[]>(initialCategories);

  useEffect(() => {
    let unsubCats: (() => void) | null = null;
    const timer = setTimeout(() => {
      unsubCats = subscribeToAllCategories((remoteCats) => {
        if (Array.isArray(remoteCats) && remoteCats.length > 0) {
          const map = new Map<string, Category>();
          initialCategories.forEach(c => map.set(c.id, c));
          remoteCats.forEach(c => map.set(c.id, { ...(map.get(c.id) || {}), ...c }));
          setCategoriesList(Array.from(map.values()));
        }
      });
    }, 600);

    return () => {
      clearTimeout(timer);
      if (unsubCats) unsubCats();
    };
  }, []);

  // Pre-warm most common customer views during idle time after first paint
  useEffect(() => {
    const warmChunks = () => {
      import('./components/ProductDetailPage').catch(() => {});
      import('./components/ProductListing').catch(() => {});
      import('./components/CheckoutPage').catch(() => {});
    };
    const tId = setTimeout(warmChunks, 800);
    return () => clearTimeout(tId);
  }, []);

  // Single O(N) pass category item counts (preserving exact catalog counts while 80-item home seed is active)
  const dynamicCategories = useMemo(() => {
    const isSeedMode = products.length <= 120;
    const countsByCat = new Map<string, number>();
    let totalActive = 0;

    if (!isSeedMode) {
      for (const p of products) {
        if (!p || p.status === 'inactive') continue;
        totalActive++;
        const catId = p.category === 'watches' || isWatchProductTitle(p.titleEn, p.titleBn)
          ? 'watches'
          : normalizeCategoryId(p.category);
        countsByCat.set(catId, (countsByCat.get(catId) || 0) + 1);
      }
    }

    const list = categoriesList.map(cat => {
      const count = isSeedMode
        ? (cat.itemCount || 0)
        : (cat.id === 'all' ? totalActive : (countsByCat.get(cat.id) || 0));
      return {
        ...cat,
        itemCount: count,
      };
    });

    const customOrder = customizerSettings?.homeCategoryOrder;
    if (Array.isArray(customOrder) && customOrder.length > 0) {
      list.sort((a, b) => {
        if (a.id === 'all') return -1;
        if (b.id === 'all') return 1;
        const indexA = customOrder.indexOf(a.id);
        const indexB = customOrder.indexOf(b.id);
        if (indexA !== -1 && indexB !== -1) return indexA - indexB;
        if (indexA !== -1) return -1;
        if (indexB !== -1) return 1;
        return 0;
      });
    }

    return list;
  }, [products, categoriesList, customizerSettings?.homeCategoryOrder]);

  // Review Modal State
  const [isWriteReviewOpen, setIsWriteReviewOpen] = useState(false);
  const [reviewTargetProduct, setReviewTargetProduct] = useState<{ id: string; titleBn: string; titleEn: string; image: string; price?: number } | null>(null);
  const [reviewTargetOrderId, setReviewTargetOrderId] = useState<string | undefined>(undefined);
  const [existingReviewToEdit, setExistingReviewToEdit] = useState<ProductReview | null>(null);

  // User Auth Profile
  const [currentUserProfile, setCurrentUserProfile] = useState<UserProfile | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [authModalTitle, setAuthModalTitle] = useState<string | undefined>(undefined);
  const [authModalSubtitle, setAuthModalSubtitle] = useState<string | undefined>(undefined);
  const [isOrderAuthGate, setIsOrderAuthGate] = useState(false);
  const [pendingCheckoutAfterAuth, setPendingCheckoutAfterAuth] = useState(false);

  // Navigation and views
  type AppView = 'home' | 'products' | 'product-detail' | 'checkout' | 'order-success' | 'admin' | 'account';
  const [activeView, setActiveView] = useState<AppView>('home');
  const [searchQuery, setSearchQuery] = useState('');

  // Filters
  const [filters, setFilters] = useState<FilterState>({
    category: 'all',
    searchQuery: '',
    minPrice: 0,
    maxPrice: 50000,
    inStockOnly: false,
    sortBy: 'popular',
  });

  // Modals & Drawers
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isTrackingModalOpen, setIsTrackingModalOpen] = useState(false);
  const [trackingInitialQuery, setTrackingInitialQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [recentPlacedOrder, setRecentPlacedOrder] = useState<Order | null>(null);
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | undefined>();

  // Total cart items count
  const totalCartCount = useMemo(() => cart.reduce((acc, item) => acc + (item.quantity || 1), 0), [cart]);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const t = translations[language];

  // Sync catalog index asynchronously to IndexedDB (non-blocking)
  const catalogMapRef = useRef<Map<string, Product>>(new Map());
  const adminFullCatalogLoadedRef = useRef(false);

  useEffect(() => {
    const map = new Map<string, Product>();
    for (const p of products) {
      if (p && p.id) map.set(p.id, p);
    }
    catalogMapRef.current = map;
    saveProductsToStorage(products);
  }, [products]);

  // Fast 2-Phase Catalog & Settings Hydration:
  // Phase 1 (<15ms IDB or ~120ms pre-gzipped /api/products-index): Hydrate all 3,073 products without blocking first paint
  // Phase 2 (deferred after initial render): Attach single real-time Firestore listeners (zero duplicate getDocs)
  useEffect(() => {
    let isMounted = true;
    let unsubscribeProducts: (() => void) | null = null;
    let unsubscribeCustomizer: (() => void) | null = null;
    let unsubscribeLiveSync: (() => void) | null = null;

    const applyCatalogList = (rawList: Product[]) => {
      if (!isMounted || !Array.isArray(rawList) || rawList.length === 0) return;
      const deletedSet = new Set(getStoredDeletedProductIds());
      const normalized: Product[] = [];
      for (const sp of rawList) {
        if (!sp || !sp.id) continue;
        const cleanId = String(sp.id).trim();
        if (deletedSet.has(cleanId)) continue;
        const fallback = catalogMapRef.current.get(cleanId);
        const preferFallback = Boolean(
          fallback?.updatedAt && sp.updatedAt && fallback.updatedAt > sp.updatedAt
        );
        const winner = preferFallback ? { ...sp, ...fallback } : { ...fallback, ...sp };
        const titleEn = winner.titleEn || winner.titleBn || '';
        const titleBn = winner.titleBn || winner.titleEn || '';
        const rawCat = winner.category ? normalizeCategoryId(winner.category) : 'others';
        const validCategory = isWatchProductTitle(titleEn, titleBn) ? 'watches' : rawCat;
        const variants = (winner.variants && winner.variants.length > 0)
          ? winner.variants
          : (preferFallback ? undefined : fallback?.variants);
        normalized.push({
          ...winner,
          id: cleanId,
          titleEn,
          titleBn,
          category: validCategory,
          price: typeof winner.price === 'number' ? Math.max(1, winner.price) : (fallback?.price ?? 100),
          ...(variants && variants.length > 0 ? { variants } : {}),
        });
      }
      const deduplicated = deduplicateProducts(normalized);
      if (isMounted && deduplicated.length > 0) {
        setProducts(deduplicated);
      }
    };

    // Phase 1: Instant IndexedDB / pre-gzipped API catalog index
    loadFastCatalogIndex((bgFresh) => {
      applyCatalogList(bgFresh);
    })
      .then((fastList) => {
        applyCatalogList(fastList);
      })
      .catch(() => {});

    // Quietly check lightweight server settings fallback
    fetchSettingsFromServer()
      .then((serverSettings) => {
        if (isMounted && serverSettings) {
          setCustomizerSettings((prev) => {
            const next = { ...prev, ...serverSettings };
            saveCustomizerSettingsToStorage(next);
            return next;
          });
        }
      })
      .catch(() => {});

    // Phase 2: Defer Firestore real-time WebSocket streams until after initial images & interactivity settle
    const realtimeTimer = setTimeout(async () => {
      if (!isMounted) return;
      try {
        const fsDeleted = await getDeletedProductIdsFromFirestore();
        if (Array.isArray(fsDeleted) && fsDeleted.length > 0) {
          addDeletedProductIdToStorage(fsDeleted);
        }
      } catch {}

      if (!isMounted) return;

      unsubscribeCustomizer = subscribeToCustomizerSettings((updatedSettings) => {
        if (isMounted && updatedSettings) {
          setCustomizerSettings(updatedSettings);
          saveCustomizerSettingsToStorage(updatedSettings);
        }
      });

      unsubscribeLiveSync = subscribeToLiveSync(() => {});

      unsubscribeProducts = subscribeToAllProducts((allProducts) => {
        if (!isMounted || !Array.isArray(allProducts) || allProducts.length === 0) return;
        applyCatalogList(allProducts);
      });
    }, 2500);

    return () => {
      isMounted = false;
      clearTimeout(realtimeTimer);
      if (unsubscribeProducts) unsubscribeProducts();
      if (unsubscribeCustomizer) unsubscribeCustomizer();
      if (unsubscribeLiveSync) unsubscribeLiveSync();
    };
  }, []);

  // Hydrate full descriptions & galleries for all products only when Admin Panel is opened
  useEffect(() => {
    if (activeView !== 'admin' || adminFullCatalogLoadedRef.current) return;
    adminFullCatalogLoadedRef.current = true;
    fetchProductsFromServer()
      .then((fullServerProducts) => {
        if (Array.isArray(fullServerProducts) && fullServerProducts.length > 0) {
          const deletedSet = new Set(getStoredDeletedProductIds());
          const filtered = fullServerProducts.filter(p => p && p.id && !deletedSet.has(String(p.id).trim()));
          setProducts(deduplicateProducts(filtered));
        }
      })
      .catch(() => {});
  }, [activeView]);

  // Hydrate full details for a single product ID (used on click, deep-link, and back/forward navigation)
  const openAndHydrateProductById = useCallback((prodId: string, fallbackProduct?: Product | null) => {
    const cleanId = decodeURIComponent(prodId).trim();
    if (!cleanId) return;
    const localMatch = fallbackProduct || catalogMapRef.current.get(cleanId) ||
      Array.from(catalogMapRef.current.values()).find(p => p.id.toLowerCase() === cleanId.toLowerCase()) || null;

    if (localMatch) {
      setSelectedProduct(localMatch);
      setActiveView('product-detail');
    }

    fetchFullProductDetails(localMatch?.id || cleanId)
      .then((fullProd) => {
        if (fullProd) {
          primeFullProductDetailCache(fullProd);
          setSelectedProduct((prev) => {
            if (!localMatch || !prev || prev.id === fullProd.id || prev.id.toLowerCase() === cleanId.toLowerCase()) {
              return { ...(localMatch || {}), ...fullProd };
            }
            return prev;
          });
          if (!localMatch) {
            setActiveView('product-detail');
          }
        }
      })
      .catch(() => {});
  }, []);

  // Inspect initial URL route once on mount
  const didParseInitialRouteRef = useRef(false);
  useEffect(() => {
    if (didParseInitialRouteRef.current) return;
    didParseInitialRouteRef.current = true;

    try {
      const pathname = window.location.pathname;
      const lowerPath = pathname.toLowerCase();
      const params = new URLSearchParams(window.location.search);

      if (lowerPath.startsWith('/product/')) {
        const prodId = pathname.slice('/product/'.length).trim();
        if (prodId) openAndHydrateProductById(prodId);
      } else if (lowerPath.includes('/checkout')) {
        setActiveView('checkout');
      } else if (lowerPath.includes('/order-success')) {
        const ordId = params.get('id');
        if (ordId) {
          const ord = orders.find(o => o.id === ordId);
          if (ord) setRecentPlacedOrder(ord);
        }
        setActiveView('order-success');
      } else if (lowerPath.includes('/products')) {
        setActiveView('products');
      } else if (lowerPath.startsWith('/category/')) {
        const catId = lowerPath.replace('/category/', '').trim();
        if (catId) {
          setFilters(prev => ({ ...prev, category: catId }));
          setActiveView('products');
        }
      } else if (lowerPath.includes('/admin')) {
        setActiveView('admin');
      } else if (lowerPath.includes('/account')) {
        setActiveView('account');
      } else if (lowerPath.includes('/privacy-policy')) {
        handleOpenPolicy('privacy');
      } else if (lowerPath.includes('/terms')) {
        handleOpenPolicy('terms');
      } else if (lowerPath.includes('/return-policy') || lowerPath.includes('/refund')) {
        handleOpenPolicy('refund');
      } else if (lowerPath.includes('/shipping-policy') || lowerPath.includes('/shipping')) {
        handleOpenPolicy('shipping');
      } else if (lowerPath.includes('/about-us') || lowerPath.includes('/about')) {
        handleOpenPolicy('about');
      } else if (lowerPath.includes('/contact')) {
        handleOpenPolicy('contact');
      }

      const qCat = params.get('category');
      const qProd = params.get('product');
      if (qCat) {
        setFilters(prev => ({ ...prev, category: qCat }));
        setActiveView('products');
      }
      if (qProd) {
        openAndHydrateProductById(qProd);
      }
    } catch {
      // Ignore URL parsing errors
    }
  }, [openAndHydrateProductById, orders]);

  // Preload only hero banner images so initial CPU/network stays dedicated to visible viewport
  useEffect(() => {
    if (customizerSettings?.heroBanners && customizerSettings.heroBanners.length > 0) {
      const bannerImages = customizerSettings.heroBanners.slice(0, 2).map(b => b.imageUrl);
      preloadImages(bannerImages);
    }
  }, [customizerSettings?.heroBanners]);

  // Support native browser Back/Forward buttons and mobile navigation
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      const state = event.state;
      if (state && state.view) {
        setActiveView(state.view);
        if (state.productId) {
          openAndHydrateProductById(state.productId);
        }
        if (state.orderId) {
          const ord = orders.find(o => o.id === state.orderId);
          if (ord) setRecentPlacedOrder(ord);
        }
        if (state.category) {
          setFilters(prev => ({ ...prev, category: state.category }));
        }
      } else {
        const pathname = window.location.pathname;
        const lowerPath = pathname.toLowerCase();
        if (lowerPath.startsWith('/product/')) {
          const prodId = pathname.slice('/product/'.length).trim();
          if (prodId) {
            openAndHydrateProductById(prodId);
            return;
          }
        }
        if (lowerPath.includes('/checkout')) {
          setActiveView('checkout');
          return;
        }
        if (lowerPath.includes('/order-success')) {
          setActiveView('order-success');
          return;
        }
        if (lowerPath.includes('/products')) {
          setActiveView('products');
          return;
        }
        if (lowerPath.includes('/admin')) {
          setActiveView('admin');
          return;
        }
        if (lowerPath.includes('/account')) {
          setActiveView('account');
          return;
        }
        setActiveView('home');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [openAndHydrateProductById, orders]);

  // Central Navigation router helper that maintains clean URLs and browser history
  const navigateTo = (
    view: AppView,
    options?: {
      product?: Product | null;
      category?: CategoryId;
      order?: Order | null;
      replace?: boolean;
      checkoutItems?: CartItem[];
    }
  ) => {
    if (options?.product !== undefined) {
      setSelectedProduct(options.product);
    }
    if (options?.order !== undefined) {
      setRecentPlacedOrder(options.order);
    }
    if (options?.category) {
      setFilters(prev => ({ ...prev, category: options.category! }));
    }
    if (options?.checkoutItems) {
      setCart(options.checkoutItems);
    }

    setActiveView(view);
    window.scrollTo(0, 0);

    let url = '/';
    if (view === 'products') {
      const catParam = options?.category || filters.category;
      url = catParam && catParam !== 'all' ? `/products?category=${encodeURIComponent(catParam)}` : '/products';
    } else if (view === 'product-detail') {
      const p = options?.product || selectedProduct;
      if (p) {
        url = `/product/${encodeURIComponent(p.id)}`;
      }
    } else if (view === 'checkout') {
      url = '/checkout';
    } else if (view === 'order-success') {
      const ord = options?.order || recentPlacedOrder;
      url = ord ? `/order-success?id=${encodeURIComponent(ord.id)}` : '/order-success';
    } else if (view === 'account') {
      url = '/account';
    } else if (view === 'admin') {
      url = '/admin';
    }

    const historyState = {
      view,
      productId: (options?.product || selectedProduct)?.id,
      orderId: (options?.order || recentPlacedOrder)?.id,
      category: options?.category || filters.category
    };

    try {
      if (options?.replace) {
        window.history.replaceState(historyState, '', url);
      } else {
        window.history.pushState(historyState, '', url);
      }
    } catch {
      // Ignore history update errors in iframe environments
    }
  };

  // Back button handler respecting previous page state
  const handleGoBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      if (activeView === 'checkout') {
        if (selectedProduct) {
          navigateTo('product-detail', { product: selectedProduct });
        } else {
          navigateTo('products');
        }
      } else if (activeView === 'product-detail') {
        navigateTo('products');
      } else if (activeView === 'order-success') {
        navigateTo('home');
      } else {
        navigateTo('home');
      }
    }
  };

  useEffect(() => {
    saveOrdersToStorage(orders);
  }, [orders]);

  useEffect(() => {
    saveCartToStorage(cart);
  }, [cart]);

  useEffect(() => {
    saveReviewsToStorage(reviews);
  }, [reviews]);

  useEffect(() => {
    saveLanguageToStorage(language);
  }, [language]);

  useEffect(() => {
    saveCustomizerSettingsToStorage(customizerSettings);
  }, [customizerSettings]);

  const handleCustomizerSettingsChange = useCallback((nextSettings: WebsiteCustomizerSettings) => {
    setCustomizerSettings(nextSettings);
    saveCustomizerSettingsToStorage(nextSettings);
    saveSettingsToServer(nextSettings).catch(err => console.warn('Settings server sync warning:', err));
  }, []);

  // Subscribe to Firestore orders only when needed (authenticated user, account/admin/order-success view, or parcel tracking modal)
  const shouldSyncOrders = Boolean(currentUserProfile) || activeView === 'admin' || activeView === 'account' || activeView === 'order-success' || isTrackingModalOpen;
  useEffect(() => {
    if (!shouldSyncOrders) return;
    let isMounted = true;

    const unsubscribeOrders = subscribeToAllOrders((allOrders) => {
      if (isMounted && Array.isArray(allOrders)) {
        setOrders(allOrders);
        saveOrdersToStorage(allOrders);
      }
    });

    return () => {
      isMounted = false;
      if (unsubscribeOrders) unsubscribeOrders();
    };
  }, [shouldSyncOrders]);

  // Firebase Auth State Listener & User Profile Sync
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          let profile = await getUserProfileFromFirestore(user.uid);
          if (!profile) {
            profile = {
              uid: user.uid,
              displayName: user.displayName || user.email?.split('@')[0] || 'Customer',
              email: user.email || '',
              photoURL: user.photoURL || '',
              phone: user.phoneNumber || '',
              createdAt: new Date().toISOString(),
            };
            await saveUserProfileToFirestore(user.uid, profile);
          }
          setCurrentUserProfile(profile);
        } catch (err) {
          console.error('Failed to load user profile from Firestore:', err);
        }
      } else {
        setCurrentUserProfile(null);
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentUserProfile(null);
      showToast(language === 'bn' ? 'লগআউট সফল হয়েছে' : 'Signed out successfully');
      if (activeView === 'account') {
        setActiveView('home');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  };

  const handleToggleLanguage = () => {
    setLanguage(prev => (prev === 'bn' ? 'en' : 'bn'));
  };

  // Stable ref to navigateTo so memoized ProductCards never re-render unnecessarily
  const navigateToRef = useRef(navigateTo);
  navigateToRef.current = navigateTo;

  // Direct Order handling (Direct Order flow navigating straight to dedicated Checkout Page)
  const handleAddToCart = useCallback((product: Product, eOrQuantity?: React.MouseEvent | number) => {
    let quantityToAdd = 1;
    if (typeof eOrQuantity === 'number') {
      quantityToAdd = eOrQuantity;
    } else if (eOrQuantity && 'stopPropagation' in eOrQuantity) {
      eOrQuantity.stopPropagation();
    }

    const item: CartItem = { product, quantity: quantityToAdd };
    navigateToRef.current('checkout', { product, checkoutItems: [item] });
  }, []);

  const handleSelectProduct = useCallback((product: Product) => {
    navigateToRef.current('product-detail', { product });

    const needsFullDetail = !product.additionalImages || !product.descriptionBn || product.descriptionBn.length <= 260;
    if (needsFullDetail) {
      fetchFullProductDetails(product.id)
        .then((fullProd) => {
          if (fullProd) {
            primeFullProductDetailCache(fullProd);
            setSelectedProduct((prev) => (prev && prev.id === product.id ? { ...prev, ...fullProd } : prev));
          }
        })
        .catch(() => {});
    } else {
      primeFullProductDetailCache(product);
    }
  }, []);

  const handleBuyNowFromDetail = (
    product: Product, 
    quantity: number, 
    variant?: { size?: string; color?: string; variant?: any }
  ) => {
    const item: CartItem = {
      product,
      quantity,
      selectedSize: variant?.size,
      selectedColor: variant?.color,
      selectedVariant: variant?.variant
    };
    navigateTo('checkout', { product, checkoutItems: [item] });
  };

  const handleAddToCartFromDetail = (
    product: Product, 
    quantity: number, 
    variant?: { size?: string; color?: string; variant?: any }
  ) => {
    const item: CartItem = {
      product,
      quantity,
      selectedSize: variant?.size,
      selectedColor: variant?.color,
      selectedVariant: variant?.variant
    };
    setCart(prev => {
      const existingIdx = prev.findIndex(ci => ci.product.id === product.id && ci.selectedSize === variant?.size && ci.selectedColor === variant?.color);
      let updated: CartItem[];
      if (existingIdx !== -1) {
        updated = [...prev];
        updated[existingIdx] = {
          ...updated[existingIdx],
          quantity: updated[existingIdx].quantity + quantity
        };
      } else {
        updated = [item, ...prev];
      }
      saveCartToStorage(updated);
      return updated;
    });
    showToast(language === 'bn' ? 'পণ্যটি কার্টে যোগ করা হয়েছে!' : 'Product added to cart!');
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null);
    });
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const handleBuyNow = (product: Product, quantity: number) => {
    handleAddToCart(product, quantity);
  };

  const handleProceedToCheckout = (coupon?: { code: string; discount: number }) => {
    setAppliedCoupon(coupon);
    setIsCheckoutOpen(true);
  };

  const handleOrderSuccess = async (newOrder: Order) => {
    // 1. Optimistically add to orders list so it appears in Admin and Profile instantly
    setOrders(prev => {
      const exists = prev.some(o => o.id === newOrder.id);
      const updated = exists ? prev : [newOrder, ...prev];
      saveOrdersToStorage(updated);
      return updated;
    });

    // 2. Persist to Firestore
    try {
      await saveOrderToFirestore(newOrder);
    } catch (err) {
      console.warn('Order Firestore save note:', err);
    }

    // 3. Save/Update user profile in Firestore with address and phone from checkout
    if (currentUserProfile?.uid) {
      const updatedProfile: UserProfile = {
        ...currentUserProfile,
        displayName: newOrder.customerName || currentUserProfile.displayName,
        phone: newOrder.phone || currentUserProfile.phone,
        address: newOrder.address || currentUserProfile.address,
        updatedAt: new Date().toISOString()
      };
      setCurrentUserProfile(updatedProfile);
      saveUserProfileToFirestore(currentUserProfile.uid, updatedProfile).catch(err => console.warn('Profile save note:', err));
    }

    // 4. Decrease product stock
    setProducts(prev => {
      const updated = [...prev];
      newOrder.items.forEach(orderItem => {
        const idx = updated.findIndex(p => p.id === orderItem.product.id);
        if (idx !== -1) {
          updated[idx] = {
            ...updated[idx],
            stock: Math.max(0, updated[idx].stock - orderItem.quantity)
          };
        }
      });
      saveProductsToStorage(updated);
      return updated;
    });

    // 5. Clear cart & show success modal
    setCart([]);
    setRecentPlacedOrder(newOrder);
  };

  const handleSelectCategory = useCallback((cat: CategoryId) => {
    setFilters(f => ({ ...f, category: cat }));
  }, []);

  const handleSearchChange = useCallback((q: string) => {
    setSearchQuery(q);
    React.startTransition(() => {
      setFilters(f => ({ ...f, searchQuery: q }));
    });
  }, []);

  const handleFilterChange = useCallback((newFilters: Partial<FilterState>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  }, []);

  const handleResetFilters = useCallback(() => {
    setFilters({
      category: 'all',
      searchQuery: '',
      minPrice: 0,
      maxPrice: 50000,
      inStockOnly: false,
      sortBy: 'popular',
    });
    setSearchQuery('');
  }, []);

  // Admin handlers
  const handleAddProduct = async (newProd: Omit<Product, 'id' | 'createdAt'>) => {
    const generatedId = `prod-${Date.now()}`;
    const isWatch = isWatchProductTitle(newProd.titleEn, newProd.titleBn);
    const productToAdd: Product = {
      ...newProd,
      category: isWatch ? 'watches' : newProd.category,
      subcategory: isWatch ? (newProd.subcategory || 'ঘড়ি ও স্মার্টওয়াচ (Watches)') : newProd.subcategory,
      id: generatedId,
      createdAt: new Date().toISOString().split('T')[0],
    };

    // 1. Immediately update UI & localStorage
    setProducts(prev => {
      const updated = deduplicateProducts([productToAdd, ...prev]);
      saveProductsToStorage(updated);
      return updated;
    });

    // 2. Persist to Server API
    try {
      await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productToAdd)
      });
    } catch (err) {
      console.warn('Server product add note:', err);
    }

    // 3. Persist to Firestore
    try {
      await addProductToFirestore(productToAdd);
    } catch (err) {
      console.warn('Firestore product add note:', err);
    }

    showToast(language === 'bn' ? 'পণ্য সফলভাবে যুক্ত ও সংরক্ষিত হয়েছে!' : 'Product added and saved successfully!');
  };

  const handleReorderProduct = async (productId: string, newOrder: number) => {
    let shiftedList: Product[] = [];
    setProducts(prev => {
      shiftedList = shiftProductOrder(prev, productId, newOrder, true);
      const deduped = deduplicateProducts(shiftedList);
      saveProductsToStorage(deduped);
      return deduped;
    });

    // Bulk sync updated positions to Firestore so cloud stays synced
    if (shiftedList.length > 0) {
      bulkSyncProductsToFirestore(shiftedList).catch(err => console.warn('Firestore reorder sync note:', err));
    }

    const p = products.find(prod => prod.id === productId);
    const title = language === 'bn' ? (p?.titleBn || 'পণ্য') : (p?.titleEn || 'Product');
    showToast(
      language === 'bn'
        ? `"${title}" ${toBengaliNumber(newOrder)} নম্বরে সেট করা হয়েছে এবং পূর্বের পণ্যগুলো নিচে স্থানান্তরিত হয়েছে!`
        : `"${title}" set to position #${newOrder} with automatic shifting!`
    );
  };

  const handleUpdateProduct = async (updated: Product) => {
    let finalList: Product[] = [];

    // 1. Immediately update UI & localStorage with automatic shifting if displayOrder changed
    setProducts(prev => {
      let next: Product[];
      const existing = prev.find(p => p.id === updated.id);
      if (
        typeof updated.displayOrder === 'number' && 
        (!existing || existing.displayOrder !== updated.displayOrder)
      ) {
        const withUpdated = prev.map(p => (p.id === updated.id ? updated : p));
        next = shiftProductOrder(withUpdated, updated.id, updated.displayOrder, true);
      } else {
        next = prev.map(p => (p.id === updated.id ? updated : p));
      }
      const deduped = deduplicateProducts(next);
      finalList = deduped;
      saveProductsToStorage(deduped);
      return deduped;
    });

    // 2. Persist to Server API
    try {
      await fetch(`/api/products/${encodeURIComponent(updated.id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
    } catch (err) {
      console.warn('Server product update note:', err);
    }

    // 3. Persist to Firestore
    try {
      await updateProductInFirestore(updated.id, updated);
      if (typeof updated.displayOrder === 'number' && finalList.length > 0) {
        bulkSyncProductsToFirestore(finalList).catch(() => {});
      }
    } catch (err) {
      console.warn('Firestore product update note:', err);
    }

    showToast(language === 'bn' ? 'পণ্য সফলভাবে আপডেট ও সেভ হয়েছে!' : 'Product updated & saved!');
  };

  const handleDeleteProduct = async (id: string) => {
    const targetId = String(id || '').trim();
    if (!targetId) return;

    // 1. Add to permanent deleted product IDs blacklist
    addDeletedProductIdToStorage(targetId);

    // 2. Immediately update UI products state & localStorage
    setProducts(prev => {
      const next = prev.filter(p => String(p.id || '').trim() !== targetId);
      const deduplicated = deduplicateProducts(next);
      saveProductsToStorage(deduplicated);
      return deduplicated;
    });

    // 3. Remove from cart if present
    setCart(prev => {
      const next = prev.filter(item => String(item.product.id || '').trim() !== targetId);
      saveCartToStorage(next);
      return next;
    });

    // 4. Clean up any hero banners in customizerSettings linked to this product
    setCustomizerSettings(prev => {
      const heroBanners = (prev.heroBanners || []).filter((b: any) => {
        if (!b) return false;
        const bLink = String(b.linkUrl || '').trim();
        const bId = String(b.id || '').trim();
        if (bLink === targetId) return false;
        if (bId === `banner-${targetId}`) return false;
        return true;
      });
      const updatedSettings = { ...prev, heroBanners };
      saveCustomizerSettingsToStorage(updatedSettings);
      saveSettingsToFirestore(updatedSettings).catch(() => {});
      saveSettingsToServer(updatedSettings).catch(() => {});
      return updatedSettings;
    });

    // 5. Persist delete to Server API
    try {
      await fetch(`/api/products/${encodeURIComponent(targetId)}`, {
        method: 'DELETE'
      });
    } catch (err) {
      console.warn('Server product delete note:', err);
    }

    // 6. Persist delete & tombstone to Firestore
    try {
      await deleteProductFromFirestore(targetId);
    } catch (err) {
      console.warn('Firestore product delete note:', err);
    }

    showToast(language === 'bn' ? 'পণ্য স্থায়ীভাবে মুছে ফেলা হয়েছে!' : 'Product deleted successfully!');
  };

  const handleBulkDeleteProducts = async (ids: string[]) => {
    if (!Array.isArray(ids) || ids.length === 0) return;
    const cleanIds = ids.map(String).map(s => s.trim()).filter(Boolean);
    if (cleanIds.length === 0) return;
    const deleteSet = new Set(cleanIds);

    // 1. Add to permanent deleted blacklist
    addDeletedProductIdToStorage(cleanIds);

    // 2. Update UI products
    setProducts(prev => {
      const next = prev.filter(p => !deleteSet.has(String(p.id || '').trim()));
      const deduplicated = deduplicateProducts(next);
      saveProductsToStorage(deduplicated);
      return deduplicated;
    });

    // 3. Remove from cart
    setCart(prev => {
      const next = prev.filter(item => !deleteSet.has(String(item.product.id || '').trim()));
      saveCartToStorage(next);
      return next;
    });

    // 4. Clean up hero banners
    setCustomizerSettings(prev => {
      const heroBanners = (prev.heroBanners || []).filter((b: any) => {
        if (!b) return false;
        const bLink = String(b.linkUrl || '').trim();
        const bId = String(b.id || '').trim();
        if (deleteSet.has(bLink)) return false;
        if (bId.startsWith('banner-') && deleteSet.has(bId.replace('banner-', ''))) return false;
        return true;
      });
      const updatedSettings = { ...prev, heroBanners };
      saveCustomizerSettingsToStorage(updatedSettings);
      saveSettingsToFirestore(updatedSettings).catch(() => {});
      saveSettingsToServer(updatedSettings).catch(() => {});
      return updatedSettings;
    });

    // 5. Persist to server bulk-delete
    try {
      await bulkDeleteProductsOnServer(cleanIds);
    } catch (err) {
      console.warn('Server bulk delete error:', err);
    }

    // 6. Persist to Firestore
    cleanIds.forEach(id => {
      deleteProductFromFirestore(id).catch(() => {});
    });

    showToast(language === 'bn' ? `${cleanIds.length}টি পণ্য স্থায়ীভাবে মুছে ফেলা হয়েছে!` : `${cleanIds.length} products permanently deleted!`);
  };

  const handleUpdateOrderStatus = (
    orderId: string, 
    status: OrderStatus, 
    paymentStatus?: PaymentStatus,
    courierTracking?: string,
    courierName?: string
  ) => {
    setOrders(prev => {
      const updated = prev.map(o => {
        if (o.id === orderId) {
          const currentHistory = Array.isArray(o.statusHistory) ? o.statusHistory : [];
          
          // COD automatic payment success rule on delivery:
          // COD তে পেমেন্ট করলে ডেলিভারি সাকসেস ফুল হওয়ার সাথে সাথে পেমেন্ট ও সাকসেস ফুল (paid) হয়ে যাবে
          const isCOD = !o.paymentMethod || o.paymentMethod === 'cod';
          const isDelivered = status === 'delivered';
          const resolvedPaymentStatus: PaymentStatus = 
            (isDelivered && isCOD)
              ? 'paid'
              : (paymentStatus !== undefined 
                  ? paymentStatus 
                  : (isDelivered && (isCOD || o.paymentStatus === 'pending') ? 'paid' : o.paymentStatus));

          const statusNote = isDelivered && (isCOD || resolvedPaymentStatus === 'paid')
            ? (language === 'bn' 
                ? 'ডেলিভারি সম্পন্ন: ক্যাশ অন ডেলিভারি (COD) পেমেন্ট সফলভাবে পরিশোধিত (Paid) হয়েছে।' 
                : 'Delivered: Cash on Delivery (COD) payment collected and marked as Paid.')
            : `স্ট্যাটাস পরিবর্তন: ${status}`;

          const updatedOrder: Order = {
            ...o,
            orderStatus: status,
            paymentStatus: resolvedPaymentStatus,
            courierTrackingCode: courierTracking !== undefined ? courierTracking : o.courierTrackingCode,
            trackingCode: courierTracking !== undefined ? courierTracking : (o.trackingCode || o.courierTrackingCode),
            courierName: courierName !== undefined ? (courierName as any) : o.courierName,
            statusHistory: [
              ...currentHistory,
              {
                status,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                date: new Date().toISOString(),
                note: statusNote
              }
            ]
          };

          // Save to Firestore
          updateOrderInFirestore(orderId, {
            orderStatus: status,
            paymentStatus: resolvedPaymentStatus,
            ...(courierTracking !== undefined ? { courierTrackingCode: courierTracking, trackingCode: courierTracking } : {}),
            ...(courierName !== undefined ? { courierName } : {}),
            statusHistory: updatedOrder.statusHistory
          }, statusNote);

          return updatedOrder;
        }
        return o;
      });
      saveOrdersToStorage(updated);
      return updated;
    });

    const statusMsg = 
      status === 'confirmed' 
        ? (language === 'bn' ? 'অর্ডারটি সফলভাবে অ্যাপ্রুভ / কনফার্ম করা হয়েছে!' : 'Order successfully approved & confirmed!')
        : status === 'cancelled'
        ? (language === 'bn' ? 'অর্ডারটি বাতিল / রিজেক্ট করা হয়েছে!' : 'Order cancelled / rejected!')
        : status === 'shipped'
        ? (language === 'bn' ? 'অর্ডার কুরিয়ারে পাঠানো হয়েছে!' : 'Order marked as shipped!')
        : status === 'delivered'
        ? (language === 'bn' ? 'অর্ডার ডেলিভারি সফল এবং COD পেমেন্ট সফল (Paid) হয়েছে!' : 'Order delivered and COD payment marked as Paid!')
        : (language === 'bn' ? 'অর্ডার স্ট্যাটাস আপডেট হয়েছে!' : 'Order status updated!');

    showToast(statusMsg);
  };

  const handleCancelOrder = (orderId: string, reason?: string) => {
    // 1. Update order status to 'cancelled'
    setOrders(prev => {
      const updated = prev.map(o => {
        if (o.id === orderId) {
          const currentHistory = Array.isArray(o.statusHistory) ? o.statusHistory : [];
          const cancelNote = reason 
            ? `গ্রাহক কর্তৃক বাতিল: ${reason}` 
            : 'গ্রাহক কর্তৃক অর্ডারটি বাতিল করা হয়েছে';

          const updatedOrder: Order = {
            ...o,
            orderStatus: 'cancelled',
            statusHistory: [
              ...currentHistory,
              {
                status: 'cancelled',
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                date: new Date().toISOString(),
                note: cancelNote
              }
            ]
          };

          // Save to Firestore
          updateOrderInFirestore(orderId, {
            orderStatus: 'cancelled',
            statusHistory: updatedOrder.statusHistory
          });

          return updatedOrder;
        }
        return o;
      });

      saveOrdersToStorage(updated);
      return updated;
    });

    // 2. Restore product stock for cancelled items
    setProducts(prev => {
      const targetOrder = orders.find(o => o.id === orderId);
      if (!targetOrder || targetOrder.orderStatus === 'cancelled') {
        return prev;
      }

      const updated = [...prev];
      targetOrder.items.forEach(orderItem => {
        const idx = updated.findIndex(p => p.id === orderItem.product.id);
        if (idx !== -1) {
          updated[idx] = {
            ...updated[idx],
            stock: (updated[idx].stock || 0) + orderItem.quantity
          };
        }
      });
      saveProductsToStorage(updated);
      return updated;
    });

    // 3. If recentPlacedOrder is this order, update it as well
    if (recentPlacedOrder && recentPlacedOrder.id === orderId) {
      setRecentPlacedOrder(prev => prev ? { ...prev, orderStatus: 'cancelled' } : null);
    }

    showToast(
      language === 'bn' 
        ? 'আপনার অর্ডারটি সফলভাবে বাতিল করা হয়েছে।' 
        : 'Your order has been cancelled successfully.'
    );
  };

  const handleDeleteOrder = (orderId: string) => {
    setOrders(prev => {
      const filtered = prev.filter(o => o.id !== orderId);
      saveOrdersToStorage(filtered);
      return filtered;
    });
    deleteOrderFromFirestore(orderId);
    showToast(language === 'bn' ? 'অর্ডারটি সফলভাবে মুছে ফেলা হয়েছে!' : 'Order deleted successfully!');
  };

  const handleBulkDeleteOrders = (orderIds: string[]) => {
    setOrders(prev => {
      const filtered = prev.filter(o => !orderIds.includes(o.id));
      saveOrdersToStorage(filtered);
      return filtered;
    });
    orderIds.forEach(id => deleteOrderFromFirestore(id));
    showToast(language === 'bn' ? `${toBengaliNumber(orderIds.length)} টি অর্ডার সফলভাবে মুছে ফেলা হয়েছে!` : `${orderIds.length} orders deleted successfully!`);
  };

  // Review System Handlers: Strictly only customer who bought the product can review AFTER delivery
  const handleOpenWriteReview = (
    product: { id: string; titleBn: string; titleEn: string; image: string; price?: number },
    orderId?: string,
    existing?: ProductReview | null
  ) => {
    if (!currentUserProfile) {
      setAuthModalMode('login');
      setAuthModalTitle(language === 'bn' ? 'রিভিউ দিতে লগইন করুন' : 'Sign In to Review');
      setAuthModalSubtitle(
        language === 'bn' 
          ? 'যে পণ্যটি আপনি কিনেছেন, ডেলিভারি হওয়ার পর সেটির ভেরিফাইড রিভিউ দিতে অনুগ্রহ করে লগইন করুন।' 
          : 'Please sign in to leave a verified review. Reviews are unlocked once your order is delivered.'
      );
      setIsAuthModalOpen(true);
      return;
    }

    // Check user orders for this specific product
    const userOrdersForProduct = orders.filter(o => {
      const isUserMatch = 
        (currentUserProfile.uid && o.userId === currentUserProfile.uid) ||
        (currentUserProfile.email && o.userEmail?.toLowerCase() === currentUserProfile.email.toLowerCase()) ||
        (currentUserProfile.phone && o.phone?.trim() === currentUserProfile.phone.trim());
      
      const containsProduct = o.items.some(
        item => item.product.id === product.id || 
                item.product.titleEn === product.titleEn || 
                item.product.titleBn === product.titleBn
      );
      return isUserMatch && containsProduct;
    });

    // Find delivered order
    let validDeliveredOrder = orderId 
      ? (orders.find(o => o.id === orderId && o.orderStatus === 'delivered') || userOrdersForProduct.find(o => o.orderStatus === 'delivered'))
      : userOrdersForProduct.find(o => o.orderStatus === 'delivered');

    if (!validDeliveredOrder) {
      // Check if user has an order that is currently pending/processing/shipped
      const activeOrder = userOrdersForProduct.find(o => o.orderStatus !== 'delivered' && o.orderStatus !== 'cancelled');
      if (activeOrder) {
        showToast(
          language === 'bn'
            ? `📦 আপনার অর্ডার #${activeOrder.id} এখনও ডেলিভারি সম্পন্ন হয়নি। পণ্যটি ডেলিভারি পাওয়ার পরই রিভিউ দিতে পারবেন।`
            : `Order #${activeOrder.id} is in transit. You can review this product once it is delivered.`
        );
      } else {
        showToast(
          language === 'bn'
            ? '⚠️ দুঃখিত! যে পণ্যটি আপনি কিনবেন, শুধুমাত্র সেটির ডেলিভারি সম্পন্ন হওয়ার পরই রিভিউ দিতে পারবেন।'
            : 'Sorry! Only customers who purchase and receive delivery of this product can review it.'
        );
      }
      return;
    }

    setReviewTargetProduct(product);
    setReviewTargetOrderId(validDeliveredOrder.id);
    setExistingReviewToEdit(existing || null);
    setIsWriteReviewOpen(true);
  };

  const handleSubmitReview = (reviewPayload: Omit<ProductReview, 'id' | 'createdAt'>) => {
    // Security check: Verify order delivery status
    const hasDeliveredOrder = orders.some(o => 
      o.orderStatus === 'delivered' &&
      (
        (currentUserProfile && o.userId === currentUserProfile.uid) ||
        (currentUserProfile?.email && o.userEmail?.toLowerCase() === currentUserProfile.email.toLowerCase()) ||
        (currentUserProfile?.phone && o.phone?.trim() === currentUserProfile.phone.trim())
      ) &&
      (o.id === reviewPayload.orderId ||
       o.items.some(item => 
         item.product.id === reviewPayload.productId || 
         item.product.titleEn === reviewPayload.productTitle || 
         item.product.titleBn === reviewPayload.productTitle
       )
      )
    );

    if (!hasDeliveredOrder && !reviewPayload.orderId) {
      showToast(
        language === 'bn'
          ? '❌ দুঃখিত! শুধুমাত্র পণ্য ডেলিভারি সম্পন্ন হওয়া ক্রেতাগণ রিভিউ দিতে পারবেন।'
          : 'Error: Only customers with delivered orders can submit a review.'
      );
      return;
    }
    let updatedReviews: ProductReview[];
    
    if (existingReviewToEdit) {
      updatedReviews = reviews.map(r => 
        r.id === existingReviewToEdit.id ? { ...r, ...reviewPayload } : r
      );
    } else {
      const newReview: ProductReview = {
        ...reviewPayload,
        id: `rev_${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      updatedReviews = [newReview, ...reviews];
    }

    setReviews(updatedReviews);

    // Recalculate average rating & count for this product across all users
    const productReviewsList = updatedReviews.filter(
      r => (r.productId === reviewPayload.productId || r.productTitle === reviewPayload.productTitle) && 
           r.status === 'approved'
    );

    if (productReviewsList.length > 0) {
      const sum = productReviewsList.reduce((acc, r) => acc + r.rating, 0);
      const newAvg = Number((sum / productReviewsList.length).toFixed(1));

      setProducts(prev => prev.map(p => {
        if (p.id === reviewPayload.productId) {
          return {
            ...p,
            rating: newAvg,
            reviewsCount: productReviewsList.length
          };
        }
        return p;
      }));

      // Update selected product state if currently open in modal
      if (selectedProduct && selectedProduct.id === reviewPayload.productId) {
        setSelectedProduct(prev => prev ? {
          ...prev,
          rating: newAvg,
          reviewsCount: productReviewsList.length
        } : null);
      }
    }

    showToast(
      language === 'bn' 
        ? 'ধন্যবাদ! আপনার রিভিউ সফলভাবে প্রকাশিত হয়েছে।' 
        : 'Thank you! Your review has been successfully published.'
    );
  };

  const cartItemIds = useMemo(() => new Set(cart.map(c => c.product.id)), [cart]);

  const relatedProductsForDetail = useMemo(() => {
    if (activeView !== 'product-detail' || !selectedProduct) return [];
    const list: Product[] = [];
    for (const p of products) {
      if (!p || p.id === selectedProduct.id || p.status === 'inactive') continue;
      if (p.category === selectedProduct.category || matchesCategoryFilter(p, selectedProduct.category)) {
        list.push(p);
        if (list.length >= 12) break;
      }
    }
    return list;
  }, [activeView, selectedProduct, products]);

  const viewFallback = (
    <div className="min-h-[45vh] flex items-center justify-center">
      <div className="w-8 h-8 rounded-full border-2 border-amber-400 border-t-transparent animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#380208] text-white font-sans antialiased selection:bg-amber-400 selection:text-neutral-950">
      {/* Friendly Smooth Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-24 md:bottom-8 right-4 sm:right-6 z-50 bg-neutral-900/95 backdrop-blur-md text-white text-xs font-bold px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 animate-popIn border border-neutral-700/80">
          <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Check className="w-3.5 h-3.5" />
          </div>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <Header
        language={language}
        onToggleLanguage={handleToggleLanguage}
        activeView={activeView}
        onChangeView={(v) => navigateTo(v as AppView)}
        onSelectCategory={(cat) => {
          handleSelectCategory(cat);
          navigateTo('products', { category: cat });
        }}
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
        products={products}
        onSelectProduct={handleSelectProduct}
        userProfile={currentUserProfile}
        onOpenAuth={() => {
          setAuthModalMode('login');
          setIsAuthModalOpen(true);
        }}
        onLogout={handleLogout}
        onOpenCart={() => setIsCartOpen(true)}
        cartCount={totalCartCount}
        onOpenTracking={(q) => {
          setTrackingInitialQuery(q || '');
          setIsTrackingModalOpen(true);
        }}
        customizerSettings={customizerSettings}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-20 md:pb-8">
        {activeView === 'home' && (
          <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-3 sm:py-6 space-y-6 sm:space-y-8 animate-fadeIn">
            {/* Hero Banner Carousel */}
            <BannerSlider
              products={products}
              language={language}
              onSelectCategory={(cat) => {
                handleSelectCategory(cat);
                navigateTo('products', { category: cat });
              }}
              onExplore={() => navigateTo('products')}
              onSelectProduct={handleSelectProduct}
              customizerSettings={customizerSettings}
            />

            {/* Category Icons Navigation Bar */}
            <CategoryBar
              categories={dynamicCategories}
              selectedCategory={filters.category}
              onSelectCategory={(cat) => {
                handleSelectCategory(cat);
                navigateTo('products', { category: cat });
              }}
              language={language}
            />

            {/* Home Page Category-Wise Product Showcase Sections */}
            <HomeCategorySections
              products={products}
              categories={categoriesList}
              language={language}
              onSelectProduct={handleSelectProduct}
              onAddToCart={handleAddToCart}
              cartItemIds={cartItemIds}
              onViewCategory={(catId) => {
                handleSelectCategory(catId);
                navigateTo('products', { category: catId });
              }}
              customizerSettings={customizerSettings}
            />

            {/* Bangladeshi E-commerce Direct Order Callout */}
            <section className="rounded-2xl sm:rounded-3xl bg-gradient-to-r from-[#2A0005] via-[#45030C] to-[#2A0005] border border-[#70081C] text-white p-4 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-6 shadow-xl">
              <div className="space-y-1.5 sm:space-y-2 text-center sm:text-left">
                <span className="bg-[#800020] text-amber-300 text-[10px] sm:text-xs font-bold px-2.5 py-0.5 sm:py-1 rounded-full uppercase tracking-wider inline-block border border-amber-400/30">
                  {language === 'bn' ? 'সরাসরি হটলাইন যোগাযোগ' : 'Direct Hotline Support'}
                </span>
                <h3 className="text-base sm:text-xl md:text-2xl font-black text-white">
                  {customizerSettings
                    ? (language === 'bn' ? customizerSettings.directOrderTitleBn : customizerSettings.directOrderTitleEn)
                    : (language === 'bn' ? 'অনলাইনে অর্ডারে সমস্যা? আমাদের হটলাইনে সরাসরি যোগাযোগ করুন!' : 'Trouble ordering online? Contact our hotline directly!')}
                </h3>
                <p className="text-[11px] sm:text-xs text-neutral-300 max-w-lg leading-relaxed">
                  {customizerSettings
                    ? (language === 'bn' ? customizerSettings.directOrderSubtitleBn : customizerSettings.directOrderSubtitleEn)
                    : (language === 'bn' 
                        ? 'আমাদের কাস্টমার কেয়ার টিম সর্বদা প্রস্তুত আপনার পছন্দের পণ্য পৌঁছে দিতে সাহায্য করতে।' 
                        : 'Our friendly customer service is ready to assist and confirm your delivery.')}
                </p>
              </div>
              <div className="flex flex-col items-center sm:items-end gap-2 shrink-0">
                <a
                  href={`https://wa.me/8801732408652?text=${encodeURIComponent(language === 'bn' ? 'হ্যালো, আমি Happy Shopping স্টোর থেকে সাহায্য চাচ্ছি।' : 'Hello, I need assistance from Happy Shopping.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 sm:px-6 sm:py-3 rounded-xl sm:rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg transition"
                >
                  <MessageCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white shrink-0" />
                  <span className="font-mono text-xs sm:text-sm">01732408652</span>
                </a>
                <span className="text-[10px] sm:text-[11px] text-amber-300 font-semibold">
                  {t.codAvailable}
                </span>
              </div>
            </section>
          </div>
        )}

        {activeView !== 'home' && (
          <Suspense fallback={viewFallback}>
            {/* Product Listing Page */}
            {activeView === 'products' && (
              <ProductListing
                products={products}
                categories={categoriesList}
                language={language}
                filters={filters}
                onFilterChange={handleFilterChange}
                onResetFilters={handleResetFilters}
                onSelectProduct={handleSelectProduct}
                onAddToCart={handleAddToCart}
                cartItemIds={cartItemIds}
              />
            )}

            {/* Dedicated Product Details Page */}
            {activeView === 'product-detail' && (
              selectedProduct ? (
                <ProductDetailPage
                  product={selectedProduct}
                  language={language}
                  onBack={handleGoBack}
                  onBuyNow={handleBuyNowFromDetail}
                  onAddToCart={handleAddToCartFromDetail}
                  isInCart={cartItemIds.has(selectedProduct.id)}
                  reviews={reviews}
                  currentUser={currentUserProfile}
                  orders={orders}
                  onOpenWriteReview={(p, orderId, existing) => handleOpenWriteReview(p, orderId, existing)}
                  relatedProducts={relatedProductsForDetail}
                  onSelectProduct={handleSelectProduct}
                />
              ) : (
                <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
                  <p className="text-neutral-500 font-medium">
                    {language === 'bn' ? 'কোনো পণ্য পাওয়া যায়নি।' : 'No product found.'}
                  </p>
                  <button
                    onClick={() => navigateTo('products')}
                    className="px-6 py-2.5 bg-rose-600 text-white font-bold rounded-xl shadow cursor-pointer hover:bg-rose-700 transition"
                  >
                    {language === 'bn' ? 'সকল পণ্য দেখুন' : 'Browse All Products'}
                  </button>
                </div>
              )
            )}

            {/* Dedicated Checkout / Order Page */}
            {activeView === 'checkout' && (
              <CheckoutPage
                items={cart.length > 0 ? cart : (selectedProduct ? [{ product: selectedProduct, quantity: 1 }] : [])}
                language={language}
                onBack={handleGoBack}
                onOrderSuccess={async (newOrder) => {
                  await handleOrderSuccess(newOrder);
                  navigateTo('order-success', { order: newOrder });
                }}
                currentUserProfile={currentUserProfile}
                appliedCoupon={appliedCoupon}
                onOpenLogin={() => {
                  setAuthModalMode('register');
                  setAuthModalTitle(language === 'bn' ? 'অর্ডার কনফার্ম করতে অ্যাকাউন্ট তৈরি করুন' : 'Create Account to Confirm Order');
                  setAuthModalSubtitle(language === 'bn' ? 'অর্ডার ট্র্যাকিং ও ডেলিভারি নিশ্চিত করতে অনুগ্রহ করে সাইন আপ বা লগইন করুন।' : 'Please register or sign in to track and confirm your order.');
                  setIsOrderAuthGate(true);
                  setIsAuthModalOpen(true);
                }}
                onUpdateQuantity={(pId, delta) => handleUpdateCartQuantity(pId, delta)}
              />
            )}

            {/* Dedicated Order Success Page */}
            {activeView === 'order-success' && (
              recentPlacedOrder ? (
                <OrderSuccessPage
                  order={recentPlacedOrder}
                  language={language}
                  onContinueShopping={() => navigateTo('products')}
                  onViewAccountOrders={() => navigateTo('account')}
                  onTrackOrder={(orderId) => {
                    setTrackingInitialQuery(orderId);
                    setIsTrackingModalOpen(true);
                  }}
                  onCancelOrder={handleCancelOrder}
                />
              ) : (
                <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
                  <p className="text-neutral-500 font-medium">
                    {language === 'bn' ? 'কোনো সক্রিয় অর্ডার পাওয়া যায়নি।' : 'No active order found.'}
                  </p>
                  <button
                    onClick={() => navigateTo('home')}
                    className="px-6 py-2.5 bg-rose-600 text-white font-bold rounded-xl shadow cursor-pointer hover:bg-rose-700 transition"
                  >
                    {language === 'bn' ? 'হোমে ফিরে যান' : 'Back to Home'}
                  </button>
                </div>
              )
            )}

            {/* Account & Profile View */}
            {activeView === 'account' && (
              <AccountProfileView
                userProfile={currentUserProfile}
                orders={orders}
                reviews={reviews}
                language={language}
                onUpdateProfile={(updated) => setCurrentUserProfile(updated)}
                onLogout={handleLogout}
                onGoShopping={() => navigateTo('products')}
                onOpenLogin={() => {
                  setAuthModalMode('login');
                  setIsAuthModalOpen(true);
                }}
                onOpenAdmin={() => navigateTo('admin')}
                onCancelOrder={handleCancelOrder}
                onOpenWriteReview={handleOpenWriteReview}
                onDeleteOrder={handleDeleteOrder}
                onBulkDeleteOrders={handleBulkDeleteOrders}
              />
            )}

            {/* Admin Dashboard */}
            {activeView === 'admin' && (
              <AdminPanel
                products={products}
                categories={categoriesList}
                onCategoriesChange={setCategoriesList}
                orders={orders}
                reviews={reviews}
                onReviewsChange={setReviews}
                language={language}
                currentUserProfile={currentUserProfile}
                customizerSettings={customizerSettings}
                onCustomizerSettingsChange={handleCustomizerSettingsChange}
                onProductsChange={setProducts}
                onOpenLogin={() => {
                  setAuthModalMode('login');
                  setIsAuthModalOpen(true);
                }}
                onAddProduct={handleAddProduct}
                onUpdateProduct={handleUpdateProduct}
                onReorderProduct={handleReorderProduct}
                onDeleteProduct={handleDeleteProduct}
                onBulkDeleteProducts={handleBulkDeleteProducts}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onDeleteOrder={handleDeleteOrder}
                onBulkDeleteOrders={handleBulkDeleteOrders}
                onBackToShop={() => navigateTo('home')}
              />
            )}
          </Suspense>
        )}
      </main>

      {/* Footer */}
      <Footer
        language={language}
        onOpenPolicy={handleOpenPolicy}
        onOpenTracking={() => {
          setTrackingInitialQuery('');
          setIsTrackingModalOpen(true);
        }}
        customizerSettings={customizerSettings}
      />

      {/* Lazy-Loaded Modals & Drawers (zero initial bundle cost) */}
      <Suspense fallback={null}>
        {isWriteReviewOpen && reviewTargetProduct && (
          <WriteReviewModal
            isOpen={isWriteReviewOpen}
            onClose={() => {
              setIsWriteReviewOpen(false);
              setReviewTargetProduct(null);
              setExistingReviewToEdit(null);
              setReviewTargetOrderId(undefined);
            }}
            product={reviewTargetProduct}
            orderId={reviewTargetOrderId}
            currentUser={currentUserProfile}
            language={language}
            onSubmitReview={handleSubmitReview}
            existingReview={existingReviewToEdit}
          />
        )}

        {isAuthModalOpen && (
          <AuthModal
            isOpen={isAuthModalOpen}
            onClose={() => {
              setIsAuthModalOpen(false);
              setIsOrderAuthGate(false);
              setAuthModalTitle(undefined);
              setAuthModalSubtitle(undefined);
              setPendingCheckoutAfterAuth(false);
            }}
            language={language}
            initialMode={authModalMode}
            isOrderGate={isOrderAuthGate}
            customTitle={authModalTitle}
            customSubtitle={authModalSubtitle}
            onSuccess={(profile, isAdmin) => {
              setCurrentUserProfile(profile);
              const isUserAdmin = isAdmin || profile.email?.toLowerCase() === 'rmd474915@gmail.com' || profile.email?.toLowerCase() === 'winlucky414@gmail.com';
              
              if (isUserAdmin) {
                setActiveView('admin');
                showToast(language === 'bn' ? 'এডমিন হিসেবে লগইন হয়েছে!' : 'Logged in as Admin!');
              } else {
                showToast(language === 'bn' ? `স্বাগতম, ${profile.displayName}!` : `Welcome, ${profile.displayName}!`);
              }

              setIsAuthModalOpen(false);
              if (pendingCheckoutAfterAuth && !isUserAdmin) {
                setPendingCheckoutAfterAuth(false);
                setIsOrderAuthGate(false);
                navigateTo('checkout');
              }
            }}
          />
        )}

        {isPolicyModalOpen && (
          <LegalPolicyModal
            isOpen={isPolicyModalOpen}
            onClose={() => setIsPolicyModalOpen(false)}
            language={language}
            initialTab={policyModalTab}
          />
        )}

        {isCartOpen && (
          <CartDrawer
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            cartItems={cart}
            language={language}
            onUpdateQuantity={handleUpdateCartQuantity}
            onRemoveItem={handleRemoveFromCart}
            onProceedToCheckout={(coupon) => {
              setIsCartOpen(false);
              setAppliedCoupon(coupon);
              navigateTo('checkout');
            }}
            onContinueShopping={() => {
              setIsCartOpen(false);
              navigateTo('products');
            }}
            isLoggedIn={!!currentUserProfile}
          />
        )}

        {isTrackingModalOpen && (
          <OrderTrackingModal
            isOpen={isTrackingModalOpen}
            onClose={() => {
              setIsTrackingModalOpen(false);
              setTrackingInitialQuery('');
            }}
            language={language}
            orders={orders}
            initialQuery={trackingInitialQuery}
            onSelectProduct={handleSelectProduct}
          />
        )}
      </Suspense>

      {/* Bottom Navigation Bar (Visible across mobile, tablet & desktop) */}
      {activeView !== 'admin' && (
        <MobileBottomNav
          activeView={activeView}
          onChangeView={(v) => navigateTo(v as AppView)}
          cartCount={totalCartCount}
          onOpenCart={() => setIsCartOpen(true)}
          onOpenTracking={() => {
            setTrackingInitialQuery('');
            setIsTrackingModalOpen(true);
          }}
          language={language}
          isLoggedIn={!!currentUserProfile}
        />
      )}

      {/* Direct Floating WhatsApp Support Button */}
      {activeView !== 'admin' && activeView !== 'checkout' && (
        <aside
          aria-label="Direct WhatsApp Support"
          className="fixed bottom-20 md:bottom-6 right-3 md:right-6 z-30 transform-gpu"
        >
          <a
            href={`https://wa.me/8801732408652?text=${encodeURIComponent(language === 'bn' ? 'হ্যালো, আমি Happy Shopping স্টোর থেকে সাহায্য চাচ্ছি।' : 'Hello, I need assistance from Happy Shopping.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white px-3.5 py-2.5 rounded-full shadow-lg hover:shadow-xl transition-transform duration-150 sm:hover:scale-105 active:scale-95 text-xs font-bold group cursor-pointer"
            title={language === 'bn' ? 'হোয়াটসঅ্যাপে নক দিন' : 'Chat on WhatsApp'}
          >
            <span className="inline-flex rounded-full h-2 w-2 bg-white shrink-0" />
            <MessageCircle className="w-4 h-4 fill-white text-[#25D366]" />
            <span className="inline-block font-bold">WhatsApp</span>
          </a>
        </aside>
      )}
    </div>
  );
}
