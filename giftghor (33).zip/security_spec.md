# Firebase Security Specification & Rules Architecture

## 1. Data Invariants
1. **Admin Control**: Administrative operations (deleting orders, managing products, editing settings, viewing activity logs) are restricted to authorized administrators (emails `rmd474915@gmail.com`, `winlucky414@gmail.com`, or entries in `/admins/{adminId}`).
2. **Order Placement**: Guests and authenticated customers can create new orders (`allow create`). Order documents must contain required fields (`id`, `customerName`, `phone`, `total`, `orderStatus`).
3. **Order Access**: Customers can read their own orders (`resource.data.userId == request.auth.uid` or `resource.data.email == request.auth.token.email`); Admins can read, update, and manage all orders.
4. **Public Store Data**: Products, categories, active banners, approved product reviews, and public store settings are readable by anyone (`allow read: if true`).
5. **Product & Inventory Management**: Modifying products, categories, banners, and coupons requires administrator authorization.
6. **User Profiles**: Users can only read and update their own profile document (`/users/{userId}` where `request.auth.uid == userId`) or administrators.
7. **Reviews**: Authenticated users and customers can create reviews in 'pending' status; only admins can approve or reject reviews.

---

## 2. The "Dirty Dozen" Threat Models & Hardening
1. **Unauthorized Admin Escalation**: A normal user attempts to write to `/admins/{uid}` or `/settings/{settingId}`. -> **REJECTED (isAdmin required)**
2. **Order Mutation by Foreign User**: User A attempts to edit User B's order status to 'delivered' or 'refunded'. -> **REJECTED (Only admin or order creator)**
3. **Ghost Field / Shadow Key Injection**: Malicious payloads with oversized or disallowed keys. -> **REJECTED (Validated schema bounds)**
4. **Junk Path ID Poisoning**: Document IDs with invalid symbols or length > 128 characters. -> **REJECTED (isValidId check)**
5. **PII Scraping**: Anonymous scraping of user private profile data. -> **REJECTED (User profile read restricted to owner or admin)**
6. **Fake Review Injection**: Unauthenticated bots attempting mass automated review writes. -> **REJECTED (Reviews require valid payload)**
7. **Coupon Manipulation**: Regular users creating 100% discount coupons. -> **REJECTED (Only admins can write to /coupons)**
8. **Inventory Stock Poisoning**: Non-admins editing product quantities or stock logs directly. -> **REJECTED (Write restricted to admins)**
9. **Settings / Customizer Tampering**: Malicious user altering banner URLs to phishing domains. -> **REJECTED (Only admins can write to /settings or /banners)**
10. **Activity Log Tampering**: Modifying or deleting audit trails. -> **REJECTED (Only admins can write, no deletion)**
11. **Order Total Negative Exploit**: Placing orders with negative pricing. -> **REJECTED (total must be >= 0)**
12. **Status History Spoofing**: Injecting unauthorized status changes without admin permissions. -> **REJECTED**

---

## 3. Production Rules Matrix
| Collection | Read Rule | Create Rule | Update Rule | Delete Rule |
|---|---|---|---|---|
| `/admins/{adminId}` | Admin only | Admin only | Admin only | Admin only |
| `/users/{userId}` | Owner or Admin | Owner or Admin or Public init | Owner or Admin | Admin only |
| `/orders/{orderId}` | Public/Owner/Admin | Valid payload (Anyone) | Admin or Owner | Admin only |
| `/orders/{orderId}/statusHistory/{id}` | Read if Order accessible | Admin or Order Creator | Admin only | Admin only |
| `/products/{productId}` | Public (`true`) | Admin only | Admin only | Admin only |
| `/settings/{settingId}` | Public (`true`) | Admin only | Admin only | Admin only |
| `/banners/{bannerId}` | Public (`true`) | Admin only | Admin only | Admin only |
| `/coupons/{couponId}` | Public (`true`) | Admin only | Admin only | Admin only |
| `/reviews/{reviewId}` | Public if approved, or Admin | Anyone (Valid shape) | Admin only | Admin only |
| `/categories/{catId}` | Public (`true`) | Admin only | Admin only | Admin only |
| `/activityLogs/{logId}`| Admin only | Admin only | False | False |
| `/stockLogs/{logId}` | Admin only | Admin only | False | False |
