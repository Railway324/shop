import fs from 'fs';
import path from 'path';
import { Product } from '../src/types';

const CATEGORY_IDS = [
  'winter',
  'mens-fashion',
  'watches',
  'womens-fashion',
  'jewelry',
  'home-lifestyle',
  'gadgets-electronics',
  'kids-zone',
  'foods',
  'others',
];

function main() {
  const productsPath = path.resolve(process.cwd(), 'src/data/products.json');
  const seedPath = path.resolve(process.cwd(), 'src/data/homeSeedProducts.json');
  const allProducts: Product[] = JSON.parse(fs.readFileSync(productsPath, 'utf8'));

  const seed: Partial<Product>[] = [];
  for (const catId of CATEGORY_IDS) {
    const catProducts = allProducts
      .filter(p => p && p.id && p.status !== 'inactive' && p.category === catId)
      .sort((a, b) => {
        if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
        if (!a.isPinnedToTop && b.isPinnedToTop) return 1;
        const oA = typeof a.displayOrder === 'number' ? a.displayOrder : 99999;
        const oB = typeof b.displayOrder === 'number' ? b.displayOrder : 99999;
        return oA - oB;
      })
      .slice(0, 8);

    for (const p of catProducts) {
      const shortDesc = (p.descriptionBn || p.descriptionEn || p.titleBn || '')
        .slice(0, 240)
        .replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '');
      const compact: Partial<Product> = {
        id: p.id,
        titleBn: p.titleBn,
        titleEn: p.titleEn || p.titleBn,
        descriptionBn: shortDesc,
        descriptionEn: shortDesc,
        category: p.category,
        ...(p.subcategory ? { subcategory: p.subcategory } : {}),
        price: p.price,
        ...(p.originalPrice ? { originalPrice: p.originalPrice } : {}),
        ...(p.discountPercent ? { discountPercent: p.discountPercent } : {}),
        image: p.image,
        rating: p.rating ?? 4.8,
        reviewsCount: p.reviewsCount ?? 15,
        stock: p.stock ?? 50,
        status: p.status || 'active',
        ...(p.isFeatured ? { isFeatured: true } : {}),
        ...(p.freeDelivery ? { freeDelivery: true } : {}),
        ...(p.isPinnedToTop ? { isPinnedToTop: true } : {}),
        ...(typeof p.displayOrder === 'number' ? { displayOrder: p.displayOrder } : {}),
        ...(p.sku ? { sku: p.sku } : {}),
        ...(p.size ? { size: p.size } : {}),
        ...(p.color ? { color: p.color } : {}),
        ...(p.weight ? { weight: p.weight } : {}),
        ...(p.variants && p.variants.length > 0 ? { variants: p.variants } : {}),
        createdAt: p.createdAt || '2026-01-01',
      };
      seed.push(compact);
    }
  }

  fs.writeFileSync(seedPath, JSON.stringify(seed), 'utf8');
  const kb = (Buffer.byteLength(JSON.stringify(seed)) / 1024).toFixed(1);
  console.log(`Generated src/data/homeSeedProducts.json with ${seed.length} products (${kb} KB).`);
}

main();
