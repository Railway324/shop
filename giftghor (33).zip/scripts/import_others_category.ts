import fs from 'fs';
import path from 'path';
import { isWatchProductTitle } from '../src/utils/categoryUtils';
import {
  bulkSyncProductsToFirestore,
  saveCategoryToFirestore,
  getAllProductsFromFirestore,
} from '../src/lib/firebase';
import { initialCategories } from '../src/data/initialData';
import { Product } from '../src/types';

function decodeHtml(html: string): string {
  if (!html) return '';
  return html
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#038;/g, '&')
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8217;/g, "'")
    .replace(/&#8216;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#2547;/g, '৳')
    .replace(/&nbsp;/g, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeImageUrl(url: string): string {
  if (!url) return '';
  return url
    .trim()
    .replace('public//storage/', 'public/storage/')
    .replace(/^http:\/\//i, 'https://');
}

function mapOthersSubcategory(sub: string, subsub: string, title: string): string {
  const s = `${sub} ${subsub}`.toLowerCase();
  const t = title.normalize('NFKD').toLowerCase();

  if (s.includes('combo-pack') || t.includes('combo')) {
    return 'কম্বো প্যাক (Combo Packs)';
  }
  if (s.includes('mystery-box') || t.includes('magic box') || t.includes('mystery box')) {
    return 'মিস্ট্রি বক্স (Mystery Box)';
  }
  if (s.includes('couple') || t.includes('couple')) {
    return 'কাপল সেট (Couple Collection)';
  }
  if (s.includes('customize-item') || t.includes('customize') || t.includes('personalised') || t.includes('personalized')) {
    return 'কাস্টমাইজ গিফট ও আইটেম (Customized Items)';
  }
  if (s.includes('gift-item') || t.includes('gift')) {
    return 'গিফট আইটেম (Gift Items)';
  }
  if (s.includes('stock-clearance')) {
    return 'স্টক ক্লিয়ারেন্স (Stock Clearance)';
  }
  return 'স্পেশাল অফার ও অন্যান্য (Special Deals & Others)';
}

interface DiscoveredCard {
  slug: string;
  sub: string;
  subsub: string;
  cardTitle: string;
  thumbImg: string;
  hoverImg: string;
}

async function discoverAllOthersProducts(): Promise<Map<string, DiscoveredCard>> {
  console.log('1. Fetching https://www.dropshipping.com.bd/others session & subcategories...');
  const mainRes = await fetch('https://www.dropshipping.com.bd/others');
  const setCookies = mainRes.headers.getSetCookie
    ? mainRes.headers.getSetCookie().map((c: string) => c.split(';')[0]).join('; ')
    : (mainRes.headers.get('set-cookie') || '');
  const mainHtml = await mainRes.text();
  const csrf = (mainHtml.match(/name="csrf-token"\s+content="([^"]+)"/) || [])[1] || '';

  const discoveredLinks = [
    ...mainHtml.matchAll(/href="(https?:\/\/(?:www\.)?dropshipping\.com\.bd\/others[^"]*)"/g),
  ].map((m) => m[1]);

  const allUrls = Array.from(
    new Set([
      'https://www.dropshipping.com.bd/others',
      ...discoveredLinks,
    ])
  );
  console.log(`   Found ${allUrls.length} /others category & subcategory URLs.`);

  const slugMap = new Map<string, DiscoveredCard>();

  const parseCardsFromHtml = (htmlChunk: string, sub: string, subsub: string) => {
    const cardRegex = /<div class="product_card">([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>/g;
    let match: RegExpExecArray | null;
    while ((match = cardRegex.exec(htmlChunk)) !== null) {
      const block = match[1];
      const slugMatch = block.match(/href="https?:\/\/(?:www\.)?dropshipping\.com\.bd\/product\/([^"]+)"/);
      if (!slugMatch) continue;
      const slug = slugMatch[1].trim();
      const imgs = [...block.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/g)].map((m) => normalizeImageUrl(m[1]));
      const nameMatch = block.match(/class="product_name_link"[^>]*>([\s\S]*?)<\/a>/);
      const cardTitle = nameMatch ? decodeHtml(nameMatch[1]) : '';
      const existing = slugMap.get(slug);
      if (!existing || (sub && !existing.sub)) {
        slugMap.set(slug, {
          slug,
          sub: sub || existing?.sub || '',
          subsub: subsub || existing?.subsub || '',
          cardTitle: cardTitle || existing?.cardTitle || '',
          thumbImg: imgs[0] || existing?.thumbImg || '',
          hoverImg: imgs[1] || existing?.hoverImg || '',
        });
      }
    }
  };

  for (const url of allUrls) {
    const pathPart = url.replace(/^https?:\/\/(?:www\.)?dropshipping\.com\.bd\//, '');
    const parts = pathPart.split('/');
    const cat = parts[0] || 'others';
    const sub = parts[1] || '';
    const subsub = parts[2] || '';

    // Check direct HTML first
    try {
      const pRes = await fetch(url, { headers: { Cookie: setCookies } });
      const pHtml = await pRes.text();
      parseCardsFromHtml(pHtml, sub, subsub);
    } catch (e) {
      console.warn(`   Direct page fetch warning for ${url}:`, e);
    }

    // Paginate load-more-data until empty
    for (let page = 1; page <= 50; page++) {
      try {
        const r = await fetch('https://www.dropshipping.com.bd/load-more-data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-CSRF-TOKEN': csrf,
            'X-Requested-With': 'XMLHttpRequest',
            Cookie: setCookies,
          },
          body: new URLSearchParams({
            page: String(page),
            limit: '20',
            category_slug: cat,
            subcategory_slug: sub,
            sub_subcategory_slug: subsub,
          }).toString(),
        });
        if (!r.ok) break;
        const j = await r.json();
        const htmlData = j?.data || '';
        if (!htmlData || (j?.product_length || 0) === 0) break;
        parseCardsFromHtml(htmlData, sub, subsub);
        if ((j?.product_length || 0) < 20) break;
      } catch (e) {
        console.warn(`   Pagination warning on ${url} page ${page}:`, e);
        break;
      }
    }
  }

  console.log(`   Total unique slugs discovered in /others: ${slugMap.size}`);
  return slugMap;
}

async function scrapeProductDetail(card: DiscoveredCard, index: number): Promise<Product | null> {
  const url = `https://www.dropshipping.com.bd/product/${card.slug}`;
  let html = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(url);
      if (res.ok) {
        html = await res.text();
        break;
      }
    } catch (e) {
      if (attempt === 3) console.warn(`   Failed to fetch ${url}:`, e);
    }
  }

  if (!html) return null;

  // Title
  const h2Match = html.match(/<div class="single_product_name">[\s\S]*?<h2>([\s\S]*?)<\/h2>/i);
  const ogTitleMatch = html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i);
  const title = decodeHtml(h2Match?.[1] || ogTitleMatch?.[1] || card.cardTitle);
  if (!title) return null;

  // Wholesale price from meta property="product:price:amount"
  const metaPriceMatch = html.match(/property="product:price:amount"\s+content="([^"]+)"/i);
  let wholesalePrice = metaPriceMatch ? parseFloat(metaPriceMatch[1]) : 0;
  if (!wholesalePrice || isNaN(wholesalePrice) || wholesalePrice <= 0) {
    // Fallback check for deal-139 or numeric price in title
    if (card.subsub === 'deal-139') wholesalePrice = 139;
    else wholesalePrice = 250;
  }

  // Exact catalog pricing formula: wholesale + 100 BDT
  const price = Math.round(wholesalePrice + 100);
  const originalPrice =
    price < 400
      ? price + 100
      : Math.max(price + 100, Math.round((price * 1.25) / 50) * 50);
  const discountPercent = Math.round(((originalPrice - price) / originalPrice) * 100);

  // Extract gallery images strictly inside .zoom_img_active so we don't grab unrelated products
  const galleryImages: string[] = [];
  const zoomBlockMatch = html.match(/<div class="zoom_img_active[^"]*">([\s\S]*?)<div class="single_product_details">/i);
  if (zoomBlockMatch) {
    const picRegex = /<div class="project-picture"[^>]*>\s*<img[^>]+src="([^"]+)"/gi;
    let pm: RegExpExecArray | null;
    while ((pm = picRegex.exec(zoomBlockMatch[1])) !== null) {
      const cleanImg = normalizeImageUrl(pm[1]);
      if (cleanImg && !galleryImages.includes(cleanImg)) {
        galleryImages.push(cleanImg);
      }
    }
  }

  if (galleryImages.length === 0) {
    const ogImg = html.match(/property="og:image"\s+content="([^"]+)"/i)?.[1];
    if (ogImg) galleryImages.push(normalizeImageUrl(ogImg));
    if (card.hoverImg && !galleryImages.includes(card.hoverImg)) galleryImages.push(card.hoverImg);
    if (card.thumbImg && !galleryImages.includes(card.thumbImg)) galleryImages.push(card.thumbImg);
  }

  const primaryImage = galleryImages[0] || card.thumbImg || card.hoverImg;
  if (!primaryImage) return null;

  // Standing watch rule check
  const isWatch = isWatchProductTitle(title, title);
  const category = isWatch ? 'watches' : 'others';
  const subcategory = isWatch
    ? 'ঘড়ি ও স্মার্টওয়াচ (Watches)'
    : mapOthersSubcategory(card.sub, card.subsub, title);

  const nowIso = new Date().toISOString();
  const rating = Number((4.7 + (index % 4) * 0.1).toFixed(1));
  const reviewsCount = 18 + ((index * 7) % 42);

  const descriptionEn = isWatch
    ? `${title} - Premium Watches Collection. Stylish design, reliable movement & durable finish. 100% Cash on Delivery across Bangladesh.`
    : `${title} - Exclusive Other's & Special Gift Collection (${subcategory}). Premium quality, value bundle & reliable packaging. 100% Cash on Delivery across Bangladesh.`;

  const descriptionBn = isWatch
    ? `${title} - প্রিমিয়াম ঘড়ি কালেকশন। আকর্ষণীয় ডিজাইন, নিখুঁত ফিনিশিং ও দীর্ঘস্থায়ী মান। সারাদেশে ১০০% ক্যাশ অন ডেলিভারি সুবিধা।`
    : `${title} - এক্সক্লুসিভ অন্যান্য ও স্পেশাল গিফট কালেকশন (${subcategory})। উন্নতমানের ফিনিশিং, সাশ্রয়ী অফার এবং গিফট বা ব্যক্তিগত ব্যবহারের জন্য চমৎকার। সারাদেশে ১০০% ক্যাশ অন ডেলিভারি সুবিধা।`;

  const specificationsEn = isWatch
    ? [
        'Premium Watches Collection',
        'Durable Build & Elegant Finish',
        '100% Cash on Delivery Available',
        'Fast Nationwide Home Delivery',
      ]
    : [
        `Category: ${subcategory}`,
        'Premium Quality & Verified Packaging',
        '100% Cash on Delivery Available',
        'Fast Nationwide Home Delivery',
      ];

  const specificationsBn = isWatch
    ? [
        'প্রিমিয়াম ঘড়ি কালেকশন',
        'টেকসই ম্যাটেরিয়াল ও আকর্ষণীয় ফিনিশিং',
        '১০০% ক্যাশ অন ডেলিভারি সুবিধা',
        'সারাদেশে দ্রুত হোম ডেলিভারি',
      ]
    : [
        `ক্যাটাগরি: ${subcategory}`,
        'উন্নতমানের কোয়ালিটি ও আকর্ষণীয় প্যাকেজিং',
        '১০০% ক্যাশ অন ডেলিভারি সুবিধা',
        'সারাদেশে দ্রুত হোম ডেলিভারি',
      ];

  return {
    id: `dsp-${card.slug}`,
    titleEn: title,
    titleBn: title,
    category,
    subcategory,
    price,
    originalPrice,
    discountPercent,
    rating: Math.min(5, rating),
    reviewsCount,
    stock: 50,
    image: primaryImage,
    additionalImages: galleryImages,
    freeDelivery: false,
    status: 'active',
    isFeatured: index < 8,
    descriptionEn,
    descriptionBn,
    specificationsEn,
    specificationsBn,
    createdAt: nowIso,
    updatedAt: nowIso,
  };
}

async function main() {
  const productsPath = path.join(process.cwd(), 'src', 'data', 'products.json');
  const deletedPath = path.join(process.cwd(), 'src', 'data', 'deleted_product_ids.json');

  const existingProducts: Product[] = JSON.parse(fs.readFileSync(productsPath, 'utf8'));
  const deletedIds = new Set<string>(
    fs.existsSync(deletedPath) ? JSON.parse(fs.readFileSync(deletedPath, 'utf8')) : []
  );

  const existingIds = new Set(existingProducts.map((p) => p.id));
  console.log(`Existing catalog count: ${existingProducts.length}`);

  const discoveredMap = await discoverAllOthersProducts();
  const toScrape: DiscoveredCard[] = [];

  for (const [slug, card] of discoveredMap.entries()) {
    const id = `dsp-${slug}`;
    if (existingIds.has(id) || deletedIds.has(id)) continue;
    toScrape.push(card);
  }

  console.log(`2. Brand-new products to scrape from /others: ${toScrape.length}`);

  const scrapedProducts: Product[] = [];
  const concurrency = 10;
  let cursor = 0;

  async function worker() {
    while (cursor < toScrape.length) {
      const idx = cursor++;
      const card = toScrape[idx];
      const prod = await scrapeProductDetail(card, idx);
      if (prod) {
        scrapedProducts.push(prod);
        console.log(`   [${scrapedProducts.length}/${toScrape.length}] ${prod.id} -> ${prod.category} | ৳${prod.price} (was ৳${prod.originalPrice}) | ${prod.titleEn.slice(0, 55)}`);
      }
    }
  }

  await Promise.all(Array.from({ length: concurrency }, () => worker()));

  // Preserve deterministic order matching toScrape
  const orderMap = new Map(toScrape.map((c, i) => [`dsp-${c.slug}`, i]));
  scrapedProducts.sort((a, b) => (orderMap.get(a.id) ?? 0) - (orderMap.get(b.id) ?? 0));

  const updatedCatalog = [...existingProducts, ...scrapedProducts];
  fs.writeFileSync(productsPath, JSON.stringify(updatedCatalog, null, 2), 'utf8');
  console.log(`\n3. Saved updated src/data/products.json! Total products: ${updatedCatalog.length}`);

  // Compute exact category counts
  const catCounts: Record<string, number> = {};
  for (const p of updatedCatalog) {
    if (p.status === 'inactive') continue;
    catCounts[p.category] = (catCounts[p.category] || 0) + 1;
  }
  console.log('4. Category counts in updated catalog:', catCounts);

  // Sync new products to Firebase Firestore
  if (scrapedProducts.length > 0) {
    console.log(`5. Syncing ${scrapedProducts.length} newly imported products to Firebase Firestore...`);
    await bulkSyncProductsToFirestore(scrapedProducts);
    console.log('   Firestore product sync complete!');
  }

  // Sync updated category itemCounts to Firebase Firestore
  console.log('6. Syncing updated category counts to Firebase Firestore...');
  for (const cat of initialCategories) {
    const exactCount =
      cat.id === 'all'
        ? updatedCatalog.filter((p) => p.status !== 'inactive').length
        : catCounts[cat.id] || 0;
    await saveCategoryToFirestore({
      ...cat,
      itemCount: exactCount,
    });
  }
  console.log('   Firestore category sync complete!');

  // Verify live Firestore count
  const liveFirestoreProducts = await getAllProductsFromFirestore();
  console.log(`7. Verified live Firestore total products: ${liveFirestoreProducts.length}`);

  const addedOthers = scrapedProducts.filter((p) => p.category === 'others').length;
  const addedWatches = scrapedProducts.filter((p) => p.category === 'watches').length;
  console.log(`\nSUMMARY: Added ${scrapedProducts.length} new products (${addedOthers} in others, ${addedWatches} routed to watches).`);
  process.exit(0);
}

main().catch((err) => {
  console.error('Fatal error in import_others_category:', err);
  process.exit(1);
});
