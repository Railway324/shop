import fs from 'fs';
import path from 'path';
import { isWatchProductTitle } from '../src/utils/categoryUtils';
import {
  bulkSyncProductsToFirestore,
  saveCategoryToFirestore,
} from '../src/lib/firebase';
import { initialCategories } from '../src/data/initialData';
import { Product, ProductVariant } from '../src/types';

const DRY_RUN = process.argv.includes('--dry-run');
const SCRAPE_ONLY = process.argv.includes('--scrape-only');
const REFRESH_CACHE = process.argv.includes('--refresh');
const CACHE_PATH = '/tmp/home_lifestyle_scraped_cache.json';

function toAsciiDigits(str: string): string {
  return str.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
}

function decodeEntities(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFKC')
    .replace(/Â°/g, '°')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#038;/g, '&')
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8217;/g, "'")
    .replace(/&#8216;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#2547;/g, '৳')
    .replace(/&nbsp;/g, ' ');
}

function cleanSingleLine(html: string): string {
  return decodeEntities(html)
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function htmlToFormattedText(html: string): { fullText: string; bulletSpecs: string[] } {
  if (!html) return { fullText: '', bulletSpecs: [] };

  const bulletSpecs: string[] = [];
  const liRegex = /<li[^>]*>([\s\S]*?)<\/li>/gi;
  let m: RegExpExecArray | null;
  while ((m = liRegex.exec(html)) !== null) {
    const item = cleanSingleLine(m[1]);
    if (item && item.length > 2 && item.length <= 180) {
      bulletSpecs.push(item);
    }
  }

  const trRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  while ((m = trRegex.exec(html)) !== null) {
    const cells = [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
      .map(c => cleanSingleLine(c[1]))
      .filter(Boolean);
    if (cells.length >= 2) {
      const rowText = cells.join(' | ');
      if (rowText.length <= 180) bulletSpecs.push(rowText);
    }
  }

  const formatted = decodeEntities(
    html
      .replace(/<\/t[dh]>\s*<t[dh][^>]*>/gi, ' | ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<li[^>]*>/gi, '\n• ')
      .replace(/<\/(?:p|div|li|tr|h[1-6]|ul|ol|table)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .split('\n')
    .map(line => line.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean)
    .join('\n');

  return { fullText: formatted, bulletSpecs: Array.from(new Set(bulletSpecs)).slice(0, 14) };
}

function normalizeImageUrl(url: string): string {
  if (!url) return '';
  return url
    .trim()
    .replace('public//storage/', 'public/storage/')
    .replace(/^http:\/\//i, 'https://');
}

const STANDARD_ALPHA_ORDER = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL'];

function normalizeAlphaToken(tok: string): string {
  const u = tok.toUpperCase();
  if (u === '2XL') return 'XXL';
  if (u === 'XXXL') return '3XL';
  if (u === 'XXXXL') return '4XL';
  return u;
}

function expandAlphaRange(startTok: string, endTok: string): string[] {
  const sIdx = STANDARD_ALPHA_ORDER.indexOf(normalizeAlphaToken(startTok));
  const eIdx = STANDARD_ALPHA_ORDER.indexOf(normalizeAlphaToken(endTok));
  if (sIdx !== -1 && eIdx !== -1 && eIdx > sIdx) {
    return STANDARD_ALPHA_ORDER.slice(sIdx, eIdx + 1);
  }
  return [];
}

/**
 * Determines if a product in /home-lifestyle (or reassigned categories) genuinely has selectable sizes.
 */
export function isSelectableSizeCandidate(
  title: string,
  targetCat: string,
  sub: string,
  subsub: string,
  desc: string
): boolean {
  const t = title.toLowerCase();
  const s = `${sub} ${subsub}`.toLowerCase();

  // Unstitched fabrics never have selectable garment sizes
  if (/\bunstitched\b|আনস্টিচড/i.test(`${title} ${desc}`)) {
    return false;
  }

  // Never put sizes on watches or clocks
  if (targetCat === 'watches' || isWatchProductTitle(title, title)) return false;

  // Check positive wearable / multi-size items BEFORE generic household keyword exclusions
  // (e.g. "Children's Raincoat ... with School Bag Space" contains "bag" in title, so check raincoat first!)
  if (/\b(?:raincoat|rain\s*coat|rain\s*suit)\b|রেইনকোট|রেইন\s*কোট/i.test(t) && !/\brain\s*card|pocket\s*rain\s*coat|wallet\s*rain\s*coat\b/i.test(t)) {
    return true;
  }
  if (/\b(?:sweat\s*(?:slim\s*)?belt|slim(?:ming)?\s*belt|shaper\s*belt|waist\s*(?:trimmer|support|belt)|posture\s*corrector|back\s*support\s*belt|knee\s*(?:cap|support)|ankle\s*support)\b/i.test(t)) {
    return true;
  }
  if (s.includes('tupi') || /\b(?:tupi|prayer\s*cap|টুপি)\b/i.test(t)) {
    return true;
  }
  if (['mens-fashion', 'womens-fashion', 'winter', 'kids-zone'].includes(targetCat)) {
    // Only apparel/footwear inside these categories (never toys/games like Sup Game Box)
    if (/\b(?:game\s*box|toy|car|drone|feeder|diaper|stroller|bouncer|bag|backpack|umbrella)\b/i.test(t)) {
      return false;
    }
    return true;
  }

  // Exclude household, kitchen, bags, sunglasses, fragrances, decor, single-size bedsheets, etc.
  if (s.includes('kitchen') || s.includes('home-appliance') || s.includes('sunglass') || s.includes('bag')) return false;
  if (s.includes('ator') || s.includes('fragrance') || s.includes('jainamaj') || s.includes('organic-food')) return false;

  if (
    /\b(?:mug|cup|bottle|flask|kettle|grinder|blender|chopper|knife|peeler|pan|pot|cooker|plate|bowl|tray|spoon|rack|organizer|basket|hanger|mop|brush|wiper|dispenser|filter|faucet|tap|light|lamp|clock|mirror|sticker|frame|vase|flower|plant|curtain|পর্দা|টেবিল\s*ক্লথ|table\s*cloth|mat|carpet|rug|doormat|pillow|cushion|comforter|blanket|mosquito\s*net|মশারি|umbrella|ছাতা|sunglass|glasses|goggles|সানগ্লাস|চশমা|bag|backpack|handbag|purse|wallet|luggage|ব্যাগ|মানিব্যাগ|attar|atar|perfume|body\s*spray|fragrance|আতর|পারফিউম|soap|shampoo|cream|lotion|serum|oil|gel|face\s*wash|tooth|trimmer|shaver|massager|jainamaj|জায়নামাজ|জায়নামাজ|tasbih|তসবিহ|rehal|রেহাল|miswak|মিসওয়াক|bed\s*sheet|বেডশিট)\b/i.test(
      t
    )
  ) {
    return false;
  }

  if (
    s.includes('cloth-item') ||
    /\b(?:jubba|thobe|thowb|kabli|panjabi|punjabi|pajama|payjama|borka|burqa|abaya|khimar|kurti|t-?shirt|shirt|polo|jersey|pant|trouser|jogger|hoodie|jacket|shoe|sneaker|sandal|slipper|loafer)\b/i.test(
      t
    )
  ) {
    return true;
  }

  return false;
}

export function extractRealSizesHomeLifestyle(
  detailsHtml: string,
  descText: string,
  title: string,
  targetCat: string,
  sub: string,
  subsub: string
): string[] {
  if (!isSelectableSizeCandidate(title, targetCat, sub, subsub, descText)) {
    return [];
  }

  const found: string[] = [];
  const addSize = (s: string) => {
    const clean = s
      .trim()
      .replace(/^[-–—:•➤=>*#\s]+|[-–—:•*″"'।.\s]+$/g, '')
      .trim();
    if (!clean) return;
    if (/\b(?:cm|mm|ml|ltr|liter|kg|gm|gram|watt|volt|mah|feet|ft|inch|ইঞ্চি|ফুট|হাত)\b/i.test(clean)) return;
    if (/\d+\s*[xX*×]\s*\d+/.test(clean)) return;

    const norm = normalizeAlphaToken(clean);
    const normalized = STANDARD_ALPHA_ORDER.includes(norm) ? norm : clean;
    if (!found.some(x => x.toLowerCase() === normalized.toLowerCase())) {
      found.push(normalized);
    }
  };

  const asciiDesc = toAsciiDigits(descText);
  const lines = asciiDesc.split('\n').map(l => l.trim()).filter(Boolean);

  // Special handling for Tupi / Prayer Caps (only if multiple discrete head sizes like 54, 55, 56, 57, 58 exist; "One Size Fits All" -> [])
  const isTupi = sub.includes('tupi') || subsub.includes('tupi') || /\b(?:tupi|prayer\s*cap|টুপি)\b/i.test(title);
  if (isTupi) {
    if (/one\s*size|free\s*size|ফ্রি\s*সাইজ|ওয়ান\s*সাইজ/i.test(`${title} ${asciiDesc}`)) {
      return [];
    }
    for (const line of lines) {
      const m = line.match(/(?:size|সাইজ|মাপ)\s*[:ঃ=–—-]+\s*([^\n]+)/i);
      if (m) {
        const rhs = m[1].replace(/[।.]+$/g, '').trim();
        const tupiNums = [...rhs.matchAll(/\b(5[2-9]|2[0-3](?:\.5)?)\b/g)].map(x => x[1]);
        if (tupiNums.length >= 2) {
          tupiNums.forEach(addSize);
        }
      }
    }
    return found;
  }

  // 1. Explicit Size / সাইজ / Body Size (Bust) / Age Group lines
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    const alphaRangeInLine = line.match(
      /(?:সাইজ|size|আকার)[^\n]{0,30}?\b(XS|S|M|L|XL)\s*(?:to|থেকে|[-–—])\s*(L|XL|XXL|2XL|3XL|4XL|XXXL)\b/i
    );
    if (alphaRangeInLine) {
      expandAlphaRange(alphaRangeInLine[1], alphaRangeInLine[2]).forEach(addSize);
    }

    if (/size\s*chart|সাইজ\s*চার্ট/i.test(line) && !/[:ঃ=-]\s*(?:XS|S|M|L|XL|XXL|\d{2})\b/i.test(line)) {
      continue;
    }

    // Kids Age Group range (e.g. "বয়সসীমা (Age Group): 2 বছর থেকে 12 বছর (2 Years to 12 Years)")
    const ageRangeMatch = line.match(
      /(?:বয়সসীমা|age\s*group|বয়স|age)\s*(?:\([^)]*\))?\s*[:ঃ=-]+\s*(\d{1,2})\s*(?:বছর|years?|yrs?)?\s*(?:থেকে|to|[-–—])\s*(\d{1,2})\s*(?:বছর|years?|yrs?)/i
    );
    if (ageRangeMatch && targetCat === 'kids-zone') {
      const sAge = parseInt(ageRangeMatch[1], 10);
      const eAge = parseInt(ageRangeMatch[2], 10);
      if (sAge === 2 && eAge === 12) {
        ['2-3 Yrs', '4-5 Yrs', '6-7 Yrs', '8-9 Yrs', '10-12 Yrs'].forEach(addSize);
        continue;
      }
    }

    // Standalone header followed by next line
    if (
      /^(?:[^\w\u0980-\u09FF]*)(?:এভেইলেবল\s*সাইজ|available\s+sizes?|সাইজ\s*অপশনস?|sizes?|সাইজ|আকার)(?:\s*\([^)]*\))?\s*[:ঃ=-]?\s*$/i.test(
        line
      )
    ) {
      if (i + 1 < lines.length) {
        const nextLine = lines[i + 1].replace(/^[•➤❑\-*👉]+\s*/, '').replace(/[।.]+$/, '').trim();
        const nextAlpha = nextLine.match(/^(?:(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL)$/i);
        if (nextAlpha) {
          nextLine.split(/[,/|&\s]+/).filter(Boolean).forEach(addSize);
          continue;
        }
        const nextNums = nextLine.split(/[,;|/&]+/).map(s => s.trim()).filter(Boolean);
        if (nextNums.length >= 2 && nextNums.every(p => /^\d{2}$/.test(p))) {
          nextNums.forEach(addSize);
          continue;
        }
      }
    }

    const parenAlpha = line.match(
      /(?:সাইজে?|size|fit|আকার)[^()\n]{0,25}\(\s*((?:(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL))\s*\)/i
    );
    if (parenAlpha) {
      parenAlpha[1].split(/[,/|&\s]+/).filter(Boolean).forEach(addSize);
    }

    const explicitSizeLabel = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(?:এভেইলেবল\s*সাইজ|available\s+sizes?|body\s*size(?:\s*\(bust\))?|measurements?|সাইজ\s*অপশনস?|sizes?|সাইজ|আকার)\s*[:ঃ=–—-]+\s*([^\n]+)/i
    );
    if (explicitSizeLabel) {
      const rhs = explicitSizeLabel[1].replace(/[।.]+$/g, '').trim();
      if (/^(?:chest|waist|length|body|in\s+inches|\d+\s*(?:ft|feet|inch|cm|mm))/i.test(rhs)) {
        continue;
      }

      const alphaTokens = rhs.match(/\b(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL|XXXL)\b/gi);
      if (alphaTokens && alphaTokens.length >= 2) {
        alphaTokens.forEach(addSize);
        continue;
      }

      const discreteNums = rhs
        .split(/[,;|/&]+|\s+and\s+|\s+ও\s+/i)
        .map(s => s.replace(/["″'।.]+/g, '').trim())
        .filter(Boolean);

      if (discreteNums.length >= 2 && discreteNums.every(p => /^\d{2}$/.test(p))) {
        discreteNums.forEach(addSize);
        continue;
      }
    }
  }

  // 2. Alpha measurement rows: supports "XL সাইজ: চেস্ট 44 ইঞ্চি", "L সাইজ: বয়স 5 - 7 বছর | উচ্চতা 100 - 110 সেমি", "• M=29-31' inch"
  const measurementAlphaSizes: string[] = [];
  for (const line of lines) {
    const mRow = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(XS|S|M|L|XL|XXL|2XL|3XL|4XL|XXXL)\b(?:\s*(?:size|সাইজ|\([^)]{1,32}\)))?\s*[-–—:=|]+\s*[^\n]*\d+/i
    );
    if (mRow) {
      const tok = normalizeAlphaToken(mRow[1]);
      if (!measurementAlphaSizes.includes(tok)) measurementAlphaSizes.push(tok);
    }
  }
  if (measurementAlphaSizes.length >= 2) {
    measurementAlphaSizes.forEach(addSize);
  }

  // 3. Numeric garment/jubba/shoe rows (if >= 2 distinct 2-digit sizes)
  if (found.length === 0) {
    const numericRowSizes: string[] = [];
    for (const line of lines) {
      const numRow = line.match(
        /^(?:[^\w\u0980-\u09FF]*)(?:size\s*|সাইজ\s*)?(\d{2})\s*(?:[-–—:=|]+|\s+\|\s+)\s*[^\n]*\b\d{2}\b/i
      );
      if (numRow) {
        const n = parseInt(numRow[1], 10);
        if (n >= 20 && n <= 58) {
          const sNum = String(n);
          if (!numericRowSizes.includes(sNum)) numericRowSizes.push(sNum);
        }
      }
    }
    if (numericRowSizes.length >= 2) {
      numericRowSizes.forEach(addSize);
      if (found.every(f => /^\d{2}$/.test(f))) {
        found.sort((a, b) => parseInt(a, 10) - parseInt(b, 10));
      }
    }
  }

  if (found.length >= 2 && found.every(f => STANDARD_ALPHA_ORDER.includes(f))) {
    found.sort((a, b) => STANDARD_ALPHA_ORDER.indexOf(a) - STANDARD_ALPHA_ORDER.indexOf(b));
  }

  return found;
}

const KNOWN_COLOR_MAP: Array<{ pattern: RegExp; label: string }> = [
  { pattern: /\brose\s*gold\b|রোজ\s*গোল্ড/i, label: 'Rose Gold' },
  { pattern: /\bcoffee\s*\/\s*brown\b/i, label: 'Coffee/Brown' },
  { pattern: /\bash\s*\/\s*gr[ae]y\b|অ্যাশ\s*\/\s*গ্রে/i, label: 'Ash/Grey' },
  { pattern: /\bnavy\s*blue\b|নেভি\s*ব্লু|\bnavy\b/i, label: 'Navy Blue' },
  { pattern: /\bsky\s*blue\b|স্কাই\s*ব্লু|আকাশি/i, label: 'Sky Blue' },
  { pattern: /\broyal\s*blue\b|রয়্যাল\s*ব্লু/i, label: 'Royal Blue' },
  { pattern: /\bbottle\s*green\b|বটল\s*গ্রিন/i, label: 'Bottle Green' },
  { pattern: /\bsea\s*green\b|সি\s*গ্রিন/i, label: 'Sea Green' },
  { pattern: /\bteal(?:\s*green)?\b|টিল(?:\s*গ্রিন)?/i, label: 'Teal' },
  { pattern: /\bolive\s*green\b|\bolive\b|অলিভ|জলপাই/i, label: 'Olive' },
  { pattern: /\boff[\s-]*white\b|অফ[\s-]*হোয়াইট/i, label: 'Off-White' },
  { pattern: /\bmaroon\b|মেরুন|খয়েরি/i, label: 'Maroon' },
  { pattern: /\bmagenta\b|ম্যাজেন্টা/i, label: 'Magenta' },
  { pattern: /\bcoffee\b|কফি/i, label: 'Coffee' },
  { pattern: /\bchocolate\b|চকলেট/i, label: 'Chocolate' },
  { pattern: /\bmustard\b|মাস্টার্ড|সরিষা/i, label: 'Mustard' },
  { pattern: /\bbeige\b|বেইজ/i, label: 'Beige' },
  { pattern: /\bkhaki\b|খাকি/i, label: 'Khaki' },
  { pattern: /\bgolden\b|\bgold\b|গোল্ডেন|সোনালী/i, label: 'Golden' },
  { pattern: /\bsilver\b|সিলভার|রুপালি/i, label: 'Silver' },
  { pattern: /\blavender\b|ল্যাভেন্ডার/i, label: 'Lavender' },
  { pattern: /\bpurple\b|বেগুনি|পার্পল/i, label: 'Purple' },
  { pattern: /\bpink\b|গোলাপি|পিঙ্ক/i, label: 'Pink' },
  { pattern: /\byellow\b|হলুদ|ইয়েলো/i, label: 'Yellow' },
  { pattern: /\borange\b|কমলা|অরেঞ্জ/i, label: 'Orange' },
  { pattern: /\bred\b|লাল|রেড/i, label: 'Red' },
  { pattern: /\bgreen\b|সবুজ|গ্রিন/i, label: 'Green' },
  { pattern: /\bblue\b|\bblu\b|নীল|ব্লু/i, label: 'Blue' },
  { pattern: /\bbrown\b|বাদামী|ব্রাউন/i, label: 'Brown' },
  { pattern: /\bash\b|অ্যাশ/i, label: 'Ash' },
  { pattern: /\bgr[ae]y\b|গ্রে|ধূসর/i, label: 'Grey' },
  { pattern: /\bwhite\b|সাদা|হোয়াইট/i, label: 'White' },
  { pattern: /\bblack\b|কালো|ব্ল্যাক/i, label: 'Black' },
  { pattern: /\bcream\b|ক্রিম/i, label: 'Cream' },
];

export function extractRealColorsHomeLifestyle(
  detailsHtml: string,
  descText: string,
  title: string,
  targetCat: string,
  sub: string,
  subsub: string
): string[] {
  const s = `${sub} ${subsub}`.toLowerCase();

  // Never extract colors for fragrances/attars, personal care/cosmetics/oils, organic foods, or 3D bedsheets/curtains/wall-decor/hardware
  if (
    targetCat === 'foods' ||
    s.includes('ator') ||
    s.includes('fragrance') ||
    s.includes('organic-food') ||
    s.includes('personal-care') ||
    s.includes('mens-care') ||
    /\b(?:perfume|attar|atar|body\s*spray|deodorant|fragrance|fogg|আতর|পারফিউম|বডি\s*স্প্রে|shampoo|soap|cream|lotion|serum|face\s*wash|hair\s*oil|onion\s*oil|black\s*seed|green\s*tea|honey|ghee|masala|tooth|gel)\b/i.test(
      title
    )
  ) {
    return [];
  }

  // Random / Assorted / Multi-color items where customer cannot choose a color
  if (
    /\b(?:random\s*colou?r|assorted\s*colou?r|any\s*colou?r|multi[\s-]*colou?r|র‍্যান্ডম\s*কালার|মাল্টি[\s-]*কালার)\b/i.test(
      `${title} ${descText}`
    )
  ) {
    return [];
  }

  const cleanTitleForColor = title
    .replace(/\brose\s*gold\s*plated\b/gi, '')
    .replace(/\bgold[\s-]*plated\b/gi, '')
    .replace(/\bsilver[\s-]*plated\b/gi, '')
    .replace(/\bstainless\s*steel\b/gi, '')
    .replace(/\bgreen\s*tea\b/gi, '')
    .replace(/\bblack\s*seed\b/gi, '')
    .replace(/\bblack\s*head\b/gi, '')
    .replace(/\bwhite\s*head\b/gi, '')
    .replace(/\bblue\s*cut\b/gi, '')
    .replace(/\bblue\s*light\b/gi, '')
    .replace(/\bred\s*velvet\b/gi, '')
    .replace(/\bwhite\s*board\b/gi, '')
    .replace(/\bblack\s*board\b/gi, '');

  const matchColorsInSegment = (seg: string): string[] => {
    const res: string[] = [];
    for (const kc of KNOWN_COLOR_MAP) {
      if (kc.pattern.test(seg)) {
        if (kc.label === 'Golden' && res.some(x => x.includes('Gold'))) continue;
        if (res.some(existing => existing.toLowerCase() === kc.label.toLowerCase() || existing.toLowerCase().includes(kc.label.toLowerCase()))) {
          continue;
        }
        res.push(kc.label);
      }
    }
    return res;
  };

  // STEP 1: Check if the Title ITSELF explicitly pins this SKU to a specific color in parentheses "(Pink)", "(blu colore)", "(black brown color)" or trailing "- Black", "- Brown"
  const parenMatches = [...cleanTitleForColor.matchAll(/\(([^)]+)\)/g)];
  for (const pm of parenMatches) {
    const inside = pm[1].trim();
    if (/random|multi|assorted|led|pack|pcs|inch|cm|mm|ml|ft/i.test(inside)) continue;
    const pCols = matchColorsInSegment(inside);
    if (pCols.length === 1) {
      return pCols;
    }
    if (pCols.length === 2) {
      // e.g. "( black brown color )" -> single two-tone SKU
      return [`${pCols[0]} & ${pCols[1]}`];
    }
  }

  const trailingDashMatch = cleanTitleForColor.match(/[-–—]\s*([A-Za-z\s&/]{3,25})$/);
  if (trailingDashMatch) {
    const tCols = matchColorsInSegment(trailingDashMatch[1]);
    if (tCols.length === 1) {
      return tCols;
    }
    if (tCols.length === 2 && /&|and|\//i.test(trailingDashMatch[1])) {
      return [`${tCols[0]} & ${tCols[1]}`];
    }
  }

  // STEP 2: Check explicit "Available Colors / কালার / রঙ" line in description
  // Skip generic hardware/home-appliance/jewelry description lines unless they explicitly say "Available Color" / "কালার অপশন"
  const found: string[] = [];
  const addColor = (c: string) => {
    if (c === 'Golden' && found.some(x => x.includes('Gold'))) return;
    if (!found.some(existing => existing.toLowerCase() === c.toLowerCase() || existing.toLowerCase().includes(c.toLowerCase()))) {
      found.push(c);
    }
  };

  const lines = descText.split('\n').map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    if (
      /guarantee|longevity|fade|wash|দীর্ঘস্থায়ী|পাকা\s*রঙ|রঙ\s*উঠবে\s*না|রঙের\s*গ্যারান্টি|random|র‍্যান্ডম|assorted|led\s*light|লাইট|কন্ট্রাস্ট|contrast|dial|strap\s*material|case\s*material/i.test(
        line
      )
    ) {
      continue;
    }

    const explicitColorLine = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(?:available\s+colou?rs?|কালার\s*অপশন|colou?rs?|কালার|রঙ|রং)\s*[:ঃ=-]+\s*([^\n]+)/i
    );
    if (explicitColorLine) {
      const rhs = explicitColorLine[1].trim();
      if (/as\s+picture|as\s+shown|ছবির\s*মত|গ্যারান্টি|multi|মাল্টি|random|র‍্যান্ডম/i.test(rhs)) continue;
      // If a single item has "Rose Gold & White" or "Silver & Gold" with "&" / "উইথ" (two-tone design, not comma-separated options)
      const cList = matchColorsInSegment(rhs);
      if (cList.length === 2 && !/[,/|]|অথবা|\bor\b/i.test(rhs) && /&|and|উইথ|with/i.test(rhs)) {
        addColor(`${cList[0]} & ${cList[1]}`);
      } else {
        cList.forEach(addColor);
      }
    }
  }
  if (found.length > 0) return found;

  // STEP 3: Scan Title for single-SKU color (Watches, Bags, Sunglasses, Raincoats, Umbrellas, Bottles, Tupi/Jainamaj, Apparel)
  const allowTitleColorScan =
    targetCat === 'watches' ||
    s.includes('bag') ||
    s.includes('sunglass') ||
    s.includes('rain-item') ||
    s.includes('islamic-corner') ||
    s.includes('bottle-mug-cup') ||
    ['mens-fashion', 'womens-fashion', 'winter'].includes(targetCat);

  if (allowTitleColorScan) {
    const titleCols = matchColorsInSegment(cleanTitleForColor);
    if (titleCols.length === 1) {
      return titleCols;
    }
    if (titleCols.length >= 2) {
      // Two-tone watch/sunglass/bag title (e.g. "Rose Gold & White Ceramic Watch", "White frame Black lense Sunglasses") -> combine as 1 SKU color so buyer isn't forced to choose between frame & lens!
      return [`${titleCols[0]} & ${titleCols[1]}`];
    }
  }

  return [];
}

export function mapHomeLifestyleSubcategory(sub: string, subsub: string, title: string, existingSub?: string): string {
  const s = `${sub} ${subsub}`.toLowerCase();
  const t = title.toLowerCase();

  if (s.includes('rain-item') || /\b(?:raincoat|rain\s*coat|rain\s*suit|rain\s*card|umbrella|রেইনকোট|ছাতা)\b/i.test(t)) {
    return 'ছাতা ও রেইন গিয়ার (Rain Gear)';
  }
  if (
    s.includes('bed-sheet') ||
    s.includes('curtain') ||
    /\b(?:bed\s*sheet|bed\s*cover|pillow|cushion|curtain|comforter|mosquito\s*net|বেডশিট|বিছানার\s*চাদর|পর্দা|বালিশ|মশারি)\b/i.test(t)
  ) {
    return 'বেডশিট, পর্দা ও বেডিং (Bedding & Curtains)';
  }
  if (
    s.includes('bag') ||
    /\b(?:bag|backpack|handbag|tote|purse|luggage|suitcase|travel\s*bag|school\s*bag|waist\s*bag|chest\s*bag|ব্যাগ|ব্যাকপ্যাক|লাগেজ)\b/i.test(t)
  ) {
    return 'ব্যাগ ও ট্রাভেল গিয়ার (Bags & Travel)';
  }
  if (
    s.includes('kitchen') ||
    s.includes('bottle-mug-cup') ||
    s.includes('3d-design-mug') ||
    s.includes('table-cloth') ||
    /\b(?:kitchen|cook|kettle|grinder|blender|chopper|peeler|knife|pan|pot|plate|bowl|tray|mug|cup|bottle|flask|thermos|table\s*cloth|কিচেন|রান্না|কেতলি|গ্রাইন্ডার|ব্লেন্ডার|মগ|বোতল|ফ্লাস্ক|টেবিল\s*ক্লথ)\b/i.test(
      t
    )
  ) {
    return 'কিচেন ও ডাইনিং (Kitchen & Dining)';
  }
  if (
    s.includes('islamic-corner') ||
    /\b(?:jainamaj|prayer\s*mat|tupi|jubba|thobe|tasbih|rehal|attar|atar|zamzam|miswak|জায়নামাজ|জায়নামাজ|টুপি|জুব্বা|তসবিহ|রেহাল|আতর)\b/i.test(
      t
    )
  ) {
    return 'ইসলামিক কর্নার (Islamic Corner)';
  }
  if (s.includes('sunglass') || /\b(?:sunglass|eyeglasses?|glasses|goggles|সানগ্লাস|চশমা)\b/i.test(t)) {
    return 'সানগ্লাস ও চশমা (Sunglasses)';
  }
  if (
    /\b(?:rack|organizer|storage|shelf|hanger|wardrobe|box|holder|ড্রয়ার|অর্গানাইজার|র্যাক|হ্যাঙ্গার)\b/i.test(t)
  ) {
    return 'অর্গানাইজার ও স্টোরেজ (Storage & Organizers)';
  }
  if (
    /\b(?:mop|brush|cleaner|cleaning|wiper|broom|bathroom|soap\s*dispenser|toilet|মপ|ব্রাশ|ক্লিনিং|বাথরুম)\b/i.test(t)
  ) {
    return 'ক্লিনিং ও বাথরুম এক্সেসরিজ (Cleaning & Bath)';
  }
  if (
    s.includes('wall-decor') ||
    s.includes('home-appliance') ||
    /\b(?:decor|wall|sticker|frame|vase|flower|lamp|light|mat|carpet|rug|ইন্টেরিয়র|ডেকোর|ওয়াল)\b/i.test(t)
  ) {
    return 'হোম ডেকোর ও ইন্টেরিয়র (Home Decor)';
  }
  if (
    s.includes('health-beauty') ||
    /\b(?:exercise|fitness|gym|posture|massager|support\s*belt|sweat\s*slim|slim\s*belt|personal\s*care|হেলথ|ফিটনেস|ম্যাসাজার)\b/i.test(t)
  ) {
    return 'ডেইলি লাইফস্টাইল ও হেলথ (Lifestyle & Wellness)';
  }
  if (existingSub && !/হুডি|জ্যাকেট|পাঞ্জাবি|শার্ট/i.test(existingSub)) {
    return existingSub;
  }
  return 'হোম ও লাইফস্টাইল স্পেশাল (Home & Lifestyle)';
}

export function mapWatchesSubcategory(sub: string, subsub: string, title: string, existingSub?: string): string {
  const s = `${sub} ${subsub}`.toLowerCase();
  const t = title.toLowerCase();

  if (s.includes('couple-watch') || /\bcouple\b|কাপল/i.test(t)) {
    return 'কাপল ঘড়ি (Couple Watches)';
  }
  if (s.includes('smart-watch') || /\bsmart\s*watch|স্মার্ট\s*ওয়াচ|স্মার্টওয়াচ/i.test(t)) {
    return 'স্মার্টওয়াচ (Smartwatches)';
  }
  if (s.includes('kids-watch') || /\bkids?\s*watch|baby\s*watch|বাচ্চাদের\s*ঘড়ি/i.test(t)) {
    return 'কিডস ও স্মার্টওয়াচ (Kids & Smartwatches)';
  }
  if (s.includes('ladies-watch') || /\b(?:ladies|women'?s?|female|girl'?s?)\b.*watch|লেডিস\s*ঘড়ি/i.test(t)) {
    return 'লেডিস ঘড়ি (Ladies Watches)';
  }
  if (/\bcombo\b|কম্বো/i.test(t)) {
    return 'ঘড়ি কম্বো সেট (Watch Combos)';
  }
  if (/\bdigital\b|ডিজিটাল|led\s*watch/i.test(t)) {
    return 'ডিজিটাল ঘড়ি (Digital Watches)';
  }
  if (/\btable\s*clock|wall\s*clock|alarm\s*clock|টেবিল\s*ঘড়ি|দেয়াল\s*ঘড়ি/i.test(t) || s.includes('table-clock')) {
    return 'ঘড়ি ও স্মার্টওয়াচ (Watches)';
  }
  if (existingSub && existingSub.includes('ঘড়ি')) {
    return existingSub;
  }
  return 'অ্যানালগ ও লাক্সারি ঘড়ি (Luxury Watches)';
}

function mapReassignedSubcategory(targetCat: string, sub: string, subsub: string, title: string, existingSub?: string): string | undefined {
  const t = title.toLowerCase();
  if (targetCat === 'mens-fashion') {
    if (/\bpolo\b/i.test(t) || subsub.includes('polo')) return 'পোলো টি-শার্ট (Polo T-Shirt)';
    if (/\bpanjabi|punjabi\b/i.test(t)) return 'পাঞ্জাবি (Panjabi)';
    if (/\bt-?shirts?\b/i.test(t)) return 'টি-শার্ট (T-Shirt)';
    if (/\bshirts?\b/i.test(t)) return 'শার্ট (Casual & Formal Shirt)';
    return "মেনস কালেকশন (Men's Special)";
  }
  if (targetCat === 'womens-fashion') {
    if (/\bsaree|sharee\b|শাড়ি|শাড়ি/i.test(t)) return 'শাড়ি (Saree)';
    if (/\bborka|burqa|abaya|hijab|khimar\b|বোরকা|আবায়া/i.test(t)) return 'বোরকা ও আবায়া (Borka & Abaya)';
    return 'সালোয়ার কামিজ ও থ্রি-পিস (Salwar Kameez)';
  }
  if (targetCat === 'jewelry') {
    if (/\bearring|jhumka\b|কানের\s*দুল|ঝুমকা/i.test(t) || subsub.includes('earring')) return 'কানের দুল ও ঝুমকা (Earrings)';
    if (/\bbangle|bracelet\b|চুড়ি|ব্রেসলেট/i.test(t)) return 'চুড়ি ও ব্রেসলেট (Bangles & Bracelets)';
    return 'নেকলেস সেট (Necklace Set)';
  }
  if (targetCat === 'kids-zone') {
    if (/\bgame|toy|car|পুতুল|খেলনা\b/i.test(t) || sub.includes('toys')) return 'খেলনা ও লার্নিং টয় (Toys & Learning)';
    return 'বাচ্চাদের পোশাক (Kids Clothing)';
  }
  if (targetCat === 'foods') {
    return 'খাঁটি মধু, ঘি ও অর্গানিক ফুডস (Organic Foods)';
  }
  if (targetCat === 'gadgets-electronics') {
    return 'স্মার্ট গ্যাজেট ও ইলেকট্রনিক্স (Smart Gadgets)';
  }
  return existingSub;
}

interface DiscoveredCard {
  slug: string;
  sub: string;
  subsub: string;
  cardTitle: string;
  thumbImg: string;
  hoverImg: string;
}

async function discoverLiveHomeLifestyleProducts(): Promise<Map<string, DiscoveredCard>> {
  console.log('1. Discovering all live /home-lifestyle products on https://www.dropshipping.com.bd/home-lifestyle ...');
  const mainRes = await fetch('https://www.dropshipping.com.bd/home-lifestyle');
  const cookies = mainRes.headers.getSetCookie
    ? mainRes.headers.getSetCookie().map((c: string) => c.split(';')[0]).join('; ')
    : mainRes.headers.get('set-cookie') || '';
  const mainHtml = await mainRes.text();
  const csrf = (mainHtml.match(/name="csrf-token"\s+content="([^"]+)"/) || [])[1] || '';

  const links = Array.from(
    new Set([
      'https://www.dropshipping.com.bd/home-lifestyle',
      ...[...mainHtml.matchAll(/href="(https?:\/\/(?:www\.)?dropshipping\.com\.bd\/home-lifestyle[^"]*)"/g)].map(
        m => m[1]
      ),
    ])
  );
  console.log(`   Found ${links.length} /home-lifestyle category & subcategory URLs.`);

  const slugMap = new Map<string, DiscoveredCard>();
  const parseCards = (htmlChunk: string, sub: string, subsub: string) => {
    const slugLinks = [
      ...htmlChunk.matchAll(/href="(?:https?:\/\/(?:www\.)?dropshipping\.com\.bd)?\/product\/([^"/?#]+)"/gi),
    ];
    for (const sl of slugLinks) {
      const slug = sl[1].trim();
      if (!slug) continue;
      const idx = sl.index || 0;
      const windowHtml = htmlChunk.slice(Math.max(0, idx - 600), Math.min(htmlChunk.length, idx + 900));
      const imgs = [...windowHtml.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/gi)]
        .map(m => normalizeImageUrl(m[1]))
        .filter(u => u.includes('/storage/images/products/'));
      const nameMatch = windowHtml.match(/class="product_name_link"[^>]*>([\s\S]*?)<\/a>/i);
      const cardTitle = nameMatch ? cleanSingleLine(nameMatch[1]) : '';
      const existing = slugMap.get(slug);
      if (!existing || (subsub && !existing.subsub) || (sub && !existing.sub)) {
        slugMap.set(slug, {
          slug,
          sub: sub || existing?.sub || '',
          subsub: subsub || existing?.subsub || '',
          cardTitle: cardTitle || existing?.cardTitle || '',
          thumbImg: imgs[0] || existing?.thumbImg || '',
          hoverImg: imgs[1] || existing?.hoverImg || '',
        });
      }
    }
  };

  for (const url of links) {
    const parts = url.replace(/^https?:\/\/(?:www\.)?dropshipping\.com\.bd\//, '').split('/');
    const cat = parts[0] || 'home-lifestyle';
    const sub = parts[1] || '';
    const subsub = parts[2] || '';

    try {
      const pr = await fetch(url, { headers: { Cookie: cookies } });
      parseCards(await pr.text(), sub, subsub);
    } catch (_) {}

    for (let page = 1; page <= 55; page++) {
      try {
        const r = await fetch('https://www.dropshipping.com.bd/load-more-data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-CSRF-TOKEN': csrf,
            'X-Requested-With': 'XMLHttpRequest',
            Cookie: cookies,
          },
          body: new URLSearchParams({
            page: String(page),
            limit: '20',
            category_slug: cat,
            subcategory_slug: sub,
            sub_subcategory_slug: subsub,
          }).toString(),
        });
        if (!r.ok) break;
        const j = await r.json();
        if (!j?.data || !j?.product_length) break;
        parseCards(j.data, sub, subsub);
        if (j.product_length < 20) break;
      } catch (_) {
        break;
      }
    }
  }

  console.log(`   Discovered ${slugMap.size} live /home-lifestyle products.`);
  return slugMap;
}

interface ScrapedPageInfo {
  slug: string;
  liveTitle: string;
  liveCategorySlug: string;
  liveSubSlug: string;
  liveSubSubSlug: string;
  wholesalePrice: number;
  sku: string;
  galleryImages: string[];
  detailsBlock: string;
  descriptionFormatted: string;
  specs: string[];
  notFound?: boolean;
}

async function fetchProductPageInfo(slug: string): Promise<ScrapedPageInfo> {
  const url = `https://www.dropshipping.com.bd/product/${slug}`;
  let html = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      if (res.status === 404 || res.status === 500) {
        return {
          slug,
          liveTitle: '',
          liveCategorySlug: '',
          liveSubSlug: '',
          liveSubSubSlug: '',
          wholesalePrice: 0,
          sku: '',
          galleryImages: [],
          detailsBlock: '',
          descriptionFormatted: '',
          specs: [],
          notFound: true,
        };
      }
      if (res.ok) {
        html = await res.text();
        break;
      }
    } catch (_) {
      await new Promise(r => setTimeout(r, 350 * attempt));
    }
  }

  if (!html) {
    return {
      slug,
      liveTitle: '',
      liveCategorySlug: '',
      liveSubSlug: '',
      liveSubSubSlug: '',
      wholesalePrice: 0,
      sku: '',
      galleryImages: [],
      detailsBlock: '',
      descriptionFormatted: '',
      specs: [],
      notFound: true,
    };
  }

  const h2Raw = (html.match(/<div class="single_product_name"[^>]*>[\s\S]*?<h2[^>]*>([\s\S]*?)<\/h2>/i) || [])[1] || '';
  const liveTitle = cleanSingleLine(h2Raw);

  const detailsBlock = (html.match(/<div class="single_product_details">([\s\S]{0,6000})/i) || [])[1] || '';
  const bcLinks = [
    ...detailsBlock.matchAll(/href="https?:\/\/(?:www\.)?dropshipping\.com\.bd\/([a-z0-9-]+(?:\/[a-z0-9-]+)*)"/gi),
  ].map(m => m[1].toLowerCase());
  const deepest = bcLinks[bcLinks.length - 1] || '';
  const bcParts = deepest.split('/').filter(Boolean);
  const liveCategorySlug = bcParts[0] || '';
  const liveSubSlug = bcParts[1] || '';
  const liveSubSubSlug = bcParts[2] || '';

  const priceMeta = (html.match(/property="product:price:amount"\s+content="([^"]+)"/i) || [])[1] || '0';
  const wholesalePrice = Math.round(parseFloat(priceMeta.replace(/,/g, '')) || 0);

  const codeMatch =
    detailsBlock.match(/Code\s*:\s*<\/strong>\s*<span>([^<]+)<\/span>/i) || html.match(/Code:\s*(\d+)/i);
  const sku = codeMatch ? `DSP-${codeMatch[1].trim()}` : '';

  const zoomBlockMatch = html.match(
    /<div class="zoom_img_active[^"]*">([\s\S]*?)<\/div>\s*(?:<div class="zoom_thumb|<\/div>\s*<\/div>)/i
  );
  const zoomHtml = zoomBlockMatch ? zoomBlockMatch[1] : '';
  const galleryImages = Array.from(
    new Set(
      [...zoomHtml.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/gi)]
        .map(m => normalizeImageUrl(m[1]))
        .filter(u => u && u.includes('/storage/images/products/'))
    )
  );

  const homeTabHtml =
    (html.match(/<div class="single_product_tab_content">([\s\S]*?)<div class="tab-pane fade" id="profile"/i) || [])[1] ||
    '';
  const { fullText: descriptionFormatted, bulletSpecs } = htmlToFormattedText(homeTabHtml);

  return {
    slug,
    liveTitle,
    liveCategorySlug,
    liveSubSlug,
    liveSubSubSlug,
    wholesalePrice,
    sku,
    galleryImages,
    detailsBlock,
    descriptionFormatted,
    specs: bulletSpecs,
  };
}

async function main() {
  const productsPath = path.resolve(process.cwd(), 'src/data/products.json');
  const allProducts: Product[] = JSON.parse(fs.readFileSync(productsPath, 'utf8'));

  let liveMap: Map<string, DiscoveredCard>;
  let scrapedMap: Map<string, ScrapedPageInfo>;

  if (!REFRESH_CACHE && fs.existsSync(CACHE_PATH)) {
    console.log(`Loading cached scrape data from ${CACHE_PATH} ...`);
    const cached = JSON.parse(fs.readFileSync(CACHE_PATH, 'utf8'));
    liveMap = new Map(cached.liveEntries);
    scrapedMap = new Map(cached.scrapedEntries);
    console.log(`Loaded ${liveMap.size} live cards and ${scrapedMap.size} scraped product pages from cache.`);
  } else {
    liveMap = await discoverLiveHomeLifestyleProducts();
    const existingTarget = allProducts.filter(p => p.category === 'home-lifestyle' || p.category === 'watches');
    const slugsToFetch = new Set<string>();
    for (const s of liveMap.keys()) slugsToFetch.add(s);
    for (const p of existingTarget) {
      if (p.id.startsWith('dsp-')) slugsToFetch.add(p.id.replace(/^dsp-/, ''));
    }

    const slugList = Array.from(slugsToFetch);
    console.log(`2. Scraping ${slugList.length} product detail pages (concurrency=24)...`);

    scrapedMap = new Map<string, ScrapedPageInfo>();
    let cursor = 0;
    const concurrency = 24;
    const workers = Array.from({ length: concurrency }, async () => {
      while (cursor < slugList.length) {
        const idx = cursor++;
        const slug = slugList[idx];
        const info = await fetchProductPageInfo(slug);
        scrapedMap.set(slug, info);
        if ((idx + 1) % 100 === 0 || idx + 1 === slugList.length) {
          console.log(`   Scraped ${idx + 1}/${slugList.length}...`);
        }
      }
    });
    await Promise.all(workers);

    fs.writeFileSync(
      CACHE_PATH,
      JSON.stringify({
        liveEntries: Array.from(liveMap.entries()),
        scrapedEntries: Array.from(scrapedMap.entries()),
      }),
      'utf8'
    );
    console.log(`   Cached scraped data to ${CACHE_PATH}`);
  }

  if (SCRAPE_ONLY) {
    console.log('[SCRAPE ONLY] Finished caching /home-lifestyle pages.');
    process.exit(0);
  }

  const byId = new Map<string, Product>();
  for (const p of allProducts) byId.set(p.id, p);

  const slugList = Array.from(scrapedMap.keys());
  const updatedProductsToSync: Product[] = [];
  const sizedItemsAudit: Array<{ id: string; cat: string; subcat: string; title: string; size: string; color?: string }> = [];
  const reassignedOut: Array<{ id: string; oldCat?: string; newCat: string; title: string; bc: string }> = [];
  const sizeDistribution: Record<string, number> = {};
  const colorDistribution: Record<string, number> = {};

  let homeTotal = 0;
  let homeWithSize = 0;
  let homeWithColor = 0;
  let watchesTotal = 0;
  let watchesWithColor = 0;
  let fixedCorruptTitles = 0;

  for (const slug of slugList) {
    const id = `dsp-${slug}`;
    const existing = byId.get(id);
    const liveCard = liveMap.get(slug);
    const info = scrapedMap.get(slug);
    if (!info || info.notFound || !info.liveTitle) continue;

    // Protect already-curated winter and mens-fashion items unless they are explicitly under /home-lifestyle on live!
    if (
      (existing?.category === 'winter' && info.liveCategorySlug === 'winter') ||
      (existing?.category === 'mens-fashion' && info.liveCategorySlug === 'mens-fashion')
    ) {
      continue;
    }

    const effSub = info.liveSubSlug || liveCard?.sub || '';
    const effSubSub = info.liveSubSubSlug || liveCard?.subsub || '';

    // Explicit Home & Lifestyle household/bag/umbrella items (even if an old overwritten slug had mens-fashion breadcrumb, e.g. Umbrella 4585 or Waist Bag 5080)
    const isExplicitHouseholdOrBag =
      /\b(?:umbrella|ছাতা|vacuum\s*flask|water\s*bottle|bed\s*sheet|waist\s*bag|chest\s*bag|shoulder\s*bag|crossbody|backpack|handbag|messenger\s*bag|belt\s*bag)\b/i.test(
        info.liveTitle
      ) && !/\braincoat|rain\s*coat\b/i.test(info.liveTitle);

    // 1. Standing rule: Watches & Clocks always belong to 'watches'
    const isWatch = isWatchProductTitle(info.liveTitle, info.liveTitle) || effSub === 'watches';

    // 2. Jewelry (check BEFORE womens-fashion so womens-fashion/jewellery/necklace goes to 'jewelry'!)
    const isLadiesJewelry =
      info.liveCategorySlug === 'jewellery' ||
      info.liveCategorySlug === 'jewelry' ||
      effSub === 'jewellery' ||
      effSub === 'jewelry' ||
      /\b(?:earrings?|jhumka|anklet|payel|nose\s*pin|tiara|mangalsutra|bridal.*jewelry|necklace\s+set|crystal\s+jewelry|bangles?)\b|কানের\s*দুল|ঝুমকা|পায়েল|নাকফুল|চুড়ি|মালা\s*সেট/i.test(
        info.liveTitle
      );

    // 3. Foods
    const isFoods =
      info.liveCategorySlug === 'food' ||
      info.liveCategorySlug === 'foods' ||
      effSubSub === 'organic-food' ||
      /\b(?:pure\s*honey|sundarban\s*honey|mustard\s*oil|desi\s*ghee|medjool|ajwa|mariyam\s*dates|chia\s*seeds?)\b|খাঁটি\s*মধু|গাওয়া\s*ঘি/i.test(
        info.liveTitle
      );

    // 4. Kids Zone (check BEFORE mens-fashion so kids-zone/children-clothing goes to 'kids-zone'!)
    const isKidsZone =
      info.liveCategorySlug === 'kids-zone' ||
      (/\b(?:baby\s*bouncer|baby\s*walker|baby\s*stroller|baby\s*feeder|diaper|robot\s*car|sup\s*game\s*box)\b|খেলনা|ফিডার|ডায়াপার/i.test(
        info.liveTitle
      ) &&
        info.liveCategorySlug !== 'home-lifestyle');

    // 5. Women's Apparel (guard against "3-Piece Stainless Steel Vacuum Flask Set"!)
    const isWomenApparel =
      !isExplicitHouseholdOrBag &&
      info.liveCategorySlug !== 'home-lifestyle' &&
      (info.liveCategorySlug === 'womens-fashion' ||
        /\b(?:saree|sharee|three[\s-]*piece|salwar|kameez|kurti|borka|burqa|abaya|lehenga|gown)\b|শাড়ি|শাড়ি|থ্রি[\s-]*পিস|সালোয়ার|কামিজ|কুর্তি|বোরকা|আবায়া/i.test(
          info.liveTitle
        ));

    // 6. Winter Apparel
    const isWinterApparel =
      info.liveCategorySlug === 'winter' ||
      (/\b(?:hoodie|sweatshirt|winter\s+jacket|winter\s+set|sherpa|balaclava)\b|হুডি|সোয়েটশার্ট/i.test(info.liveTitle) &&
        info.liveCategorySlug !== 'home-lifestyle');

    // 7. Men's Apparel
    const isMensApparel =
      !isExplicitHouseholdOrBag &&
      (info.liveCategorySlug === 'mens-fashion' ||
        (/\b(?:panjabi|punjabi|t-?shirt|polo\s+shirt|casual\s+shirt|formal\s+shirt|check.*shirt|jeans\s+pant|gabardine\s+pant)\b/i.test(
          info.liveTitle
        ) &&
          effSub !== 'islamic-corner' &&
          info.liveCategorySlug !== 'home-lifestyle'));

    // 8. Gadgets & Electronics
    const isGadgets =
      info.liveCategorySlug === 'gadgets' ||
      info.liveCategorySlug === 'electronics' ||
      info.liveCategorySlug === 'gadgets-electronics' ||
      (/\b(?:earbuds?|airpods?|headphone|neckband|power\s*bank|charger|speaker|microphone|router|ip\s*camera|cctv|trimmer|shaver|clipper)\b/i.test(
        info.liveTitle
      ) &&
        info.liveCategorySlug !== 'home-lifestyle');

    let targetCat: Product['category'] = 'home-lifestyle';
    if (isWatch) targetCat = 'watches';
    else if (isLadiesJewelry) targetCat = 'jewelry';
    else if (isFoods) targetCat = 'foods';
    else if (isKidsZone) targetCat = 'kids-zone';
    else if (isWomenApparel) targetCat = 'womens-fashion';
    else if (isWinterApparel) targetCat = 'winter';
    else if (isMensApparel) targetCat = 'mens-fashion';
    else if (isGadgets) targetCat = 'gadgets-electronics';
    else if (!isExplicitHouseholdOrBag && info.liveCategorySlug && info.liveCategorySlug !== 'home-lifestyle' && !liveMap.has(slug)) {
      targetCat = 'others';
    }

    // Do not overwrite already-curated winter or mens-fashion items if they already reside there
    if ((targetCat === 'winter' && existing?.category === 'winter') || (targetCat === 'mens-fashion' && existing?.category === 'mens-fashion')) {
      continue;
    }

    if (existing && existing.category !== targetCat) {
      reassignedOut.push({
        id,
        oldCat: existing.category,
        newCat: targetCat,
        title: info.liveTitle,
        bc: `${info.liveCategorySlug}/${effSub}/${effSubSub}`,
      });
    }

    const retailPrice = info.wholesalePrice > 0 ? info.wholesalePrice + 100 : existing?.price || 490;
    const titleChanged = existing && existing.titleEn.trim() !== info.liveTitle.trim();
    if (titleChanged) fixedCorruptTitles++;

    const subcat =
      targetCat === 'home-lifestyle'
        ? mapHomeLifestyleSubcategory(effSub, effSubSub, info.liveTitle, existing?.subcategory)
        : targetCat === 'watches'
        ? mapWatchesSubcategory(effSub, effSubSub, info.liveTitle, existing?.subcategory)
        : mapReassignedSubcategory(targetCat, effSub, effSubSub, info.liveTitle, existing?.subcategory);

    const finalSizes = extractRealSizesHomeLifestyle(
      info.detailsBlock,
      info.descriptionFormatted,
      info.liveTitle,
      targetCat,
      effSub,
      effSubSub
    );
    const finalColors = extractRealColorsHomeLifestyle(
      info.detailsBlock,
      info.descriptionFormatted,
      info.liveTitle,
      targetCat,
      effSub,
      effSubSub
    );

    if (targetCat === 'home-lifestyle') {
      homeTotal++;
      if (finalSizes.length > 0) homeWithSize++;
      if (finalColors.length > 0) homeWithColor++;
    } else if (targetCat === 'watches') {
      watchesTotal++;
      if (finalColors.length > 0) watchesWithColor++;
    }

    if (finalSizes.length > 0) {
      const sKey = finalSizes.join(', ');
      sizeDistribution[sKey] = (sizeDistribution[sKey] || 0) + 1;
      sizedItemsAudit.push({
        id,
        cat: targetCat,
        subcat: subcat || '',
        title: info.liveTitle,
        size: sKey,
        color: finalColors.join(', ') || undefined,
      });
    }
    if (finalColors.length > 0) {
      const cKey = finalColors.join(', ');
      colorDistribution[cKey] = (colorDistribution[cKey] || 0) + 1;
    }

    const effectivePrice = !existing || titleChanged ? retailPrice : existing.price;
    const variants: ProductVariant[] = [];
    if (finalSizes.length > 0 && finalColors.length > 0) {
      for (const sz of finalSizes) {
        for (const cl of finalColors) {
          variants.push({ size: sz, color: cl, price: effectivePrice, stock: 50 });
        }
      }
    } else if (finalSizes.length > 0) {
      for (const sz of finalSizes) {
        variants.push({ size: sz, price: effectivePrice, stock: 50 });
      }
    } else if (finalColors.length > 0) {
      for (const cl of finalColors) {
        variants.push({ color: cl, price: effectivePrice, stock: 50 });
      }
    }

    const primaryImg = info.galleryImages[0] || liveCard?.thumbImg || existing?.image || '';
    const extraImgs = Array.from(
      new Set([
        ...(info.galleryImages.length > 0 ? info.galleryImages : []),
        ...(liveCard?.thumbImg ? [liveCard.thumbImg] : []),
        ...(liveCard?.hoverImg ? [liveCard.hoverImg] : []),
      ])
    ).filter(Boolean);

    const cleanDesc = info.descriptionFormatted || existing?.descriptionBn || `${info.liveTitle}`;

    const updatedProduct: Product = {
      ...(existing || {
        id,
        rating: 4.8,
        reviewsCount: 14,
        stock: 50,
        status: 'active',
        isFeatured: false,
        freeDelivery: false,
        createdAt: new Date().toISOString(),
      }),
      id,
      titleBn: info.liveTitle,
      titleEn: info.liveTitle,
      category: targetCat,
      ...(subcat ? { subcategory: subcat } : {}),
      price: effectivePrice,
      originalPrice: !existing || titleChanged ? Math.round(effectivePrice * 1.2) : existing.originalPrice,
      discountPercent: !existing || titleChanged ? 17 : existing.discountPercent,
      sku: info.sku || existing?.sku || `DSP-${slug.split('-').pop()}`,
      image: primaryImg,
      additionalImages: extraImgs.length > 0 ? extraImgs : existing?.additionalImages,
      descriptionBn: cleanDesc,
      descriptionEn: cleanDesc,
      specificationsBn: info.specs.length > 0 ? info.specs : existing?.specificationsBn,
      specificationsEn: info.specs.length > 0 ? info.specs : existing?.specificationsEn,
      size: finalSizes.length > 0 ? finalSizes.join(', ') : undefined,
      color: finalColors.length > 0 ? finalColors.join(', ') : undefined,
      variants: variants.length > 0 ? variants : undefined,
      updatedAt: new Date().toISOString(),
    };

    if (!subcat) delete updatedProduct.subcategory;
    if (!updatedProduct.size) delete updatedProduct.size;
    if (!updatedProduct.color) delete updatedProduct.color;
    if (!updatedProduct.variants) delete updatedProduct.variants;

    byId.set(id, updatedProduct);
    updatedProductsToSync.push(updatedProduct);
  }

  fs.writeFileSync(
    '/tmp/home_lifestyle_audit.json',
    JSON.stringify({ sizedItemsAudit, reassignedOut }, null, 2),
    'utf8'
  );

  console.log('\n=== HOME & LIFESTYLE (+ WATCHES) VARIANT EXTRACTION SUMMARY ===');
  console.log({
    totalProcessed: updatedProductsToSync.length,
    homeTotal,
    homeWithSize,
    homeWithColor,
    watchesTotal,
    watchesWithColor,
    fixedCorruptTitles,
    reassignedOutCount: reassignedOut.length,
  });

  console.log('\nSized Items Breakdown:', Object.entries(sizeDistribution).sort((a, b) => b[1] - a[1]));
  console.log('\nTop Color Combinations:', Object.entries(colorDistribution).sort((a, b) => b[1] - a[1]).slice(0, 25));

  if (DRY_RUN) {
    console.log('\n[DRY RUN] Wrote /tmp/home_lifestyle_audit.json. Skipping file write and Firestore sync.');
    process.exit(0);
  }

  const finalProducts = Array.from(byId.values());
  fs.writeFileSync(productsPath, JSON.stringify(finalProducts, null, 2), 'utf8');
  console.log(`\n3. Saved ${finalProducts.length} products to src/data/products.json.`);

  console.log(`4. Syncing ${updatedProductsToSync.length} updated products to Firebase Firestore...`);
  await bulkSyncProductsToFirestore(updatedProductsToSync);

  const counts: Record<string, number> = {};
  for (const p of finalProducts) {
    const c = String(p.category || 'others');
    counts[c] = (counts[c] || 0) + 1;
  }
  for (const cat of initialCategories) {
    const newCount = cat.id === 'all' ? finalProducts.length : counts[cat.id] || 0;
    await saveCategoryToFirestore({
      ...cat,
      itemCount: newCount,
    });
  }
  console.log('5. Category counts updated in Firestore:', counts);
  process.exit(0);
}

if (process.argv[1]?.includes('fix_home_lifestyle_variants')) {
  main().catch(err => {
    console.error('Fatal error in fix_home_lifestyle_variants:', err);
    process.exit(1);
  });
}
