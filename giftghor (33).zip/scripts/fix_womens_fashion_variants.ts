import fs from 'fs';
import path from 'path';
import { isWatchProductTitle } from '../src/utils/categoryUtils';
import {
  bulkSyncProductsToFirestore,
  saveCategoryToFirestore,
} from '../src/lib/firebase';
import { initialCategories } from '../src/data/initialData';
import { Product, ProductVariant } from '../src/types';

const DRY_RUN = process.argv.includes('--dry-run');
const SCRAPE_ONLY = process.argv.includes('--scrape-only');
const REFRESH_CACHE = process.argv.includes('--refresh');
const CACHE_PATH = '/tmp/womens_fashion_scraped_cache.json';

function toAsciiDigits(str: string): string {
  return str.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
}

function decodeEntities(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFKC')
    .replace(/Â°/g, '°')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#038;/g, '&')
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8217;/g, "'")
    .replace(/&#8216;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#2547;/g, '৳')
    .replace(/&nbsp;/g, ' ');
}

function cleanSingleLine(html: string): string {
  return decodeEntities(html)
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function htmlToFormattedText(html: string): { fullText: string; bulletSpecs: string[] } {
  if (!html) return { fullText: '', bulletSpecs: [] };

  const bulletSpecs: string[] = [];
  const liRegex = /<li[^>]*>([\s\S]*?)<\/li>/gi;
  let m: RegExpExecArray | null;
  while ((m = liRegex.exec(html)) !== null) {
    const item = cleanSingleLine(m[1]);
    if (item && item.length > 2 && item.length <= 180) {
      bulletSpecs.push(item);
    }
  }

  const trRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  while ((m = trRegex.exec(html)) !== null) {
    const cells = [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
      .map(c => cleanSingleLine(c[1]))
      .filter(Boolean);
    if (cells.length >= 2) {
      const rowText = cells.join(' | ');
      if (rowText.length <= 180) bulletSpecs.push(rowText);
    }
  }

  const formatted = decodeEntities(
    html
      .replace(/<\/t[dh]>\s*<t[dh][^>]*>/gi, ' | ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<li[^>]*>/gi, '\n• ')
      .replace(/<\/(?:p|div|li|tr|h[1-6]|ul|ol|table)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .split('\n')
    .map(line => line.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean)
    .join('\n');

  return { fullText: formatted, bulletSpecs: Array.from(new Set(bulletSpecs)).slice(0, 14) };
}

function normalizeImageUrl(url: string): string {
  if (!url) return '';
  return url
    .trim()
    .replace('public//storage/', 'public/storage/')
    .replace(/^http:\/\//i, 'https://');
}

const STANDARD_ALPHA_ORDER = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL'];

function normalizeAlphaToken(tok: string): string {
  const u = tok.toUpperCase();
  if (u === '2XL') return 'XXL';
  if (u === 'XXXL') return '3XL';
  if (u === 'XXXXL') return '4XL';
  return u;
}

function expandAlphaRange(startTok: string, endTok: string): string[] {
  const sIdx = STANDARD_ALPHA_ORDER.indexOf(normalizeAlphaToken(startTok));
  const eIdx = STANDARD_ALPHA_ORDER.indexOf(normalizeAlphaToken(endTok));
  if (sIdx !== -1 && eIdx !== -1 && eIdx > sIdx) {
    return STANDARD_ALPHA_ORDER.slice(sIdx, eIdx + 1);
  }
  return [];
}

export function isUnstitchedDress(title: string, desc: string): boolean {
  if (/\b(?:unstitched|un-stitched)\b|আনস্টিচড|আন-স্টিচড|সেলাইবিহীন|সেলাই\s*ছাড়া/i.test(`${title} ${desc}`)) {
    return true;
  }
  // Yardage measurements like "2.5 goj", "২.৫ গজ", "ওড়নাঃ ৫ হাত / ৫.৫ হাত" without Ready-Made / Body Size (Bust)
  const asciiDesc = toAsciiDigits(desc);
  if (
    !/(?:\b(?:readymade|ready[\s-]*made|body\s*size)\b|রেডিমেইড|রেডিমেড|বডি\s*সাইজ)/i.test(`${title} ${asciiDesc}`) &&
    /(?:^|[^\d])\d+(?:\.\d+)?\s*(?:\b(?:goj|gaj)\b|গজ)/i.test(asciiDesc)
  ) {
    return true;
  }
  return false;
}

export function isWomensOrJewelrySizeCandidate(
  title: string,
  targetCat: string,
  sub: string,
  subsub: string,
  desc: string
): boolean {
  const t = title.toLowerCase();
  const s = `${sub} ${subsub}`.toLowerCase();
  const asciiDesc = toAsciiDigits(desc);

  // Special case: Compression support brace in home-lifestyle ("Small, Medium, Large")
  if (targetCat === 'home-lifestyle') {
    return /\bsmall,\s*medium,\s*large\b/i.test(title);
  }

  if (['watches', 'foods', 'gadgets-electronics'].includes(targetCat)) {
    return false;
  }
  if (isWatchProductTitle(title, title)) return false;

  // Sarees NEVER have selectable garment sizes
  if (
    s.includes('saree') ||
    /\b(?:saree|sharee|sari|jamdani|katan\s+saree|tangail\s+saree|silk\s+saree|cotton\s+saree|georgette\s+saree)\b|শাড়ি|শাড়ি|জামদানি/i.test(
      t
    )
  ) {
    return false;
  }

  // Unstitched fabrics NEVER have selectable garment sizes
  if (isUnstitchedDress(title, desc)) {
    return false;
  }

  // Cosmetics, Makeup, Skin Care, Hair Care, Beauty Tools, Perfumes, Hair Bands NEVER have sizes
  if (
    s.includes('cosmetics') ||
    s.includes('skin-care') ||
    s.includes('hair-care') ||
    s.includes('makeup') ||
    /(?:\b(?:lipstick|foundation|concealer|mascara|eyeliner|compact\s*powder|face\s*wash|serum|cream|lotion|shampoo|conditioner|hair\s*oil|hair\s*bands?|blackhead|remover|derma\s*roller|soap|cleanser|toner|sunscreen|perfume|attar|fogg|body\s*spray)\b|মেকআপ|লিপস্টিক|ক্রিম|সিরাম|শ্যাম্পু|তেল|সাবান|বডি\s*স্প্রে)/i.test(
      t
    )
  ) {
    return false;
  }

  // Ladies Bags, Purses, Sunglasses, Umbrellas NEVER have sizes
  if (
    s.includes('ladies-bag') ||
    s.includes('women-bag') ||
    /(?:\b(?:bag|handbag|purse|clutch|wallet|backpack|tote|sunglass|umbrella|lunch\s*box)\b|ব্যাগ|হ্যান্ডব্যাগ|পার্স|মানিব্যাগ|সানগ্লাস|ছাতা)/i.test(
      t
    )
  ) {
    return false;
  }

  // Palazzo Khimar Sets & Khimar-type fixed-length Abayas (single fixed length like লং ৬০ / লং ৪৫ without discrete 50/52/54/56)
  if (
    s.includes('palazzo-khimar-set') ||
    (/\b(?:palazzo\s*(?:long\s*)?khimar\s*set|khimar)\b/i.test(t) && !/\b(?:50|52|54)\s*[,/-]\s*(?:52|54|56)\b/.test(asciiDesc))
  ) {
    return false;
  }
  if (
    /\bfloor\s*touch\s*long\s*abaya\b/i.test(t) &&
    !/\b(?:50|52|54)\s*[,/-]\s*(?:52|54|56)\b/.test(asciiDesc) &&
    /ঘের\s*130\s*লং\s*45/i.test(asciiDesc)
  ) {
    return false;
  }

  // Explicit Free-Size Sports Bra / Panty / Undergarments ("Size- FREE", "SIZE FREE SIZE", "(28-52) ফ্রি সাইজ")
  if (
    /(?:\b(?:size[\s:-]*free|free\s*size)\b|ফ্রি\s*সাইজ)/i.test(asciiDesc) &&
    !/\b(?:50|52|54)\s*[,/-]\s*(?:52|54|56)\b/.test(asciiDesc) &&
    !/\b(?:M|L|XL|XXL)\b/.test(asciiDesc) &&
    !/(?:36|38|40|42|44)\s*,\s*(?:38|40|42|44|46)/.test(asciiDesc)
  ) {
    return false;
  }

  // Jewelry: ONLY Churi / Bangles or explicitly multi-sized Rings can ever have sizes
  if (targetCat === 'jewelry' || s.includes('jewellery') || s.includes('jewelry')) {
    if (/(?:\b(?:bangles?|churi|kada)\b|চুড়ি|চুড়ি|বালা)/i.test(t) && !/(?:\b(?:bracelet|adjustable|free\s*size)\b|ফ্রি\s*সাইজ|এডজাস্টেবল|অ্যাডজাস্টেবল)/i.test(`${title} ${desc}`)) {
      return /\b2\.(?:2|4|6|8|10)\b/.test(asciiDesc);
    }
    if (/(?:\bring\b|আংটি)/i.test(t) && !/(?:\b(?:ear\s*ring|earring|nose\s*ring|key\s*ring|adjustable|free\s*size)\b|ফ্রি\s*সাইজ|এডজাস্টেবল|অ্যাডজাস্টেবল)/i.test(`${title} ${desc}`)) {
      return /(?:size|সাইজ)\s*[:ঃ=-]+\s*(?:\d{1,2}\s*[,/]\s*)+\d{1,2}/i.test(asciiDesc);
    }
    return false;
  }

  // Only Hijab / Scarf / Orna / Dupatta / Niqab -> Free size drape
  if (
    s.includes('only-hijab') ||
    (/(?:\b(?:hijab|scarf|stole|orna|dupatta|niqab)\b|হিজাব|ওড়না|দোপাট্টা|নিকাব)/i.test(t) &&
      !/(?:\b(?:borka|burqa|burka|abaya|gown|kameez|kurti)\b|বোরকা|বোরখা|আবায়া|গাউন)/i.test(t))
  ) {
    return false;
  }

  return true;
}

export function extractRealSizesWomensAndJewelry(
  detailsHtml: string,
  descText: string,
  title: string,
  targetCat: string,
  sub: string,
  subsub: string
): string[] {
  if (!isWomensOrJewelrySizeCandidate(title, targetCat, sub, subsub, descText)) {
    return [];
  }

  if (targetCat === 'home-lifestyle' && /\bsmall,\s*medium,\s*large\b/i.test(title)) {
    return ['S', 'M', 'L'];
  }

  const found: string[] = [];
  const addSize = (s: string) => {
    const clean = s
      .trim()
      .replace(/^[-–—:•➤=>*#\s]+|[-–—:•*″"'।.\s]+$/g, '')
      .trim();
    if (!clean) return;
    if (/(?:\b(?:cm|mm|ml|ltr|liter|kg|gm|gram|watt|volt|mah|feet|ft|inch)\b|ইঞ্চি|ফুট|হাত)/i.test(clean)) return;
    if (/\d+\s*[xX*×]\s*\d+/.test(clean)) return;

    const norm = normalizeAlphaToken(clean);
    const normalized = STANDARD_ALPHA_ORDER.includes(norm) ? norm : clean;
    if (!found.some(x => x.toLowerCase() === normalized.toLowerCase())) {
      found.push(normalized);
    }
  };

  const asciiDesc = toAsciiDigits(descText);
  const lines = asciiDesc.split('\n').map(l => l.trim()).filter(Boolean);

  // Jewelry Churi / Bangle sizes (2.2, 2.4, 2.6, 2.8, 2.10)
  if (targetCat === 'jewelry') {
    const bangleMatches = [...asciiDesc.matchAll(/\b(2\.(?:2|4|6|8|10))\b/g)].map(m => m[1]);
    const uniqueBangle = Array.from(new Set(bangleMatches));
    if (uniqueBangle.length >= 2) {
      uniqueBangle.forEach(addSize);
      return found;
    }
    for (const line of lines) {
      const rm = line.match(/(?:size|সাইজ)\s*[:ঃ=-]+\s*((?:\d{1,2}\s*[,/]\s*)+\d{1,2})/i);
      if (rm) {
        rm[1].split(/[,/\s]+/).filter(Boolean).forEach(addSize);
        return found;
      }
    }
    return [];
  }

  const isBorkaOrAbaya =
    sub.includes('borka') ||
    /(?:\b(?:borka|burqa|burka|abaya|jilbab|kaftan)\b|বোরকা|বোরখা|আবায়া|জিলবাব|কাফতান)/i.test(`${title} ${descText.slice(0, 160)}`);

  // Dedicated Borka / Abaya length pass FIRST — once length sizes (50, 52, 54, 56, 58) are found, return immediately so free-fit bust range ("বডি সাইজ: ৩৬–৪৬") is NEVER mixed in!
  if (isBorkaOrAbaya) {
    for (const line of lines) {
      const borkaLenMatch = line.match(
        /(?:long|length|লম্বা|লেন্থ|লং|সাইজ|size|মাপ)[^:ঃ=/0-9\n]{0,20}[:ঃ=/–—-]+\s*([^\n]+)/i
      );
      if (borkaLenMatch) {
        const borkaNums = [...borkaLenMatch[1].matchAll(/\b(48|50|52|54|56|58)\b/g)].map(m => m[1]);
        const uniq = Array.from(new Set(borkaNums));
        if (uniq.length >= 2) {
          uniq.forEach(addSize);
        }
      } else if (/(?:long|length|লম্বা|লেন্থ|লং|সাইজ|size)/i.test(line)) {
        const inlineBorka = [...line.matchAll(/\b(48|50|52|54|56|58)\b/g)].map(m => m[1]);
        const uniq = Array.from(new Set(inlineBorka));
        if (uniq.length >= 2) {
          uniq.forEach(addSize);
        }
      }
    }
    if (found.length >= 2) {
      return found;
    }
    // Standard Dubai Cherry Irani Party Abaya Burkha Set (e.g. Taqwa Burka Set 5021) where sizes are only in login-gated form
    if (/(?:\b(?:dubai\s*cherry|abaya|burkha|burka|borka)\b|দুবাই\s*চেরি|বোরকা|আবায়া)/i.test(`${title} ${descText}`)) {
      return ['50', '52', '54', '56'];
    }
  }

  // 1. Check explicit Size / Body Size (Bust) / বডি সাইজ lines
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    const alphaRangeInLine = line.match(
      /(?:সাইজ|size|আকার)[^\n]{0,30}?\b(XS|S|M|L|XL)\s*(?:to|থেকে|[-–—])\s*(L|XL|XXL|2XL|3XL|4XL|XXXL)\b/i
    );
    if (alphaRangeInLine) {
      expandAlphaRange(alphaRangeInLine[1], alphaRangeInLine[2]).forEach(addSize);
    }

    const numRangeMatch = line.match(
      /(?:body\s*size|bust\s*size|বডি\s*সাইজ|সাইজ|size)(?:\s*\([^)]*\))?[^:\n]{0,18}[:ঃ=–—-]+\s*(3[2468]|4[024]|50)\s*(?:to|থেকে|[-–—])\s*(4[02468]|5[0246])\b/i
    );
    if (numRangeMatch) {
      const start = parseInt(numRangeMatch[1], 10);
      const end = parseInt(numRangeMatch[2], 10);
      if (!/free\s*size|ফ্রি\s*সাইজ|পর্যন্ত|up\s*to|adjustable|ফিট\s*হবে/i.test(line) && end > start && end - start <= 12 && start % 2 === 0 && end % 2 === 0) {
        for (let n = start; n <= end; n += 2) addSize(String(n));
        continue;
      }
    }

    if (/size\s*chart|সাইজ\s*চার্ট/i.test(line) && !/[:ঃ=-]\s*(?:XS|S|M|L|XL|XXL|\d{2})\b/i.test(line)) {
      continue;
    }

    // Standalone header followed by next line(s)
    if (
      /^(?:[^\w\u0980-\u09FF]*)(?:এভেইলেবল\s*সাইজ|available\s+sizes?|সাইজ\s*অপশনস?|sizes?|সাইজ|আকার)(?:\s*\([^)]*\))?\s*[:ঃ=-]?\s*$/i.test(
        line
      )
    ) {
      if (i + 1 < lines.length) {
        const nextLine = lines[i + 1].replace(/^[•➤❑\-*👉]+\s*/, '').replace(/[।.]+$/, '').trim();
        const nextAlpha = nextLine.match(/^(?:(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL)$/i);
        if (nextAlpha) {
          nextLine.split(/[,/|&\s]+/).filter(Boolean).forEach(addSize);
          continue;
        }
        const nextNums = [...nextLine.matchAll(/\b(3[2468]|4[02468]|5[02468])\b/g)].map(m => m[1]);
        if (nextNums.length >= 2) {
          nextNums.forEach(addSize);
          continue;
        }
      }
    }

    const parenAlpha = line.match(
      /(?:সাইজে?|size|fit|আকার)[^()\n]{0,25}\(\s*((?:(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL))\s*\)/i
    );
    if (parenAlpha) {
      parenAlpha[1].split(/[,/|&\s]+/).filter(Boolean).forEach(addSize);
    }

    // Supports optional "(Bust)", "(Body Size)", etc. BEFORE ":"!
    const explicitSizeLabel = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(?:এভেইলেবল\s*সাইজ|available\s+sizes?|body\s*size|bust\s*size|বডি\s*সাইজ|বডি|measurements?|সাইজ\s*অপশনস?|sizes?|সাইজ|আকার)(?:\s*\([^)]{1,25}\))?\s*[:ঃ=–—-]+\s*([^\n]+)/i
    );
    if (explicitSizeLabel) {
      const rhs = explicitSizeLabel[1]
        .replace(/^available\s+in\s+/i, '')
        .replace(/\([^)]*\)/g, '')
        .replace(/(?:\b(?:inches|inch)\b|ইঞ্চি)/gi, '')
        .replace(/[।.]+$/g, '')
        .trim();

      if (/free\s*size|ফ্রি\s*সাইজ|সব\s*সাইজে/i.test(rhs) && !/\b(?:34|36|38|40|42|44)\b/.test(rhs)) {
        continue;
      }

      if (/^(?:chest|waist|length|in\s+inches)/i.test(rhs)) {
        continue;
      }

      const alphaTokens = rhs.match(/\b(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL|XXXL)\b/gi);
      if (alphaTokens && alphaTokens.length >= 2) {
        alphaTokens.forEach(addSize);
        continue;
      }

      if (!/পর্যন্ত|up\s*to|-|\bto\b|থেকে/i.test(rhs)) {
        const discreteNums = rhs
          .split(/[,;|/&]+|\s+and\s+|\s+ও\s+|\s+এবং\s+/i)
          .map(s => s.replace(/["″'।.]+/g, '').trim())
          .filter(Boolean);
        if (discreteNums.length >= 2 && discreteNums.every(p => /^\d{2}$/.test(p))) {
          discreteNums.forEach(addSize);
          continue;
        }
      }
    }
  }

  // 2. Alpha measurement rows: e.g. "M - Chest 38, Length 26", "XL সাইজ: ..."
  if (found.length === 0) {
    const measurementAlphaSizes: string[] = [];
    for (const line of lines) {
      const mRow = line.match(
        /^(?:[^\w\u0980-\u09FF]*)(XS|S|M|L|XL|XXL|2XL|3XL|4XL|XXXL)\b(?:\s*(?:size|সাইজ|\([^)]{1,32}\)))?\s*[-–—:=|]+\s*[^\n]*\d+/i
      );
      if (mRow) {
        const tok = normalizeAlphaToken(mRow[1]);
        if (!measurementAlphaSizes.includes(tok)) measurementAlphaSizes.push(tok);
      }
    }
    if (measurementAlphaSizes.length >= 2) {
      measurementAlphaSizes.forEach(addSize);
    }
  }

  // 3. Numeric measurement rows (e.g. "Size 38: Bust 38...")
  if (found.length === 0) {
    const numericRowSizes: string[] = [];
    for (const line of lines) {
      const numRow = line.match(
        /^(?:[^\w\u0980-\u09FF]*)(?:size\s*|সাইজ\s*)?(\d{2})\s*(?:[-–—:=|]+|\s+\|\s+)\s*[^\n]*\b\d{2}\b/i
      );
      if (numRow) {
        const n = parseInt(numRow[1], 10);
        if (n >= 20 && n <= 58) {
          const sNum = String(n);
          if (!numericRowSizes.includes(sNum)) numericRowSizes.push(sNum);
        }
      }
    }
    if (numericRowSizes.length >= 2) {
      numericRowSizes.forEach(addSize);
      if (found.every(f => /^\d{2}$/.test(f))) {
        found.sort((a, b) => parseInt(a, 10) - parseInt(b, 10));
      }
    }
  }

  // 4. Reassigned Men's Shirts / Polos whose sizes are only in login-gated form
  if (found.length === 0 && targetCat === 'mens-fashion' && /\b(?:polo|shirt|t-?shirt)\b/i.test(title)) {
    ['M', 'L', 'XL', 'XXL'].forEach(addSize);
  }

  if (found.length >= 2 && found.every(f => STANDARD_ALPHA_ORDER.includes(f))) {
    found.sort((a, b) => STANDARD_ALPHA_ORDER.indexOf(a) - STANDARD_ALPHA_ORDER.indexOf(b));
  }

  return found;
}

const KNOWN_COLOR_MAP: Array<{ pattern: RegExp; label: string }> = [
  { pattern: /\brose\s*gold\b|রোজ\s*গোল্ড/i, label: 'Rose Gold' },
  { pattern: /\bcoffee\s*\/\s*brown\b/i, label: 'Coffee/Brown' },
  { pattern: /\bash\s*\/\s*gr[ae]y\b|অ্যাশ\s*\/\s*গ্রে/i, label: 'Ash/Grey' },
  { pattern: /\bnavy\s*blue\b|নেভি\s*ব্লু|\bnavy\b/i, label: 'Navy Blue' },
  { pattern: /\bsky\s*blue\b|স্কাই\s*ব্লু|আকাশি/i, label: 'Sky Blue' },
  { pattern: /\bslate\s*blue\b/i, label: 'Slate Blue' },
  { pattern: /\broyal\s*blue\b|রয়্যাল\s*ব্লু/i, label: 'Royal Blue' },
  { pattern: /\bbottle\s*green\b|বটল\s*গ্রিন/i, label: 'Bottle Green' },
  { pattern: /\bsea\s*green\b|সি\s*গ্রিন/i, label: 'Sea Green' },
  { pattern: /\bteal(?:\s*green)?\b|টিল(?:\s*গ্রিন)?/i, label: 'Teal' },
  { pattern: /\bolive(?:\s*green)?\b|অলিভ(?:\s*গ্রিন)?|জলপাই/i, label: 'Olive' },
  { pattern: /\bmustard(?:\s*yellow)?\b|মাস্টার্ড|সরিষা|বাসন্তী(?:\s*হলুদ)?/i, label: 'Mustard' },
  { pattern: /\bpasta\b|পেস্ট\s*কালার|পেস্ট/i, label: 'Paste' },
  { pattern: /\bpeach\b|পিচ/i, label: 'Peach' },
  { pattern: /\brust\b|রাস্ট/i, label: 'Rust' },
  { pattern: /\bwine\b|ওয়াইন/i, label: 'Wine' },
  { pattern: /\boff[\s-]*white\b|অফ[\s-]*হোয়াইট/i, label: 'Off-White' },
  { pattern: /\bmaroon\b|মেরুন|খয়েরি/i, label: 'Maroon' },
  { pattern: /\bmagenta\b|ম্যাজেন্টা/i, label: 'Magenta' },
  { pattern: /\bcoffee\b|কফি/i, label: 'Coffee' },
  { pattern: /\bchocolate\b|চকলেট/i, label: 'Chocolate' },
  { pattern: /\bbeige\b|বেইজ|নুড|\bnude\b/i, label: 'Beige' },
  { pattern: /\bkhaki\b|খাকি/i, label: 'Khaki' },
  { pattern: /\bgolden\b|\bgold\b|গোল্ডেন|সোনালী/i, label: 'Golden' },
  { pattern: /\bsilver\b|সিলভার|রুপালি/i, label: 'Silver' },
  { pattern: /\blavender\b|ল্যাভেন্ডার/i, label: 'Lavender' },
  { pattern: /\bpurple\b|বেগুনি|পার্পল|ভায়োলেট|\bviolet\b/i, label: 'Purple' },
  { pattern: /\bpink\b|গোলাপি|পিঙ্ক/i, label: 'Pink' },
  { pattern: /\byellow\b|হলুদ|ইয়েলো/i, label: 'Yellow' },
  { pattern: /\borange\b|কমলা|অরেঞ্জ/i, label: 'Orange' },
  { pattern: /\bred\b|লাল|রেড/i, label: 'Red' },
  { pattern: /\bgreen\b|সবুজ|গ্রিন/i, label: 'Green' },
  { pattern: /\bblue\b|\bblu\b|নীল|ব্লু/i, label: 'Blue' },
  { pattern: /\bbrown\b|বাদামী|ব্রাউন/i, label: 'Brown' },
  { pattern: /\bash\b|অ্যাশ/i, label: 'Ash' },
  { pattern: /\bgr[ae]y\b|গ্রে|ধূসর/i, label: 'Grey' },
  { pattern: /\bwhite\b|সাদা|হোয়াইট/i, label: 'White' },
  { pattern: /\bblack\b|কালো|ব্ল্যাক/i, label: 'Black' },
  { pattern: /\bcream\b|ক্রিম/i, label: 'Cream' },
];

export function extractRealColorsWomensAndJewelry(
  detailsHtml: string,
  descText: string,
  title: string,
  targetCat: string,
  sub: string,
  subsub: string
): string[] {
  const s = `${sub} ${subsub}`.toLowerCase();

  // Never extract fake colors on Skin Care / Hair Care / Beauty Tools / Perfumes / Foods
  if (
    targetCat === 'foods' ||
    s.includes('skin-care') ||
    s.includes('hair-care') ||
    /\b(?:perfume|attar|atar|fogg|body\s*spray|deodorant|fragrance|shampoo|conditioner|soap|cream|lotion|serum|face\s*wash|cleanser|toner|sunscreen|hair\s*oil|onion\s*oil|black\s*seed|green\s*tea|blackhead|remover|derma\s*roller|honey|ghee|gel|scrub)\b/i.test(
      title
    )
  ) {
    return [];
  }

  // Random / Assorted / Multi-color items where customer cannot choose a single color
  if (
    /(?:\b(?:random\s*colou?r|assorted\s*colou?r|any\s*colou?r|multi[\s-]*colou?r)\b|র‍্যান্ডম\s*কালার|মাল্টি[\s-]*কালার)/i.test(
      title
    )
  ) {
    return [];
  }

  const cleanTitleForColor = title
    .replace(/\brose\s*gold[\s-]*plated\b/gi, '')
    .replace(/\bgold[\s-]*plated\b/gi, '')
    .replace(/\bsilver[\s-]*plated\b/gi, '')
    .replace(/\brhodium[\s-]*plated\b/gi, '')
    .replace(/\b18k\s*gold\b/gi, '')
    .replace(/\b22k\s*gold\b/gi, '')
    .replace(/\b24k\s*gold\b/gi, '')
    .replace(/\bgolden\s*zari\b/gi, '')
    .replace(/\bstainless\s*steel\b/gi, '')
    .replace(/\bwhite\s*pearl\b/gi, '')
    .replace(/\bgold\s*pearl\b/gi, '')
    .replace(/\bblack\s*head\b/gi, '')
    .replace(/\bwhite\s*head\b/gi, '')
    .replace(/\bblack\s*dot\b/gi, '')
    .replace(/\bgreen\s*tea\b/gi, '')
    .replace(/\bblack\s*seed\b/gi, '')
    .replace(/\bred\s*velvet\b/gi, '');

  const matchColorsInSegment = (seg: string): string[] => {
    const res: string[] = [];
    // Mask compound color phrases as we match them so "Olive Green" doesn't also trigger standalone "Green" and "Mustard Yellow" doesn't also trigger standalone "Yellow"!
    let working = seg;
    for (const kc of KNOWN_COLOR_MAP) {
      if (kc.pattern.test(working)) {
        if (kc.label === 'Golden' && res.some(x => x.includes('Gold'))) continue;
        if (kc.label === 'White' && res.includes('Off-White') && !/\bwhite\b/i.test(working.replace(/\boff[\s-]*white\b/gi, ''))) continue;
        if (!res.some(existing => existing.toLowerCase() === kc.label.toLowerCase())) {
          res.push(kc.label);
          working = working.replace(new RegExp(kc.pattern.source, 'gi'), ' ');
        }
      }
    }
    return res;
  };

  // Jewelry: ONLY extract colors if explicit "(Red)" / "- Green" SKU color or explicit "Available Colors" option line!
  if (targetCat === 'jewelry') {
    const parenMatches = [...cleanTitleForColor.matchAll(/\(([^)]+)\)/g)];
    for (const pm of parenMatches) {
      const inside = pm[1].trim();
      if (/multi|random|pack|pcs|pieces|set|pair|stone|pearl|plated|adjustable/i.test(inside)) continue;
      const pCols = matchColorsInSegment(inside);
      if (pCols.length === 1) return pCols;
      if (pCols.length === 2) return [`${pCols[0]} & ${pCols[1]}`];
    }

    const trailingDash = cleanTitleForColor.match(/[-–—]\s*([A-Za-z\s&/]{3,22})$/);
    if (trailingDash && !/set|design|style|collection|edition|jewelry|necklace|earring|ring|bangle/i.test(trailingDash[1])) {
      const tCols = matchColorsInSegment(trailingDash[1]);
      if (tCols.length === 1) return tCols;
      if (tCols.length === 2) return [`${tCols[0]} & ${tCols[1]}`];
    }

    const jLines = descText.split('\n').map(l => l.trim()).filter(Boolean);
    for (const line of jLines) {
      if (/guarantee|fade|পাকা\s*রঙ|রঙ\s*উঠবে\s*না|গ্যারান্টি|plated|পলিশ|polish|stone|পাথর|মুক্তা|pearl/i.test(line)) {
        continue;
      }
      const explicitJColor = line.match(
        /^(?:[^\w\u0980-\u09FF]*)(?:available\s+colou?rs?|কালার\s*অপশন|stone\s+colou?rs?)\s*[:ঃ=-]+\s*([^\n]+)/i
      );
      if (explicitJColor) {
        const cList = matchColorsInSegment(explicitJColor[1]);
        if (cList.length >= 1) return cList;
      }
    }
    return [];
  }

  // STEP 1: Check if Title pins this SKU to a specific color in parentheses "(Pink)" or trailing "- Maroon"
  const parenMatches = [...cleanTitleForColor.matchAll(/\(([^)]+)\)/g)];
  for (const pm of parenMatches) {
    const inside = pm[1].trim();
    if (/random|multi|assorted|pack|pcs|inch|cm|mm|ml|ft|stitched|unstitched/i.test(inside)) continue;
    const pCols = matchColorsInSegment(inside);
    if (pCols.length === 1) return pCols;
    if (pCols.length === 2) return [`${pCols[0]} & ${pCols[1]}`];
  }

  const trailingDashMatch = cleanTitleForColor.match(/[-–—]\s*([A-Za-z\s&/]{3,25})$/);
  if (trailingDashMatch && !/saree|borka|abaya|kurti|collection|design|set|bag|combo|piece/i.test(trailingDashMatch[1])) {
    const tCols = matchColorsInSegment(trailingDashMatch[1]);
    if (tCols.length === 1) return tCols;
    if (tCols.length === 2) return [`${tCols[0]} & ${tCols[1]}`];
  }

  // Sarees & Unstitched 3-Pieces: Each listing is ONE single saree/dress design!
  // Take its primary/two-tone color from the Title (unless an explicit "Available Colors / কালার অপশন" multi-variant line exists)
  const isSingleDesignSareeOrUnstitched =
    s.includes('saree') ||
    /\b(?:saree|sharee)\b|শাড়ি|শাড়ি/i.test(title) ||
    isUnstitchedDress(title, descText);

  if (isSingleDesignSareeOrUnstitched) {
    const lines = descText.split('\n').map(l => l.trim()).filter(Boolean);
    for (const line of lines) {
      const multiOpt = line.match(/^(?:[^\w\u0980-\u09FF]*)(?:available\s+colou?rs?|কালার\s*অপশন)\s*[:ঃ=-]+\s*([^\n]+)/i);
      if (multiOpt) {
        const cList = matchColorsInSegment(multiOpt[1]);
        if (cList.length >= 2) return cList;
      }
    }
    const titleCols = matchColorsInSegment(cleanTitleForColor);
    if (titleCols.length === 1) return titleCols;
    if (titleCols.length >= 2) return [`${titleCols[0]} & ${titleCols[1]}`];
    return [];
  }

  // STEP 2: Check explicit "Available Colors / কালার / রঙ" line in description
  const found: string[] = [];
  const addColor = (c: string) => {
    if (c === 'Golden' && found.some(x => x.includes('Gold'))) return;
    if (!found.some(existing => existing.toLowerCase() === c.toLowerCase())) {
      found.push(c);
    }
  };

  const lines = descText.split('\n').map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    if (
      /guarantee|longevity|fade|wash|দীর্ঘস্থায়ী|পাকা\s*রঙ|রঙ\s*উঠবে\s*না|রঙের\s*গ্যারান্টি|কালার\s*গ্যারান্টি|random|র‍্যান্ডম|assorted|কন্ট্রাস্ট|contrast|আঁচল|পাড়|border|embroidery|এম্ব্রয়ডারি|প্রিন্ট|print/i.test(
        line
      )
    ) {
      continue;
    }

    const explicitColorLine = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(?:available\s+colou?rs?|কালার\s*অপশন|colou?rs?|কালার|রঙ|রং)\s*[:ঃ=-]+\s*([^\n]+)/i
    );
    if (explicitColorLine) {
      const rhs = explicitColorLine[1].trim();
      if (/as\s+picture|as\s+shown|ছবির\s*মত|গ্যারান্টি|multi|মাল্টি|random|র‍্যান্ডম/i.test(rhs)) continue;
      const cList = matchColorsInSegment(rhs);
      if (cList.length === 2 && !/[,/|]|অথবা|\bor\b/i.test(rhs) && /&|and|উইথ|with|ও/i.test(rhs)) {
        addColor(`${cList[0]} & ${cList[1]}`);
      } else {
        cList.forEach(addColor);
      }
    }
  }
  if (found.length > 0) return found;

  // STEP 3: Scan Title for single-SKU color
  if (!s.includes('makeup')) {
    const titleCols = matchColorsInSegment(cleanTitleForColor);
    if (titleCols.length === 1) return titleCols;
    if (titleCols.length >= 2) {
      return [`${titleCols[0]} & ${titleCols[1]}`];
    }
  }

  return [];
}

export function mapWomensFashionSubcategory(sub: string, subsub: string, title: string, existingSub?: string): string {
  const s = `${sub} ${subsub}`.toLowerCase();
  const t = title.toLowerCase();

  if (
    (s.includes('saree') ||
      /(?:\b(?:saree|sharee|sari|jamdani|tangail|katan|manipuri)\b|শাড়ি|শাড়ি|জামদানি|কাতান|টাঙ্গাইল)/i.test(t)) &&
    !/\bsaree\s*pin\b|\bwaist\s*chain\b|শাড়ি\s*পিন|কোমরবন্ধ/i.test(t)
  ) {
    return 'শাড়ি (Saree)';
  }
  if (
    s.includes('borka') ||
    s.includes('abaya') ||
    s.includes('khimar') ||
    s.includes('hijab') ||
    /(?:\b(?:borka|burqa|burka|abaya|khimar|hijab|niqab|jilbab|kaftan)\b|বোরকা|বোরখা|আবায়া|খিমার|হিজাব|নিকাব|কটি\s*সেট)/i.test(t)
  ) {
    return 'বোরকা ও হিজাব (Borka & Hijab)';
  }
  if (
    s.includes('salwar-kameez') ||
    s.includes('3-pcs') ||
    s.includes('2-pcs') ||
    /\b(?:three[\s-]*piece|3[\s-]*piece|3[\s-]*pcs|two[\s-]*piece|2[\s-]*pcs|salwar|shalwar|kameez|lawn\s*suit|pakistani\s*suit)\b|থ্রি[\s-]*পিস|টু[\s-]*পিস|সালোয়ার|কামিজ/i.test(
      t
    )
  ) {
    if (/\bkurti\b|কুর্তি/i.test(t) || s.includes('kurti')) {
      return 'কুর্তি ও টপস (Kurti & Tops)';
    }
    return 'থ্রি-পিস ও সালোয়ার কামিজ (Three-Piece)';
  }
  if (
    s.includes('kurti') ||
    s.includes('girls-wear') ||
    /\b(?:kurti|tunic|tops?|ladies\s*t-?shirt|women'?s?\s*t-?shirt|drop\s*shoulder|mexi|maxi|gown|palazzo|leggings|skirt)\b|কুর্তি|টপস|ম্যাক্সি|গাউন|প্লাজো/i.test(
      t
    )
  ) {
    return 'কুর্তি ও টপস (Kurti & Tops)';
  }
  if (
    s.includes('ladies-bag') ||
    s.includes('women-bag') ||
    /\b(?:bag|handbag|purse|clutch|tote|backpack)\b|ব্যাগ|হ্যান্ডব্যাগ|পার্স/i.test(t)
  ) {
    return 'লেডিস ব্যাগ ও পার্স (Ladies Bags)';
  }
  if (
    s.includes('cosmetics') ||
    /\b(?:lipstick|foundation|makeup|serum|cream|lotion|face\s*wash|shampoo|hair\s*oil|skin\s*care|beauty|blackhead|remover|derma\s*roller|fogg|body\s*spray|perfume)\b|কসমেটিক্স|মেকআপ|স্কিনকেয়ার|ক্রিম|সিরাম/i.test(
      t
    )
  ) {
    return 'কসমেটিক্স ও স্কিনকেয়ার (Beauty & Care)';
  }
  if (
    existingSub &&
    [
      'শাড়ি (Saree)',
      'বোরকা ও হিজাব (Borka & Hijab)',
      'থ্রি-পিস ও সালোয়ার কামিজ (Three-Piece)',
      'কুর্তি ও টপস (Kurti & Tops)',
      'লেডিস ব্যাগ ও পার্স (Ladies Bags)',
      'কসমেটিক্স ও স্কিনকেয়ার (Beauty & Care)',
    ].includes(existingSub)
  ) {
    return existingSub;
  }
  return "ওমেনস কালেকশন (Women's Special)";
}

export function mapJewelrySubcategory(sub: string, subsub: string, title: string, existingSub?: string): string {
  const s = `${sub} ${subsub}`.toLowerCase();
  const t = title.toLowerCase();

  if (
    s.includes('nose-pin') ||
    /\b(?:nose[\s-]*pin|nose[\s-]*ring|nath)\b|নাকফুল|নথ/i.test(t)
  ) {
    return 'নাকফুল (Nose Pins)';
  }
  if (
    s.includes('ear-ring') ||
    s.includes('earring') ||
    /\b(?:ear[\s-]*rings?|jhumka|studs?|ear\s*drops?|পাশা|কানের\s*দুল|ঝুমকা|দুল)\b/i.test(t)
  ) {
    if (!/\b(?:necklace|bridal\s*set|jewelry\s*set|jewellery\s*set|choker\s*set|হার|নেকলেস|মালা\s*সেট)\b/i.test(t)) {
      return 'কানের দুল ও ঝুমকা (Earrings & Jhumka)';
    }
  }
  if (
    (s.includes('/ring') || subsub === 'ring' || /\b(?:finger\s*ring|couple\s*ring|stone\s*ring|ring)\b|আংটি/i.test(t)) &&
    !/\b(?:ear[\s-]*ring|nose[\s-]*ring|key[\s-]*ring|toe\s*ring|necklace|bangle|bracelet)\b/i.test(t)
  ) {
    return 'আংটি কালেকশন (Rings)';
  }
  if (
    s.includes('baslate') ||
    s.includes('bracelet') ||
    s.includes('bangle') ||
    /\b(?:bangles?|bracelet|churi|kada|kangan|payel|anklet|চুড়ি|চুড়ি|ব্রেসলেট|বালা|পায়েল|নুপুর)\b/i.test(t)
  ) {
    return 'চুড়ি ও ব্রেসলেট (Bangles & Bracelets)';
  }
  if (
    s.includes('pendant') ||
    (/\b(?:pendant|locket|chain)\b|লকেট|পেনডেন্ট|চেইন/i.test(t) &&
      !/\b(?:necklace\s*set|bridal\s*set|choker|সীতাহার)\b/i.test(t))
  ) {
    return 'চেইন ও পেনডেন্ট (Chains & Pendants)';
  }
  if (
    s.includes('necklace') ||
    /\b(?:necklace|choker|bridal\s*set|jewelry\s*set|jewellery\s*set|har|mala|sitahar|নেকলেস|হার|মালা|চোকার|ব্রাইডাল\s*সেট)\b/i.test(
      t
    )
  ) {
    return 'নেকলেস ও ব্রাইডাল সেট (Necklace & Bridal Sets)';
  }
  if (
    existingSub &&
    [
      'নেকলেস ও ব্রাইডাল সেট (Necklace & Bridal Sets)',
      'কানের দুল ও ঝুমকা (Earrings & Jhumka)',
      'চেইন ও পেনডেন্ট (Chains & Pendants)',
      'চুড়ি ও ব্রেসলেট (Bangles & Bracelets)',
      'আংটি কালেকশন (Rings)',
      'নাকফুল (Nose Pins)',
    ].includes(existingSub)
  ) {
    return existingSub;
  }
  return "এক্সক্লুসিভ জুয়েলারি (Jewelry's Special)";
}

interface DiscoveredCard {
  slug: string;
  sub: string;
  subsub: string;
  cardTitle: string;
  thumbImg: string;
  hoverImg: string;
}

async function fetchWithTimeout(url: string, init?: RequestInit, timeoutMs = 15000): Promise<Response> {
  return fetch(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
}

async function discoverLiveWomensFashionProducts(): Promise<Map<string, DiscoveredCard>> {
  console.log('1. Discovering all live /womens-fashion (+ jewellery) products on https://www.dropshipping.com.bd/womens-fashion ...');
  const mainRes = await fetchWithTimeout('https://www.dropshipping.com.bd/womens-fashion');
  const cookies = mainRes.headers.getSetCookie
    ? mainRes.headers.getSetCookie().map((c: string) => c.split(';')[0]).join('; ')
    : mainRes.headers.get('set-cookie') || '';
  const mainHtml = await mainRes.text();
  const csrf = (mainHtml.match(/name="csrf-token"\s+content="([^"]+)"/) || [])[1] || '';

  const links = Array.from(
    new Set([
      'https://www.dropshipping.com.bd/womens-fashion',
      ...[...mainHtml.matchAll(/href="(https?:\/\/(?:www\.)?dropshipping\.com\.bd\/womens-fashion[^"]*)"/g)].map(
        m => m[1]
      ),
    ])
  );
  console.log(`   Found ${links.length} /womens-fashion & /jewellery URLs.`);

  const slugMap = new Map<string, DiscoveredCard>();
  const parseCards = (htmlChunk: string, sub: string, subsub: string) => {
    const slugLinks = [
      ...htmlChunk.matchAll(/href="(?:https?:\/\/(?:www\.)?dropshipping\.com\.bd)?\/product\/([^"/?#]+)"/gi),
    ];
    for (const sl of slugLinks) {
      const slug = sl[1].trim();
      if (!slug) continue;
      const idx = sl.index || 0;
      const windowHtml = htmlChunk.slice(Math.max(0, idx - 600), Math.min(htmlChunk.length, idx + 900));
      const imgs = [...windowHtml.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/gi)]
        .map(m => normalizeImageUrl(m[1]))
        .filter(u => u.includes('/storage/images/products/'));
      const nameMatch = windowHtml.match(/class="product_name_link"[^>]*>([\s\S]*?)<\/a>/i);
      const cardTitle = nameMatch ? cleanSingleLine(nameMatch[1]) : '';
      const existing = slugMap.get(slug);
      if (!existing || (subsub && !existing.subsub) || (sub && !existing.sub)) {
        slugMap.set(slug, {
          slug,
          sub: sub || existing?.sub || '',
          subsub: subsub || existing?.subsub || '',
          cardTitle: cardTitle || existing?.cardTitle || '',
          thumbImg: imgs[0] || existing?.thumbImg || '',
          hoverImg: imgs[1] || existing?.hoverImg || '',
        });
      }
    }
  };

  let urlCursor = 0;
  const urlWorkers = Array.from({ length: 6 }, async () => {
    while (urlCursor < links.length) {
      const url = links[urlCursor++];
      const parts = url.replace(/^https?:\/\/(?:www\.)?dropshipping\.com\.bd\//, '').split('/');
      const cat = parts[0] || 'womens-fashion';
      const sub = parts[1] || '';
      const subsub = parts[2] || '';

      try {
        const pr = await fetchWithTimeout(url, { headers: { Cookie: cookies } });
        parseCards(await pr.text(), sub, subsub);
      } catch (_) {}

      for (let page = 1; page <= 50; page++) {
        try {
          const r = await fetchWithTimeout('https://www.dropshipping.com.bd/load-more-data', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
              'X-CSRF-TOKEN': csrf,
              'X-Requested-With': 'XMLHttpRequest',
              Cookie: cookies,
            },
            body: new URLSearchParams({
              page: String(page),
              limit: '20',
              category_slug: cat,
              subcategory_slug: sub,
              sub_subcategory_slug: subsub,
            }).toString(),
          });
          if (!r.ok) break;
          const j = await r.json();
          if (!j?.data || !j?.product_length) break;
          parseCards(j.data, sub, subsub);
          if (j.product_length < 20) break;
        } catch (_) {
          break;
        }
      }
    }
  });
  await Promise.all(urlWorkers);

  console.log(`   Discovered ${slugMap.size} live /womens-fashion (+ jewellery) products.`);
  return slugMap;
}

interface ScrapedPageInfo {
  slug: string;
  liveTitle: string;
  liveCategorySlug: string;
  liveSubSlug: string;
  liveSubSubSlug: string;
  wholesalePrice: number;
  sku: string;
  galleryImages: string[];
  detailsBlock: string;
  descriptionFormatted: string;
  specs: string[];
  notFound?: boolean;
}

async function fetchProductPageInfo(slug: string): Promise<ScrapedPageInfo> {
  const url = `https://www.dropshipping.com.bd/product/${slug}`;
  let html = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetchWithTimeout(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, 15000);
      if (res.status === 404 || res.status === 500) {
        return {
          slug,
          liveTitle: '',
          liveCategorySlug: '',
          liveSubSlug: '',
          liveSubSubSlug: '',
          wholesalePrice: 0,
          sku: '',
          galleryImages: [],
          detailsBlock: '',
          descriptionFormatted: '',
          specs: [],
          notFound: true,
        };
      }
      if (res.ok) {
        html = await res.text();
        break;
      }
    } catch (_) {
      await new Promise(r => setTimeout(r, 300 * attempt));
    }
  }

  if (!html) {
    return {
      slug,
      liveTitle: '',
      liveCategorySlug: '',
      liveSubSlug: '',
      liveSubSubSlug: '',
      wholesalePrice: 0,
      sku: '',
      galleryImages: [],
      detailsBlock: '',
      descriptionFormatted: '',
      specs: [],
      notFound: true,
    };
  }

  const h2Raw = (html.match(/<div class="single_product_name"[^>]*>[\s\S]*?<h2[^>]*>([\s\S]*?)<\/h2>/i) || [])[1] || '';
  const liveTitle = cleanSingleLine(h2Raw);

  const detailsBlock = (html.match(/<div class="single_product_details">([\s\S]{0,6000})/i) || [])[1] || '';
  const bcLinks = [
    ...detailsBlock.matchAll(/href="https?:\/\/(?:www\.)?dropshipping\.com\.bd\/([a-z0-9-]+(?:\/[a-z0-9-]+)*)"/gi),
  ].map(m => m[1].toLowerCase());
  const deepest = bcLinks[bcLinks.length - 1] || '';
  const bcParts = deepest.split('/').filter(Boolean);
  const liveCategorySlug = bcParts[0] || '';
  const liveSubSlug = bcParts[1] || '';
  const liveSubSubSlug = bcParts[2] || '';

  const priceMeta = (html.match(/property="product:price:amount"\s+content="([^"]+)"/i) || [])[1] || '0';
  const wholesalePrice = Math.round(parseFloat(priceMeta.replace(/,/g, '')) || 0);

  const codeMatch =
    detailsBlock.match(/Code\s*:\s*<\/strong>\s*<span>([^<]+)<\/span>/i) || html.match(/Code:\s*(\d+)/i);
  const sku = codeMatch ? `DSP-${codeMatch[1].trim()}` : '';

  const zoomBlockMatch = html.match(
    /<div class="zoom_img_active[^"]*">([\s\S]*?)<\/div>\s*(?:<div class="zoom_thumb|<\/div>\s*<\/div>)/i
  );
  const zoomHtml = zoomBlockMatch ? zoomBlockMatch[1] : '';
  const galleryImages = Array.from(
    new Set(
      [...zoomHtml.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/gi)]
        .map(m => normalizeImageUrl(m[1]))
        .filter(u => u && u.includes('/storage/images/products/'))
    )
  );

  const homeTabHtml =
    (html.match(/<div class="single_product_tab_content">([\s\S]*?)<div class="tab-pane fade" id="profile"/i) || [])[1] ||
    '';
  const { fullText: descriptionFormatted, bulletSpecs } = htmlToFormattedText(homeTabHtml);

  return {
    slug,
    liveTitle,
    liveCategorySlug,
    liveSubSlug,
    liveSubSubSlug,
    wholesalePrice,
    sku,
    galleryImages,
    detailsBlock,
    descriptionFormatted,
    specs: bulletSpecs,
  };
}

async function main() {
  const productsPath = path.resolve(process.cwd(), 'src/data/products.json');
  const allProducts: Product[] = JSON.parse(fs.readFileSync(productsPath, 'utf8'));

  let liveMap: Map<string, DiscoveredCard>;
  let scrapedMap: Map<string, ScrapedPageInfo>;

  if (!REFRESH_CACHE && fs.existsSync(CACHE_PATH)) {
    console.log(`Loading cached scrape data from ${CACHE_PATH} ...`);
    const cached = JSON.parse(fs.readFileSync(CACHE_PATH, 'utf8'));
    liveMap = new Map(cached.liveEntries);
    scrapedMap = new Map(cached.scrapedEntries);
    console.log(`Loaded ${liveMap.size} live cards and ${scrapedMap.size} scraped product pages from cache.`);
  } else {
    liveMap = await discoverLiveWomensFashionProducts();
    const existingTarget = allProducts.filter(p => p.category === 'womens-fashion' || p.category === 'jewelry');
    const slugsToFetch = new Set<string>();
    for (const s of liveMap.keys()) slugsToFetch.add(s);
    for (const p of existingTarget) {
      if (p.id.startsWith('dsp-')) slugsToFetch.add(p.id.replace(/^dsp-/, ''));
    }

    const slugList = Array.from(slugsToFetch);
    console.log(`2. Scraping ${slugList.length} product detail pages (concurrency=25)...`);

    scrapedMap = new Map<string, ScrapedPageInfo>();
    let cursor = 0;
    const concurrency = 25;
    const workers = Array.from({ length: concurrency }, async () => {
      while (cursor < slugList.length) {
        const idx = cursor++;
        const slug = slugList[idx];
        const info = await fetchProductPageInfo(slug);
        scrapedMap.set(slug, info);
        if ((idx + 1) % 100 === 0 || idx + 1 === slugList.length) {
          console.log(`   Scraped ${idx + 1}/${slugList.length}...`);
        }
      }
    });
    await Promise.all(workers);

    fs.writeFileSync(
      CACHE_PATH,
      JSON.stringify({
        liveEntries: Array.from(liveMap.entries()),
        scrapedEntries: Array.from(scrapedMap.entries()),
      }),
      'utf8'
    );
    console.log(`   Cached scraped data to ${CACHE_PATH}`);
  }

  if (SCRAPE_ONLY) {
    console.log('[SCRAPE ONLY] Finished caching /womens-fashion & /jewellery pages.');
    process.exit(0);
  }

  const byId = new Map<string, Product>();
  for (const p of allProducts) byId.set(p.id, p);

  const slugList = Array.from(scrapedMap.keys());
  const updatedProductsToSync: Product[] = [];
  const sizedItemsAudit: Array<{ id: string; cat: string; subcat: string; title: string; size: string; color?: string }> = [];
  const noSizeStitchedCandidatesCheck: Array<{ id: string; sub: string; title: string; descSnippet: string }> = [];
  const reassignedOut: Array<{ id: string; oldCat?: string; newCat: string; title: string; bc: string }> = [];
  const sizeDistribution: Record<string, number> = {};
  const colorDistribution: Record<string, number> = {};

  let womensTotal = 0;
  let womensWithSize = 0;
  let womensWithColor = 0;
  let jewelryTotal = 0;
  let jewelryWithSize = 0;
  let jewelryWithColor = 0;
  let fixedCorruptTitles = 0;

  for (const slug of slugList) {
    const id = `dsp-${slug}`;
    const existing = byId.get(id);
    const liveCard = liveMap.get(slug);
    const info = scrapedMap.get(slug);

    // Handle offline/404 items already in womens-fashion or jewelry: normalize their stale subcategories!
    if (!info || info.notFound || !info.liveTitle) {
      if (existing && (existing.category === 'womens-fashion' || existing.category === 'jewelry')) {
        const cleanSub =
          existing.category === 'jewelry'
            ? mapJewelrySubcategory('', '', existing.titleEn, existing.subcategory)
            : mapWomensFashionSubcategory('', '', existing.titleEn, existing.subcategory);
        if (existing.subcategory !== cleanSub) {
          const fixedOffline: Product = { ...existing, subcategory: cleanSub, updatedAt: new Date().toISOString() };
          byId.set(id, fixedOffline);
          updatedProductsToSync.push(fixedOffline);
        }
      }
      continue;
    }

    // Protect already-curated winter, mens-fashion, home-lifestyle, kids-zone, gadgets-electronics, and foods items UNLESS they are currently sitting in womens-fashion/jewelry!
    if (
      existing &&
      ['winter', 'mens-fashion', 'home-lifestyle', 'kids-zone', 'gadgets-electronics', 'foods'].includes(existing.category) &&
      info.liveCategorySlug === existing.category
    ) {
      continue;
    }

    const effSub = info.liveSubSlug || liveCard?.sub || '';
    const effSubSub = info.liveSubSubSlug || liveCard?.subsub || '';
    const tLower = info.liveTitle.toLowerCase();

    // 1. Standing rule: Watches always go to 'watches' (including basic-watch with Bengali ঘড়ি in description like Apache 3016!)
    const isWatch =
      isWatchProductTitle(info.liveTitle, info.liveTitle) ||
      effSub === 'watches' ||
      ((effSubSub === 'watch' || effSubSub.includes('watch')) && info.liveCategorySlug !== 'kids-zone');

    // 2. Medical/Support Anklet ("Compression, Support, Pain Relief") & Kitchen Lunch Box ("ketchen-dining") -> 'home-lifestyle'
    const isSupportOrKitchen =
      /\b(?:compression,\s*support|pain\s*relief|electric\s*heated\s*lunch\s*box|lunch\s*box)\b/i.test(info.liveTitle) ||
      effSub.includes('ketchen') ||
      effSub.includes('kitchen');

    // 3. ALL Jewelry items (whether under /womens-fashion/jewellery or anywhere else) MUST go to 'jewelry'!
    const isJewelryAccessoryOverride = /\bsaree\s*pin\b|\bwaist\s*chain\b|\bhathphool\b|শাড়ি\s*পিন|কোমরবন্ধ/i.test(info.liveTitle);
    const isApparelOrBag =
      !isJewelryAccessoryOverride &&
      /(?:\b(?:saree|sharee|three[\s-]*piece|3[\s-]*pcs|two[\s-]*piece|2[\s-]*pcs|salwar|kameez|kurti|borka|burqa|burka|abaya|khimar|hijab|niqab|gown|mexi|maxi|t-?shirt|shirt|panjabi|pant|bag|handbag|purse|backpack|wallet)\b|শাড়ি|শাড়ি|থ্রি[\s-]*পিস|টু[\s-]*পিস|কটি\s*সেট|সালোয়ার|কামিজ|কুর্তি|বোরকা|আবায়া|খিমার|হিজাব|ব্যাগ)/i.test(
        info.liveTitle
      );

    const isJewelry =
      !isWatch &&
      !isSupportOrKitchen &&
      !isApparelOrBag &&
      (isJewelryAccessoryOverride ||
        effSub === 'jewellery' ||
        effSub === 'jewelry' ||
        info.liveCategorySlug === 'jewellery' ||
        info.liveCategorySlug === 'jewelry' ||
        /(?:\b(?:necklace|ear[\s-]*rings?|jhumka|pendant|locket|bangles?|bracelet|churi|kada|anklet|payel|nose[\s-]*pin|nose[\s-]*ring|finger\s*ring|couple\s*ring|jewelry|jewellery|choker|sitahar|mangalsutra|tiara|bridal\s*set)\b|নেকলেস|কানের\s*দুল|ঝুমকা|পেনডেন্ট|লকেট|চুড়ি|চুড়ি|ব্রেসলেট|বালা|পায়েল|নুপুর|নাকফুল|আংটি|গহনা|জুয়েলারি|হার|মালা)/i.test(
          info.liveTitle
        ));

    const isFoods =
      !isWatch &&
      !isJewelry &&
      (['food', 'foods'].includes(info.liveCategorySlug) ||
        effSubSub === 'organic-food' ||
        /\b(?:pure\s*honey|sundarban\s*honey|desi\s*ghee|medjool|ajwa|chia\s*seeds?|slimming.*coffee|weight\s*loss.*coffee)\b|খাঁটি\s*মধু|গাওয়া\s*ঘি/i.test(
          info.liveTitle
        ));

    const isMensFashion =
      !isWatch &&
      !isJewelry &&
      (info.liveCategorySlug === 'mens-fashion' ||
        (/\b(?:men'?s?\s+(?:panjabi|shirt|t-?shirt|polo|jeans|pant|wallet|belt)|panjabi|punjabi|shirt\s*combo\s*pack|half-sleeve\s*polo\s*shirt)\b|পাঞ্জাবি/i.test(
          info.liveTitle
        ) &&
          info.liveCategorySlug !== 'womens-fashion'));

    const isWinter = !isWatch && !isJewelry && info.liveCategorySlug === 'winter';
    const isKidsZone = !isWatch && !isJewelry && info.liveCategorySlug === 'kids-zone';

    const isGadgets =
      !isWatch &&
      !isJewelry &&
      (['gadgets', 'electronics', 'gadgets-electronics'].includes(info.liveCategorySlug) ||
        (/\b(?:earbuds?|airpods?|headphone|neckband|power\s*bank|charger|speaker|microphone|router|trimmer|shaver)\b/i.test(
          tLower
        ) &&
          info.liveCategorySlug !== 'womens-fashion'));

    const isHomeLifestyle =
      !isWatch &&
      !isJewelry &&
      (isSupportOrKitchen || (info.liveCategorySlug === 'home-lifestyle' && !liveMap.has(slug)));

    let targetCat: Product['category'] = 'womens-fashion';
    if (isWatch) targetCat = 'watches';
    else if (isJewelry) targetCat = 'jewelry';
    else if (isFoods) targetCat = 'foods';
    else if (isHomeLifestyle) targetCat = 'home-lifestyle';
    else if (isWinter) targetCat = 'winter';
    else if (isMensFashion) targetCat = 'mens-fashion';
    else if (isKidsZone) targetCat = 'kids-zone';
    else if (isGadgets) targetCat = 'gadgets-electronics';
    else if (info.liveCategorySlug && info.liveCategorySlug !== 'womens-fashion' && !liveMap.has(slug)) {
      targetCat = 'others';
    }

    // Do not overwrite already-curated winter, mens-fashion, home-lifestyle, or watches items if they already reside there!
    if (
      existing &&
      ['winter', 'mens-fashion', 'home-lifestyle', 'watches'].includes(targetCat) &&
      existing.category === targetCat
    ) {
      continue;
    }

    if (existing && existing.category !== targetCat) {
      reassignedOut.push({
        id,
        oldCat: existing.category,
        newCat: targetCat,
        title: info.liveTitle,
        bc: `${info.liveCategorySlug}/${effSub}/${effSubSub}`,
      });
    }

    const retailPrice = info.wholesalePrice > 0 ? info.wholesalePrice + 100 : existing?.price || 590;
    const titleChanged = existing && existing.titleEn.trim() !== info.liveTitle.trim();
    if (titleChanged) fixedCorruptTitles++;

    const subcat =
      targetCat === 'womens-fashion'
        ? mapWomensFashionSubcategory(effSub, effSubSub, info.liveTitle, existing?.subcategory)
        : targetCat === 'jewelry'
        ? mapJewelrySubcategory(effSub, effSubSub, info.liveTitle, existing?.subcategory)
        : targetCat === 'watches'
        ? effSubSub.includes('smart') || /\bsmart\s*watch\b/i.test(info.liveTitle)
          ? 'স্মার্টওয়াচ (Smartwatches)'
          : effSubSub.includes('basic')
          ? 'অ্যানালগ ও লাক্সারি ঘড়ি (Luxury Watches)'
          : 'লেডিস ঘড়ি (Ladies Watches)'
        : targetCat === 'mens-fashion'
        ? /\bpolo\b/i.test(info.liveTitle)
          ? 'পোলো টি-শার্ট (Polo T-Shirt)'
          : 'শার্ট (Casual & Formal Shirt)'
        : targetCat === 'home-lifestyle'
        ? /\blunch\s*box|kitchen|ketchen\b/i.test(`${info.liveTitle} ${effSub}`)
          ? 'কিচেন ও ডাইনিং (Kitchen & Dining)'
          : 'ডেইলি লাইফস্টাইল ও হেলথ (Lifestyle & Wellness)'
        : targetCat === 'foods'
        ? 'খাঁটি মধু, ঘি ও অর্গানিক ফুডস (Organic Foods)'
        : existing?.subcategory;

    const finalSizes = extractRealSizesWomensAndJewelry(
      info.detailsBlock,
      info.descriptionFormatted,
      info.liveTitle,
      targetCat,
      effSub,
      effSubSub
    );
    const finalColors = extractRealColorsWomensAndJewelry(
      info.detailsBlock,
      info.descriptionFormatted,
      info.liveTitle,
      targetCat,
      effSub,
      effSubSub
    );

    if (targetCat === 'womens-fashion') {
      womensTotal++;
      if (finalSizes.length > 0) {
        womensWithSize++;
      } else if (isWomensOrJewelrySizeCandidate(info.liveTitle, targetCat, effSub, effSubSub, info.descriptionFormatted)) {
        noSizeStitchedCandidatesCheck.push({
          id,
          sub: `${effSub}/${effSubSub}`,
          title: info.liveTitle,
          descSnippet: info.descriptionFormatted.slice(0, 260).replace(/\n/g, ' | '),
        });
      }
      if (finalColors.length > 0) womensWithColor++;
    } else if (targetCat === 'jewelry') {
      jewelryTotal++;
      if (finalSizes.length > 0) jewelryWithSize++;
      if (finalColors.length > 0) jewelryWithColor++;
    }

    if (finalSizes.length > 0) {
      const sKey = finalSizes.join(', ');
      sizeDistribution[sKey] = (sizeDistribution[sKey] || 0) + 1;
      sizedItemsAudit.push({
        id,
        cat: targetCat,
        subcat: subcat || '',
        title: info.liveTitle,
        size: sKey,
        color: finalColors.join(', ') || undefined,
      });
    }
    if (finalColors.length > 0) {
      const cKey = finalColors.join(', ');
      colorDistribution[cKey] = (colorDistribution[cKey] || 0) + 1;
    }

    const effectivePrice = !existing || titleChanged ? retailPrice : existing.price;
    const variants: ProductVariant[] = [];
    if (finalSizes.length > 0 && finalColors.length > 0) {
      for (const sz of finalSizes) {
        for (const cl of finalColors) {
          variants.push({ size: sz, color: cl, price: effectivePrice, stock: 50 });
        }
      }
    } else if (finalSizes.length > 0) {
      for (const sz of finalSizes) {
        variants.push({ size: sz, price: effectivePrice, stock: 50 });
      }
    } else if (finalColors.length > 0) {
      for (const cl of finalColors) {
        variants.push({ color: cl, price: effectivePrice, stock: 50 });
      }
    }

    const primaryImg = info.galleryImages[0] || liveCard?.thumbImg || existing?.image || '';
    const extraImgs = Array.from(
      new Set([
        ...(info.galleryImages.length > 0 ? info.galleryImages : []),
        ...(liveCard?.thumbImg ? [liveCard.thumbImg] : []),
        ...(liveCard?.hoverImg ? [liveCard.hoverImg] : []),
      ])
    ).filter(Boolean);

    const cleanDesc = info.descriptionFormatted || existing?.descriptionBn || `${info.liveTitle}`;

    const updatedProduct: Product = {
      ...(existing || {
        id,
        rating: 4.8,
        reviewsCount: 15,
        stock: 50,
        status: 'active',
        isFeatured: false,
        freeDelivery: false,
        createdAt: new Date().toISOString(),
      }),
      id,
      titleBn: info.liveTitle,
      titleEn: info.liveTitle,
      category: targetCat,
      ...(subcat ? { subcategory: subcat } : {}),
      price: effectivePrice,
      originalPrice: !existing || titleChanged ? Math.round(effectivePrice * 1.2) : existing.originalPrice,
      discountPercent: !existing || titleChanged ? 17 : existing.discountPercent,
      sku: info.sku || existing?.sku || `DSP-${slug.split('-').pop()}`,
      image: primaryImg,
      additionalImages: extraImgs.length > 0 ? extraImgs : existing?.additionalImages,
      descriptionBn: cleanDesc,
      descriptionEn: cleanDesc,
      specificationsBn: info.specs.length > 0 ? info.specs : existing?.specificationsBn,
      specificationsEn: info.specs.length > 0 ? info.specs : existing?.specificationsEn,
      size: finalSizes.length > 0 ? finalSizes.join(', ') : undefined,
      color: finalColors.length > 0 ? finalColors.join(', ') : undefined,
      variants: variants.length > 0 ? variants : undefined,
      updatedAt: new Date().toISOString(),
    };

    if (!subcat) delete updatedProduct.subcategory;
    if (!updatedProduct.size) delete updatedProduct.size;
    if (!updatedProduct.color) delete updatedProduct.color;
    if (!updatedProduct.variants) delete updatedProduct.variants;

    byId.set(id, updatedProduct);
    updatedProductsToSync.push(updatedProduct);
  }

  fs.writeFileSync(
    '/tmp/womens_jewelry_audit.json',
    JSON.stringify({ sizedItemsAudit, noSizeStitchedCandidatesCheck, reassignedOut }, null, 2),
    'utf8'
  );

  console.log('\n=== WOMENS FASHION & JEWELRY VARIANT EXTRACTION SUMMARY ===');
  console.log({
    totalProcessed: updatedProductsToSync.length,
    womensTotal,
    womensWithSize,
    womensWithColor,
    noSizeStitchedCandidatesCount: noSizeStitchedCandidatesCheck.length,
    jewelryTotal,
    jewelryWithSize,
    jewelryWithColor,
    fixedCorruptTitles,
    reassignedOutCount: reassignedOut.length,
  });

  console.log('\nSized Items Breakdown:', Object.entries(sizeDistribution).sort((a, b) => b[1] - a[1]));
  console.log('\nTop Color Combinations:', Object.entries(colorDistribution).sort((a, b) => b[1] - a[1]).slice(0, 25));

  if (DRY_RUN) {
    console.log('\n[DRY RUN] Wrote /tmp/womens_jewelry_audit.json. Skipping file write and Firestore sync.');
    process.exit(0);
  }

  const finalProducts = Array.from(byId.values());
  fs.writeFileSync(productsPath, JSON.stringify(finalProducts, null, 2), 'utf8');
  console.log(`\n3. Saved ${finalProducts.length} products to src/data/products.json.`);

  console.log(`4. Syncing ${updatedProductsToSync.length} updated products to Firebase Firestore...`);
  await bulkSyncProductsToFirestore(updatedProductsToSync);

  const counts: Record<string, number> = {};
  for (const p of finalProducts) {
    const c = String(p.category || 'others');
    counts[c] = (counts[c] || 0) + 1;
  }
  for (const cat of initialCategories) {
    const newCount = cat.id === 'all' ? finalProducts.length : counts[cat.id] || 0;
    await saveCategoryToFirestore({
      ...cat,
      itemCount: newCount,
    });
  }
  console.log('5. Category counts updated in Firestore:', counts);
  process.exit(0);
}

if (process.argv[1]?.includes('fix_womens_fashion_variants')) {
  main().catch(err => {
    console.error('Fatal error in fix_womens_fashion_variants:', err);
    process.exit(1);
  });
}
