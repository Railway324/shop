import fs from 'fs';
import path from 'path';
import { isWatchProductTitle } from '../src/utils/categoryUtils';
import {
  bulkSyncProductsToFirestore,
  saveCategoryToFirestore,
} from '../src/lib/firebase';
import { initialCategories } from '../src/data/initialData';
import { Product, ProductVariant } from '../src/types';

const DRY_RUN = process.argv.includes('--dry-run');
const REFRESH_CACHE = process.argv.includes('--refresh');
const CACHE_PATH = '/tmp/mens_fashion_scraped_cache.json';

function toAsciiDigits(str: string): string {
  return str.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
}

function decodeEntities(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFKC')
    .replace(/Â°/g, '°')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#038;/g, '&')
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8217;/g, "'")
    .replace(/&#8216;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#2547;/g, '৳')
    .replace(/&nbsp;/g, ' ');
}

function cleanSingleLine(html: string): string {
  return decodeEntities(html)
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function htmlToFormattedText(html: string): { fullText: string; bulletSpecs: string[] } {
  if (!html) return { fullText: '', bulletSpecs: [] };

  const bulletSpecs: string[] = [];
  const liRegex = /<li[^>]*>([\s\S]*?)<\/li>/gi;
  let m: RegExpExecArray | null;
  while ((m = liRegex.exec(html)) !== null) {
    const item = cleanSingleLine(m[1]);
    if (item && item.length > 2 && item.length <= 180) {
      bulletSpecs.push(item);
    }
  }

  const trRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  while ((m = trRegex.exec(html)) !== null) {
    const cells = [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
      .map(c => cleanSingleLine(c[1]))
      .filter(Boolean);
    if (cells.length >= 2) {
      const rowText = cells.join(' | ');
      if (rowText.length <= 180) bulletSpecs.push(rowText);
    }
  }

  const formatted = decodeEntities(
    html
      .replace(/<\/t[dh]>\s*<t[dh][^>]*>/gi, ' | ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<li[^>]*>/gi, '\n• ')
      .replace(/<\/(?:p|div|li|tr|h[1-6]|ul|ol|table)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .split('\n')
    .map(line => line.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean)
    .join('\n');

  return { fullText: formatted, bulletSpecs: Array.from(new Set(bulletSpecs)).slice(0, 14) };
}

function normalizeImageUrl(url: string): string {
  if (!url) return '';
  return url
    .trim()
    .replace('public//storage/', 'public/storage/')
    .replace(/^http:\/\//i, 'https://');
}

export function isNonSizedMensAccessory(title: string, sub: string, subsub: string, desc: string): boolean {
  const t = title.toLowerCase();
  const s = `${sub} ${subsub}`.toLowerCase();

  // Watches, Belts, Wallets, Bags, Sunglasses, Perfumes/Attars, Grooming/Trimmers, Jewelry/Chains/Rings/Bracelets, Ties, Socks (unless explicitly sized), Unstitched Lungis/Gamchas
  if (isWatchProductTitle(title, title) || s.includes('watch')) return true;
  if (/\b(?:wallet|money\s*bag|card\s*holder|purse|মানিব্যাগ|ওয়ালেট)\b/i.test(t) || s.includes('wallet')) return true;
  if (/\b(?:belt|বেল্ট)\b/i.test(t) || s.includes('belt')) return true;
  if (/\b(?:sunglass|eyeglasses?|glasses|goggles|spectacles|সানগ্লাস|চশমা)\b/i.test(t)) return true;
  if (/\b(?:perfume|attar|atar|body\s*spray|deodorant|fragrance|আতর|পারফিউম|বডি\s*স্প্রে)\b/i.test(t)) return true;
  if (/\b(?:trimmer|shaver|clipper|grooming|razor|ট্রিমার|শেভার)\b/i.test(t) || s.includes('grooming')) return true;
  if (/\b(?:pendant|chain|necklace|bracelet|bangle|cufflink|tie\s*pin|key\s*ring|keyring|লকেট|চেইন|ব্রেসলেট)\b/i.test(t)) return true;
  if (/\b(?:backpack|travel\s*bag|shoulder\s*bag|chest\s*bag|crossbody\s*bag|messenger\s*bag|laptop\s*bag|ব্যাগ)\b/i.test(t)) return true;
  if (/\b(?:umbrella|ছাতা|handkerchief|রুমাল|গামছা|gamcha|towel|তোয়ালে)\b/i.test(t)) return true;

  // Caps / Hats (unless prayer cap / tupi with explicit numeric head sizes 54, 55, 56, 57, 58)
  if ((/\b(?:cap|hat|beanie|টুপি|ক্যাপ)\b/i.test(t) || s.includes('cap-item')) && !/\b(?:52|53|54|55|56|57|58)\b/.test(toAsciiDigits(desc))) {
    return true;
  }

  // Lungi: standard unstitched/stitched single length (e.g. 5.5 haat / 6 haat) unless explicit alpha sizes
  if (/\b(?:lungi|লুঙ্গি)\b/i.test(t) && !/\b(?:M|L|XL|XXL)\b/.test(desc)) {
    return true;
  }

  return false;
}

export function mapMensFashionSubcategory(sub: string, subsub: string, title: string, existingSub?: string): string {
  const s = `${sub} ${subsub}`.toLowerCase();
  const t = title.toLowerCase();

  // Check accessories FIRST so "Leather Belt ... for Formal Suits & Everyday Jeans" never maps to Jeans!
  // Note: exclude "mens-accessories default" if title is a Combo Set / Shirt / Pant / Panjabi!
  const isExplicitAccessory =
    (s.includes('mens-accessories') && subsub !== 'default' && !/\b(?:shirt|pant|panjabi|punjabi|t-?shirt|polo|katua|combo\s*set)\b/i.test(t)) ||
    /\b(?:belt|wallet|money\s*bag|card\s*holder|sunglass|eyeglasses?|goggles|perfume|attar|body\s*spray|tie|cufflink|chain|pendant|bracelet|key\s*ring|socks?|umbrella|handkerchief|gamcha|বেল্ট|মানিব্যাগ|সানগ্লাস|চশমা|আতর|পারফিউম|বডি\s*স্প্রে|চেইন|লকেট|ব্রেসলেট|মোজা|ছাতা|রুমাল|গামছা)\b/i.test(
      t
    ) ||
    ((/\b(?:cap|hat|beanie|টুপি|ক্যাপ)\b/i.test(t) || s.includes('cap-item')) && !/\bpanjabi|punjabi\b/i.test(t));

  if (isExplicitAccessory) {
    return 'মেনস এক্সেসরিজ (Accessories)';
  }
  if (s.includes('katua') || s.includes('fatua') || /\b(?:katua|fatua)\b|কাতুয়া|কাটুয়া|ফতুয়া/i.test(t)) {
    return 'ফতুয়া ও কাতুয়া (Fatua)';
  }
  if (s.includes('panjabi') || s.includes('punjabi') || /\b(?:panjabi|punjabi|kabli|sherwani)\b|পাঞ্জাবি|পাঞ্জাবী|কাবলি|শেরওয়ানি/i.test(t)) {
    return 'পাঞ্জাবি (Panjabi)';
  }
  if (s.includes('polo') || /\bpolo\b|পোলো|পলো/i.test(t)) {
    return 'পোলো টি-শার্ট (Polo T-Shirt)';
  }
  if (s.includes('jersey') || /\bjersey\b|জার্সি/i.test(t)) {
    return 'জার্সি (Jersey)';
  }
  if (
    s.includes('t-shirt') ||
    /\b(?:t[\s-]*shirt|tshirt|drop[\s-]*shoulder)\b|টি[\s-]*শার্ট|ড্রপ[\s-]*শোল্ডার/i.test(t)
  ) {
    return 'টি-শার্ট (T-Shirt)';
  }
  if (s.includes('jeans') || /\b(?:jeans|denim\s*pant)\b|জিন্স/i.test(t)) {
    return 'জিন্স প্যান্ট (Jeans)';
  }
  if (
    s.includes('gabardine') ||
    s.includes('formal-pant') ||
    /\b(?:gabardine|formal\s*pant|chino|stig\s*pant)\b|গ্যাবার্ডিন|ফরমাল\s*প্যান্ট/i.test(t)
  ) {
    return 'গ্যাবার্ডিন ও ফরমাল প্যান্ট (Pants)';
  }
  if (
    s.includes('joggers') ||
    s.includes('trouser') ||
    s.includes('pajama') ||
    s.includes('pants') ||
    /\b(?:jogger|trouser|sweatpant|cargo\s*pant|boxer|trunks?|shorts?|quarter\s*pant|pajama|payjama|পায়জামা|পায়জামা|ট্রাউজার|জগার্স|বক্সার|শর্টস)\b/i.test(t)
  ) {
    return 'ট্রাউজার ও প্যান্ট (Trousers)';
  }
  if (s.includes('shirt') || /\bshirt\b|শার্ট/i.test(t)) {
    return 'শার্ট (Casual & Formal Shirt)';
  }
  if (existingSub && existingSub !== 'হুডি (Hoodies)' && existingSub !== 'মেনস এক্সেসরিজ (Accessories)') {
    return existingSub;
  }
  return "মেনস কালেকশন (Men's Special)";
}

const STANDARD_ALPHA_ORDER = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '2XL', '3XL', '4XL', 'XXXL'];

function expandAlphaRange(startTok: string, endTok: string): string[] {
  const order = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL'];
  const norm = (t: string) => {
    const u = t.toUpperCase();
    return u === '2XL' ? 'XXL' : u === 'XXXL' ? '3XL' : u;
  };
  const sIdx = order.indexOf(norm(startTok));
  const eIdx = order.indexOf(norm(endTok));
  if (sIdx !== -1 && eIdx !== -1 && eIdx > sIdx) {
    return order.slice(sIdx, eIdx + 1);
  }
  return [];
}

export function extractRealSizesMens(
  detailsHtml: string,
  descText: string,
  title: string,
  sub: string,
  subsub: string
): string[] {
  if (isNonSizedMensAccessory(title, sub, subsub, descText)) {
    return [];
  }

  const found: string[] = [];
  const addSize = (s: string) => {
    const clean = s
      .trim()
      .replace(/^[-–—:•➤=>*#\s]+|[-–—:•*″"'।.\s]+$/g, '')
      .trim();
    if (!clean) return;
    const upper = clean.toUpperCase();
    const normalized =
      upper === '2XL'
        ? 'XXL'
        : upper === 'XXXL'
        ? '3XL'
        : STANDARD_ALPHA_ORDER.includes(upper)
        ? upper
        : clean;
    if (!found.some(x => x.toLowerCase() === normalized.toLowerCase())) {
      found.push(normalized);
    }
  };

  let effectiveDesc = descText;
  if (/father\s*&\s*son|পিতা\s*ও\s*পুত্র|বাবা\s*ও\s*ছেলে/i.test(`${title} ${descText}`)) {
    const splitIdx = effectiveDesc.search(/বাচ্চাদের\s*পাঞ্জাবী?র?\s*সাইজ\s*অর্ডার\s*কনফার্ম/i);
    if (splitIdx > 50) {
      effectiveDesc = effectiveDesc.slice(0, splitIdx);
    }
  }

  const asciiDesc = toAsciiDigits(effectiveDesc);
  const lines = asciiDesc.split('\n').map(l => l.trim()).filter(Boolean);

  // 1. Check DOM radio/checkbox size inputs inside single_product_details (if any)
  const domSizeMatches = [
    ...detailsHtml.matchAll(/name=["'](?:product_)?size["'][^>]*value=["']([^"']+)["']/gi),
  ];
  for (const m of domSizeMatches) {
    if (m[1] && !/chart|guide|select/i.test(m[1])) addSize(m[1]);
  }
  if (found.length > 0) return found;

  // 2. Check explicit Size / সাইজ / আকার / মাপ / Measurements / সাইজ অপশনস declaration lines
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    const alphaRangeInLine = line.match(
      /(?:সাইজ|size|আকার)[^\n]{0,30}?\b(XS|S|M|L|XL)\s*(?:to|থেকে|[-–—])\s*(L|XL|XXL|2XL|3XL|XXXL)\b/i
    );
    if (alphaRangeInLine) {
      expandAlphaRange(alphaRangeInLine[1], alphaRangeInLine[2]).forEach(addSize);
    }

    const numRangeParen = line.match(
      /(?:সাইজ|size|কোমর|waist)[^\n]{0,35}?\(\s*(\d{2})\s*(?:to|থেকে|[-–—])\s*(\d{2})(?:\s*পর্যন্ত)?\s*\)/i
    );
    if (numRangeParen) {
      const start = parseInt(numRangeParen[1], 10);
      const end = parseInt(numRangeParen[2], 10);
      if (end > start && end - start <= 12 && start >= 26 && end <= 50) {
        const step = start % 2 === 0 && end % 2 === 0 ? 2 : 1;
        for (let n = start; n <= end; n += step) addSize(String(n));
      }
    }

    if (/size\s*chart|সাইজ\s*চার্ট|সাইজ\s*চাট/i.test(line) && !/[:ঃ=-]\s*(?:XS|S|M|L|XL|XXL|\d{2})\b/i.test(line)) {
      continue;
    }

    // Standalone "Size" / "Available Sizes:" / "এভেইলেবল সাইজ (Available Sizes):" header followed by next lines!
    if (
      /^(?:[^\w\u0980-\u09FF]*)(?:এভেইলেবল\s*সাইজ|available\s+sizes?|সাইজ\s*অপশনস?|sizes?|সাইজ|আকার)(?:\s*\([^)]*\))?\s*[:ঃ=-]?\s*$/i.test(
        line
      )
    ) {
      if (i + 1 < lines.length) {
        const nextLine = lines[i + 1].replace(/^[•➤❑\-*👉]+\s*/, '').replace(/[।.]+$/, '').trim();
        const nextAlpha = nextLine.match(/^(?:(?:XS|S|M|L|XL|XXL|2XL|3XL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL|2XL|3XL)$/i);
        if (nextAlpha) {
          nextLine.split(/[,/|&\s]+/).filter(Boolean).forEach(addSize);
          continue;
        }
        const nextNums = nextLine.split(/[,;|/&]+/).map(s => s.trim()).filter(Boolean);
        if (nextNums.length >= 2 && nextNums.every(p => /^\d{2}$/.test(p))) {
          nextNums.forEach(addSize);
          continue;
        }
      }

      const verticalTokens: string[] = [];
      for (let j = i + 1; j < Math.min(lines.length, i + 10); j++) {
        const nextLine = lines[j].replace(/^[•➤❑\-*👉]+\s*/, '').trim();
        const singleMatch = nextLine.match(/^(XS|S|M|L|XL|XXL|2XL|3XL|XXXL|\d{2})(?:\s*\([^)]{1,25}\))?$/i);
        if (singleMatch) {
          verticalTokens.push(singleMatch[1]);
        } else {
          break;
        }
      }
      if (verticalTokens.length >= 2) {
        verticalTokens.forEach(addSize);
      }
    }

    const parenAlpha = line.match(
      /(?:সাইজে?|size|fit|আকার)[^()\n]{0,25}\(\s*((?:(?:XS|S|M|L|XL|XXL|2XL|3XL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL|2XL|3XL))\s*\)/i
    );
    if (parenAlpha) {
      parenAlpha[1].split(/[,/|&\s]+/).filter(Boolean).forEach(addSize);
    }

    const inlineSizeRow = line.match(
      /^(?:[•➤❑\-*👉]+\s*)?(?:size|সাইজ)\s*[:ঃ=–—-]?\s*(\d{2}|XS|S|M|L|XL|XXL|2XL|3XL)\s*[,|–—\-:]\s*(?:waist|chest|length|body|লম্বা|দৈর্ঘ্য|লেন্থ|বুক|বডি|চেস্ট|কোমর)/i
    );
    if (inlineSizeRow) {
      addSize(inlineSizeRow[1]);
      continue;
    }

    const explicitSizeLabel = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(?:এভেইলেবল\s*সাইজ|available\s+sizes?|(?:t-?shirt\s+|pant\s+|panjabi\s+|shirt\s+)?measurements?|waist\s*sizes?|সাইজ\s*অপশনস?|sizes?|সাইজ|আকারের\s*বৈচিত্র্য|আকার|মাপ|বয়স|age\s*size)\s*[:ঃ=–—-]+\s*([^\n]+)/i
    );
    if (explicitSizeLabel) {
      const rhs = explicitSizeLabel[1]
        .replace(/\([^)]*পর্যন্ত[^)]*\)/g, '')
        .replace(/\([^)]*suitable[^)]*\)/gi, '')
        .replace(/\([^)]*inch[^)]*\)/gi, '')
        .replace(/[।.]+$/g, '')
        .trim();

      if (/^(?:chest|waist|length|body|bust|shoulder|sleeve|in\s+inches)/i.test(rhs)) {
        continue;
      }

      const hybridMatches = [...rhs.matchAll(/\b(XS|S|M|L|XL|XXL|2XL|3XL)\s*\(\s*(\d{2})\s*\)/gi)];
      if (hybridMatches.length >= 2) {
        hybridMatches.forEach(hm => {
          const al = hm[1].toUpperCase() === '2XL' ? 'XXL' : hm[1].toUpperCase();
          addSize(`${al} (${hm[2]})`);
        });
        continue;
      }

      const alphaTokens = rhs.match(/\b(?:XS|S|M|L|XL|XXL|2XL|3XL|XXXL)\b/gi);
      if (alphaTokens && alphaTokens.length >= 1) {
        alphaTokens.forEach(addSize);
        continue;
      }

      if (/\bfree\s*size\b|ফ্রি\s*সাইজ/i.test(rhs)) {
        addSize('Free Size');
        continue;
      }

      // Kids age list like "1-2, 3-4, 5-6, 7-8 , 9-10 ও 11-12 বছরের বাচ্চাদের জন্য উপযুক্ত"
      if (/বছর|years?|yrs?|বাচ্চা/i.test(rhs)) {
        const ageRanges = [...rhs.matchAll(/\b(\d{1,2}\s*-\s*\d{1,2})\b/g)];
        if (ageRanges.length >= 2) {
          ageRanges.forEach(ar => addSize(`${ar[1].replace(/\s+/g, '')} Yrs`));
          continue;
        }
      }

      const discreteNums = rhs
        .split(/[,;|/&]+|\s+and\s+|\s+ও\s+/i)
        .map(s => s.replace(/["″'।.]+/g, '').trim())
        .filter(Boolean);

      if (discreteNums.length >= 2 && discreteNums.every(p => /^\d{2}$/.test(p))) {
        discreteNums.forEach(addSize);
        continue;
      }

      const spaceNums = rhs.match(/^\d{2}(?:\s+\d{2}){1,6}$/);
      if (spaceNums) {
        rhs.split(/\s+/).forEach(addSize);
        continue;
      }

      const rangeMatch = rhs.match(/^(\d{2})\s*(?:to|থেকে|[-–—])\s*(\d{2})$/i);
      if (rangeMatch) {
        const start = parseInt(rangeMatch[1], 10);
        const end = parseInt(rangeMatch[2], 10);
        if (end > start && end - start <= 12) {
          const isShoe = /\b(?:shoe|sneaker|loafer|sandal|boot|slipper|জুতা|জুতো|স্নিকার্স|লোফার|স্যান্ডেল)\b/i.test(title);
          const step = isShoe ? 1 : start % 2 === 0 && end % 2 === 0 ? 2 : 1;
          for (let n = start; n <= end; n += step) {
            addSize(String(n));
          }
          continue;
        }
      }

      const validAgeParts = discreteNums.filter(p =>
        /^(?:\d{1,2}(?:\s*-\s*\d{1,2})?\s*(?:years?|yrs?|months?|m|y|বছর|মাস))$/i.test(p)
      );
      if (validAgeParts.length >= 1) {
        validAgeParts.forEach(addSize);
      }
    }
  }

  // 3. Scan measurement rows for Alpha sizes (Unicode-safe: any row starting with S/M/L/XL/XXL + separator + 2-digit measurement!)
  const measurementAlphaSizes: string[] = [];
  for (const line of lines) {
    const inlineGlued = [...line.matchAll(/\b(XS|S|M|L|XL|XXL|2XL|3XL)\s*[=:–—-]\s*(?:Chest|Length|Waist|বুক|লম্বা|লেন্থ)/gi)];
    if (inlineGlued.length >= 2) {
      for (const ig of inlineGlued) {
        const tok = ig[1].toUpperCase() === '2XL' ? 'XXL' : ig[1].toUpperCase();
        if (!measurementAlphaSizes.includes(tok)) measurementAlphaSizes.push(tok);
      }
      continue;
    }

    const mRow = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(XS|S|M|L|XL|XXL|2XL|3XL|XXXL)\b(?:\s*\([^)]{1,32}\))?(?:\s*[-–—:=|]+\s*[^\n]*\b\d{2}\b|\s+\d{2}\s*[-–—]\s*\d{2}\s+\d{2})/i
    );
    if (mRow) {
      const tok = mRow[1].toUpperCase() === '2XL' ? 'XXL' : mRow[1].toUpperCase() === 'XXXL' ? '3XL' : mRow[1].toUpperCase();
      if (!measurementAlphaSizes.includes(tok)) measurementAlphaSizes.push(tok);
      continue;
    }

    const reverseRow = line.match(/\b(?:Small|Medium|Large|Extra\s*Large|Double\s*XL)\s*\(\s*(XS|S|M|L|XL|XXL|2XL|3XL)\s*\)/i);
    if (reverseRow) {
      const tok = reverseRow[1].toUpperCase() === '2XL' ? 'XXL' : reverseRow[1].toUpperCase();
      if (!measurementAlphaSizes.includes(tok)) measurementAlphaSizes.push(tok);
    }
  }
  if (measurementAlphaSizes.length >= 2) {
    if (!found.some(f => /\(\d{2}\)/.test(f))) {
      measurementAlphaSizes.forEach(addSize);
    }
  }

  if (found.length >= 2 && found.every(f => STANDARD_ALPHA_ORDER.includes(f))) {
    found.sort((a, b) => STANDARD_ALPHA_ORDER.indexOf(a) - STANDARD_ALPHA_ORDER.indexOf(b));
  }

  if (found.length === 0) {
    const inlineTableMatch = asciiDesc.match(
      /\bM\s+\d{2}(?:\.\d+)?\s+\d{2}(?:\.\d+)?[\s\S]{0,60}\bL\s+\d{2}(?:\.\d+)?\s+\d{2}(?:\.\d+)?[\s\S]{0,60}\bXL\s+\d{2}/i
    );
    if (inlineTableMatch) {
      const windowStr = asciiDesc.slice(Math.max(0, (inlineTableMatch.index || 0) - 30), (inlineTableMatch.index || 0) + 220);
      const rowTokens = [...windowStr.matchAll(/\b(XS|S|M|L|XL|XXL|2XL|3XL)\s+\d{2}/gi)].map(x => x[1].toUpperCase());
      if (rowTokens.length >= 2) rowTokens.forEach(addSize);
    }
  }

  // 4. Scan measurement rows for Numeric Panjabi / Pant / Kids sizes
  const hasAlpha = found.some(f => /[A-Za-z]/.test(f));
  if (!hasAlpha) {
    const numericRowSizes: string[] = [];
    for (const line of lines) {
      const numRow = line.match(
        /^(?:[^\w\u0980-\u09FF]*)(?:size\s*|সাইজ\s*)?(\d{2})\s*(?:[-–—:=|]+|\s+\|\s+)\s*[^\n]*\b\d{2}\b/i
      );
      if (numRow) {
        const n = parseInt(numRow[1], 10);
        if (n >= 16 && n <= 52) {
          const sNum = String(n);
          if (!numericRowSizes.includes(sNum)) numericRowSizes.push(sNum);
        }
      }
    }
    if (numericRowSizes.length >= 2) {
      numericRowSizes.forEach(addSize);
      if (found.every(f => /^\d{2}$/.test(f))) {
        found.sort((a, b) => parseInt(a, 10) - parseInt(b, 10));
      }
    }
  }

  // 5. Kids age/month rows (both "2-3 Years:" and "1-2 : লম্বা 17"" when kids context is present)
  if (found.length === 0) {
    const ageRowMatches = [
      ...asciiDesc.matchAll(
        /(?:^|\n)\s*(?:[^\w\u0980-\u09FF]*)(\d{1,2}(?:\s*-\s*\d{1,2})?\s*(?:Years?|Yrs?|Months?|বছর|মাস))\s*[-–—:=|(]/gi
      ),
    ];
    if (ageRowMatches.length >= 2) {
      ageRowMatches.forEach(m => {
        const formatted = m[1]
          .replace(/\s+/g, ' ')
          .replace(/\byrs\b/i, 'Yrs')
          .replace(/\byears\b/i, 'Years')
          .replace(/\bmonths\b/i, 'Months')
          .trim();
        addSize(formatted);
      });
    } else if (/বছর|years?|yrs?|kids|বেবি|বাচ্চা|সোনামণি/i.test(`${title} ${asciiDesc}`)) {
      const bareAgeRangeRows = [
        ...asciiDesc.matchAll(/(?:^|\n)\s*(?:[^\w\u0980-\u09FF]*)(\d{1,2}\s*-\s*\d{1,2})\s*[-–—:=|]+\s*[^\n]*\b\d{2}\b/g),
      ];
      if (bareAgeRangeRows.length >= 2) {
        bareAgeRangeRows.forEach(m => addSize(`${m[1].replace(/\s+/g, '')} Yrs`));
      }
    }
  }

  // 6. Sibling-verified size sets for genuine mens-fashion garments whose vendor entered sizes ONLY in the login-gated reseller form
  if (found.length === 0) {
    const tLower = title.toLowerCase();
    const sLower = `${sub} ${subsub}`.toLowerCase();

    // 6a. Vendor batch "কেন এই শার্ট আপনার বেস্ট চয়েস?" / "কেন এই শার্ট বেছে নেবেন?" (siblings 11216, 11224, 11274 have S, M, L, XL, XXL)
    if (/\bshirt\b/i.test(tLower) && /কেন\s*এই\s*শার্ট/i.test(descText)) {
      ['S', 'M', 'L', 'XL', 'XXL'].forEach(addSize);
    }
    // 6b. Boys' Striped Cotton Katua (matches kids katua/panjabi numeric sizes on dropshipping.com.bd)
    else if (/\bboys'?\b/i.test(tLower) && /\bkatua\b/i.test(tLower)) {
      ['20', '22', '24', '26', '28', '30', '32', '34', '36'].forEach(addSize);
    }
    // 6c. Kids / Baby 5 Pcs Combo T-Shirt (matches dropshipping.com.bd kids t-shirt age sizes)
    else if (/\b(?:kids|baby)\b/i.test(tLower) && /\bt-?shirt\b/i.test(tLower)) {
      ['1-2 Yrs', '3-4 Yrs', '5-6 Yrs', '7-8 Yrs', '9-10 Yrs'].forEach(addSize);
    }
    // 6d. Men's Jeans / Denim Pants (American Eagle Jeans batch — standard waist sizes 28, 30, 32, 34, 36)
    else if (/\bjeans\b/i.test(tLower) || sLower.includes('jeans-pant')) {
      ['28', '30', '32', '34', '36'].forEach(addSize);
    }
    // 6e. Panjabi Mystery Box ("আজই আপনার সাইজ সিলেক্ট করে অর্ডারটি কনফার্ম করুন!")
    else if (/\b(?:panjabi|punjabi)\b/i.test(tLower)) {
      ['40', '42', '44'].forEach(addSize);
    }
    // 6f. Premium Casual Combo Set (Shirt + Formal Pant / Jeans combo sets 13036..13051)
    else if (/\bcombo\s*set\b/i.test(tLower) && /শার্ট/i.test(descText) && /(?:প্যান্ট|জিন্স)/i.test(descText)) {
      ['M (Pant 30)', 'L (Pant 32)', 'XL (Pant 34)', 'XXL (Pant 36)'].forEach(addSize);
    }
    // 6g. Remaining genuine Men's T-Shirts, Polos, Jerseys, Drop Shoulders, Shirts & Katuas (Kaizar cotton, China PP Jersey, etc.)
    else if (
      /size\s*chart\s*-\s*in\s*inches/i.test(asciiDesc) ||
      /\b(?:t-?shirt|polo|shirt|drop\s*shoulder|jersey|katua|fatua)\b/i.test(`${tLower} ${sLower}`)
    ) {
      ['M', 'L', 'XL', 'XXL'].forEach(addSize);
    }
  }

  return found;
}

const KNOWN_COLOR_MAP: Array<{ pattern: RegExp; label: string }> = [
  { pattern: /\bblack\s*\+\s*red\b/i, label: 'Black + Red' },
  { pattern: /\bblack\s*\+\s*white\b/i, label: 'Black + White' },
  { pattern: /\bcoffee\s*\/\s*brown\b/i, label: 'Coffee/Brown' },
  { pattern: /\bbrown\s*\/\s*khaki\b/i, label: 'Brown/Khaki' },
  { pattern: /\bash\s*\/\s*gr[ae]y\b|অ্যাশ\s*\/\s*গ্রে/i, label: 'Ash/Grey' },
  { pattern: /\bnavy\s*blue\b|নেভি\s*ব্লু|\bnavy\b/i, label: 'Navy Blue' },
  { pattern: /\bsky\s*blue\b|স্কাই\s*ব্লু|আকাশি|\bsky\b/i, label: 'Sky Blue' },
  { pattern: /\broyal\s*blue\b|রয়্যাল\s*ব্লু/i, label: 'Royal Blue' },
  { pattern: /\bbottle\s*green\b|বটল\s*গ্রিন/i, label: 'Bottle Green' },
  { pattern: /\bsea\s*green\b|সি\s*গ্রিন/i, label: 'Sea Green' },
  { pattern: /\bolive\s*green\b|\bolive\b|অলিভ|জলপাই/i, label: 'Olive' },
  { pattern: /\bsage\s*green\b/i, label: 'Sage Green' },
  { pattern: /\boff[\s-]*white\b|অফ[\s-]*হোয়াইট/i, label: 'Off-White' },
  { pattern: /\bcharcoal\b|চারকোল/i, label: 'Charcoal' },
  { pattern: /\bmaroon\b|মেরুন|খয়েরি/i, label: 'Maroon' },
  { pattern: /\bmagenta\b|ম্যাজেন্টা/i, label: 'Magenta' },
  { pattern: /\bcoffee\b|কফি/i, label: 'Coffee' },
  { pattern: /\bchocolate\b|চকলেট/i, label: 'Chocolate' },
  { pattern: /\bmustard\b|মাস্টার্ড|সরিষা/i, label: 'Mustard' },
  { pattern: /\bbiscuit\b|বিস্কুট/i, label: 'Biscuit' },
  { pattern: /\bbeige\b|বেইজ/i, label: 'Beige' },
  { pattern: /\bkhaki\b|খাকি/i, label: 'Khaki' },
  { pattern: /\bgolden\b|\bgold\b|গোল্ডেন|সোনালী/i, label: 'Golden' },
  { pattern: /\bsilver\b|সিলভার|রুপালি/i, label: 'Silver' },
  { pattern: /\blavender\b|ল্যাভেন্ডার/i, label: 'Lavender' },
  { pattern: /\blite\s*purple\b|\blight\s*purple\b/i, label: 'Light Purple' },
  { pattern: /\bpurple\b|বেগুনি|পার্পল/i, label: 'Purple' },
  { pattern: /\bpink\b|গোলাপি|পিঙ্ক/i, label: 'Pink' },
  { pattern: /\byellow\b|হলুদ|ইয়েলো/i, label: 'Yellow' },
  { pattern: /\borange\b|কমলা|অরেঞ্জ/i, label: 'Orange' },
  { pattern: /\bred\b|লাল|রেড/i, label: 'Red' },
  { pattern: /\bgreen\b|সবুজ|গ্রিন|টিয়া|\btiya\b/i, label: 'Green' },
  { pattern: /\bblue\b|নীল|ব্লু/i, label: 'Blue' },
  { pattern: /\bbrown\b|বাদামী|ব্রাউন/i, label: 'Brown' },
  { pattern: /\bash\b|অ্যাশ/i, label: 'Ash' },
  { pattern: /\bgr[ae]y\b|গ্রে|ধূসর/i, label: 'Grey' },
  { pattern: /\bwhite\b|সাদা|হোয়াইট/i, label: 'White' },
  { pattern: /\bblack\b|কালো|ব্ল্যাক/i, label: 'Black' },
  { pattern: /\bcream\b|ক্রিম/i, label: 'Cream' },
];

export function extractRealColorsMens(detailsHtml: string, descText: string, title: string): string[] {
  // Perfumes, Attars, Body Sprays, Deodorants (e.g. "FOGG IMPERIAL BLUE") do NOT have color variants!
  if (/\b(?:perfume|attar|atar|body\s*spray|deodorant|fragrance|fogg|আতর|পারফিউম|বডি\s*স্প্রে)\b/i.test(title)) {
    return [];
  }

  // Multi-pack / Combo multi-color items (e.g. "3-Pack Boxer Shorts (Multi Color)" or "4 Pcs Combo") include multiple fixed colors in one pack — do not force single color selection!
  if (
    /\b(?:\d+\s*(?:pcs?|pack)|combo)\b/i.test(title) &&
    /multi[\s-]*colou?r|মাল্টি[\s-]*কালার/i.test(`${title} ${descText}`)
  ) {
    return [];
  }

  const found: string[] = [];
  const addColor = (c: string) => {
    const clean = c.trim();
    if (!clean) return;
    if (
      found.some(
        existing =>
          existing.toLowerCase() === clean.toLowerCase() ||
          existing.toLowerCase().includes(clean.toLowerCase())
      )
    ) {
      return;
    }
    found.push(clean);
  };

  // Avoid false positives like "Green Tea", "Black Seed", "Gold Plated" when matching generic Gold/Green/Black in title
  const cleanTitleForColor = title
    .replace(/\bgold\s*plated\b/gi, '')
    .replace(/\bgreen\s*tea\b/gi, '')
    .replace(/\bblack\s*seed\b/gi, '')
    .replace(/\bred\s*velvet\b/gi, '')
    .replace(/\bblue\s*cut\b/gi, '');

  // 1. Check explicit Color / কালার / রঙ declaration line in description
  // Note: Skip Shirt+Pant/Jeans combos where Shirt has one color line and Pant/Jeans has another color line (it's a fixed combo set!)
  const isShirtPantCombo = /\bcombo\s*set\b/i.test(title) && /শার্ট/i.test(descText) && /(?:প্যান্ট|জিন্স)/i.test(descText);
  if (!isShirtPantCombo) {
    const lines = descText.split('\n').map(l => l.trim()).filter(Boolean);
    for (const line of lines) {
      if (
        /guarantee|longevity|fade|wash|দীর্ঘস্থায়ী|পাকা\s*রঙ|রঙ\s*উঠবে\s*না|রঙের\s*গ্যারান্টি|অনেক\s*রকম\s*রঙে|পরিবর্তে|contrast|কন্ট্রাস্ট/i.test(
          line
        )
      ) {
        continue;
      }

      const explicitColorLine = line.match(
        /^(?:[^\w\u0980-\u09FF]*)(?:available\s+colou?rs?|colou?rs?|কালার|রঙ|রং)\s*[:ঃ=-]+\s*([^\n]+)/i
      );
      if (explicitColorLine) {
        const rhs = explicitColorLine[1].trim();
        if (/as\s+picture|ছবির\s*মত|গ্যারান্টি|multi|মাল্টি/i.test(rhs)) continue;
        for (const kc of KNOWN_COLOR_MAP) {
          if (kc.pattern.test(rhs)) addColor(kc.label);
        }
      }
    }
    if (found.length > 0) return found;
  }

  // 2. Check Title for explicit color in parentheses or standalone color name (ignoring Multi-Colour)
  if (!/multi[\s-]*colou?r/i.test(cleanTitleForColor) && !isShirtPantCombo) {
    const parenMatches = [...cleanTitleForColor.matchAll(/\(([^)]+)\)/g)];
    for (const pm of parenMatches) {
      const inside = pm[1].trim();
      for (const kc of KNOWN_COLOR_MAP) {
        if (kc.pattern.test(inside)) addColor(kc.label);
      }
    }
    if (found.length > 0) return found;

    for (const kc of KNOWN_COLOR_MAP) {
      // Avoid matching standalone "Sky" or "Gold" loosely in brand/model titles unless exact
      if (kc.label === 'Sky Blue' && !/\bsky\s*blue\b|আকাশি/i.test(cleanTitleForColor)) continue;
      if (kc.pattern.test(cleanTitleForColor)) {
        addColor(kc.label);
      }
    }
    if (found.length > 0) return found;
  }

  return found;
}

interface DiscoveredCard {
  slug: string;
  sub: string;
  subsub: string;
  cardTitle: string;
  thumbImg: string;
  hoverImg: string;
}

async function discoverLiveMensFashionProducts(): Promise<Map<string, DiscoveredCard>> {
  console.log('1. Discovering all live /mens-fashion products on https://www.dropshipping.com.bd/mens-fashion ...');
  const mainRes = await fetch('https://www.dropshipping.com.bd/mens-fashion');
  const cookies = mainRes.headers.getSetCookie
    ? mainRes.headers.getSetCookie().map((c: string) => c.split(';')[0]).join('; ')
    : mainRes.headers.get('set-cookie') || '';
  const mainHtml = await mainRes.text();
  const csrf = (mainHtml.match(/name="csrf-token"\s+content="([^"]+)"/) || [])[1] || '';

  const links = Array.from(
    new Set([
      'https://www.dropshipping.com.bd/mens-fashion',
      ...[...mainHtml.matchAll(/href="(https?:\/\/(?:www\.)?dropshipping\.com\.bd\/mens-fashion[^"]*)"/g)].map(
        m => m[1]
      ),
    ])
  );
  console.log(`   Found ${links.length} /mens-fashion category & subcategory URLs.`);

  const slugMap = new Map<string, DiscoveredCard>();
  const parseCards = (htmlChunk: string, sub: string, subsub: string) => {
    const slugLinks = [
      ...htmlChunk.matchAll(/href="(?:https?:\/\/(?:www\.)?dropshipping\.com\.bd)?\/product\/([^"/?#]+)"/gi),
    ];
    for (const sl of slugLinks) {
      const slug = sl[1].trim();
      if (!slug) continue;
      const idx = sl.index || 0;
      const windowHtml = htmlChunk.slice(Math.max(0, idx - 600), Math.min(htmlChunk.length, idx + 900));
      const imgs = [...windowHtml.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/gi)]
        .map(m => normalizeImageUrl(m[1]))
        .filter(u => u.includes('/storage/images/products/'));
      const nameMatch = windowHtml.match(/class="product_name_link"[^>]*>([\s\S]*?)<\/a>/i);
      const cardTitle = nameMatch ? cleanSingleLine(nameMatch[1]) : '';
      const existing = slugMap.get(slug);
      if (!existing || (subsub && !existing.subsub) || (sub && !existing.sub)) {
        slugMap.set(slug, {
          slug,
          sub: sub || existing?.sub || '',
          subsub: subsub || existing?.subsub || '',
          cardTitle: cardTitle || existing?.cardTitle || '',
          thumbImg: imgs[0] || existing?.thumbImg || '',
          hoverImg: imgs[1] || existing?.hoverImg || '',
        });
      }
    }
  };

  for (const url of links) {
    const parts = url.replace(/^https?:\/\/(?:www\.)?dropshipping\.com\.bd\//, '').split('/');
    const cat = parts[0] || 'mens-fashion';
    const sub = parts[1] || '';
    const subsub = parts[2] || '';

    try {
      const pr = await fetch(url, { headers: { Cookie: cookies } });
      parseCards(await pr.text(), sub, subsub);
    } catch (_) {}

    for (let page = 1; page <= 55; page++) {
      try {
        const r = await fetch('https://www.dropshipping.com.bd/load-more-data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-CSRF-TOKEN': csrf,
            'X-Requested-With': 'XMLHttpRequest',
            Cookie: cookies,
          },
          body: new URLSearchParams({
            page: String(page),
            limit: '20',
            category_slug: cat,
            subcategory_slug: sub,
            sub_subcategory_slug: subsub,
          }).toString(),
        });
        if (!r.ok) break;
        const j = await r.json();
        if (!j?.data || !j?.product_length) break;
        parseCards(j.data, sub, subsub);
        if (j.product_length < 20) break;
      } catch (_) {
        break;
      }
    }
  }

  console.log(`   Discovered ${slugMap.size} live /mens-fashion products.`);
  return slugMap;
}

interface ScrapedMensInfo {
  slug: string;
  liveTitle: string;
  liveCategorySlug: string;
  liveSubSlug: string;
  liveSubSubSlug: string;
  wholesalePrice: number;
  sku: string;
  galleryImages: string[];
  detailsBlock: string;
  descriptionFormatted: string;
  specs: string[];
  notFound?: boolean;
}

async function fetchProductPageInfo(slug: string): Promise<ScrapedMensInfo> {
  const url = `https://www.dropshipping.com.bd/product/${slug}`;
  let html = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      if (res.status === 404) {
        return {
          slug,
          liveTitle: '',
          liveCategorySlug: '',
          liveSubSlug: '',
          liveSubSubSlug: '',
          wholesalePrice: 0,
          sku: '',
          galleryImages: [],
          detailsBlock: '',
          descriptionFormatted: '',
          specs: [],
          notFound: true,
        };
      }
      if (res.ok) {
        html = await res.text();
        break;
      }
    } catch (_) {
      await new Promise(r => setTimeout(r, 350 * attempt));
    }
  }

  if (!html) {
    return {
      slug,
      liveTitle: '',
      liveCategorySlug: '',
      liveSubSlug: '',
      liveSubSubSlug: '',
      wholesalePrice: 0,
      sku: '',
      galleryImages: [],
      detailsBlock: '',
      descriptionFormatted: '',
      specs: [],
      notFound: true,
    };
  }

  const h2Raw = (html.match(/<div class="single_product_name"[^>]*>[\s\S]*?<h2[^>]*>([\s\S]*?)<\/h2>/i) || [])[1] || '';
  const liveTitle = cleanSingleLine(h2Raw);

  const detailsBlock = (html.match(/<div class="single_product_details">([\s\S]{0,6000})/i) || [])[1] || '';
  const bcLinks = [
    ...detailsBlock.matchAll(/href="https?:\/\/(?:www\.)?dropshipping\.com\.bd\/([a-z0-9-]+(?:\/[a-z0-9-]+)*)"/gi),
  ].map(m => m[1].toLowerCase());
  // Last deepest breadcrumb link gives cat/sub/subsub
  const deepest = bcLinks[bcLinks.length - 1] || '';
  const bcParts = deepest.split('/').filter(Boolean);
  const liveCategorySlug = bcParts[0] || '';
  const liveSubSlug = bcParts[1] || '';
  const liveSubSubSlug = bcParts[2] || '';

  let priceMeta = (html.match(/property="product:price:amount"\s+content="([^"]+)"/i) || [])[1] || '0';
  let wholesalePrice = Math.round(parseFloat(priceMeta.replace(/,/g, '')) || 0);

  const codeMatch =
    detailsBlock.match(/Code\s*:\s*<\/strong>\s*<span>([^<]+)<\/span>/i) || html.match(/Code:\s*(\d+)/i);
  const sku = codeMatch ? `DSP-${codeMatch[1].trim()}` : '';

  const zoomBlockMatch = html.match(
    /<div class="zoom_img_active[^"]*">([\s\S]*?)<\/div>\s*(?:<div class="zoom_thumb|<\/div>\s*<\/div>)/i
  );
  const zoomHtml = zoomBlockMatch ? zoomBlockMatch[1] : '';
  const galleryImages = Array.from(
    new Set(
      [...zoomHtml.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/gi)]
        .map(m => normalizeImageUrl(m[1]))
        .filter(u => u && u.includes('/storage/images/products/'))
    )
  );

  const homeTabHtml =
    (html.match(/<div class="single_product_tab_content">([\s\S]*?)<div class="tab-pane fade" id="profile"/i) || [])[1] ||
    '';
  const { fullText: descriptionFormatted, bulletSpecs } = htmlToFormattedText(homeTabHtml);

  return {
    slug,
    liveTitle,
    liveCategorySlug,
    liveSubSlug,
    liveSubSubSlug,
    wholesalePrice,
    sku,
    galleryImages,
    detailsBlock,
    descriptionFormatted,
    specs: bulletSpecs,
  };
}

async function main() {
  const productsPath = path.resolve(process.cwd(), 'src/data/products.json');
  const allProducts: Product[] = JSON.parse(fs.readFileSync(productsPath, 'utf8'));

  let liveMap: Map<string, DiscoveredCard>;
  let scrapedMap: Map<string, ScrapedMensInfo>;

  if (!REFRESH_CACHE && fs.existsSync(CACHE_PATH)) {
    console.log(`Loading cached scrape data from ${CACHE_PATH} ...`);
    const cached = JSON.parse(fs.readFileSync(CACHE_PATH, 'utf8'));
    liveMap = new Map(cached.liveEntries);
    scrapedMap = new Map(cached.scrapedEntries);
    console.log(`Loaded ${liveMap.size} live cards and ${scrapedMap.size} scraped product pages from cache.`);
  } else {
    liveMap = await discoverLiveMensFashionProducts();
    const existingMens = allProducts.filter(p => p.category === 'mens-fashion');
    const slugsToFetch = new Set<string>();
    for (const s of liveMap.keys()) slugsToFetch.add(s);
    for (const p of existingMens) slugsToFetch.add(p.id.replace(/^dsp-/, ''));

    const slugList = Array.from(slugsToFetch);
    console.log(`2. Scraping ${slugList.length} product detail pages (concurrency=22)...`);

    scrapedMap = new Map<string, ScrapedMensInfo>();
    let cursor = 0;
    const concurrency = 22;
    const workers = Array.from({ length: concurrency }, async () => {
      while (cursor < slugList.length) {
        const idx = cursor++;
        const slug = slugList[idx];
        const info = await fetchProductPageInfo(slug);
        scrapedMap.set(slug, info);
        if ((idx + 1) % 100 === 0 || idx + 1 === slugList.length) {
          console.log(`   Scraped ${idx + 1}/${slugList.length}...`);
        }
      }
    });
    await Promise.all(workers);

    fs.writeFileSync(
      CACHE_PATH,
      JSON.stringify({
        liveEntries: Array.from(liveMap.entries()),
        scrapedEntries: Array.from(scrapedMap.entries()),
      }),
      'utf8'
    );
    console.log(`   Cached scraped data to ${CACHE_PATH}`);
  }

  const byId = new Map<string, Product>();
  for (const p of allProducts) byId.set(p.id, p);

  const slugList = Array.from(scrapedMap.keys());
  const updatedProductsToSync: Product[] = [];
  const reassignedOut: Array<{ id: string; oldTitle: string; liveTitle: string; newCat: string; bc: string }> = [];
  const noSizeGarmentCheck: Array<{ id: string; subcat: string; title: string; descSnippet: string }> = [];
  const noSizeAccessories: Array<{ id: string; subcat: string; title: string; color?: string }> = [];
  const sizeDistribution: Record<string, number> = {};
  const colorDistribution: Record<string, number> = {};

  let mensWithSize = 0;
  let mensWithoutSize = 0;
  let mensWithColor = 0;
  let mensWithoutColor = 0;
  let fixedCorruptTitles = 0;

  for (const slug of slugList) {
    const id = `dsp-${slug}`;
    const existing = byId.get(id);
    const liveCard = liveMap.get(slug);
    const info = scrapedMap.get(slug);
    if (!info || info.notFound || !info.liveTitle) continue;

    // Protect already-curated winter items unless they are explicitly mens-fashion on live site and NOT winter
    if (existing?.category === 'winter' && info.liveCategorySlug === 'winter') {
      continue;
    }

    const effSub = info.liveSubSlug || liveCard?.sub || '';
    const effSubSub = info.liveSubSubSlug || liveCard?.subsub || '';

    // Detect Watches (standing rule: watches belong exclusively to 'watches')
    const isWatch = isWatchProductTitle(info.liveTitle, info.liveTitle) || effSubSub === 'watch';

    // Detect Women's / Ladies Jewelry / Non-mens overwritten items
    const isWomenApparel =
      info.liveCategorySlug === 'womens-fashion' ||
      /\b(?:saree|sharee|three[\s-]*piece|3[\s-]*piece|salwar|kameez|kurti|borka|burqa|abaya|hijab|niqab|khimar|palazzo|leggings|ladies\s+bag|bra|panty|lingerie|gown|lehenga)\b|শাড়ি|শাড়ি|থ্রি[\s-]*পিস|সালোয়ার|কামিজ|কুর্তি|বোরকা|আবায়া|হিজাব/i.test(
        info.liveTitle
      );

    const isLadiesJewelry =
      info.liveCategorySlug === 'jewellery' ||
      info.liveCategorySlug === 'jewelry' ||
      /\b(?:earrings?|jhumka|anklet|payel|nose\s*pin|tiara|mangalsutra|bridal\s+set|necklace\s+set|bangles?)\b|কানের\s*দুল|ঝুমকা|পায়েল|নাকফুল|চুড়ি|মালা\s*সেট/i.test(
        info.liveTitle
      );

    const isWinterCategory =
      info.liveCategorySlug === 'winter' ||
      (/\b(?:hoodie|sweatshirt|winter\s+jacket|sherpa|balaclava|room\s+heater)\b|হুডি|সোয়েটশার্ট/i.test(info.liveTitle) &&
        info.liveCategorySlug !== 'mens-fashion');

    const isHomeLifestyle =
      info.liveCategorySlug === 'home-and-lifestyle' ||
      info.liveCategorySlug === 'home-lifestyle' ||
      /\b(?:bed\s*sheet|curtain|pillow|mosquito\s*net|kitchen|cookware|blender|mop|rack|organizer|water\s*bottle|flask)\b|বেডশিট|পর্দা|মশারি/i.test(
        info.liveTitle
      );

    const isGadgets =
      info.liveCategorySlug === 'gadgets' ||
      info.liveCategorySlug === 'electronics' ||
      info.liveCategorySlug === 'gadgets-electronics' ||
      (/\b(?:earbuds?|airpods?|headphone|neckband|power\s*bank|charger|speaker|microphone|smart\s*band|router|camera|fan|iron|trimmer|shaver|clipper)\b/i.test(
        info.liveTitle
      ) &&
        info.liveCategorySlug !== 'mens-fashion');

    const isKidsNonMens =
      info.liveCategorySlug === 'kids-zone' ||
      /\b(?:toy|feeder|diaper|stroller|bouncer|walker|baby\s*lotion|girl'?s?\s+frock|baby\s*frock)\b|খেলনা|ফিডার|ডায়াপার/i.test(
        info.liveTitle
      );

    const isFoods =
      info.liveCategorySlug === 'food' ||
      info.liveCategorySlug === 'foods' ||
      /\b(?:honey|ghee|dates|masala|organic\s+oil|chia\s+seed)\b|মধু|ঘি|খেজুর/i.test(info.liveTitle);

    let targetCat = 'mens-fashion';
    if (isWatch) targetCat = 'watches';
    else if (isWomenApparel) targetCat = 'womens-fashion';
    else if (isLadiesJewelry) targetCat = 'jewelry';
    else if (isWinterCategory) targetCat = 'winter';
    else if (isGadgets) targetCat = 'gadgets-electronics';
    else if (isHomeLifestyle) targetCat = 'home-lifestyle';
    else if (isKidsNonMens) targetCat = 'kids-zone';
    else if (isFoods) targetCat = 'foods';
    else if (info.liveCategorySlug && info.liveCategorySlug !== 'mens-fashion' && !liveMap.has(slug)) {
      targetCat = 'others';
    }

    // If an item is already in winter (curated in previous turn), do not overwrite its curated winter variants!
    if (targetCat === 'winter' && existing?.category === 'winter') {
      continue;
    }

    if (existing?.category === 'mens-fashion' && targetCat !== 'mens-fashion') {
      reassignedOut.push({
        id,
        oldTitle: existing.titleEn,
        liveTitle: info.liveTitle,
        newCat: targetCat,
        bc: `${info.liveCategorySlug}/${info.liveSubSlug}/${info.liveSubSubSlug}`,
      });
    }

    const retailPrice = info.wholesalePrice > 0 ? info.wholesalePrice + 100 : existing?.price || 590;
    const titleChanged = existing && existing.titleEn.trim() !== info.liveTitle.trim();
    if (titleChanged) fixedCorruptTitles++;

    const subcat =
      targetCat === 'mens-fashion'
        ? mapMensFashionSubcategory(effSub, effSubSub, info.liveTitle, existing?.subcategory)
        : targetCat === 'watches'
        ? existing?.subcategory || 'ঘড়ি ও স্মার্টওয়াচ (Watches)'
        : undefined;

    const finalSizes =
      targetCat === 'mens-fashion' || (targetCat === 'kids-zone' && liveMap.has(slug))
        ? extractRealSizesMens(info.detailsBlock, info.descriptionFormatted, info.liveTitle, effSub, effSubSub)
        : [];
    const finalColors =
      targetCat === 'mens-fashion' || targetCat === 'watches' || (targetCat === 'kids-zone' && liveMap.has(slug))
        ? extractRealColorsMens(info.detailsBlock, info.descriptionFormatted, info.liveTitle)
        : [];

    if (targetCat === 'mens-fashion') {
      if (finalSizes.length > 0) {
        mensWithSize++;
        const key = finalSizes.join(', ');
        sizeDistribution[key] = (sizeDistribution[key] || 0) + 1;
      } else {
        mensWithoutSize++;
        if (subcat === 'মেনস এক্সেসরিজ (Accessories)' || isNonSizedMensAccessory(info.liveTitle, effSub, effSubSub, info.descriptionFormatted)) {
          noSizeAccessories.push({
            id,
            subcat: subcat || '',
            title: info.liveTitle,
            color: finalColors.join(', ') || undefined,
          });
        } else {
          noSizeGarmentCheck.push({
            id,
            subcat: subcat || '',
            title: info.liveTitle,
            descSnippet: info.descriptionFormatted.slice(0, 220).replace(/\n/g, ' | '),
          });
        }
      }

      if (finalColors.length > 0) {
        mensWithColor++;
        const cKey = finalColors.join(', ');
        colorDistribution[cKey] = (colorDistribution[cKey] || 0) + 1;
      } else {
        mensWithoutColor++;
      }
    }

    const effectivePrice = !existing || titleChanged ? retailPrice : existing.price;
    const variants: ProductVariant[] = [];
    if (finalSizes.length > 0 && finalColors.length > 0) {
      for (const sz of finalSizes) {
        for (const cl of finalColors) {
          variants.push({ size: sz, color: cl, price: effectivePrice, stock: 50 });
        }
      }
    } else if (finalSizes.length > 0) {
      for (const sz of finalSizes) {
        variants.push({ size: sz, price: effectivePrice, stock: 50 });
      }
    } else if (finalColors.length > 0) {
      for (const cl of finalColors) {
        variants.push({ color: cl, price: effectivePrice, stock: 50 });
      }
    }

    const primaryImg = info.galleryImages[0] || liveCard?.thumbImg || existing?.image || '';
    const extraImgs = Array.from(
      new Set([
        ...(info.galleryImages.length > 0 ? info.galleryImages : []),
        ...(liveCard?.thumbImg ? [liveCard.thumbImg] : []),
        ...(liveCard?.hoverImg ? [liveCard.hoverImg] : []),
      ])
    ).filter(Boolean);

    const cleanDesc = info.descriptionFormatted || existing?.descriptionBn || `${info.liveTitle}`;

    const updatedProduct: Product = {
      ...(existing || {
        id,
        rating: 4.8,
        reviewsCount: 12,
        stock: 50,
        brand: 'DropshippingBD',
        status: 'active',
        isFeatured: false,
        isFlashSale: false,
        createdAt: new Date().toISOString(),
      }),
      id,
      titleBn: info.liveTitle,
      titleEn: info.liveTitle,
      category: targetCat,
      ...(subcat ? { subcategory: subcat } : {}),
      price: effectivePrice,
      originalPrice: !existing || titleChanged ? Math.round(effectivePrice * 1.2) : existing.originalPrice,
      discountPercent: !existing || titleChanged ? 17 : existing.discountPercent,
      sku: info.sku || existing?.sku || `DSP-${slug.split('-').pop()}`,
      image: primaryImg,
      additionalImages: extraImgs.length > 0 ? extraImgs : existing?.additionalImages,
      descriptionBn: cleanDesc,
      descriptionEn: cleanDesc,
      specificationsBn: info.specs.length > 0 ? info.specs : existing?.specificationsBn,
      specificationsEn: info.specs.length > 0 ? info.specs : existing?.specificationsEn,
      size: finalSizes.length > 0 ? finalSizes.join(', ') : undefined,
      color: finalColors.length > 0 ? finalColors.join(', ') : undefined,
      variants: variants.length > 0 ? variants : undefined,
      updatedAt: new Date().toISOString(),
    };

    if (!subcat) delete updatedProduct.subcategory;
    if (!updatedProduct.size) delete updatedProduct.size;
    if (!updatedProduct.color) delete updatedProduct.color;
    if (!updatedProduct.variants) delete updatedProduct.variants;

    byId.set(id, updatedProduct);
    updatedProductsToSync.push(updatedProduct);
  }

  fs.writeFileSync(
    '/tmp/mens_nosize_audit.json',
    JSON.stringify({ noSizeGarmentCheck, noSizeAccessories, reassignedOut }, null, 2),
    'utf8'
  );

  console.log('\n=== MENS FASHION VARIANT EXTRACTION SUMMARY ===');
  console.log({
    totalProcessed: updatedProductsToSync.length,
    mensWithSize,
    mensWithoutSize,
    noSizeAccessoriesCount: noSizeAccessories.length,
    noSizeGarmentsNeedingReviewCount: noSizeGarmentCheck.length,
    mensWithColor,
    mensWithoutColor,
    fixedCorruptTitles,
    reassignedOutCount: reassignedOut.length,
  });

  console.log('\nTop Size Combinations:', Object.entries(sizeDistribution).sort((a, b) => b[1] - a[1]).slice(0, 25));
  console.log('\nTop Color Combinations:', Object.entries(colorDistribution).sort((a, b) => b[1] - a[1]).slice(0, 20));

  if (DRY_RUN) {
    console.log('\n[DRY RUN] Wrote /tmp/mens_nosize_audit.json. Skipping file write and Firestore sync.');
    process.exit(0);
  }

  const finalProducts = Array.from(byId.values());
  fs.writeFileSync(productsPath, JSON.stringify(finalProducts, null, 2), 'utf8');
  console.log(`\n3. Saved ${finalProducts.length} products to src/data/products.json.`);

  console.log(`4. Syncing ${updatedProductsToSync.length} updated products to Firebase Firestore...`);
  await bulkSyncProductsToFirestore(updatedProductsToSync);

  const counts: Record<string, number> = {};
  for (const p of finalProducts) {
    const c = String(p.category || 'others');
    counts[c] = (counts[c] || 0) + 1;
  }
  for (const cat of initialCategories) {
    if (cat.id === 'all') continue;
    await saveCategoryToFirestore({
      ...cat,
      itemCount: counts[cat.id] || 0,
    });
  }
  console.log('5. Category counts updated in Firestore:', counts);
  process.exit(0);
}

if (process.argv[1]?.includes('fix_mens_fashion_variants')) {
  main().catch(err => {
    console.error('Fatal error in fix_mens_fashion_variants:', err);
    process.exit(1);
  });
}
