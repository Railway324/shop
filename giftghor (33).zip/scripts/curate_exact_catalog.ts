import fs from 'fs';
import path from 'path';
import { bulkSyncProductsToFirestore, saveCategoryToFirestore } from '../src/lib/firebase';
import { initialCategories } from '../src/data/initialData';
import { Product, ProductVariant } from '../src/types';

const DRY_RUN = process.argv.includes('--dry-run');

function toAsciiDigits(str: string): string {
  return str.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
}

function normalizeCleanText(str: string): string {
  if (!str) return '';
  return str
    .replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '')
    .normalize('NFKC')
    .replace(/\uFFFD/g, '')
    .replace(/Â°/g, '°')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#038;/g, '&')
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8217;/g, "'")
    .replace(/&#8216;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#2547;/g, '৳')
    .replace(/&nbsp;/g, ' ');
}

const STANDARD_ALPHA_ORDER = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL'];

function normalizeAlphaToken(tok: string): string {
  const u = tok.toUpperCase();
  if (u === '2XL') return 'XXL';
  if (u === 'XXXL') return '3XL';
  if (u === 'XXXXL') return '4XL';
  return u;
}

const COLOR_DICTIONARY: Array<{ pattern: RegExp; label: string }> = [
  { pattern: /\bhot\s*pink\b|হট\s*পিঙ্ক/i, label: 'Hot Pink' },
  { pattern: /\blight\s*pink\b|\bpastel\s*pink\b|\bblush\s*pink\b|\bbaby\s*pink\b|হালকা\s*গোলাপি/i, label: 'Light Pink' },
  { pattern: /\brose\s*gold\b|রোজ\s*গোল্ড/i, label: 'Rose Gold' },
  { pattern: /\bocean\s*green\b/i, label: 'Ocean Green' },
  { pattern: /\bmint\s*green\b/i, label: 'Mint Green' },
  { pattern: /\blime\s*green\b|\bchartreuse\s*green\b|লাইম\s*গ্রিন/i, label: 'Lime Green' },
  { pattern: /\bsage\s*green\b/i, label: 'Sage Green' },
  { pattern: /\bbottle\s*green\b|বটল\s*গ্রিন/i, label: 'Bottle Green' },
  { pattern: /\bsea\s*green\b|সি\s*গ্রিন/i, label: 'Sea Green' },
  { pattern: /\bolive(?:\s*green)?\b|অলিভ|জলপাই/i, label: 'Olive' },
  { pattern: /\bteal(?:\s*green)?\b|টিল/i, label: 'Teal' },
  { pattern: /\bnavy\s*blue\b|নেভি\s*ব্লু|\bnavy\b/i, label: 'Navy Blue' },
  { pattern: /\bsky\s*(?:lite\s*)?blue\b|\blight\s*sky\b|স্কাই\s*ব্লু|আকাশি|হালকা\s*নীল/i, label: 'Sky Blue' },
  { pattern: /\broyal\s*blue\b|রয়্যাল\s*ব্লু/i, label: 'Royal Blue' },
  { pattern: /\bslate\s*blue\b/i, label: 'Slate Blue' },
  { pattern: /\bturkish\s*blue\b/i, label: 'Turkish Blue' },
  { pattern: /\blight\s*purple\b|\blite\s*purple\b/i, label: 'Light Purple' },
  { pattern: /\blavender\b|ল্যাভেন্ডার|লেভেন্ডার/i, label: 'Lavender' },
  { pattern: /\bmustard(?:\s*yellow)?\b|মাস্টার্ড|সরিষা|বাসন্তী/i, label: 'Mustard' },
  { pattern: /\boff[\s-]*white\b|অফ[\s-]*হোয়াইট/i, label: 'Off-White' },
  { pattern: /\bchili\s*red\b/i, label: 'Chili Red' },
  { pattern: /\bcharcoal\b|চারকোল/i, label: 'Charcoal' },
  { pattern: /\bmaroon\b|মেরুন|খয়েরি/i, label: 'Maroon' },
  { pattern: /\bmagenta\b|ম্যাজেন্টা/i, label: 'Magenta' },
  { pattern: /\bcoffee\b|কফি/i, label: 'Coffee' },
  { pattern: /\bchocolate\b|চকলেট/i, label: 'Chocolate' },
  { pattern: /\bbiscuit\b|বিস্কুট/i, label: 'Biscuit' },
  { pattern: /\bbeige\b|বেইজ|\bnude\b|নুড/i, label: 'Beige' },
  { pattern: /\bkhaki\b|খাকি/i, label: 'Khaki' },
  { pattern: /\bpeach\b|পিচ/i, label: 'Peach' },
  { pattern: /\bpaste\b|\bpest\b|পেস্ট/i, label: 'Paste' },
  { pattern: /\bwine\b|ওয়াইন/i, label: 'Wine' },
  { pattern: /\bamber\b|অ্যাম্বার/i, label: 'Amber' },
  { pattern: /\bgolden\b|\bgold\b|\bipg\s*colou?r\b|গোল্ডেন|সোনালী/i, label: 'Golden' },
  { pattern: /\bsilver(?:-tone)?\b|সিলভার|রুপালি/i, label: 'Silver' },
  { pattern: /\bpurple\b|বেগুনি|পার্পল|\bviolet\b/i, label: 'Purple' },
  { pattern: /\bpink\b|গোলাপি|পিঙ্ক/i, label: 'Pink' },
  { pattern: /\byellow\b|হলুদ|ইয়েলো/i, label: 'Yellow' },
  { pattern: /\borange\b|কমলা|অরেঞ্জ/i, label: 'Orange' },
  { pattern: /\bred\b|লাল|রেড/i, label: 'Red' },
  { pattern: /\bgreen\b|সবুজ|গ্রিন/i, label: 'Green' },
  { pattern: /\bblue\b|\bblu\b|নীল|ব্লু/i, label: 'Blue' },
  { pattern: /\bbrown\b|বাদামী|ব্রাউন/i, label: 'Brown' },
  { pattern: /\bash\b|অ্যাশ/i, label: 'Ash' },
  { pattern: /\bgr[ae]y\b|গ্রে|ধূসর/i, label: 'Grey' },
  { pattern: /\bwhite\b|সাদা|হোয়াইট/i, label: 'White' },
  { pattern: /\bblack\b|কালো|ব্ল্যাক/i, label: 'Black' },
  { pattern: /\bcream\b|ক্রিম/i, label: 'Cream' },
];

function matchColorsOrdered(seg: string): string[] {
  const res: string[] = [];
  let working = seg
    .replace(/\brose\s*gold[\s-]*plated\b/gi, ' ')
    .replace(/\bgold[\s-]*plated\b/gi, ' ')
    .replace(/\bsilver[\s-]*plated\b/gi, ' ')
    .replace(/\brhodium[\s-]*plated\b/gi, ' ')
    .replace(/\b(?:18k|22k|24k)\s*gold\b/gi, ' ')
    .replace(/\bgolden\s*(?:clip|zari|logo|fifa)\b/gi, ' ')
    .replace(/\bstainless\s*steel\b/gi, ' ')
    .replace(/\bgreen\s*tea\b/gi, ' ')
    .replace(/\bblack\s*(?:seed|garlic|cumin|head|dot|board)\b/gi, ' ')
    .replace(/\bwhite\s*(?:sesame|head|board|pearl|crystal)\b/gi, ' ')
    .replace(/\bblue\s*(?:cut|light|tooth)\b/gi, ' ')
    .replace(/\bred\s*(?:velvet|heart|accent|ribbon)\b/gi, ' ')
    .replace(/\bpanc?h?\s*mishali\b/gi, ' ');

  // Sort matches by earliest appearance in string while respecting longer patterns first
  const hits: Array<{ idx: number; label: string }> = [];
  for (const kc of COLOR_DICTIONARY) {
    const m = kc.pattern.exec(working);
    if (m) {
      if (kc.label === 'Golden' && hits.some(h => h.label.includes('Gold'))) continue;
      if (!hits.some(h => h.label.toLowerCase() === kc.label.toLowerCase())) {
        hits.push({ idx: m.index, label: kc.label });
        working = working.replace(new RegExp(kc.pattern.source, 'gi'), mStr => ' '.repeat(mStr.length));
      }
    }
  }
  hits.sort((a, b) => a.idx - b.idx);
  for (const h of hits) res.push(h.label);
  return res;
}

function fixExactTitle(p: Product, cleanDesc: string): string {
  let t = normalizeCleanText(p.titleBn || p.titleEn || '')
    .replace(/\s+/g, ' ')
    .trim();

  // Specific verified truncated / typo fixes
  if (/^remium\b/i.test(t)) {
    t = t.replace(/^remium\b/i, 'Premium');
  }
  if (p.id === 'dsp-cuena-6008-stainless-steel-chronograph-analog-luminous-men' || /Men['’]s Watc$/i.test(t)) {
    t = "CUENA 6008 Stainless Steel Chronograph Analog Luminous Men's Watch";
  }
  if (p.id === 'dsp-bump-and-go-monkey-ice-cream-toy-for-kids-11996' || /Unstitched Cotton Thr$/i.test(t)) {
    t = 'Elegant Mustard Yellow & Slate Blue Printed Unstitched Cotton Three-Piece';
  }
  if (p.id === 'dsp-full-sleeves-double-pocket-kemo-printed-shirt-11679' || /Colored Stone Br$/i.test(t)) {
    t = 'Premium Gold-Plated Floral Necklace with Pearl & Colored Stone Bracelet';
  }
  if (p.id === 'dsp-mens-ban-collar-cotton-shirt-coffee-7083' && /Cotton Shirt-\s*$/i.test(t)) {
    t = "Men's Ban Collar Cotton Shirt (Coffee)";
  }
  if (p.id === 'dsp-three-piece-for-women-3-pice-dress-3346' || /^tiny crystal triangle earrings\s*\|?$/i.test(t)) {
    t = 'Tiny Crystal Triangle Earrings';
  }

  // If title has an unclosed '(' (like "(Black & Red T-Shirt with Shorts S" or "(Men's Solid Navy Blue & Striped Pol")
  const openCount = (t.match(/\(/g) || []).length;
  const closeCount = (t.match(/\)/g) || []).length;
  if (openCount > closeCount) {
    const lastOpenIdx = t.lastIndexOf('(');
    const partialInside = t.slice(lastOpenIdx + 1).trim();
    const firstLines = cleanDesc.split('\n').slice(0, 3).join(' ');
    if (partialInside.length >= 4) {
      const escapedPrefix = partialInside.slice(0, Math.min(20, partialInside.length)).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const fullParenMatch = firstLines.match(new RegExp(`\\((${escapedPrefix}[^)]{1,80})\\)`, 'i'));
      if (fullParenMatch) {
        t = `${t.slice(0, lastOpenIdx)}(${fullParenMatch[1].trim()})`;
      } else if (/\.\.\s*\(\s*Biscuit$/i.test(t)) {
        t = t.replace(/\.\.\s*\(\s*Biscuit$/i, ' (Biscuit)');
      } else {
        t = `${t.replace(/\(\s+/, '(')})`;
      }
    }
  } else if (closeCount > openCount) {
    // Remove extra trailing ')'
    t = t.replace(/\)\s*\)+$/, ')');
  }

  // Clean "( Sky Lite Blue)" spacing inside parens, vendor typos, and trailing dangling symbols "- / | / l"
  t = t
    .replace(/\(\s+/g, '(')
    .replace(/\s+\)/g, ')')
    .replace(/\(blu\s+colore\)/gi, '(Blue)')
    .replace(/\(black\s+brown\s+color\)/gi, '(Black & Brown)')
    .replace(/\(stell\s+chain\s+paste\s+dial\)/gi, '(Steel Chain Paste Dial)')
    .replace(/\(Sigle\s+pcs\)/gi, '(Single Pcs)')
    .replace(/\(Orrange\/\s*black\)/gi, '(Orange / Black)')
    .replace(/\bnavy\s+bule\b/gi, 'Navy Blue')
    .replace(/\bmens's\b/gi, "Men's")
    .replace(/weight\s+lossalvin\.?/gi, 'Weight Loss')
    .replace(/^valentine's\s+day\b/i, "Valentine's Day")
    .replace(/^tiny\s+crystal\s+Circel\b/i, 'Tiny Crystal Circle')
    .replace(/\s*\|\|+\s*/g, ' | ')
    .replace(/\s*\|\s*$/g, '')
    .replace(/\s*[-–—]\s*$/g, '')
    .replace(/\(Argentina\)\s+l$/i, '(Argentina)')
    .replace(/\(chili red\)/i, '(Chili Red)')
    .trim();

  return t;
}

function isKidsWearable(title: string, desc: string): boolean {
  const t = title.toLowerCase();
  if (
    /\b(?:frocks?|shorts?\s*set|trouser\s*set|pants?\s*set|pajama\s*set|two[\s-]*piece|2[\s-]*piece|t-?shirts?|shirts?|polos?|panjabis?|punjabis?|katuas?|fatuas?|hoodies?|sweatshirts?|winter\s*suits?|rompers?|jumpsuits?|jersey\s*set|raincoats?|rain\s*coats?|rain\s*jackets?|borkas?|burqas?|abayas?|lehengas?|skirts?|gowns?|shoes?|sneakers?|sandals?|boots?|slippers?|loafers?|koshai|kubamu)\b|টি-শার্ট|ফ্রক|পাঞ্জাবি|বোরকা|হুডি|জ্যাকেট|রেইনকোট|জুতা|স্যান্ডেল/i.test(
      t
    )
  ) {
    // Guard against boxing set / toy / plush doll (but allow "Doll Printed" clothing!)
    if (/\b(?:boxing\s*set|toy\s*doll|plush\s*doll|princess\s*dolls?|toy)\b/i.test(t)) return false;
    return true;
  }
  return false;
}

function extractKidsSizes(title: string, desc: string, existingSize?: string): string[] {
  if (!isKidsWearable(title, desc)) {
    return [];
  }

  // Keep already-verified kids sizes (e.g. L, XL, XXL, 3XL, 4XL on raincoat or S, M, L on Panda Winter Suit) unless missing
  if (existingSize && existingSize.trim()) {
    const existingParts = existingSize.split(/[,;|]+/).map(s => s.trim()).filter(Boolean);
    if (existingParts.length >= 1) return existingParts;
  }

  const found: string[] = [];
  const addSize = (s: string) => {
    const clean = s.trim().replace(/^[-–—:•➤=>*#\s]+|[-–—:•*″"'।.\s]+$/g, '').trim();
    if (!clean) return;
    const norm = normalizeAlphaToken(clean);
    const finalTok = STANDARD_ALPHA_ORDER.includes(norm) ? norm : clean;
    if (!found.some(x => x.toLowerCase() === finalTok.toLowerCase())) {
      found.push(finalTok);
    }
  };

  const asciiDesc = toAsciiDigits(desc);
  const lines = asciiDesc.split('\n').map(l => l.trim()).filter(Boolean);

  // 1. Kids Jersey / Hoodie age rows like "1Y 11" 15"" or "• 2yrs-Lenth-15" ,Chest-25""
  const yRows = [...asciiDesc.matchAll(/(?:^|\n)\s*(\d{1,2}Y)\s+\d{1,2}(?:\.\d+)?["″']/gi)].map(m => m[1].toUpperCase());
  if (yRows.length >= 2) {
    yRows.forEach(addSize);
    return found;
  }
  const yrsRows = [...asciiDesc.matchAll(/(?:^|\n)\s*[•*➤-]?\s*(\d{1,2})\s*yrs?\s*[-–—:=]+[^\n]*(?:lenth|length|chest)/gi)].map(
    m => `${m[1]} Yrs`
  );
  if (yrsRows.length >= 3) {
    Array.from(new Set(yrsRows))
      .sort((a, b) => parseInt(a, 10) - parseInt(b, 10))
      .forEach(addSize);
    return found;
  }

  // 2. Explicit Size / সাইজ / উপলব্ধ সাইজ / আকারের বৈচিত্র্য line (supports up to 12 discrete numeric sizes like 16..32!)
  for (const line of lines) {
    const explicitLabel = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(?:এভেইলেবল\s*সাইজ|উপলব্ধ\s*সাইজ|available\s+sizes?|সাইজ\s*অপশনস?|sizes?|সাইজ|আকারের\s*বৈচিত্র্য|আকার)\s*(?:\([^)]{1,25}\))?\s*[:ঃ=–—-]+\s*([^\n]+)/i
    );
    if (explicitLabel) {
      const rhs = explicitLabel[1]
        .replace(/\([^)]*\)/g, '')
        .replace(/[।.]+$/g, '')
        .trim();
      if (/^(?:chest|waist|length|body)/i.test(rhs)) continue;

      const alphaTokens = rhs.match(/\b(?:XS|S|M|L|XL|XXL|2XL|3XL|4XL)\b/gi);
      if (alphaTokens && alphaTokens.length >= 2) {
        alphaTokens.forEach(addSize);
        return found;
      }

      if (/বছর|years?|yrs?|বাচ্চা/i.test(rhs)) {
        const ageRanges = [...rhs.matchAll(/\b(\d{1,2}\s*-\s*\d{1,2})\b/g)];
        if (ageRanges.length >= 2) {
          ageRanges.forEach(ar => addSize(`${ar[1].replace(/\s+/g, '')} Yrs`));
          return found;
        }
      }

      const discreteNums = rhs
        .split(/[,;|/&]+|\s+and\s+|\s+ও\s+|\s+এবং\s+/i)
        .map(s => s.replace(/["″'।.]+/g, '').trim())
        .filter(Boolean);
      if (discreteNums.length >= 2 && discreteNums.length <= 14 && discreteNums.every(p => /^\d{2}$/.test(p))) {
        discreteNums.forEach(addSize);
        return found;
      }
    }
  }

  // 3. Measurement rows: numeric (e.g. "20 - Chest...", "১৬ | ...") or Alpha ("M = ...") or Age ("2-3 Years: ...")
  const numRows: string[] = [];
  const alphaRows: string[] = [];
  for (const line of lines) {
    const aRow = line.match(/^(?:[^\w\u0980-\u09FF]*)(XS|S|M|L|XL|XXL|2XL|3XL)\b(?:\s*\([^)]{1,25}\))?\s*[-–—:=|]+\s*[^\n]*\d+/i);
    if (aRow) {
      const tok = normalizeAlphaToken(aRow[1]);
      if (!alphaRows.includes(tok)) alphaRows.push(tok);
    }
    const nRow = line.match(/^(?:[^\w\u0980-\u09FF]*)(?:size\s*|সাইজ\s*)?(\d{2})\s*(?:[-–—:=|]+|\s+\|\s+)\s*[^\n]*\b\d{2}\b/i);
    if (nRow) {
      const n = parseInt(nRow[1], 10);
      if (n >= 14 && n <= 44 && !numRows.includes(String(n))) numRows.push(String(n));
    }
  }
  if (alphaRows.length >= 2) {
    alphaRows.forEach(addSize);
    return found;
  }
  if (numRows.length >= 2) {
    numRows.sort((a, b) => parseInt(a, 10) - parseInt(b, 10)).forEach(addSize);
    return found;
  }

  // 4. Explicit Baby / Kids Age Group declarations in description or title
  if (/6\s*months?\s*(?:to|[-–—])\s*6\s*years?|6\s*মাস\s*থেকে\s*6\s*বছর/i.test(asciiDesc)) {
    return ['6-12 Months', '1-2 Yrs', '3-4 Yrs', '5-6 Yrs'];
  }
  if (/6\s*months?\s*(?:to|[-–—])\s*1\s*year|6\s*মাস\s*থেকে\s*1\s*বছর/i.test(asciiDesc)) {
    return ['6-12 Months'];
  }
  if (/0\s*(?:to|[-–—]|থেকে)\s*1\s*(?:year|বছর)/i.test(asciiDesc) && !/1\s*(?:to|[-–—]|থেকে)\s*2/i.test(asciiDesc)) {
    return ['0-12 Months'];
  }
  if (/(?:2\s*(?:বছর\s*)?(?:থেকে|to|[-–—])\s*12\s*(?:বছর|years?))|\(2\s*[-–—]\s*12\s*years?\)/i.test(`${title} ${asciiDesc}`)) {
    return ['2-3 Yrs', '4-5 Yrs', '6-7 Yrs', '8-9 Yrs', '10-12 Yrs'];
  }
  if (/2\s*(?:বছর\s*)?(?:থেকে|to|[-–—])\s*8\s*(?:বছর|years?)/i.test(asciiDesc)) {
    return ['2-3 Yrs', '4-5 Yrs', '6-8 Yrs'];
  }
  if (/6\s*(?:বছর\s*)?(?:থেকে|to|[-–—])\s*12\s*(?:বছর|years?)/i.test(asciiDesc)) {
    return ['6-7 Yrs', '8-9 Yrs', '10-12 Yrs'];
  }

  // 5. Sibling Kids Cotton Baby T-Shirts (e.g. Ek Diner Koshai / Eider Diner Koshai / Baby T-Shirt batch 8023..8843) & remaining 2-piece kids sets
  if (/\bbaby\s*t-?shirt\b|বেবি\s*টি-শার্ট|koshai|kubamu/i.test(title)) {
    return ['1-2 Yrs', '3-4 Yrs', '5-6 Yrs', '7-8 Yrs', '9-10 Yrs', '11-12 Yrs'];
  }
  if (/\b(?:two-piece|2-piece|t-shirt\s*&\s*(?:shorts|pant|trouser)|flutter\s*sleeve)\b/i.test(title)) {
    return ['2-3 Yrs', '4-5 Yrs', '6-7 Yrs', '8-9 Yrs', '10-12 Yrs'];
  }

  return found;
}

function extractGadgetColors(title: string, desc: string, existingColor?: string): string[] {
  if (existingColor && existingColor.trim()) {
    return existingColor.split(/[,;|]+/).map(s => s.trim()).filter(Boolean);
  }

  // Exclude random / multicolor / assorted items
  if (/\b(?:random\s*colou?r|colou?r\s*[:=-]?\s*random|assorted|multi[\s-]*colou?r)\b|র‍্যান্ডম|মাল্টি[\s-]*কালার|মাল্টিকলর/i.test(`${title} ${desc}`)) {
    return [];
  }

  // 1. Check Title parentheses e.g. "(Black)", "(White)", "(blue)", "(pink)", "(Yellow)"
  const parenMatches = [...title.matchAll(/\(([^)]+)\)/g)];
  for (const pm of parenMatches) {
    const inside = pm[1].trim();
    if (/new|pack|pcs|set|mah|watt|inch|meter|warranty|original|combo|rgb|led|version|edition/i.test(inside)) continue;
    const cols = matchColorsOrdered(inside);
    if (cols.length === 1) return cols;
    if (cols.length === 2) return [`${cols[0]} & ${cols[1]}`];
  }

  // 2. Check explicit product body Color / কালার / রঙ / রং line in description (strictly skipping lighting/temperature/screen lines!)
  const lines = desc.split('\n').map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    if (
      /টেম্পারেচার|temperature|6400k|3000k|rgb|লাইটিং|lighting|আলোর\s*রঙ|শেড\s*রঙ|display|ডিসপ্লে|screen|স্ক্রিন|গ্যারান্টি|guarantee|ক্যাবল\s*ব্যাকগ্রাউন্ড|ব্যাকগ্রাউন্ড|স্পিকার\s*মেশ/i.test(
        line
      )
    ) {
      continue;
    }

    const m = line.match(
      /^(?:[^\w\u0980-\u09FF]*)(?:(?:স্তর\s*ও\s*|ডিজাইন\s*ও\s*)?(?:available\s+colou?rs?|কালার\s*অপশন|colou?rs?|কালার|রঙ|রং))\s*[:ঃ=–—-]+\s*([^\n]+)/i
    );
    if (m) {
      const rhs = m[1].trim();
      if (/random|র‍্যান্ডম|assorted|multi|মাল্টি|পরিবর্তন\s*করা\s*যায়/i.test(rhs)) continue;

      // Special case: "black, red, black and red"
      if (/black,\s*red,\s*black\s*and\s*red/i.test(rhs)) {
        return ['Black', 'Red', 'Black & Red'];
      }

      // Split on commas / slashes / ও / or if multiple selectable options
      if (/[,/|]|অথবা|\bor\b|\bও\b/i.test(rhs)) {
        const cols = matchColorsOrdered(rhs);
        if (cols.length >= 1) return cols;
      } else {
        const cols = matchColorsOrdered(rhs);
        if (cols.length === 1) return cols;
        if (cols.length === 2 && /&|and|উইথ|with/i.test(rhs)) return [`${cols[0]} & ${cols[1]}`];
      }
    }
  }

  // 3. Check explicit color phrase in gadget title (e.g. "Yellow-Blue Mechanical Gaming Keyboard", "Matte Brown Portable Travel Case", "Black Aluminium Metal")
  if (/\byellow[\s-]*blue\b/i.test(title)) return ['Yellow & Blue'];
  const dashSplit = title.split(/\s+[–—-]\s+/);
  for (const part of dashSplit) {
    if (/\b(?:matte\s*brown|black\s*aluminium|all[\s-]*black|pure\s*white|space\s*gr[ae]y)\b/i.test(part)) {
      const cols = matchColorsOrdered(part);
      if (cols.length === 1) return cols;
    }
  }

  // Check slug suffix if vendor named the SKU with explicit "-black-9429" / "-white-..." and black/white is confirmed in text
  return [];
}

function extractKidsColors(title: string, desc: string, existingColor?: string): string[] {
  if (existingColor && existingColor.trim()) {
    return existingColor.split(/[,;|]+/).map(s => s.trim()).filter(Boolean);
  }

  // Exclude art supplies, oil pastels, color chess/board games, color display cameras, random/multicolor items
  if (
    /\b(?:oil\s*pastel|art\s*set|painting|drawing|memory\s*chess|logarithmic\s*board|colou?r\s*display|colou?r\s*may\s*vary|multicolou?r|multi[\s-]*colou?r|random\s*colou?r)\b|মাল্টিকালার|র‍্যান্ডম/i.test(
      `${title} ${desc.slice(0, 200)}`
    )
  ) {
    return [];
  }

  // National team jersey sets
  if (/\bjersey\s*set\s*\(argentina\)/i.test(title)) return ['Sky Blue & White'];
  if (/\bjersey\s*set\s*\(brazil\)/i.test(title)) return ['Yellow & Blue'];

  // 1. Trailing "- Color" on Title (e.g. "- Pink", "- Hot Pink", "- Bright Yellow", "- Chartreuse Green", "- Lavender", "- Classic Black", "- Lime Green")
  const trailingDash = title.match(/[-–—]\s*([A-Za-z\s&/]{3,26})$/);
  if (trailingDash && !/\b(?:set|pcs|pack|kids|boys|girls|toy|edition)\b/i.test(trailingDash[1])) {
    const tCols = matchColorsOrdered(trailingDash[1]);
    if (tCols.length === 1) return tCols;
    if (tCols.length === 2) return [`${tCols[0]} & ${tCols[1]}`];
  }

  // 2. Parenthesized two-tone or single-tone outfit description in Title (e.g. "(Black & Red T-Shirt with Shorts Set)", "(Yellow Flutter Sleeve Top & Black Bell-Bottom Pants Set)")
  const parenMatches = [...title.matchAll(/\(([^)]+)\)/g)];
  for (const pm of parenMatches) {
    const inside = pm[1].trim();
    if (/boys\s*&\s*girls|months?|years?|pcs|pack/i.test(inside)) continue;
    const pCols = matchColorsOrdered(inside);
    if (pCols.length === 1) return pCols;
    if (pCols.length >= 2) return [`${pCols[0]} & ${pCols[1]}`];
  }

  // 3. Explicit কালার: / Color: line in description
  const lines = desc.split('\n').map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    if (/গ্যারান্টি|guarantee|নষ্ট\s*হবে\s*না|প্রিন্ট\s*কোয়ালিটি/i.test(line)) continue;
    const m = line.match(/^(?:[^\w\u0980-\u09FF]*)(?:available\s+colou?rs?|কালার\s*অপশন|colou?rs?|কালার|রঙ|রং)\s*[:ঃ=–—-]+\s*([^\n]+)/i);
    if (m) {
      const rhs = m[1]
        .replace(/যার\s*ওপর[^\n]*/i, '')
        .replace(/এবং\s*লাল-সাদা\s*প্রিন্ট/i, '')
        .trim();
      const cList = matchColorsOrdered(rhs);
      if (cList.length === 1) return cList;
      if (cList.length >= 2) {
        if (/[,/|]|অথবা|\bor\b/i.test(rhs) && !/\((?:White|Black)\s*&\s*[A-Za-z]+\)/i.test(rhs)) {
          return cList;
        }
        return [`${cList[0]} & ${cList[1]}`];
      }
    }
  }

  // 4. First line Bangla header "- পিঙ্ক অ্যান্ড হোয়াইট" or Title color words on Kids Wearables / Sunglasses
  const firstDescLine = lines[0] || '';
  const banglaDash = firstDescLine.match(/[-–—]\s*([^\n(]{3,35})/);
  if (banglaDash) {
    const bCols = matchColorsOrdered(banglaDash[1]);
    if (bCols.length === 1) return bCols;
    if (bCols.length >= 2) return [`${bCols[0]} & ${bCols[1]}`];
  }

  if (isKidsWearable(title, desc) || /\bsunglass/i.test(title)) {
    const tCols = matchColorsOrdered(title);
    if (tCols.length === 1) return tCols;
    if (tCols.length >= 2) return [`${tCols[0]} & ${tCols[1]}`];
  }

  // Sibling white cotton Koshai / Eid baby t-shirts (8023..8843 — all white cotton printed baby tees per sibling 8843)
  if (/\b(?:koshai|goru\s*kinte|khali\s*dhormu|kurbani\s*hok)\b/i.test(title)) {
    return ['White'];
  }

  return [];
}

function extractOthersSizesAndColors(p: Product, title: string, desc: string): { sizes: string[]; colors: string[] } {
  let sizes = p.size ? p.size.split(/[,;|]+/).map(s => s.trim()).filter(Boolean) : [];
  let colors = p.color ? p.color.split(/[,;|]+/).map(s => s.trim()).filter(Boolean) : [];

  // Saree combos (without Panjabi), pens, showpieces, bulbs, ring light -> never garment sizes
  if (/\b(?:saree|pen|globe|eiffel|bulb|ring\s*light|tripod|frother|mug|keychain|key\s*ring|id\s*card|mystery\s*box|magic\s*box|piggy\s*bank|rose\s*flower)\b/i.test(title)) {
    sizes = [];
  } else if (sizes.length === 0) {
    const asciiDesc = toAsciiDigits(desc);
    const alphaMatch = asciiDesc.match(/(?:size|সাইজ)[^\n]{0,20}[:ঃ=-]+\s*((?:(?:XS|S|M|L|XL|XXL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL))/i);
    if (alphaMatch) {
      sizes = alphaMatch[1].split(/[,/|&\s]+/).filter(Boolean).map(normalizeAlphaToken);
    } else if (/Available\s+Shirt\s+Sizes/i.test(asciiDesc)) {
      const shirtRows = [...asciiDesc.matchAll(/^(XS|S|M|L|XL|XXL)\s*[—–-]/gm)].map(m => normalizeAlphaToken(m[1]));
      if (shirtRows.length >= 2) sizes = Array.from(new Set(shirtRows));
    } else if (/Couple\s+Set/i.test(title) && /পাঞ্জাবি|Panjabi/i.test(desc)) {
      sizes = ['40', '42', '44'];
    } else if (/Election\s+Campaign\s+Customized\s+Punjabi/i.test(title)) {
      sizes = ['40', '42', '44'];
    } else if (/Election\s+Campaign\s+Customized\s+Polo\s+T-Shirt/i.test(title)) {
      sizes = ['M', 'L', 'XL', 'XXL'];
    }
  }

  // Specific refined color labels in /others
  if (/[-–—]\s*Light\s*Pink$/i.test(title)) colors = ['Light Pink'];
  else if (/[-–—]\s*Ocean\s*Green$/i.test(title)) colors = ['Ocean Green'];
  else if (/[-–—]\s*Onion$/i.test(title)) colors = ['Onion'];
  else if (/Couple\s+Set/i.test(title) && /লাল-সাদা/i.test(desc)) colors = ['Red & White'];
  else if (/Election\s+Campaign\s+Customized\s+Punjabi/i.test(title) && /কালো\s*এবং\s*সাদা/i.test(desc)) colors = ['Black', 'White'];
  else if (colors.length === 0) {
    // Check parenthesized combo colors like "(White & Black)", "(Ash & Black)"
    const parenMatches = [...title.matchAll(/\(([^)]+)\)/g)];
    for (const pm of parenMatches) {
      const inside = pm[1].trim();
      if (/formal|casual|assorted|customize|xl|pcs|pack/i.test(inside)) continue;
      const pCols = matchColorsOrdered(inside);
      if (pCols.length === 1) {
        colors = pCols;
        break;
      }
      if (pCols.length === 2) {
        colors = [`${pCols[0]} & ${pCols[1]}`];
        break;
      }
    }
  }

  return { sizes, colors };
}

function extractWatchesMissingColors(title: string, desc: string, existingColor?: string): string[] {
  if (existingColor && existingColor.trim()) {
    return existingColor.split(/[,;|]+/).map(s => s.trim()).filter(Boolean);
  }
  if (/multi[\s‐-]*colou?r/i.test(`${title} ${desc.slice(0, 120)}`)) return [];

  // e.g. "Available in delightful shades including pink, blue, and orange"
  const shadesMatch = desc.match(/available\s+in\s+(?:delightful\s+|multiple\s+)?(?:shades|colou?rs?)\s+(?:including|like|:)\s*([^\n.]+)/i);
  if (shadesMatch) {
    const cols = matchColorsOrdered(shadesMatch[1]);
    if (cols.length >= 2) return cols;
  }

  // First line of description e.g. "POEDAGAR 2937 Luxury Man Wrist watch (Silver Chain & Black Dial)"
  const firstLine = desc.split('\n')[0] || '';
  const flParen = firstLine.match(/\(([^)]+)\)/);
  if (flParen && /dial|chain|strap|black|silver|gold|blue|green|white|brown|rose/i.test(flParen[1]) && !/lock|water|auto/i.test(flParen[1])) {
    const cols = matchColorsOrdered(flParen[1]);
    if (cols.length === 1) return cols;
    if (cols.length >= 2) return [`${cols[0]} & ${cols[1]}`];
  }

  // Case Color / Band Color lines
  const caseBand = desc.match(/(?:case|band|strap|dial)\s*colou?r\s*[:=-]\s*([^\n]+)/i);
  if (caseBand) {
    const cols = matchColorsOrdered(caseBand[1]);
    if (cols.length === 1) return cols;
  }

  // Title color check (e.g. IPG Colour -> Golden)
  const tCols = matchColorsOrdered(title);
  if (tCols.length === 1) return tCols;
  if (tCols.length >= 2) return [`${tCols[0]} & ${tCols[1]}`];

  return [];
}

function extractJewelryMissingColors(title: string, desc: string, existingColor?: string): string[] {
  if (existingColor && existingColor.trim()) {
    return existingColor.split(/[,;|]+/).map(s => s.trim()).filter(Boolean);
  }
  if (/multicolou?r|multi[\s-]*colou?r|মাল্টিকালার|মাল্টিকলার|নবরত্ন/i.test(`${title} ${desc.slice(0, 160)}`)) {
    return [];
  }

  // Explicit single stone/theme color in Jewelry title (e.g. "Sky Blue Cat-Eye", "Mint Green & Pearl", "Traditional Black & Pearl", "Pastel Pink/Peach", "Amber Yellow", "Glamorous Silver Plated Crystal")
  if (/\bsilver\s*plated\s*crystal\b/i.test(title)) return ['Silver'];
  const cleanedJTitle = title
    .replace(/\b(?:gold[\s-]*plated|18k|22k|24k|pearl|kundan|antique|golden|minakari|meenakari|ruby[\s-]*emerald)\b/gi, ' ');
  const tCols = matchColorsOrdered(cleanedJTitle);
  if (tCols.length === 1) return tCols;
  if (tCols.length === 2 && /pink.*peach/i.test(cleanedJTitle)) return ['Light Pink & Peach'];

  return [];
}

function extractFoodWeight(title: string): string | undefined {
  const m = title.match(/\b(\d+(?:\.\d+)?)\s*(kg|gm|g|ml|ltr|l)\b/i);
  if (!m) return undefined;
  const num = m[1];
  const unitRaw = m[2].toLowerCase();
  const unit = unitRaw === 'gm' ? 'g' : unitRaw;
  return `${num}${unit}`;
}

function buildVariants(sizes: string[], colors: string[], price: number): ProductVariant[] | undefined {
  const variants: ProductVariant[] = [];
  if (sizes.length > 0 && colors.length > 0) {
    for (const sz of sizes) {
      for (const cl of colors) {
        variants.push({ size: sz, color: cl, price, stock: 50 });
      }
    }
  } else if (sizes.length > 0) {
    for (const sz of sizes) {
      variants.push({ size: sz, price, stock: 50 });
    }
  } else if (colors.length > 0) {
    for (const cl of colors) {
      variants.push({ color: cl, price, stock: 50 });
    }
  }
  return variants.length > 0 ? variants : undefined;
}

function compactProductsForDisk(products: Product[]): any[] {
  return products.map(p => {
    const out: Record<string, any> = { ...p };
    if (out.descriptionEn && out.descriptionBn && out.descriptionEn === out.descriptionBn) {
      delete out.descriptionEn;
    }
    if (
      out.specificationsEn &&
      out.specificationsBn &&
      JSON.stringify(out.specificationsEn) === JSON.stringify(out.specificationsBn)
    ) {
      delete out.specificationsEn;
    }
    if (out.titleEn && out.titleBn && out.titleEn === out.titleBn) {
      delete out.titleEn;
    }
    if (out.status === 'active') delete out.status;
    if (out.isFeatured === false) delete out.isFeatured;
    if (out.freeDelivery === false) delete out.freeDelivery;
    if (out.isFlashSale === false) delete out.isFlashSale;
    return out;
  });
}

async function main() {
  const productsPath = path.resolve(process.cwd(), 'src/data/products.json');
  const rawProducts: Product[] = JSON.parse(fs.readFileSync(productsPath, 'utf8'));

  const nowIso = new Date().toISOString();
  const changedProducts: Product[] = [];
  const titleChanges: Array<{ id: string; cat: string; before: string; after: string }> = [];
  const categoryMoves: Array<{ id: string; title: string; from: string; to: string }> = [];

  const finalProducts: Product[] = rawProducts.map(orig => {
    const p: Product = {
      ...orig,
      titleBn: orig.titleBn || orig.titleEn || '',
      titleEn: orig.titleEn || orig.titleBn || '',
      descriptionBn: orig.descriptionBn || orig.descriptionEn || '',
      descriptionEn: orig.descriptionEn || orig.descriptionBn || '',
    };

    // Clean mathematical bold unicode & corrupted snippet in description/specs
    let cleanDesc = normalizeCleanText(p.descriptionBn).replace(/L=L=ue Sound/g, 'L= ২-৩ বছর');
    const cleanSpecs = Array.isArray(p.specificationsBn)
      ? p.specificationsBn.map(s => normalizeCleanText(s).replace(/L=L=ue Sound/g, 'L= ২-৩ বছর')).filter(Boolean)
      : undefined;

    const exactTitle = fixExactTitle(p, cleanDesc);
    if (exactTitle !== (orig.titleBn || orig.titleEn || '')) {
      titleChanges.push({
        id: p.id,
        cat: String(p.category),
        before: orig.titleBn || orig.titleEn || '',
        after: exactTitle,
      });
    }

    let targetCategory = p.category;
    let targetSubcategory = p.subcategory;

    // Fix obvious misplaced items spotted during audit
    if (p.id === 'dsp-combo-cotton-exclusive-formal-shirt-5072' && /Milk Frother/i.test(exactTitle)) {
      categoryMoves.push({ id: p.id, title: exactTitle, from: String(p.category), to: 'home-lifestyle' });
      targetCategory = 'home-lifestyle';
      targetSubcategory = 'কিচেন ও ডাইনিং (Kitchen & Dining)';
    } else if (
      (p.id === 'dsp-stylish-premium-kids-hoodie-12089' || p.id === 'dsp-long-khimar-floor-touch-jilbab-12092') &&
      p.category === 'womens-fashion'
    ) {
      categoryMoves.push({ id: p.id, title: exactTitle, from: 'womens-fashion', to: 'jewelry' });
      targetCategory = 'jewelry';
      targetSubcategory = 'ব্রেসলেট ও হাতফুল (Bracelets & Hathphool)';
    } else if (p.id.endsWith('-4024') && /Tortoise Pattern Sunglasses/i.test(exactTitle) && p.category === 'kids-zone') {
      categoryMoves.push({ id: p.id, title: exactTitle, from: 'kids-zone', to: 'home-lifestyle' });
      targetCategory = 'home-lifestyle';
      targetSubcategory = 'সানগ্লাস ও চশমা (Sunglasses)';
    }

    let sizes: string[] = p.size ? p.size.split(/[,;|]+/).map(s => s.trim()).filter(Boolean) : [];
    let colors: string[] = p.color ? p.color.split(/[,;|]+/).map(s => s.trim()).filter(Boolean) : [];
    let weight: string | undefined = p.weight;

    if (targetCategory === 'kids-zone') {
      sizes = extractKidsSizes(exactTitle, cleanDesc, p.size);
      colors = extractKidsColors(exactTitle, cleanDesc, p.color);
      // Update Panda Baby Winter Suit sizes cleanly if S, M, L
      if (p.id.endsWith('-12674')) {
        sizes = ['S (0-1 Yr)', 'M (1-2 Yrs)', 'L (2-3 Yrs)'];
      }
    } else if (targetCategory === 'gadgets-electronics') {
      sizes = [];
      colors = extractGadgetColors(exactTitle, cleanDesc, p.color);
    } else if (targetCategory === 'foods') {
      sizes = [];
      colors = [];
      weight = extractFoodWeight(exactTitle) || p.weight;
    } else if (targetCategory === 'others') {
      const res = extractOthersSizesAndColors(p, exactTitle, cleanDesc);
      sizes = res.sizes;
      colors = res.colors;
    } else if (targetCategory === 'watches') {
      sizes = [];
      colors = extractWatchesMissingColors(exactTitle, cleanDesc, p.color);
    } else if (targetCategory === 'jewelry') {
      colors = extractJewelryMissingColors(exactTitle, cleanDesc, p.color);
    } else if (targetCategory === 'womens-fashion') {
      // Fix Puja Couple Sets that include a Panjabi + 12-haat Saree so buyer can select Panjabi size!
      if (/Couple Sets?/i.test(exactTitle) && /পাঞ্জাবি|Panjabi/i.test(cleanDesc) && sizes.length === 0) {
        const ascii = toAsciiDigits(cleanDesc);
        const panjabiSizes = [...ascii.matchAll(/\b(38|40|42|44|46)\b/g)].map(m => m[1]);
        const uniq = Array.from(new Set(panjabiSizes));
        sizes = uniq.length >= 2 ? uniq : ['40', '42', '44'];
      }
      if (colors.length === 0) {
        if (/\(Chili Red\)/i.test(exactTitle)) colors = ['Chili Red'];
        else if (/\(Cream\)/i.test(exactTitle)) colors = ['Cream'];
        else if (/Mustard Yellow\s*&\s*Slate Blue/i.test(exactTitle)) colors = ['Mustard & Slate Blue'];
        else if (/-\s*Teal Blue\s*&\s*Multicolor/i.test(exactTitle)) colors = ['Teal'];
        else if (/-\s*Off-White\/Cream/i.test(exactTitle)) colors = ['Off-White & Cream'];
      }
    } else if (targetCategory === 'mens-fashion') {
      if (colors.length === 0) {
        if (/\(Coffee\)/i.test(exactTitle)) colors = ['Coffee'];
        else if (/\(Biscuit\)/i.test(exactTitle)) colors = ['Biscuit'];
        else if (/\(Paste\)/i.test(exactTitle)) colors = ['Paste'];
        else if (/Premium White (?:Argentina|Brazil)/i.test(exactTitle)) colors = ['White'];
        else if (/Premium Dark Coffee (?:Argentina|Brazil)/i.test(exactTitle)) colors = ['Coffee'];
        else if (/Men's Blue Leather Belt Pouch/i.test(exactTitle)) colors = ['Blue'];
        else if (/Men's Coffee\/Brown Leather Belt Pouch/i.test(exactTitle)) colors = ['Coffee & Brown'];
      }
    } else if (targetCategory === 'winter') {
      if (colors.length === 0 && /\(Lite Magenta\)/i.test(exactTitle)) {
        colors = ['Magenta'];
      }
    } else if (targetCategory === 'home-lifestyle') {
      if (colors.length === 0) {
        if (/Tortoise Pattern Sunglasses/i.test(exactTitle)) colors = ['Brown & Black'];
        else if (/Black Fascial Gun/i.test(exactTitle)) colors = ['Black'];
        else if (/9 Inch,\s*Royal Blue/i.test(exactTitle)) colors = ['Royal Blue'];
        else if (/Heart Shape Red Love Pillow/i.test(exactTitle)) colors = ['Red'];
        else if (/Customizable 500ml White Aluminum Water Bottle/i.test(exactTitle)) colors = ['White'];
        else if (/Small Yellow Duck Mini Non-Stick Electric Cooking Pot/i.test(exactTitle)) colors = ['Yellow'];
        else if (/Premium Black Hammered Finish Kitchen Cleaver/i.test(exactTitle)) colors = ['Black'];
      }
    }

    const newSizeStr = sizes.length > 0 ? sizes.join(', ') : undefined;
    const newColorStr = colors.length > 0 ? colors.join(', ') : undefined;
    const newVariants = buildVariants(sizes, colors, p.price);

    const specsChanged = JSON.stringify(cleanSpecs || []) !== JSON.stringify(orig.specificationsBn || []);
    const didChange =
      exactTitle !== (orig.titleBn || '') ||
      cleanDesc !== (orig.descriptionBn || '') ||
      specsChanged ||
      targetCategory !== orig.category ||
      targetSubcategory !== orig.subcategory ||
      (newSizeStr || '') !== (orig.size || '') ||
      (newColorStr || '') !== (orig.color || '') ||
      (weight || '') !== (orig.weight || '') ||
      Boolean(newVariants?.length) !== Boolean(orig.variants?.length);

    const updated: Product = {
      ...p,
      titleBn: exactTitle,
      titleEn: exactTitle,
      category: targetCategory,
      ...(targetSubcategory ? { subcategory: targetSubcategory } : {}),
      descriptionBn: cleanDesc,
      descriptionEn: cleanDesc,
      ...(cleanSpecs && cleanSpecs.length > 0 ? { specificationsBn: cleanSpecs, specificationsEn: cleanSpecs } : {}),
      size: newSizeStr,
      color: newColorStr,
      weight,
      variants: newVariants,
      updatedAt: didChange ? nowIso : p.updatedAt,
    };

    if (!updated.subcategory) delete updated.subcategory;
    if (!updated.size) delete updated.size;
    if (!updated.color) delete updated.color;
    if (!updated.weight) delete updated.weight;
    if (!updated.variants) delete updated.variants;

    if (didChange) {
      changedProducts.push(updated);
    }

    return updated;
  });

  // Summary table by category
  const summary: Record<string, any> = {};
  for (const cat of [
    'winter',
    'mens-fashion',
    'watches',
    'womens-fashion',
    'jewelry',
    'home-lifestyle',
    'gadgets-electronics',
    'kids-zone',
    'foods',
    'others',
  ]) {
    const list = finalProducts.filter(p => p.category === cat);
    summary[cat] = {
      total: list.length,
      withSize: list.filter(p => p.size).length,
      withColor: list.filter(p => p.color).length,
      withWeight: list.filter(p => p.weight).length,
      withVariants: list.filter(p => p.variants && p.variants.length > 0).length,
    };
  }

  console.log('\n=== CATALOG EXACT NAME / SIZE / COLOR SUMMARY ===');
  console.table(summary);
  console.log('Total products:', finalProducts.length, '| Modified products:', changedProducts.length);
  console.log('Title fixes count:', titleChanges.length);
  titleChanges.forEach(tc => console.log(`  [${tc.cat}] ${tc.id}:\n    - "${tc.before}"\n    + "${tc.after}"`));
  console.log('Category moves count:', categoryMoves.length, categoryMoves);

  // Write audit sample for verification
  fs.writeFileSync(
    '/tmp/curate_audit_samples.json',
    JSON.stringify(
      {
        gadgetsWithColor: finalProducts
          .filter(p => p.category === 'gadgets-electronics' && p.color)
          .map(p => ({ id: p.id, title: p.titleBn, color: p.color })),
        kidsWithSizeOrColor: finalProducts
          .filter(p => p.category === 'kids-zone' && (p.size || p.color))
          .map(p => ({ id: p.id, title: p.titleBn, size: p.size, color: p.color })),
        kidsWithoutSize: finalProducts
          .filter(p => p.category === 'kids-zone' && !p.size)
          .map(p => ({ id: p.id, title: p.titleBn, color: p.color })),
        foodsAll: finalProducts
          .filter(p => p.category === 'foods')
          .map(p => ({ id: p.id, title: p.titleBn, weight: p.weight })),
        othersAll: finalProducts
          .filter(p => p.category === 'others')
          .map(p => ({ id: p.id, title: p.titleBn, size: p.size, color: p.color })),
      },
      null,
      2
    ),
    'utf8'
  );

  if (DRY_RUN) {
    console.log('\n[DRY RUN] Wrote /tmp/curate_audit_samples.json. No files or Firestore modified yet.');
    process.exit(0);
  }

  // Save compact products.json
  const compacted = compactProductsForDisk(finalProducts);
  fs.writeFileSync(productsPath, JSON.stringify(compacted), 'utf8');
  const mb = (Buffer.byteLength(JSON.stringify(compacted)) / (1024 * 1024)).toFixed(2);
  console.log(`\n1. Saved compact src/data/products.json (${finalProducts.length} products, ${mb} MB).`);

  // Sync modified products to Firebase Firestore
  console.log(`2. Syncing ${changedProducts.length} updated products to Firebase Firestore...`);
  await bulkSyncProductsToFirestore(changedProducts);

  // Sync updated category counts to Firebase Firestore
  const counts: Record<string, number> = {};
  for (const p of finalProducts) {
    const c = String(p.category || 'others');
    counts[c] = (counts[c] || 0) + 1;
  }
  for (const cat of initialCategories) {
    const newCount = cat.id === 'all' ? finalProducts.length : counts[cat.id] || 0;
    await saveCategoryToFirestore({
      ...cat,
      itemCount: newCount,
    });
  }
  console.log('3. Synced category counts to Firestore:', counts);
  process.exit(0);
}

main().catch(err => {
  console.error('Fatal error in curate_exact_catalog:', err);
  process.exit(1);
});
