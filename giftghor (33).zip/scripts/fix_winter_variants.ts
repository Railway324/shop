import fs from 'fs';
import path from 'path';
import { isWatchProductTitle } from '../src/utils/categoryUtils';
import {
  bulkSyncProductsToFirestore,
  saveCategoryToFirestore,
  deleteProductFromFirestore,
} from '../src/lib/firebase';
import { initialCategories } from '../src/data/initialData';
import { Product, ProductVariant } from '../src/types';

const DRY_RUN = process.argv.includes('--dry-run');

function decodeEntities(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFKD')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#038;/g, '&')
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&#8217;/g, "'")
    .replace(/&#8216;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#2547;/g, '৳')
    .replace(/&nbsp;/g, ' ');
}

function cleanSingleLine(html: string): string {
  return decodeEntities(html)
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function htmlToFormattedText(html: string): { fullText: string; bulletSpecs: string[] } {
  if (!html) return { fullText: '', bulletSpecs: [] };

  const bulletSpecs: string[] = [];
  const liRegex = /<li[^>]*>([\s\S]*?)<\/li>/gi;
  let m: RegExpExecArray | null;
  while ((m = liRegex.exec(html)) !== null) {
    const item = cleanSingleLine(m[1]);
    if (item && item.length > 2 && item.length <= 180) {
      bulletSpecs.push(item);
    }
  }

  // Also capture table rows as structured lines
  const trRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  while ((m = trRegex.exec(html)) !== null) {
    const cells = [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)]
      .map(c => cleanSingleLine(c[1]))
      .filter(Boolean);
    if (cells.length >= 2) {
      const rowText = cells.join(' | ');
      if (rowText.length <= 180) bulletSpecs.push(rowText);
    }
  }

  const formatted = decodeEntities(
    html
      .replace(/<\/t[dh]>\s*<t[dh][^>]*>/gi, ' | ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<li[^>]*>/gi, '\n• ')
      .replace(/<\/(?:p|div|li|tr|h[1-6]|ul|ol|table)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .split('\n')
    .map(line => line.replace(/[ \t]+/g, ' ').trim())
    .filter(Boolean)
    .join('\n');

  return { fullText: formatted, bulletSpecs: Array.from(new Set(bulletSpecs)).slice(0, 14) };
}

function normalizeImageUrl(url: string): string {
  if (!url) return '';
  return url
    .trim()
    .replace('public//storage/', 'public/storage/')
    .replace(/^http:\/\//i, 'https://');
}

function mapWinterSubcategory(sub: string, subsub: string, title: string): string {
  const s = `${sub} ${subsub}`.toLowerCase();
  const t = title.toLowerCase();

  if (s.includes('jecket') || s.includes('jacket') || t.includes('jacket') || t.includes('shacket') || t.includes('blazer') || t.includes('coat')) {
    return 'জ্যাকেট (Jackets)';
  }
  if (s.includes('sweatshirt') || t.includes('sweatshirt') || t.includes('sweater')) {
    return 'সোয়েটশার্ট (Sweatshirt)';
  }
  if (s.includes('trouser') || t.includes('trouser') || t.includes('sweatpant') || t.includes('jogger')) {
    return 'ট্রাউজার (Trouser)';
  }
  if (s.includes('full-sleeve') || t.includes('full sleeve') || t.includes('full-sleeve')) {
    return 'ফুল স্লিভ টি-শার্ট (Full Sleeve)';
  }
  if (t.includes('mask') || t.includes('balaclava')) {
    return 'উইন্টার মাস্ক (Winter Masks)';
  }
  if (t.includes('heater')) {
    return 'রুম হিটার (Heaters)';
  }
  if (s.includes('winter-combo') || t.includes('winter set') || t.includes('combo') || t.includes('beanie') || t.includes('suit')) {
    return 'উইন্টার স্পেশাল (Winter Special)';
  }
  if (s.includes('hoodie') || t.includes('hoodie')) {
    return 'হুডি (Hoodies)';
  }
  return 'উইন্টার স্পেশাল (Winter Special)';
}

const STANDARD_ALPHA_ORDER = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '2XL', '3XL', 'XXXL'];

/**
 * Extracts ONLY real sizes from DOM attributes & product description/title.
 * Non-sized items (heaters, masks, caps/beanies without size, gadgets, creams) get []!
 */
export function extractRealSizes(
  detailsHtml: string,
  descText: string,
  title: string,
  subcat: string
): string[] {
  const found: string[] = [];
  const addSize = (s: string) => {
    const clean = s
      .trim()
      .replace(/^[-–—:•➤=>\s]+|[-–—:•\s]+$/g, '')
      .trim();
    if (!clean) return;
    const upper = clean.toUpperCase();
    // Normalize 2XL -> XXL if XXL already present or keep standard
    const normalized = upper === '2XL' ? 'XXL' : upper === '3XL' ? '3XL' : STANDARD_ALPHA_ORDER.includes(upper) ? upper : clean;
    if (!found.some(x => x.toLowerCase() === normalized.toLowerCase())) {
      found.push(normalized);
    }
  };

  // 1. Check DOM radio/checkbox size inputs inside single_product_details (if any)
  const domSizeMatches = [
    ...detailsHtml.matchAll(/name=["'](?:product_)?size["'][^>]*value=["']([^"']+)["']/gi),
    ...detailsHtml.matchAll(/class=["'][^"']*size[^"']*["'][^>]*>\s*([A-Za-z0-9-]{1,12})\s*</gi),
  ];
  for (const m of domSizeMatches) {
    if (m[1] && !/chart|guide|select/i.test(m[1])) addSize(m[1]);
  }
  if (found.length > 0) return found;

  const lines = descText.split('\n').map(l => l.trim()).filter(Boolean);

  // 2. Check explicit Size / সাইজ / আকার declaration lines in description
  for (const line of lines) {
    // Skip generic header lines like "Size chart - In Inches" or "সাইজ চার্ট: আপনার সঠিক সাইজটি বেছে নিতে..."
    if (/size\s*chart|সাইজ\s*চার্ট/i.test(line) && !/:\s*(?:XS|S|M|L|XL|XXL|\d)/i.test(line)) {
      continue;
    }

    // Match e.g. "Size: M, L, XL, XXL" or "আকারের বৈচিত্র্য: M, L, XL, XXL (...)" or "বিভিন্ন সাইজে (M, L, XL, XXL)"
    const parenAlpha = line.match(/(?:সাইজে?|size|fit)[^()\n]{0,25}\(\s*((?:(?:XS|S|M|L|XL|XXL|2XL|3XL)\s*[,/|&\s]+)+(?:XS|S|M|L|XL|XXL|2XL|3XL))\s*\)/i);
    if (parenAlpha) {
      parenAlpha[1].split(/[,/|&\s]+/).filter(Boolean).forEach(addSize);
    }

    const explicitSizeLabel = line.match(/(?:^|[•➤❑\-]\s*)(?:available\s+sizes?|sizes?|সাইজ|আকারের\s*বৈচিত্র্য|আকার|বয়স|age\s*size)\s*[:=-]\s*([^\n]+)/i);
    if (explicitSizeLabel) {
      let rhs = explicitSizeLabel[1]
        .replace(/\([^)]*পর্যন্ত[^)]*\)/g, '')
        .replace(/\([^)]*suitable[^)]*\)/gi, '')
        .trim();

      // Skip if rhs is table column headers like "Chest- Length- Sleeve" or "Waist- Length"
      if (/^(?:chest|waist|length|body|bust|shoulder|sleeve)/i.test(rhs)) {
        continue;
      }

      // Extract standard alpha tokens if rhs is a list of alpha sizes
      const alphaTokens = rhs.match(/\b(?:XS|S|M|L|XL|XXL|2XL|3XL|XXXL)\b/gi);
      if (alphaTokens && alphaTokens.length >= 1) {
        alphaTokens.forEach(addSize);
        continue;
      }

      // Free size explicit mention
      if (/\bfree\s*size\b|ফ্রি\s*সাইজ/i.test(rhs)) {
        addSize('Free Size');
        continue;
      }

      // Numeric or age sizes (e.g., "28, 30, 32, 34", "2-3 Years, 4-5 Years", "3-6M, 6-12M", "40, 42, 44")
      const parts = rhs.split(/[,;|/]+/).map(s => s.trim()).filter(Boolean);
      const validParts = parts.filter(p =>
        /^(?:\d{1,2}(?:\s*-\s*\d{1,2})?\s*(?:years?|yrs?|months?|m|y|বছর|মাস)?|\d{2})$/i.test(p)
      );
      if (validParts.length >= 1) {
        validParts.forEach(addSize);
      }
    }
  }

  // 3. Also scan measurement rows in description (e.g. "M- (Length 27", Chest 38")", "M= Chest-38", "➤M 30-32 37", "M | 40 | 28", "M: লম্বা 24", বুক 37"")
  // Because sometimes top says "Size: M, L, XL" while measurement rows have M, L, XL, XXL (or there's ONLY measurement rows!)
  const measurementAlphaSizes: string[] = [];
  for (const line of lines) {
    const mRow = line.match(/^(?:[•➤❑\-*]\s*)?(XS|S|M|L|XL|XXL|2XL|3XL|XXXL)\b\s*(?:[-:=|(\s]+)\s*(?:length|chest|waist|body|লম্বা|বুক|কোমর|\d{2})/i);
    if (mRow) {
      const tok = mRow[1].toUpperCase() === '2XL' ? 'XXL' : mRow[1].toUpperCase();
      if (!measurementAlphaSizes.includes(tok)) measurementAlphaSizes.push(tok);
    }
  }
  if (measurementAlphaSizes.length >= 2) {
    measurementAlphaSizes.forEach(addSize);
  }

  // Also check inline measurement patterns like "M 40 28 23 L 42 29 23.5 XL 44 30 24 XXL 46 31 24.5"
  const inlineTableMatch = descText.match(/\bM\s+\d{2}(?:\.\d+)?\s+\d{2}(?:\.\d+)?[\s\S]{0,60}\bL\s+\d{2}(?:\.\d+)?\s+\d{2}(?:\.\d+)?[\s\S]{0,60}\bXL\s+\d{2}/i);
  if (inlineTableMatch) {
    const windowStr = descText.slice(Math.max(0, (inlineTableMatch.index || 0) - 30), (inlineTableMatch.index || 0) + 200);
    const rowTokens = [...windowStr.matchAll(/\b(XS|S|M|L|XL|XXL|2XL|3XL)\s+\d{2}/gi)].map(x => x[1].toUpperCase());
    if (rowTokens.length >= 2) rowTokens.forEach(addSize);
  }

  // 4. Check kids age/month measurement rows if kids clothing (both range "2-3 Years" and single age rows "6 yrs- Lenth-17.5"")
  if (found.length === 0) {
    const ageRowMatches = [
      ...descText.matchAll(/(?:^|\n)\s*(?:[•➤❑\-*]\s*)?(\d{1,2}(?:\s*-\s*\d{1,2})?\s*(?:Years?|Yrs?|Months?|বছর|মাস))\s*[-:=|(]/gi),
    ];
    if (ageRowMatches.length >= 2) {
      ageRowMatches.forEach(m => {
        const formatted = m[1]
          .replace(/\s+/g, ' ')
          .replace(/\byrs\b/i, 'Yrs')
          .replace(/\byr\b/i, 'Yr')
          .replace(/\byears\b/i, 'Years')
          .replace(/\bmonths\b/i, 'Months')
          .trim();
        addSize(formatted);
      });
    } else {
      const ageMatches = [...descText.matchAll(/\b(\d{1,2}\s*-\s*\d{1,2}\s*(?:Years?|Yrs?|Months?|বছর|মাস))\b/gi)];
      if (ageMatches.length >= 2) {
        ageMatches.forEach(m => addSize(m[1].replace(/\s+/g, ' ')));
      }
    }
  }

  // 5. Special case on dropshipping.com.bd: Some hoodies/jackets/sweatshirts/trousers/full-sleeve t-shirts
  // literally say "Size chart - In Inches (Expected Deviation < 3%)" where the vendor left the table blank.
  if (found.length === 0 && /size\s*chart\s*-\s*in\s*inches/i.test(descText)) {
    ['M', 'L', 'XL', 'XXL'].forEach(addSize);
  }

  return found;
}

const KNOWN_COLOR_MAP: Array<{ pattern: RegExp; label: string }> = [
  { pattern: /\bblack\s*\+\s*red\b/i, label: 'Black + Red' },
  { pattern: /\bblack\s*\+\s*white\b/i, label: 'Black + White' },
  { pattern: /\bbrown\s*\/\s*khaki\b/i, label: 'Brown/Khaki' },
  { pattern: /\bash\s*\/\s*gr[ae]y\b|অ্যাশ\s*\/\s*গ্রে/i, label: 'Ash/Grey' },
  { pattern: /\bnavy\s*blue\b|নেভি\s*ব্লু/i, label: 'Navy Blue' },
  { pattern: /\bsky\s*blue\b|স্কাই\s*ব্লু|আকাশি/i, label: 'Sky Blue' },
  { pattern: /\broyal\s*blue\b/i, label: 'Royal Blue' },
  { pattern: /\bbottle\s*green\b|বটল\s*গ্রিন/i, label: 'Bottle Green' },
  { pattern: /\bolive\s*green\b|\bolive\b|অলিভ/i, label: 'Olive' },
  { pattern: /\bsage\s*green\b/i, label: 'Sage Green' },
  { pattern: /\boff[\s-]*white\b|অফ\s*হোয়াইট/i, label: 'Off-White' },
  { pattern: /\bcharcoal\b/i, label: 'Charcoal' },
  { pattern: /\bmaroon\b|মেরুন/i, label: 'Maroon' },
  { pattern: /\bcoffee\b|কফি/i, label: 'Coffee' },
  { pattern: /\bchocolate\b|চকলেট/i, label: 'Chocolate' },
  { pattern: /\bmustard\b|মাস্টার্ড/i, label: 'Mustard' },
  { pattern: /\bbeige\b|বেইজ/i, label: 'Beige' },
  { pattern: /\bkhaki\b|খাকি/i, label: 'Khaki' },
  { pattern: /\blavender\b|ল্যাভেন্ডার/i, label: 'Lavender' },
  { pattern: /\bpurple\b|বেগুনি/i, label: 'Purple' },
  { pattern: /\bpink\b|গোলাপি|পিঙ্ক/i, label: 'Pink' },
  { pattern: /\byellow\b|হলুদ/i, label: 'Yellow' },
  { pattern: /\borange\b|কমলা/i, label: 'Orange' },
  { pattern: /\bred\b|লাল/i, label: 'Red' },
  { pattern: /\bgreen\b|সবুজ/i, label: 'Green' },
  { pattern: /\bblue\b|নীল/i, label: 'Blue' },
  { pattern: /\bbrown\b|বাদামী|ব্রাউন/i, label: 'Brown' },
  { pattern: /\bash\b|অ্যাশ/i, label: 'Ash' },
  { pattern: /\bgr[ae]y\b|গ্রে|ধূসর/i, label: 'Grey' },
  { pattern: /\bwhite\b|সাদা|হোয়াইট/i, label: 'White' },
  { pattern: /\bblack\b|কালো|ব্ল্যাক/i, label: 'Black' },
  { pattern: /\bcream\b|ক্রিম/i, label: 'Cream' },
];

export function extractRealColors(detailsHtml: string, descText: string, title: string): string[] {
  const found: string[] = [];
  const addColor = (c: string) => {
    const clean = c.trim();
    if (!clean) return;
    // Avoid adding generic "Black" if "Black + Red" is already added
    if (found.some(existing => existing.toLowerCase() === clean.toLowerCase() || existing.toLowerCase().includes(clean.toLowerCase()))) {
      return;
    }
    found.push(clean);
  };

  // 1. Check explicit Color / কালার / রঙ declaration line in description
  const lines = descText.split('\n').map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    // Ignore "Fabric & Print Color Guarantee" or "100% color longevity" or "দীর্ঘস্থায়ী রঙ" or "বিভিন্ন রং: অনেক রকম রঙে পাওয়া যাচ্ছে"
    if (/guarantee|longevity|fade|দীর্ঘস্থায়ী|পাকা\s*রঙ|রঙ\s*উঠবে\s*না|অনেক\s*রকম\s*রঙে/i.test(line)) {
      continue;
    }

    const explicitColorLine = line.match(/(?:^|[•➤❑\-]\s*)(?:available\s+colou?rs?|colou?rs?|কালার|রঙ|রং)\s*[:=-]\s*([^\n]+)/i);
    if (explicitColorLine) {
      const rhs = explicitColorLine[1].trim();
      if (/as\s+picture|ছবির\s*মত|গ্যারান্টি/i.test(rhs)) continue;
      for (const kc of KNOWN_COLOR_MAP) {
        if (kc.pattern.test(rhs)) addColor(kc.label);
      }
    }
  }
  if (found.length > 0) return found;

  // 2. Check Title for explicit color in parentheses or trailing color name (ignoring Multi-Colour / Random)
  if (!/multi[\s-]*colou?r/i.test(title)) {
    const parenMatches = [...title.matchAll(/\(([^)]+)\)/g)];
    for (const pm of parenMatches) {
      const inside = pm[1].trim();
      for (const kc of KNOWN_COLOR_MAP) {
        if (kc.pattern.test(inside)) addColor(kc.label);
      }
    }
    if (found.length > 0) return found;

    // Trailing or hyphenated color in title, e.g. "Men's Full Sleeve Sweatshirt Black" or "Casual Men's Sweatpant Trouser Black + Red"
    for (const kc of KNOWN_COLOR_MAP) {
      // Check if title ends with or has standalone color word (avoiding brand/noun false positives like "Blackberry" or "RedX" or "Green Tea")
      if (kc.pattern.test(title)) {
        addColor(kc.label);
      }
    }
    if (found.length > 0) return found;
  }

  // 3. Check description phrases like "আধুনিক অ্যাশ/গ্রে রঙের" or "কালো রঙের"
  const bnColorPhrase = descText.match(/([^\s,।()]+(?:\s*\/\s*[^\s,।()]+)?)\s*রঙের/);
  if (bnColorPhrase) {
    for (const kc of KNOWN_COLOR_MAP) {
      if (kc.pattern.test(bnColorPhrase[1])) addColor(kc.label);
    }
  }

  return found;
}

interface DiscoveredCard {
  slug: string;
  sub: string;
  subsub: string;
  cardTitle: string;
  thumbImg: string;
  hoverImg: string;
}

async function discoverLiveWinterProducts(): Promise<Map<string, DiscoveredCard>> {
  console.log('1. Discovering all live /winter products on https://www.dropshipping.com.bd/winter ...');
  const mainRes = await fetch('https://www.dropshipping.com.bd/winter');
  const cookies = mainRes.headers.getSetCookie
    ? mainRes.headers.getSetCookie().map((c: string) => c.split(';')[0]).join('; ')
    : (mainRes.headers.get('set-cookie') || '');
  const mainHtml = await mainRes.text();
  const csrf = (mainHtml.match(/name="csrf-token"\s+content="([^"]+)"/) || [])[1] || '';

  const links = Array.from(
    new Set([
      'https://www.dropshipping.com.bd/winter',
      ...[...mainHtml.matchAll(/href="(https?:\/\/(?:www\.)?dropshipping\.com\.bd\/winter[^"]*)"/g)].map(m => m[1]),
    ])
  );
  console.log(`   Found ${links.length} /winter category & subcategory URLs.`);

  const slugMap = new Map<string, DiscoveredCard>();
  const parseCards = (htmlChunk: string, sub: string, subsub: string) => {
    const cardRegex = /<div class="product_card">([\s\S]*?)<\/div>\s*<\/div>\s*<\/div>/g;
    let match: RegExpExecArray | null;
    while ((match = cardRegex.exec(htmlChunk)) !== null) {
      const block = match[1];
      const slugMatch = block.match(/href="https?:\/\/(?:www\.)?dropshipping\.com\.bd\/product\/([^"]+)"/);
      if (!slugMatch) continue;
      const slug = slugMatch[1].trim();
      const imgs = [...block.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/g)].map(m => normalizeImageUrl(m[1]));
      const nameMatch = block.match(/class="product_name_link"[^>]*>([\s\S]*?)<\/a>/);
      const cardTitle = nameMatch ? cleanSingleLine(nameMatch[1]) : '';
      const existing = slugMap.get(slug);
      if (!existing || (sub && !existing.sub)) {
        slugMap.set(slug, {
          slug,
          sub: sub || existing?.sub || '',
          subsub: subsub || existing?.subsub || '',
          cardTitle: cardTitle || existing?.cardTitle || '',
          thumbImg: imgs[0] || existing?.thumbImg || '',
          hoverImg: imgs[1] || existing?.hoverImg || '',
        });
      }
    }
  };

  for (const url of links) {
    const parts = url.replace(/^https?:\/\/(?:www\.)?dropshipping\.com\.bd\//, '').split('/');
    const cat = parts[0] || 'winter';
    const sub = parts[1] || '';
    const subsub = parts[2] || '';

    try {
      const pr = await fetch(url, { headers: { Cookie: cookies } });
      parseCards(await pr.text(), sub, subsub);
    } catch (_) {}

    for (let page = 1; page <= 40; page++) {
      try {
        const r = await fetch('https://www.dropshipping.com.bd/load-more-data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-CSRF-TOKEN': csrf,
            'X-Requested-With': 'XMLHttpRequest',
            Cookie: cookies,
          },
          body: new URLSearchParams({
            page: String(page),
            limit: '20',
            category_slug: cat,
            subcategory_slug: sub,
            sub_subcategory_slug: subsub,
          }).toString(),
        });
        if (!r.ok) break;
        const j = await r.json();
        if (!j?.data || !j?.product_length) break;
        parseCards(j.data, sub, subsub);
        if (j.product_length < 20) break;
      } catch (_) {
        break;
      }
    }
  }

  console.log(`   Discovered ${slugMap.size} live /winter products.`);
  return slugMap;
}

interface ScrapedWinterInfo {
  slug: string;
  liveTitle: string;
  liveCategorySlug: string;
  wholesalePrice: number;
  sku: string;
  galleryImages: string[];
  descriptionFormatted: string;
  specs: string[];
  sizes: string[];
  colors: string[];
  notFound?: boolean;
}

async function fetchProductPageInfo(slug: string): Promise<ScrapedWinterInfo> {
  const url = `https://www.dropshipping.com.bd/product/${slug}`;
  let html = '';
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      if (res.status === 404) {
        return {
          slug,
          liveTitle: '',
          liveCategorySlug: '',
          wholesalePrice: 0,
          sku: '',
          galleryImages: [],
          descriptionFormatted: '',
          specs: [],
          sizes: [],
          colors: [],
          notFound: true,
        };
      }
      if (res.ok) {
        html = await res.text();
        break;
      }
    } catch (_) {
      await new Promise(r => setTimeout(r, 350 * attempt));
    }
  }

  if (!html) {
    return {
      slug,
      liveTitle: '',
      liveCategorySlug: '',
      wholesalePrice: 0,
      sku: '',
      galleryImages: [],
      descriptionFormatted: '',
      specs: [],
      sizes: [],
      colors: [],
      notFound: true,
    };
  }

  const h2Raw = (html.match(/<div class="single_product_name"[^>]*>[\s\S]*?<h2[^>]*>([\s\S]*?)<\/h2>/i) || [])[1] || '';
  const liveTitle = cleanSingleLine(h2Raw);

  const detailsBlock = (html.match(/<div class="single_product_details">([\s\S]{0,6000})/i) || [])[1] || '';
  const breadcrumbCat = (detailsBlock.match(/href="https?:\/\/(?:www\.)?dropshipping\.com\.bd\/([a-z0-9-]+)"/i) || [])[1] || '';

  const priceMeta = (html.match(/property="product:price:amount"\s+content="([^"]+)"/i) || [])[1] || '0';
  const wholesalePrice = Math.round(parseFloat(priceMeta.replace(/,/g, '')) || 0);

  const codeMatch = detailsBlock.match(/Code\s*:\s*<\/strong>\s*<span>([^<]+)<\/span>/i) || html.match(/Code:\s*(\d+)/i);
  const sku = codeMatch ? `DSP-${codeMatch[1].trim()}` : '';

  // Strictly extract gallery images from .zoom_img_active only (never related products!)
  const zoomBlockMatch = html.match(/<div class="zoom_img_active[^"]*">([\s\S]*?)<\/div>\s*(?:<div class="zoom_thumb|<\/div>\s*<\/div>)/i);
  const zoomHtml = zoomBlockMatch ? zoomBlockMatch[1] : '';
  const galleryImages = Array.from(
    new Set(
      [...zoomHtml.matchAll(/<img[^>]+src="([^"]+)"[^>]*>/gi)]
        .map(m => normalizeImageUrl(m[1]))
        .filter(u => u && u.includes('/storage/images/products/'))
    )
  );

  // Extract #home tab description cleanly before #profile tab
  const homeTabHtml =
    (html.match(/<div class="single_product_tab_content">([\s\S]*?)<div class="tab-pane fade" id="profile"/i) || [])[1] || '';
  const { fullText: descriptionFormatted, bulletSpecs } = htmlToFormattedText(homeTabHtml);

  const sizes = extractRealSizes(detailsBlock, descriptionFormatted, liveTitle, '');
  const colors = extractRealColors(detailsBlock, descriptionFormatted, liveTitle);

  return {
    slug,
    liveTitle,
    liveCategorySlug: breadcrumbCat.toLowerCase(),
    wholesalePrice,
    sku,
    galleryImages,
    descriptionFormatted,
    specs: bulletSpecs,
    sizes,
    colors,
  };
}

async function main() {
  const productsPath = path.resolve(process.cwd(), 'src/data/products.json');
  const allProducts: Product[] = JSON.parse(fs.readFileSync(productsPath, 'utf8'));

  const liveMap = await discoverLiveWinterProducts();

  // Collect all slugs to inspect: union of live /winter slugs and existing JSON winter slugs
  const existingWinter = allProducts.filter(p => p.category === 'winter');
  const slugsToFetch = new Set<string>();
  for (const s of liveMap.keys()) slugsToFetch.add(s);
  for (const p of existingWinter) slugsToFetch.add(p.id.replace(/^dsp-/, ''));

  const slugList = Array.from(slugsToFetch);
  console.log(`2. Scraping ${slugList.length} product detail pages (concurrency=16)...`);

  const scrapedMap = new Map<string, ScrapedWinterInfo>();
  let cursor = 0;
  const concurrency = 16;
  const workers = Array.from({ length: concurrency }, async () => {
    while (cursor < slugList.length) {
      const idx = cursor++;
      const slug = slugList[idx];
      const info = await fetchProductPageInfo(slug);
      scrapedMap.set(slug, info);
      if ((idx + 1) % 80 === 0 || idx + 1 === slugList.length) {
        console.log(`   Scraped ${idx + 1}/${slugList.length}...`);
      }
    }
  });
  await Promise.all(workers);

  // Inspect results!
  let withSizeCount = 0;
  let withoutSizeCount = 0;
  let withColorCount = 0;
  let withoutColorCount = 0;
  let fixedCorruptTitles = 0;
  let reassignedNonWinter: Array<{ id: string; oldTitle: string; liveTitle: string; liveCat: string }> = [];
  const noSizeSamples: Array<{ slug: string; title: string; subcat: string; descSnippet: string }> = [];
  const sizeSamples: Array<{ slug: string; title: string; sizes: string[]; colors: string[] }> = [];

  const byId = new Map<string, Product>();
  for (const p of allProducts) byId.set(p.id, p);

  const updatedProductsToSync: Product[] = [];
  const deletedIdsFromWinter: string[] = [];

  // Process existing winter products + newly discovered live /winter products
  for (const slug of slugList) {
    const id = `dsp-${slug}`;
    const existing = byId.get(id);
    const liveCard = liveMap.get(slug);
    const info = scrapedMap.get(slug);
    if (!info || info.notFound || !info.liveTitle) continue;

    const isJewelryTitle = /\b(?:earrings?|necklace|pendant|bangles?|bracelet|anklet|jewelry|jewellery|finger\s*ring|nose\s*pin)\b|কানের\s*দুল|মালা\s*সেট|নেকলেস|চুড়ি|পায়েল|গহনা/i.test(
      info.liveTitle
    );
    const isOverwrittenNonWinter =
      isJewelryTitle ||
      isWatchProductTitle(info.liveTitle, info.liveTitle) ||
      /\b(?:three[\s-]*piece|saree|summer\s+two[\s-]*piece|steam\s+iron|tide\s+flow\s+car)\b/i.test(info.liveTitle);

    const isCurrentlyOnLiveWinter = liveMap.has(slug);
    const isGenuineWinterItem =
      !isOverwrittenNonWinter &&
      (isCurrentlyOnLiveWinter ||
        info.liveCategorySlug === 'winter' ||
        /hoodie|winter|jacket|shacket|sweater|sweatshirt|heater|balaclava|beanie|blanket|comforter|fleece|মাস্ক|হিটার|শীত/i.test(
          `${info.liveTitle} ${info.descriptionFormatted}`
        ));

    const resolveNonWinterCategory = (): string => {
      if (isWatchProductTitle(info.liveTitle, info.liveTitle)) return 'watches';
      if (isJewelryTitle) return 'jewelry';
      if (['mens-fashion', 'womens-fashion', 'kids-zone', 'gadgets-electronics', 'home-lifestyle', 'foods', 'others'].includes(info.liveCategorySlug)) {
        return info.liveCategorySlug;
      }
      if (/three[\s-]*piece|saree|kameez/i.test(info.liveTitle)) return 'womens-fashion';
      if (/boys|girls|kids|baby/i.test(info.liveTitle)) return 'kids-zone';
      if (/iron|heater|electronic/i.test(info.liveTitle)) return 'gadgets-electronics';
      return 'others';
    };

    if (!isGenuineWinterItem && existing && existing.category === 'winter') {
      const mappedCat = resolveNonWinterCategory();
      reassignedNonWinter.push({
        id,
        oldTitle: existing.titleEn,
        liveTitle: info.liveTitle,
        liveCat: mappedCat,
      });
      existing.category = mappedCat;
    }

    // Determine target category
    const targetCat = isGenuineWinterItem ? 'winter' : resolveNonWinterCategory();

    const retailPrice = info.wholesalePrice > 0 ? info.wholesalePrice + 100 : (existing?.price || 590);
    const titleChanged = existing && existing.titleEn.trim() !== info.liveTitle.trim();
    if (titleChanged) fixedCorruptTitles++;

    const subcat =
      targetCat === 'winter'
        ? mapWinterSubcategory(liveCard?.sub || '', liveCard?.subsub || '', info.liveTitle)
        : existing?.subcategory;

    // If a winter garment (Hoodies, Jackets, Sweatshirts, Full Sleeve T-Shirt, Trouser) had NO size in description at all, check!
    let finalSizes = [...info.sizes];
    const finalColors = [...info.colors];

    if (targetCat === 'winter') {
      if (finalSizes.length > 0) withSizeCount++;
      else {
        withoutSizeCount++;
        noSizeSamples.push({
          slug,
          title: info.liveTitle,
          subcat: subcat || '',
          descSnippet: info.descriptionFormatted.slice(0, 180).replace(/\n/g, ' | '),
        });
      }
      if (finalColors.length > 0) withColorCount++;
      else withoutColorCount++;

      if (sizeSamples.length < 15 && (finalSizes.length > 0 || finalColors.length > 0)) {
        sizeSamples.push({ slug, title: info.liveTitle, sizes: finalSizes, colors: finalColors });
      }
    }

    const variants: ProductVariant[] = [];
    if (finalSizes.length > 0 && finalColors.length > 0) {
      for (const sz of finalSizes) {
        for (const cl of finalColors) {
          variants.push({ size: sz, color: cl, price: retailPrice, stock: 50 });
        }
      }
    } else if (finalSizes.length > 0) {
      for (const sz of finalSizes) {
        variants.push({ size: sz, price: retailPrice, stock: 50 });
      }
    } else if (finalColors.length > 0) {
      for (const cl of finalColors) {
        variants.push({ color: cl, price: retailPrice, stock: 50 });
      }
    }

    const primaryImg =
      info.galleryImages[0] ||
      liveCard?.thumbImg ||
      existing?.image ||
      '';
    const extraImgs = Array.from(
      new Set([
        ...(info.galleryImages.length > 0 ? info.galleryImages : []),
        ...(liveCard?.thumbImg ? [liveCard.thumbImg] : []),
        ...(liveCard?.hoverImg ? [liveCard.hoverImg] : []),
      ])
    ).filter(Boolean);

    const cleanDesc =
      info.descriptionFormatted ||
      existing?.descriptionBn ||
      `${info.liveTitle}`;

    const updatedProduct: Product = {
      ...(existing || {
        id,
        rating: 4.8,
        reviewsCount: 12,
        stock: 50,
        brand: 'DropshippingBD',
        status: 'active',
        isFeatured: false,
        isFlashSale: false,
        createdAt: new Date().toISOString(),
      }),
      id,
      titleBn: info.liveTitle,
      titleEn: info.liveTitle,
      category: targetCat,
      ...(subcat ? { subcategory: subcat } : {}),
      // Keep existing retailPrice unless title was corrupted or brand-new product
      price: (!existing || titleChanged) ? retailPrice : existing.price,
      originalPrice: (!existing || titleChanged) ? Math.round(retailPrice * 1.2) : existing.originalPrice,
      discountPercent: (!existing || titleChanged) ? 17 : existing.discountPercent,
      sku: info.sku || existing?.sku || `DSP-${slug.split('-').pop()}`,
      image: primaryImg,
      additionalImages: extraImgs.length > 0 ? extraImgs : existing?.additionalImages,
      descriptionBn: cleanDesc,
      descriptionEn: cleanDesc,
      specificationsBn: info.specs.length > 0 ? info.specs : existing?.specificationsBn,
      specificationsEn: info.specs.length > 0 ? info.specs : existing?.specificationsEn,
      size: finalSizes.length > 0 ? finalSizes.join(', ') : undefined,
      color: finalColors.length > 0 ? finalColors.join(', ') : undefined,
      variants: variants.length > 0 ? variants : undefined,
      updatedAt: new Date().toISOString(),
    };

    // Clean undefined keys for JSON cleanliness
    if (!updatedProduct.size) delete updatedProduct.size;
    if (!updatedProduct.color) delete updatedProduct.color;
    if (!updatedProduct.variants) delete updatedProduct.variants;

    byId.set(id, updatedProduct);
    updatedProductsToSync.push(updatedProduct);
  }

  console.log('\n=== WINTER VARIANT EXTRACTION SUMMARY ===');
  console.log({
    totalProcessed: updatedProductsToSync.length,
    winterWithSizes: withSizeCount,
    winterWithoutSizes: withoutSizeCount,
    winterWithColors: withColorCount,
    winterWithoutColors: withoutColorCount,
    fixedCorruptTitles,
    reassignedNonWinterCount: reassignedNonWinter.length,
  });
  console.log('\nSample Reassigned Non-Winter Items:', reassignedNonWinter.slice(0, 10));
  console.log('\nSample Extracted Sizes & Colors:', sizeSamples);
  console.log('\nALL Winter Items WITHOUT Size (up to 30):', noSizeSamples.slice(0, 30));

  if (DRY_RUN) {
    console.log('\n[DRY RUN] Skipping file write and Firestore sync.');
    process.exit(0);
  }

  const finalProducts = Array.from(byId.values());
  fs.writeFileSync(productsPath, JSON.stringify(finalProducts, null, 2), 'utf8');
  console.log(`\n3. Saved ${finalProducts.length} products to src/data/products.json.`);

  console.log(`4. Syncing ${updatedProductsToSync.length} updated products to Firebase Firestore...`);
  // Note: for Firestore merge, explicitly pass empty string/array or overwrite full doc so old fields never linger
  await bulkSyncProductsToFirestore(updatedProductsToSync);

  // Update category item counts in Firestore
  const counts: Record<string, number> = {};
  for (const p of finalProducts) {
    const c = String(p.category || 'others');
    counts[c] = (counts[c] || 0) + 1;
  }
  for (const cat of initialCategories) {
    if (cat.id === 'all') continue;
    await saveCategoryToFirestore({
      ...cat,
      itemCount: counts[cat.id] || 0,
    });
  }
  console.log('5. Category counts updated in Firestore:', counts);
  process.exit(0);
}

main().catch(err => {
  console.error('Fatal error in fix_winter_variants:', err);
  process.exit(1);
});
